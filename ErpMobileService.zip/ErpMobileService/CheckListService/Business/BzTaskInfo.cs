﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using CheckListService.DataAccess;
using CheckListService.Entity;

namespace CheckListService.Business
{
    public class BzTaskInfo
    {
        private static readonly DaTaskInfo dal = new DaTaskInfo();

        /// <summary>
        /// 获取任务数据
        /// </summary>
        /// <returns></returns>
        public static List<EnTask> getTaskInfo(string userId, string code)
        {
            List<EnTask> result = new List<EnTask>();
            List<EnTaskInfo> tasks = dal.getTaskInfoList(userId, code);
            List<EnTasksInfo> subTasks = dal.getTasksInfoList(userId, code);
            List<EnRepeatInfo> repeat = dal.getRepeatInfoList(userId, code);

            for (int i = 0, len = tasks.Count; i < len; i++)
            {
                //添加主任务
                EnTask en = new EnTask();
                en.info = tasks[i];
                en.SubList = new List<EnTasksInfo>();
                en.RepeatList = null;

                //添加子任务
                for (int j = 0, len1 = subTasks.Count; j< len1; j++)
                {
                    if (en.info.auto == subTasks[j].lFCode)
                    {
                        en.SubList.Add(subTasks[j]);
                    }
                }

                //添加重复
                for (int k = 0, len2 = repeat.Count; k < len2; k++)
                {
                    if (en.info.auto == repeat[k].lFCode) 
                    {
                        en.RepeatList = repeat[k];
                        en.info.isRepeat = 1;
                        break;
                    }
                }

                result.Add(en);
            }

            return result;
        }


        /// <summary>
        /// 完成任务
        /// </summary>
        /// <param name="userId">用户工号</param>
        /// <param name="lTaskCode">任务号</param>
        /// <param name="isSubTask">是否子任务</param>
        /// <returns></returns>
        public static DateTime? FinishTask(string userId, int? lTaskCode, bool isSubTask = false)
        {
            DateTime finishTime = DateTime.Now;
            if (dal.FinishTask(userId, lTaskCode, finishTime, isSubTask))
                return finishTime;
            return null;
        }
    }
}
