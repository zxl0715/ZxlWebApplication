﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace CheckListService.Entity
{
    /// <summary>
    /// 重复周期表字段
    /// </summary>
    [DataContract]
    public class EnRepeatInfo
    {
        private int m_auto;
        private int m_lFCode;
        private int m_lRepeatMode;
        private string m_sRepeatValue;
        private int m_lRepeatSpace;
        private DateTime? m_dBeginDate;
        private DateTime? m_dEndDate;

        /// <summary>
        /// 自动编号
        /// </summary>
        [DataMember]
        public int auto 
        {
            get { return m_auto; }
            set { m_auto = value; }
        }

        /// <summary>
        /// 主任务编号
        /// </summary>
        [DataMember]
        public int lFCode 
        {
            get { return m_lFCode; }
            set { m_lFCode = value; }
        }

        /// <summary>
        /// 重复模式
        /// </summary>
        [DataMember]
        public int lRepeatMode
        {
            get { return m_lRepeatMode; }
            set { m_lRepeatMode = value; }
        }

        /// <summary>
        /// 重复值
        /// </summary>
        [DataMember]
        public string sRepeatValue
        {
            get { return m_sRepeatValue; }
            set { m_sRepeatValue = value; }
        }

        /// <summary>
        /// 重复间隔
        /// </summary>
        [DataMember]
        public int lRepeatSpace
        {
            get { return m_lRepeatSpace; }
            set { m_lRepeatSpace = value; }
        }

        /// <summary>
        /// 开始时间
        /// </summary>
        [DataMember]
        public DateTime? dBeginDate
        {
            get { return m_dBeginDate; }
            set { m_dBeginDate = value; }
        }

        /// <summary>
        /// 结束时间
        /// </summary>
        [DataMember]
        public DateTime? dEndDate
        {
            get { return m_dEndDate; }
            set { m_dEndDate = value; }
        }
    }
}
