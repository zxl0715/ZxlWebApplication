﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace CheckListService.Entity
{
    /// <summary>
    /// 任务
    /// </summary>
    [DataContract]
    public class EnTask
    {
        /// <summary>
        /// 主任务
        /// </summary>
        [DataMember]
        public EnTaskInfo info { get; set; }

        /// <summary>
        /// 子任务
        /// </summary>
        [DataMember]
        public List<EnTasksInfo> SubList { get; set; }

        /// <summary>
        /// 重复周期
        /// </summary>
        [DataMember]
        public EnRepeatInfo RepeatList { get; set; }
    }
}
