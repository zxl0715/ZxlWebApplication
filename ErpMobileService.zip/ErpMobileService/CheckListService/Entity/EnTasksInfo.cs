﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace CheckListService.Entity
{
    /// <summary>
    /// 子任务表字段
    /// </summary>
    [DataContract]
    public class EnTasksInfo
    {
        private int m_iId;
        private int m_lFCode;
        private string m_sTitle;
        private DateTime? m_dBeginTime;
        private DateTime? m_dEndTime;

        /// <summary>
        /// 自动编号
        /// </summary>
        [DataMember]
        public int auto
        {
            get { return m_iId; }
            set { m_iId = value; }
        }

        /// <summary>
        /// 主任务编号
        /// </summary>
        [DataMember]
        public int lFCode
        {
            get { return m_lFCode; }
            set { m_lFCode = value; }
        }

        /// <summary>
        /// 子任务标题
        /// </summary>
        [DataMember]
        public string sTitle
        {
            get { return m_sTitle; }
            set { m_sTitle = value; }
        }

        /// <summary>
        /// 开始时间
        /// </summary>
        [DataMember]
        public DateTime? dBeginTime
        {
            get { return m_dBeginTime; }
            set { m_dBeginTime = value; }
        }

        /// <summary>
        /// 预计完成时间
        /// </summary>
        [DataMember]
        public DateTime? dEndTime
        {
            get { return m_dEndTime; }
            set { m_dEndTime = value; }
        }

    }
}
