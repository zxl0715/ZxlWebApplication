﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace CheckListService.Entity
{
    /// <summary>
    /// 主任务表字段
    /// </summary>
    [DataContract]
    public class EnTaskInfo
    {
        private int m_iId;
        private string m_sTitle;
        private string m_lWorkerId;
        private string m_lMandatorId;
        private DateTime? m_dBeginTime;
        private DateTime? m_dEndTime;
        private string m_sDuration;
        private string m_sFinishDuration;
        private string m_sPlace;
        private int m_isRemind;
        private int m_isSub;
        private int m_isAllDay;
        private int m_isRepeat;

        /// <summary>
        /// 自动编号
        /// </summary>
        [DataMember]
        public int auto
        {
            get { return m_iId; }
            set { m_iId = value; }
        }

        /// <summary>
        /// 任务名称
        /// </summary>
        [DataMember]
        public string sTitle
        {
            get { return m_sTitle; }
            set { m_sTitle = value; }
        }

        /// <summary>
        /// 执行人工号
        /// </summary>
        [DataMember]
        public string lWorkerId
        {
            get { return m_lWorkerId; }
            set { m_lWorkerId = value; }
        }

        /// <summary>
        /// 管理人工号
        /// </summary>
        [DataMember]
        public string lMandatorId
        {
            get { return m_lMandatorId; }
            set { m_lMandatorId = value; }
        }

        /// <summary>
        /// 开始时间
        /// </summary>
        [DataMember]
        public DateTime? dBeginTime
        {
            get { return m_dBeginTime; }
            set { m_dBeginTime = value; }
        }

        /// <summary>
        /// 实际完成时间
        /// </summary>
        [DataMember]
        public DateTime? dEndTime
        {
            get { return m_dEndTime; }
            set { m_dEndTime = value; }
        }

        /// <summary>
        /// 预计完成时长
        /// </summary>
        [DataMember]
        public string sDuration
        {
            get { return m_sDuration; }
            set { m_sDuration = value; }
        }

        /// <summary>
        /// 实际完成时长
        /// </summary>
        [DataMember]
        public string sFinishDuration
        {
            get { return m_sFinishDuration; }
            set { m_sFinishDuration = value; }
        }

        /// <summary>
        /// 地点
        /// </summary>
        [DataMember]
        public string sPlace
        {
            get { return m_sPlace; }
            set { m_sPlace = value; }
        }

        /// <summary>
        /// 是否提醒
        /// </summary>
        [DataMember]
        public int isRemind
        {
            get { return m_isRemind; }
            set { m_isRemind = value; }
        }

        /// <summary>
        /// 是否有子任务
        /// </summary>
        [DataMember]
        public int isSub
        {
            get { return m_isSub; }
            set { m_isSub = value; }
        }

        /// <summary>
        /// 是否全天
        /// </summary>
        [DataMember]
        public int isAllDay
        {
            get { return m_isAllDay; }
            set { m_isAllDay = value; }
        }

        /// <summary>
        /// 是否重复
        /// </summary>
        [DataMember]
        public int isRepeat
        {
            get { return m_isRepeat; }
            set { m_isRepeat = value; }
        }
    }
}
