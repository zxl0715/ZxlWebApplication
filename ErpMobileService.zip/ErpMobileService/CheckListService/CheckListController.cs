﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Web.Http;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

using CheckListService.Business;
using CheckListService.Entity;

namespace SOPService
{
    
    public class CheckListController : ApiController
    {
        /// <summary>
        /// 获取任务
        /// </summary>
        /// <returns></returns>
        public List<EnTask> getTaskInfo(string userId, string code)
        {
            List<EnTask> result = BzTaskInfo.getTaskInfo(userId,code);
            return result;
        }


        /// <summary>
        /// 完成任务
        /// </summary>
        /// <param name="userId">工号</param>
        /// <param name="lTaskCode">任务编号</param>
        /// <param name="isSubTask">是否是子任务</param>
        /// <returns></returns>
        [HttpGet]
        public string finishTaskTemp(string userId, int lTaskCode,bool isSubTask=false)
        {
            DateTime? finishTime=BzTaskInfo.FinishTask(userId, lTaskCode, isSubTask);
            if(finishTime!=null)
                return ((DateTime)finishTime).ToString("yyyy-MM-dd HH:mm:ss");
            return null;
        }
    }
}
