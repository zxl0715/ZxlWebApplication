﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using CheckListService.Entity;
using System.Data.SqlClient;
using System.Data;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;

namespace CheckListService.DataAccess
{
    class DaTaskInfo
    {
        /// <summary>
        /// 完成任务
        /// </summary>
        /// <param name="userId">用户工号</param>
        /// <param name="lTaskCode">任务号</param>
        /// <param name="finishTime">完成时间,由服务端生成</param>
        /// <param name="isSubTask">是否子任务</param>
        /// <returns></returns>
        public bool FinishTask(string userId, int? lTaskCode, DateTime finishTime, bool isSubTask = false)
        {
            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userId),
                new SqlParameter("@code", lTaskCode),
                new SqlParameter("@finishTime", finishTime),

            };
            string sqlStr = "";
            string lTaskCodeColumnName = isSubTask ? "lSubCode" : "lTaskCode";
            string TaskTableName = isSubTask ? "CL_Tasks" : "CL_Task";
            sqlStr = @"
         IF EXISTS (SELECT * FROM dbo." + TaskTableName + @" WHERE auto=@code)
        BEGIN INSERT INTO dbo.CL_Finish
        (" +lTaskCodeColumnName+@"  ,sUserID ,dDate ,dBeginTime ,dEndTime ,sFinishDuration)
        VALUES  (@code, @userID, @finishTime , @finishTime , @finishTime ,null ) end";
            return SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, arPara)>0;
        }
        /// <summary>
        /// 获取主任务数据
        /// </summary>
        /// <returns></returns>
        public List<EnTaskInfo> getTaskInfoList(string userId, string code)
        {
            List<EnTaskInfo> list = new List<EnTaskInfo>();
            string sqlStr = "";

            if (code == null)
                sqlStr = @"select auto, sTitle, lWorkerId, lMandatorId, dBeginTime, dEndTime, sDuration, sFinishDuration, sPlace, isRemind, isSub, isAllDay, 0 as isRepeat from CL_Task where lWorkerId='" + userId + "' order by auto desc";
            else
                sqlStr = @"select auto, sTitle, lWorkerId, lMandatorId, dBeginTime, dEndTime, sDuration, sFinishDuration, sPlace, isRemind, isSub, isAllDay, 0 as isRepeat from CL_Task where lWorkerId='" + userId + "' and auto > '" + code + "'order by auto desc";

            IDataReader dr = null;
            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userId),
                new SqlParameter("@code", code)
            };

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, arPara);
                list = DynamicBuilder<EnTaskInfo>.ConvertToList(dr).ConvertAll(a => (EnTaskInfo)a);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                    dr.Dispose();
            }

            return list;
        }

        /// <summary>
        /// 获取子任务数据
        /// </summary>
        /// <returns></returns>
        public List<EnTasksInfo> getTasksInfoList(string userId, string code)
        {
            List<EnTasksInfo> list = new List<EnTasksInfo>();
            string sqlStr = "";
            if (code == null)
            {
                sqlStr = @"select auto, lFCode, sTitle, dBeginTime, dEndTime from CL_Tasks order by auto desc";
            }
            else
            {
                sqlStr = @"select auto, lFCode, sTitle, dBeginTime, dEndTime from CL_Tasks where lFCode >'" + code + "'order by auto desc";
            }

            IDataReader dr = null;
            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userId),
                new SqlParameter("@code", code)
            };

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, arPara);
                list = DynamicBuilder<EnTasksInfo>.ConvertToList(dr).ConvertAll(a => (EnTasksInfo)a);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                    dr.Dispose();
            }

            return list;
        }


        public List<EnRepeatInfo> getRepeatInfoList(string userId, string code)
        {
            List<EnRepeatInfo> list = new List<EnRepeatInfo>();
            string sqlStr = "";
            if (code == null)
            {
                sqlStr = @"select auto, lFCode, lRepeatMode, sRepeatValue, lRepeatSpace, dBeginDate, dEndDate from CL_Repeat ";
            }
            else
            {
                sqlStr = @"select auto, lFCode, lRepeatMode, sRepeatValue, lRepeatSpace, dBeginDate, dEndDate from CL_Repeat where lFCode >'" + code + "'order by auto desc";
            }
            IDataReader dr = null;
            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userId),
                new SqlParameter("@code", code)
            };

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, arPara);
                list = DynamicBuilder<EnRepeatInfo>.ConvertToList(dr).ConvertAll(a => (EnRepeatInfo)a);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                    dr.Dispose();
            }
            return list;
        }


    }

}
