/*
DELETE FROM [ServiceLogInfo] WHERE SvrPrgName = 'ErpMobileService'
DELETE FROM [ServiceBusinessArg] WHERE SvrPrgName = 'ErpMobileService'
DELETE FROM [ServiceBusinessArgCls] WHERE SvrPrgName = 'ErpMobileService'
DELETE FROM [ServiceAssemblyArg] WHERE SvrPrgName = 'ErpMobileService'
DELETE FROM [ServiceArgInfo] WHERE SvrPrgName = 'ErpMobileService'
GO

----�����������
INSERT INTO [ServiceArgInfo]([SvrPrgName],[SvrPrgNameCN],[SvrType],[SvrPath],[SvrExeStyle],[ExeCycle],[Interval],[ExeAtTime],[SvrIP],[LoginUID],[LoginPwd],[ImmediatelyExe],[TimeOut],[WriteLog])
VALUES ('ErpMobileService','ERPϵͳ�ֻ��˽������','999','','03','',0,'2009-12-08 17:48','','','' ,0,0,1)
go

*/



IF EXISTS(SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID(N'[M7_ServiceLogInfo]') AND OBJECTPROPERTY(id,N'IsUserTable') = 1)
	DROP TABLE [dbo].[M7_ServiceLogInfo]
GO
  
CREATE TABLE [dbo].[M7_ServiceLogInfo](
	[ID] [int] IDENTITY(1,1) NOT NULL,
	[ServiceCode] [nvarchar](100) NOT NULL,
	[LogTime] [datetime] NOT NULL,
	[LogType] [nchar](2) NOT NULL,
	[LogInfo] [nvarchar](3000) NOT NULL,
	[IsSend91U] [char](1) NULL,
 CONSTRAINT [PK_M7_ServiceLogInfo] PRIMARY KEY CLUSTERED 
(
	[ID] ASC
) ON [PRIMARY]
) ON [PRIMARY]

GO

CREATE INDEX IX_M7_ServiceLogInfo ON [dbo].[M7_ServiceLogInfo]
(
	[ServiceCode] ASC 
)

CREATE INDEX IX_M7_ServiceLogInfo_LogTime ON [dbo].[M7_ServiceLogInfo]
(
	[LogTime] ASC 
)

CREATE INDEX IX_M7_ServiceLogInfo_LogType ON [dbo].[M7_ServiceLogInfo]
(
	[LogType] ASC 
)
GO