﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.Base
{
    public class UserCache
    {
        private static Dictionary<string, UserData> _cache = new Dictionary<string, UserData>();

        public static void Add(UserData info)
        {
            if (!_cache.ContainsKey(info.UserGUID))
            {
                string key = string.Format("{0}_{1}",info.UserID,info.UserGUID);
                _cache.Add(key, info);
            }
        }

        public static bool IsExist(string userID, string userGUID)
        {
            string key = string.Format("{0}_{1}", userID, userGUID);
            return _cache.ContainsKey(key);
        }

        public static bool IsExist(string key)
        {
            return _cache.ContainsKey(key);
        }

        public static void Clear()
        {
            _cache.Clear();
        }

        public static Dictionary<string, UserData> Get()
        {
            return _cache;
        }

        public static UserData Get(string userID, string userGUID)
        {
            string key = string.Format("{0}_{1}", userID, userGUID);
            if (_cache.ContainsKey(key))
            {
                return _cache[key];
            }
            return null;
        }

        public static UserData Get(string key)
        {
            if (_cache.ContainsKey(key))
            {
                return _cache[key];
            }
            return null;
        }

        public static void Remove(string key)
        {
            if (_cache.ContainsKey(key))
            {
                _cache.Remove(key);
            }
        }
    }
}
