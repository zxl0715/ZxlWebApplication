﻿using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;
using System.IO;
using log4net;

namespace Nd.Erp.Mobile.Base
{
    public class SysEventLog<T>
    {
        /// <summary>
        /// 日志
        /// </summary>
        private log4net.ILog _logMgr;

        /// <summary>
        /// 构造函数
        /// </summary>
        public SysEventLog()
        {
            try
            {
                string path = Assembly.GetExecutingAssembly().Location;
                string filePath = path.Substring(0, path.LastIndexOf("\\")) + "\\log4net.config";
                FileInfo file = new FileInfo(filePath);
                if (!file.Exists)
                    throw new ApplicationException("SysEventLog日志配置文件(log4net.config)不存在。");
                log4net.Config.XmlConfigurator.ConfigureAndWatch(file);
            }
            catch (Exception)
            {

            }
           
            _logMgr = LogManager.GetLogger(typeof(T));
        }

        /// <summary>
        /// 写入错误日志
        /// </summary>
        /// <param name="logInfo">日志信息</param>
        public void WriteError(string logInfo)
        {
            _logMgr.Error(logInfo);
        }

        /// <summary>
        /// 写入格式化错误日志
        /// </summary>
        /// <param name="format">格式化日志信息</param>
        /// <param name="args">格式化参数</param>
        public void WriteErrorFormat(string format, params object[] args)
        {
            _logMgr.ErrorFormat(format, args);
        }

        /// <summary>
        /// 写入日志
        /// </summary>
        /// <param name="logInfo">日志信息</param>
        public void WriteInfo(string logInfo)
        {
            _logMgr.Info(logInfo);
        }

        /// <summary>
        /// 写入格式化日志
        /// </summary>
        /// <param name="format">格式化日志信息</param>
        /// <param name="args">格式化参数</param>
        public void WriteInfoFormat(string format, params object[] args)
        {
            _logMgr.InfoFormat(format, args);
        }
    }
}
