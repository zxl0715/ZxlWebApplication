using System;
using System.Collections.Generic;

namespace Nd.Erp.Mobile
{
	/// <summary>
	/// A common interface implementation that is implemeneted by most cache providers
	/// </summary>
    public class CacheManager
	{
	    public static ICacheClient CacheClient = new MemoryCacheClient();
	}
}