﻿using System;
using System.Configuration;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;
using System.Xml;

namespace Nd.Erp.Mobile
{
    public class GZipWebHttpBindingElement
        : StandardBindingElement
    {

        #region Fields
        private ConfigurationPropertyCollection m_properties;
        #endregion

        #region Ctors

        public GZipWebHttpBindingElement(string name)
            : base(name) { }

        public GZipWebHttpBindingElement()
            : this(null) { }

        #endregion

        #region ConfigurationProperties

        [ConfigurationProperty("allowCookies", DefaultValue = false)]
        public bool AllowCookies
        {
            get { return (bool)base["allowCookies"]; }
            set { base["allowCookies"] = value; }
        }

        [LongValidator(MinValue = 0L), ConfigurationProperty("maxBufferPoolSize", DefaultValue = 524288L)]
        public long MaxBufferPoolSize
        {
            get { return (long)base["maxBufferPoolSize"]; }
            set { base["maxBufferPoolSize"] = value; }
        }

        [ConfigurationProperty("maxBufferSize", DefaultValue = 65536), IntegerValidator(MinValue = 1)]
        public int MaxBufferSize
        {
            get { return (int)base["maxBufferSize"]; }
            set { base["maxBufferSize"] = value; }
        }

        [ConfigurationProperty("maxReceivedMessageSize", DefaultValue = 65536L), LongValidator(MinValue = 1L)]
        public long MaxReceivedMessageSize
        {
            get { return (long)base["maxReceivedMessageSize"]; }
            set { base["maxReceivedMessageSize"] = value; }
        }

        [ConfigurationProperty("readerQuotas")]
        public XmlDictionaryReaderQuotasElement ReaderQuotas
        {
            get { return (XmlDictionaryReaderQuotasElement)base["readerQuotas"]; }
        }

        [ConfigurationProperty("transferMode", DefaultValue = TransferMode.Buffered)]
        public TransferMode TransferMode
        {
            get { return (TransferMode)base["transferMode"]; }
            set { base["transferMode"] = value; }
        }

        #endregion

        #region Methods

        protected override Type BindingElementType
        {
            get { return typeof(GZipWebHttpBinding); }
        }

        protected override ConfigurationPropertyCollection Properties
        {
            get
            {
                if (this.m_properties == null)
                {
                    ConfigurationPropertyCollection c = base.Properties;
                    c.Add(new ConfigurationProperty("allowCookies", typeof(bool), false, null, null, ConfigurationPropertyOptions.None));
                    c.Add(new ConfigurationProperty("maxBufferSize", typeof(int), 65536, null, new IntegerValidator(1, 2147483647, false), ConfigurationPropertyOptions.None));
                    c.Add(new ConfigurationProperty("maxBufferPoolSize", typeof(long), 524288L, null, new LongValidator(0L, 9223372036854775807L, false), ConfigurationPropertyOptions.None));
                    c.Add(new ConfigurationProperty("maxReceivedMessageSize", typeof(long), 65536L, null, new LongValidator(1L, 9223372036854775807L, false), ConfigurationPropertyOptions.None));
                    c.Add(new ConfigurationProperty("readerQuotas", typeof(XmlDictionaryReaderQuotasElement), null, null, null, ConfigurationPropertyOptions.None));
                    c.Add(new ConfigurationProperty("transferMode", typeof(TransferMode), TransferMode.Buffered, null, null, ConfigurationPropertyOptions.None));
                    this.m_properties = c;
                }
                return this.m_properties;
            }
        }

        protected override void InitializeFrom(Binding binding)
        {
            base.InitializeFrom(binding);
            GZipWebHttpBinding zBinding = (GZipWebHttpBinding)binding;
            this.MaxBufferSize = zBinding.MaxBufferSize;
            this.MaxBufferPoolSize = zBinding.MaxBufferPoolSize;
            this.MaxReceivedMessageSize = zBinding.MaxReceivedMessageSize;
            this.TransferMode = zBinding.TransferMode;
            this.AllowCookies = zBinding.AllowCookies;
            this.InitializeReaderQuotas(zBinding.ReaderQuotas);
        }

        internal void InitializeReaderQuotas(XmlDictionaryReaderQuotas readerQuotas)
        {
            if (readerQuotas == null)
            {
                throw new ArgumentNullException("readerQuotas");
            }
            this.ReaderQuotas.MaxDepth = readerQuotas.MaxDepth;
            this.ReaderQuotas.MaxStringContentLength = readerQuotas.MaxStringContentLength;
            this.ReaderQuotas.MaxArrayLength = readerQuotas.MaxArrayLength;
            this.ReaderQuotas.MaxBytesPerRead = readerQuotas.MaxBytesPerRead;
            this.ReaderQuotas.MaxNameTableCharCount = readerQuotas.MaxNameTableCharCount;
        }

        protected override void OnApplyConfiguration(Binding binding)
        {
            var zBinding = (GZipWebHttpBinding)binding;
            zBinding.MaxBufferPoolSize = this.MaxBufferPoolSize;
            zBinding.MaxReceivedMessageSize = this.MaxReceivedMessageSize;
            zBinding.TransferMode = this.TransferMode;
            zBinding.AllowCookies = this.AllowCookies;
            PropertyInformationCollection propertyInformationCollection = base.ElementInformation.Properties;
            if (propertyInformationCollection["maxBufferSize"].ValueOrigin != PropertyValueOrigin.Default)
            {
                zBinding.MaxBufferSize = this.MaxBufferSize;
            }
            this.ApplyReaderQuotasConfiguration(zBinding.ReaderQuotas);
        }

        private void ApplyReaderQuotasConfiguration(XmlDictionaryReaderQuotas readerQuotas)
        {
            if (readerQuotas == null)
                throw new ArgumentNullException("readerQuotas");
            if (this.ReaderQuotas.MaxDepth != 0)
            {
                readerQuotas.MaxDepth = this.ReaderQuotas.MaxDepth;
            }
            if (this.ReaderQuotas.MaxStringContentLength != 0)
            {
                readerQuotas.MaxStringContentLength = this.ReaderQuotas.MaxStringContentLength;
            }
            if (this.ReaderQuotas.MaxArrayLength != 0)
            {
                readerQuotas.MaxArrayLength = this.ReaderQuotas.MaxArrayLength;
            }
            if (this.ReaderQuotas.MaxBytesPerRead != 0)
            {
                readerQuotas.MaxBytesPerRead = this.ReaderQuotas.MaxBytesPerRead;
            }
            if (this.ReaderQuotas.MaxNameTableCharCount != 0)
            {
                readerQuotas.MaxNameTableCharCount = this.ReaderQuotas.MaxNameTableCharCount;
            }
        }

        #endregion

    }
}
