﻿using System;
using System.Configuration;
using System.ServiceModel.Channels;
using System.ServiceModel.Configuration;

namespace Nd.Erp.Mobile
{
    public class GZipWebHttpBindingCollectionElement
        : StandardBindingCollectionElement<GZipWebHttpBinding, GZipWebHttpBindingElement>
    {

        protected override Binding GetDefault()
        {
            return new GZipWebHttpBinding();
        }

        internal static GZipWebHttpBindingCollectionElement GetBindingCollectionElement()
        {
            BindingsSection bindingsSection = null;
            string text = "system.serviceModel/bindings";
                bindingsSection = (BindingsSection)ConfigurationManager.GetSection(text);
            BindingCollectionElement bindingCollectionElement = bindingsSection["gzipWebHttpBinding"];
            return (GZipWebHttpBindingCollectionElement)bindingCollectionElement;
        }

    }
}
