﻿using System;
using System.IO;
using System.Net;
using System.ServiceModel.Channels;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Web;

namespace Nd.Erp.Mobile
{
    [AttributeUsage(AttributeTargets.Method)]
    public class GZipAttribute
        : Attribute, IOperationBehavior
    {

        #region IOperationBehavior 成员

        public void ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
        {
            dispatchOperation.Formatter = new GZipFormatter(dispatchOperation.Formatter);
        }

        void IOperationBehavior.AddBindingParameters(OperationDescription operationDescription, System.ServiceModel.Channels.BindingParameterCollection bindingParameters) { }

        void IOperationBehavior.ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation) { }

        void IOperationBehavior.Validate(OperationDescription operationDescription) { }

        #endregion

        #region Subclass: OperationInvoker

        private sealed class GZipFormatter

            : IDispatchMessageFormatter
        {

            private readonly IDispatchMessageFormatter m_inner;

            public GZipFormatter(IDispatchMessageFormatter inner)
            {
                m_inner = inner;
            }

            #region IDispatchMessageFormatter 成员

            public void DeserializeRequest(Message message, object[] parameters)
            {
                m_inner.DeserializeRequest(message, parameters);
            }

            public Message SerializeReply(MessageVersion messageVersion, object[] parameters, object result)
            {
                var msg = m_inner.SerializeReply(messageVersion, parameters, result);
                var c = WebOperationContext.Current;
                if (c != null)
                {
                    var ae = c.IncomingRequest.Headers[HttpRequestHeader.AcceptEncoding];
                    if (ae != null && ae.IndexOf("gzip", StringComparison.OrdinalIgnoreCase) >= 0 &&
                       // "gzip".Equals(c.OutgoingResponse.Headers[HttpResponseHeader.ContentEncoding], StringComparison.OrdinalIgnoreCase) &&
                        result != null)
                    {
                        msg.Properties["gzip"] = "1";
                        c.OutgoingResponse.Headers[HttpResponseHeader.ContentEncoding] = "gzip";
                    }
                }
                return msg;
            }

            #endregion
        }

        #endregion

    }
}
