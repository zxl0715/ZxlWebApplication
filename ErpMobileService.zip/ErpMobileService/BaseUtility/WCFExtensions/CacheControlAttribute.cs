﻿using System;
using System.Net;
using System.ServiceModel.Description;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Web;

namespace Nd.Erp.Mobile
{
    [AttributeUsage(AttributeTargets.Method)]
    public class CacheControlAttribute
        : Attribute, IOperationBehavior
    {

        #region Fields
        private readonly string m_cacheControl;
        #endregion

        #region Ctors

        public CacheControlAttribute(CacheControl cacheControl)
        {
            switch (cacheControl)
            {
                case CacheControl.NoCache:
                    m_cacheControl = "no-cache";
                    break;
                case CacheControl.MustRevalidate:
                    m_cacheControl = "must-revalidate";
                    break;
                case CacheControl.Public:
                    m_cacheControl = "public";
                    break;
                case CacheControl.Private:
                default:
                    m_cacheControl = "private";
                    break;
            }
        }

        public CacheControlAttribute(int maxAge)
        {
            if (maxAge <= 0)
                throw new ArgumentOutOfRangeException("maxAge");
            m_cacheControl = "max-age=" + maxAge.ToString();
        }

        #endregion

        #region IOperationBehavior 成员

        public void ApplyDispatchBehavior(OperationDescription operationDescription, DispatchOperation dispatchOperation)
        {
            dispatchOperation.Invoker = new OperationInvoker(dispatchOperation.Invoker, m_cacheControl);
        }

        void IOperationBehavior.AddBindingParameters(OperationDescription operationDescription, System.ServiceModel.Channels.BindingParameterCollection bindingParameters) { }

        void IOperationBehavior.ApplyClientBehavior(OperationDescription operationDescription, ClientOperation clientOperation) { }

        void IOperationBehavior.Validate(OperationDescription operationDescription) { }

        #endregion

        #region Subclass: OperationInvoker

        private sealed class OperationInvoker : IOperationInvoker
        {

            private readonly IOperationInvoker m_inner;
            private readonly string m_cacheControl;

            public OperationInvoker(IOperationInvoker inner, string cacheControl)
            {
                m_inner = inner;
                m_cacheControl = cacheControl;
            }

            public object[] AllocateInputs()
            {
                return m_inner.AllocateInputs();
            }

            public object Invoke(object instance, object[] inputs, out object[] outputs)
            {
                if (WebOperationContext.Current != null)
                    WebOperationContext.Current.OutgoingResponse.Headers[HttpResponseHeader.CacheControl] = m_cacheControl;
                return m_inner.Invoke(instance, inputs, out outputs);
            }

            public IAsyncResult InvokeBegin(object instance, object[] inputs, AsyncCallback callback, object state)
            {
                if (WebOperationContext.Current != null)
                    WebOperationContext.Current.OutgoingResponse.Headers[HttpResponseHeader.CacheControl] = m_cacheControl;
                return m_inner.InvokeBegin(instance, inputs, callback, state);
            }

            public object InvokeEnd(object instance, out object[] outputs, IAsyncResult result)
            {
                return m_inner.InvokeEnd(instance, out outputs, result);
            }

            public bool IsSynchronous
            {
                get { return m_inner.IsSynchronous; }
            }

        }

        #endregion

    }

    public enum CacheControl
    {
        NoCache,
        Private,
        MustRevalidate,
        Public,
    }
}
