﻿using System;
using System.IO;
using System.IO.Compression;
using System.ServiceModel;
using System.ServiceModel.Channels;
using System.Xml;
using System.ServiceModel.Web;

namespace Nd.Erp.Mobile
{
    public class GZipWebHttpBinding
        : CustomBinding, IBindingRuntimePreferences
    {

        #region Ctors

        public GZipWebHttpBinding(WebHttpBinding webHttpBinding=null)
            : base(GetBindingElements(webHttpBinding)) { }

        public GZipWebHttpBinding(string configurationName)
            : base(GetBindingElements())
        {
            ApplyConfiguration(configurationName);
        }

        #endregion

        #region Methods

        private static BindingElementCollection GetBindingElements(WebHttpBinding webHttpBinding = null)
        {
            if (webHttpBinding == null)
                webHttpBinding = new WebHttpBinding();
            var collection = webHttpBinding.CreateBindingElements();
            var encodingBindingElement = collection.Find<MessageEncodingBindingElement>();
            var index = collection.IndexOf(encodingBindingElement);
            collection.RemoveAt(index);
            var wrapperBindingElement = new WrapperEncodingBindingElement(encodingBindingElement);
            collection.Insert(index, wrapperBindingElement);
            return collection;
        }

        private void ApplyConfiguration(string configurationName)
        {
            GZipWebHttpBindingCollectionElement c = GZipWebHttpBindingCollectionElement.GetBindingCollectionElement();
            GZipWebHttpBindingElement element = c.Bindings[configurationName];
            if (element == null)
                throw new InvalidOperationException("Configuration[" + configurationName + "] not found.");
            element.ApplyConfiguration(this);
        }

        #endregion

        #region Properties

        private HttpTransportBindingElement httpTransportBindingElement { get { return Elements.Find<HttpTransportBindingElement>(); } }

        public bool AllowCookies
        {
            get { return httpTransportBindingElement.AllowCookies; }
            set { httpTransportBindingElement.AllowCookies = value; }
        }

        public long MaxBufferPoolSize
        {
            get { return httpTransportBindingElement.MaxBufferPoolSize; }
            set { httpTransportBindingElement.MaxBufferPoolSize = value; }
        }

        public int MaxBufferSize
        {
            get { return httpTransportBindingElement.MaxBufferSize; }
            set { httpTransportBindingElement.MaxBufferSize = value; }
        }

        public long MaxReceivedMessageSize
        {
            get { return httpTransportBindingElement.MaxReceivedMessageSize; }
            set { httpTransportBindingElement.MaxReceivedMessageSize = value; }
        }

        public XmlDictionaryReaderQuotas ReaderQuotas
        {
            get { return ((WrapperEncodingBindingElement)Elements.Find<MessageEncodingBindingElement>()).ReaderQuotas; }
            set
            {
                if (value == null)
                    throw new ArgumentNullException("value");
                value.CopyTo(((WrapperEncodingBindingElement)Elements.Find<MessageEncodingBindingElement>()).ReaderQuotas);
            }
        }

        public override string Scheme { get { return "http"; } }

        bool IBindingRuntimePreferences.ReceiveSynchronously
        {
            get { return false; }
        }

        public TransferMode TransferMode
        {
            get { return httpTransportBindingElement.TransferMode; }
            set { httpTransportBindingElement.TransferMode = value; }
        }

        #endregion

        #region Wrapper Classes

        private sealed class WrapperEncodingBindingElement
            : MessageEncodingBindingElement
        {
            private readonly WebMessageEncodingBindingElement m_bindingElement;
            public WrapperEncodingBindingElement(MessageEncodingBindingElement bindingElement)
            {
                this.m_bindingElement = (WebMessageEncodingBindingElement)bindingElement;
            }
            public override MessageEncoderFactory CreateMessageEncoderFactory()
            {
                return new WrapperMessageEncoderFactory(m_bindingElement.CreateMessageEncoderFactory());
            }
            public override MessageVersion MessageVersion
            {
                get { return this.m_bindingElement.MessageVersion; }
                set { this.m_bindingElement.MessageVersion = value; }
            }
            public override BindingElement Clone()
            {
                MessageEncodingBindingElement bindingElement = (MessageEncodingBindingElement)this.m_bindingElement.Clone();
                return new WrapperEncodingBindingElement(bindingElement);
            }
            public XmlDictionaryReaderQuotas ReaderQuotas
            {
                get { return m_bindingElement.ReaderQuotas; }
            }
            public override IChannelFactory<TChannel> BuildChannelFactory<TChannel>(BindingContext context)
            {
                context.BindingParameters.Add(this);
                return context.BuildInnerChannelFactory<TChannel>();
            }
            public override IChannelListener<TChannel> BuildChannelListener<TChannel>(BindingContext context)
            {
                context.BindingParameters.Add(this);
                return context.BuildInnerChannelListener<TChannel>();
            }
            public override bool CanBuildChannelFactory<TChannel>(BindingContext context)
            {
                context.BindingParameters.Add(this);
                return context.CanBuildInnerChannelFactory<TChannel>();
            }
            public override bool CanBuildChannelListener<TChannel>(BindingContext context)
            {
                context.BindingParameters.Add(this);
                return context.CanBuildInnerChannelListener<TChannel>();
            }
            public override T GetProperty<T>(BindingContext context)
            {
                if (context == null)
                {
                    throw new ArgumentNullException("context");
                }
                if (typeof(T) == typeof(XmlDictionaryReaderQuotas))
                {
                    return (T)(object)this.ReaderQuotas;
                }
                return base.GetProperty<T>(context);
            }
        }

        private sealed class WrapperMessageEncoderFactory
            : MessageEncoderFactory
        {
            private readonly MessageEncoderFactory m_inner;
            private readonly MessageEncoder m_encoder;
            public WrapperMessageEncoderFactory(MessageEncoderFactory factory)
            {
                this.m_inner = factory;
                this.m_encoder = new WrapperMessageEncoder(factory.Encoder);
            }
            public override MessageEncoder Encoder
            {
                get { return this.m_encoder; }
            }
            public override MessageVersion MessageVersion
            {
                get { return this.m_encoder.MessageVersion; }
            }
        }

        private sealed class WrapperMessageEncoder
            : MessageEncoder
        {
            private readonly MessageEncoder m_inner;

            public WrapperMessageEncoder(MessageEncoder encoder)
            {
                this.m_inner = encoder;
            }

            #region Overrides
            public override string ContentType
            {
                get { return this.m_inner.ContentType; }
            }
            public override string MediaType
            {
                get { return this.m_inner.MediaType; }
            }
            public override MessageVersion MessageVersion
            {
                get { return this.m_inner.MessageVersion; }
            }
            public override bool IsContentTypeSupported(string contentType)
            {
                return this.m_inner.IsContentTypeSupported(contentType);
            }
            public override T GetProperty<T>()
            {
                return this.m_inner.GetProperty<T>();
            }
            public override Message ReadMessage(ArraySegment<byte> buffer, BufferManager bufferManager, string contentType)
            {
                return this.m_inner.ReadMessage(buffer, bufferManager, contentType);
            }
            public override Message ReadMessage(Stream stream, int maxSizeOfHeaders, string contentType)
            {
                return this.m_inner.ReadMessage(stream, maxSizeOfHeaders, contentType);
            }
            public override ArraySegment<byte> WriteMessage(Message message, int maxMessageSize, BufferManager bufferManager, int messageOffset)
            {
                var c = WebOperationContext.Current;
                // 写Buffered消息
                ArraySegment<byte> buffer = this.m_inner.WriteMessage(message, maxMessageSize, bufferManager, messageOffset);
                if (c != null && message.Properties.ContainsKey("gzip"))
                    return CompressBuffer(buffer, bufferManager, messageOffset);
                return buffer;
            }
            public override void WriteMessage(Message message, Stream stream)
            {
                // 写Streaming消息
                var c = WebOperationContext.Current;
                if (c != null && message.Properties.ContainsKey("gzip"))
                {
                    using (var gz = new GZipStream(stream, CompressionMode.Compress, true))
                        this.m_inner.WriteMessage(message, gz);
                    stream.Flush();
                    return;
                }
                this.m_inner.WriteMessage(message, stream);
            }
            #endregion

            private static ArraySegment<byte> CompressBuffer(ArraySegment<byte> buffer, BufferManager bufferManager, int messageOffset)
            {
                // 压缩
                var ms = new MemoryStream(Math.Max(buffer.Count >> 1, 512));
                using (var gz = new GZipStream(ms, CompressionMode.Compress, true))
                    gz.Write(buffer.Array, messageOffset, buffer.Count);
                // 重新组织消息体
                byte[] bufferedBytes = bufferManager.TakeBuffer(messageOffset + (int)ms.Length);
                byte[] compressedBytes = ms.GetBuffer();
                Array.Copy(buffer.Array, 0, bufferedBytes, 0, messageOffset);
                Array.Copy(compressedBytes, 0, bufferedBytes, messageOffset, (int)ms.Length);
                bufferManager.ReturnBuffer(buffer.Array);
                return new ArraySegment<byte>(bufferedBytes, messageOffset, (int)ms.Length);
            }

        }

        #endregion

    }
}
