﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Script.Serialization;

namespace Nd.Erp.Mobile.Base
{
    public static class JSONHelper
    {
        static JavaScriptSerializer jsonSerializer = new JavaScriptSerializer();
        /// <summary>
        /// Toes the JSON.
        /// </summary>
        /// <param name="obj">The obj.</param>
        /// <returns></returns>
        public static string ToJSON(this object obj)
        {
            return jsonSerializer.Serialize(obj);
        }

        public static string ToJSON(this object obj, bool isWithSinglQuote)
        {
            return obj.ToJSON().Replace("\"", "'");
        }
        /// <summary>
        /// Deserilizes the JSON.
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="json">The json.</param>
        /// <returns></returns>
        public static T DeserializeJSON<T>(this string json)
        {
            return jsonSerializer.Deserialize<T>(json);
        }

        public static object DeserializeJSON(string json, Type type) {
            return jsonSerializer.Deserialize(json, type);
        }
    }
}

