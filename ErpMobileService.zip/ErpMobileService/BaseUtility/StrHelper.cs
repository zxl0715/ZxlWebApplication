﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;

namespace Nd.Erp.Mobile.Base
{
    public class StrHelper
    {
        public StrHelper()
        { }

        /// <summary>
        /// 判断是否为数字
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static bool isNumeric(string str)
        {
            return Regex.IsMatch(str, @"^(-|\+)?\d+(\.\d+)?$");
        }
    }
}
