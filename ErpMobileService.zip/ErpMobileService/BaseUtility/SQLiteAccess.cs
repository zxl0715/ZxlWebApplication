﻿using System;
using System.Data.SQLite;
using Nd.Erp.Data.SQLite;
using ND.Lib.DocXMLOpe;
using ND.Lib.PDec;
using System.Data;
using System.Collections.Generic;
using System.Reflection;

namespace Nd.Erp.Mobile.Base
{
    public class SQLiteAccess
    {
        /// <summary>
        /// 访问SQLite数据库连接串
        /// </summary>
        private static string _sqliteCnnStr = "";

        /// <summary>
        /// 构造函数
        /// </summary>
        static SQLiteAccess()
        {
            _sqliteCnnStr = BaseHelper.SQLiteDBAccess;
        }
        
        /// <summary>
        /// 取得系统参数键值
        /// </summary>
        /// <param name="argKey">参数键</param>
        /// <returns>参数键值</returns>
        public static string GetSysArgValue(string argKey)
        {
            string cmdTxt = "select ArgValue from SysArg where ArgKey=@ArgKey and Enabled=1";
            object obj = SQLiteHelper.ExecuteScalar(BaseHelper.SQLiteDBAccess, cmdTxt, new SQLiteParameter("@ArgKey", argKey));
            return (obj != null ? obj.ToString() : "");
        }

        /// <summary>
        /// 取得所有服务参数信息
        /// </summary>
        /// <returns></returns>
        public static List<ServiceArgEntity> FetchServiceArg()
        {
            var list = new List<ServiceArgEntity>();
            string cmdTxt = "select ID,ServiceCode,ServiceName,OwnerType,AddressPath,Enabled from ServiceArg where Enabled=1";
            DataTable dt = SQLiteHelper.GetDataSet(_sqliteCnnStr, cmdTxt).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiceArgEntity
                    {
                        ID = dr["ID"].ToString(),
                        ServiceCode = dr["ServiceCode"].ToString(),
                        ServiceName = dr["ServiceName"].ToString(),
                        OwnerType = dr["OwnerType"].ToString(),
                        AddressPath = dr["AddressPath"].ToString(),
                        Enabled = dr["Enabled"].ToString()
                    });
                }
            }
            dt.Dispose();
            return list;
        }

        /// <summary>
        /// 取得指定服务类库参数信息
        /// </summary>
        /// <param name="serviceID"></param>
        /// <returns></returns>
        public static List<ServiceClassArgEntity> FetchServiceClassArg(string serviceID)
        {
            var list = new List<ServiceClassArgEntity>();
            string cmdTxt = string.Format("select ID,ServiceID,NameSpace,ClassName,EndPointBinding,BaseAddress,Enabled from ServiceClassArg where Enabled=1 and ServiceID = {0}", serviceID);
            DataTable dt = SQLiteHelper.GetDataSet(_sqliteCnnStr, cmdTxt).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiceClassArgEntity
                    {
                        ID = dr["ID"].ToString(),
                        ServiceID = dr["ServiceID"].ToString(),
                        NameSpace = dr["NameSpace"].ToString(),
                        ClassName = dr["ClassName"].ToString(),
                        BaseAddress = dr["BaseAddress"].ToString(),
                        EndPointBinding = dr["EndPointBinding"].ToString(),
                        Enabled = dr["Enabled"].ToString()
                    });
                }
            }
            dt.Dispose();
            return list;
        }

        /// <summary>
        /// 取得指定服务接口参数信息
        /// </summary>
        /// <param name="serviceID"></param>
        /// <returns></returns>
        public static List<ServiceInterfaceArgEntity> FetchServiceInterfaceArg(string serviceClassID)
        {
            var list = new List<ServiceInterfaceArgEntity>();
            string cmdTxt = string.Format("select ID,ServiceClassID,InterfaceName,EndPointAddress,Enabled from ServiceInterfaceArg where Enabled=1 and ServiceClassID ={0}", serviceClassID);
            DataTable dt = SQLiteHelper.GetDataSet(_sqliteCnnStr, cmdTxt).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    list.Add(new ServiceInterfaceArgEntity
                    {
                        ID = dr["ID"].ToString(),
                        ServiceClassID = dr["ServiceClassID"].ToString(),
                        InterfaceName = dr["InterfaceName"].ToString(),
                        EndPointAddress = dr["EndPointAddress"].ToString(),
                        Enabled = dr["Enabled"].ToString()
                    });
                }
            }
            dt.Dispose();
            return list;
        }
    }
}
