﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.Base
{
    public class ServiceArgEntity
    {
        public string ID { get; set; }
        public string ServiceCode { get; set; }
        public string ServiceName { get; set; }
        public string OwnerType { get; set; }
        public string AddressPath { get; set; }
        public string Enabled { get; set; }
    }

    public class ServiceClassArgEntity
    {
        public string ID { get; set; }
        public string ServiceID { get; set; }
        public string NameSpace { get; set; }
        public string ClassName { get; set; }
        public string EndPointBinding { get; set; }
        public string BaseAddress { get; set; }
        public string Enabled { get; set; }
    }

    public class ServiceInterfaceArgEntity
    {
        public string ID { get; set; }
        public string ServiceClassID { get; set; }
        public string InterfaceName { get; set; }
        public string EndPointAddress { get; set; }
        public string Enabled { get; set; }
    }

    public class UserData
    {
        /// <summary>
        /// 客户端调用类型，0:Android；1:IPhone IOS；2:JavaScript；3:.Net CS；4:C++调用；5:Delphi调用；
        /// </summary>
        public string OSType { get; set; }
        /// <summary>
        /// 用户
        /// </summary>
        public string UserID { get; set; }
        /// <summary>
        /// 登录后校验的GUID
        /// </summary>
        public string UserGUID { get; set; }
        /// <summary>
        /// 首次登录时间，即增加时间
        /// </summary>
        public DateTime FirstTime { get; set; }
        /// <summary>
        /// 最后登录时间，即更新时间
        /// </summary>
        public DateTime LastTime { get; set; }
        /// <summary>
        /// 缓存生命周期
        /// </summary>
        public DateTime LifeTime { get; set; }
    }
}
