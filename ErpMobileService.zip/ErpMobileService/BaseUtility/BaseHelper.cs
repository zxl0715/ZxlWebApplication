﻿using System;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using ND.Lib.Data.SqlHelper;
using ND.Lib.DocXMLOpe;
using ND.Lib.PDec;
using System.Data;
using System.Diagnostics;

namespace Nd.Erp.Mobile.Base
{
    public class BaseHelper
    {
        /// <summary>
        /// 日志是否写入数据库
        /// </summary>
        public static bool IsWriteLogToDataBase { get; private set; }
        /// <summary>
        /// ERP数据库访问连接字符串
        /// </summary>
        public static string ErpDataBaseAccess { get; private set; }
        /// <summary>
        /// 本地SQLite数据库访问
        /// </summary>
        public static string SQLiteDBAccess { get; private set; }
        /// <summary>
        /// 服务的启动目录
        /// </summary>
        public static string StartPath  { get; private set; }
        /// <summary>
        /// 服务对外发布的基础地址
        /// </summary>
        public static string ServiceBaseAddress { get; private set; }
        /// <summary>       
        /// 手机接入服务名称
        /// </summary>
        public readonly static string MobileServiceName = "ErpMobileService";
        /// <summary>
        /// 日志
        /// </summary>
        private static SysEventLog<BaseHelper> _logMgr = new SysEventLog<BaseHelper>();
        static BaseHelper()
        {
            RefreshConfig();
        }

        /// <summary>
        /// ERP数据库访问连接字符串
        /// </summary>
        /// <returns></returns>
        private static string GetErpDataAccess()
        {
            string sqlCnnStr = SQLiteAccess.GetSysArgValue("ErpSqlCnnStr");
            return PDesc.Decrypt(sqlCnnStr);
        }

        /// <summary>
        /// 日志是否写入数据库
        /// </summary>
        /// <returns></returns>
        private static bool IsWriteLogToDB()
        {
            string isWriteLogToDB = SQLiteAccess.GetSysArgValue("IsWriteLogToDB");
            return (isWriteLogToDB.ToLower() == "true" ? true : false);
        }
       private static string GetSQLiteDBAccess(DocXMLCls xml)
       {
           _logMgr.WriteInfo(xml.GetXmlNodeAttrValueByKey("/configuration/services/service/database", "sqliteCnnStr"));
           string sqliteCnnStr = PDesc.Decrypt(xml.GetXmlNodeAttrValueByKey("/configuration/services/service/database", "sqliteCnnStr"));
           return GetSQLiteDBAccess(sqliteCnnStr);
       }

        /// <summary>
        /// 本地SQLite数据库访问连接字符串
        /// </summary>
        /// <returns></returns>
       private static string GetSQLiteDBAccess(string sqliteCnnStr)
        {
            if (sqliteCnnStr != "")
            {
                string sqliteCnnStrNew = "";
                foreach (string para in sqliteCnnStr.Split(';'))
                {
                    if (para.Trim().Length > 0)
                    {
                        string[] arPara = para.Split('=');
                        if (arPara[0].Trim().ToLower().Replace(" ", "").Equals("datasource"))
                        {
                            sqliteCnnStrNew += string.Format("Data Source={0};", StartPath + @"\" + arPara[1]);
                        }
                        else
                        {
                            sqliteCnnStrNew += para + ";";
                        }
                    }
                }
                sqliteCnnStr = sqliteCnnStrNew;
            }
            else
                throw new ApplicationException("未配置SQLite数据库连接串。");
            return sqliteCnnStr;
        }

        /// <summary>
        /// 重新初始化配置
        /// </summary>
        public static void RefreshConfig() {
            try
            {
                if (AppDomain.CurrentDomain.DynamicDirectory == null)
                    StartPath = AppDomain.CurrentDomain.BaseDirectory;
                else
                    StartPath = AppDomain.CurrentDomain.BaseDirectory + "bin";
                DocXMLCls xml = new DocXMLCls();
#if DEBUG

                    xml.XmlFullFileName = StartPath + @"\Host.config";
                    _logMgr.WriteInfo(StartPath + @"\Host.config");
                    xml.OpenXML();     
#else
                xml.OpenXML("Host.config");
#endif
                _logMgr.WriteInfo("start initial ServiceBaseAddress");
                ServiceBaseAddress = xml.GetXmlNodeAttrValueByKey("/configuration/services/service/host/baseAddresses", "baseAddress");
                SQLiteDBAccess = GetSQLiteDBAccess(xml);

                //IsWriteLogToDataBase = IsWriteLogToDB();

                ErpDataBaseAccess = PDesc.Decrypt(xml.GetXmlNodeAttrValueByKey("/configuration/services/service/database", "sqlCnnStr"));// GetErpDataAccess();
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("初始化基础参数失败:{0}", ex.ToString());
                try
                {
                    ServiceBaseAddress = ConfigurationManager.AppSettings["baseAddress"];
                    ErpDataBaseAccess =  PDesc.Decrypt(ConfigurationManager.AppSettings["sqlCnnStr"]);
                    SQLiteDBAccess = PDesc.Decrypt(ConfigurationManager.AppSettings["sqliteCnnStr"]);
                }
                catch (Exception)
                {

                    throw;
                }
            }
        }
    }
}
