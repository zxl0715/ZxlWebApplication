﻿using System;
using System.ServiceProcess;
using System.Web.Http.Dispatcher;
using System.Web.Http;
using System.Web.Http.SelfHost;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.ERPMobile.WebApi.SelfHost;
using System.Linq;
using SysCommonLibrary.WebApiConfig;
using System.Diagnostics;

namespace Nd.Erp.Mobile.Service
{
    public partial class ErpMobileService : ServiceBase
    {        
        /// <summary>
        /// 日志
        /// </summary>
        private LogMgr<Host> _logMgr = new LogMgr<Host>();
        public static HttpSelfHostServer server = null;
        static readonly Uri _baseAddress = new Uri(BaseHelper.ServiceBaseAddress);
        static readonly Uri _address = new Uri(_baseAddress, "/ServiceHost");
        Host _host;
        public ErpMobileService()
        {
            InitializeComponent();
            this.ServiceName = "ErpMobileService";
            _host = new Host();
        }


        protected void StartWebApi() {
            try
            {
                // Set up server configuration
                _logMgr.WriteLogToLocal(false,"baseAddress:"+_baseAddress.Authority);
                // Set up server configuration
                HttpSelfHostConfiguration config = WebApiConfig.ApplyConfig(new HttpSelfHostConfiguration("http://localhost:8732/"));
                config.Services.Replace(typeof(IAssembliesResolver), new CustomAssemblyResolver());
                // Create server
                server = new HttpSelfHostServer(config);
                var explorer = config.Services.GetApiExplorer();
                explorer.ApiDescriptions.ToList().ForEach(i =>_logMgr.WriteLogToLocal(false,i.RelativePath));
                // Start listening
                server.OpenAsync().Wait();
                Console.WriteLine("Listening on " + _baseAddress);
                _logMgr.WriteLogToLocal(false, "Listening on " +config.BaseAddress);

               
            }
            catch (Exception e)
            {
                _logMgr.WriteLogToLocal(true,string.Format("Could not start server: {0}", e.GetBaseException().Message));
                Console.WriteLine("Could not start server: {0}", e.GetBaseException().Message);
                Console.WriteLine("Hit ENTER to exit...");
                Console.ReadLine();
            }
            finally
            {
              
            }
        }
        protected void StartWCF() {
            try
            {
                if (_host != null)
                    _host.Start();
            }
            catch (System.Exception ex)
            {
                _logMgr.WriteErrorFormat("服务初始化失败：{0}", ex.ToString());
                throw;
            }
        
        }
        protected override void OnStart(string[] args)
        {
            StartWebApi();
          
        }

        protected override void OnStop()
        {
            if (_host != null)
                _host.Stop();
            if (server != null)
            {
                server.CloseAsync().Wait();
                _logMgr.WriteLogToLocal(false, "OnStop：服务停止server.CloseAsync().Wait()");
            }

        }
    }
}
