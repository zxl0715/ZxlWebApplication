﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Http.Dispatcher;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile.Base;
using Newtonsoft.Json;
using SysCommonLibrary.WebApiConfig;
using Nd.Erp.Mobile.Service.Common;
using SOPService;

namespace Nd.ERPMobile.Web
{
    // Note: For instructions on enabling IIS6 or IIS7 classic mode, 
    // visit http://go.microsoft.com/?LinkId=9394801

    public class WebApiApplication : System.Web.HttpApplication
    {
        private void InitialSample()
        {
            DocumentHellper._sampleData = new Dictionary<Type, object>()
            {
                
            {typeof(List<EnApproval>),
                new List<EnApproval>() { 
                new EnApproval() { Code = 794641 ,Name="张三",Title="请假单",OverTime=new DateTime(2013,4,1)} ,
                new EnApproval() { Code = 794642 ,Name="李四",Title="请假单",OverTime=new DateTime(2013,4,1)} 
            }},
            {typeof(EnESOPDetail),
                new EnESOPDetail()
            {
                Data = new EnApproval() { Code = 794641, Name = "张三", Title = "请假单", OverTime = new DateTime(2013, 4, 1) },
                Steps = new List<EnNodeDetail>() { 
                    new EnNodeDetail(){ Appcode=1,Advice="审批意见",Status="审批状态",OpTime=new DateTime(2013, 4, 1), AppUser="审批人"},
                    new EnNodeDetail(){ Appcode=2,Advice="审批意见",Status="审批状态",OpTime=new DateTime(2013, 4, 1), AppUser="审批人",isCurrent=true}
                }
            }},
            {typeof(bool),true},
            {typeof(EnAppListParams),new EnAppListParams{UserCode="34567", Type="all", PageIndex=0,PageSize=10,Condition=new EnAppListParamsCondition{ bDay=new DateTime(2013,1,1), eDay=new DateTime(2013,1,2)}}}
            };

        }

        protected void Application_Start()
        {
            InitialSample();
            //GlobalConfiguration.Configuration.Services.Replace(typeof(IAssembliesResolver), new CustomAssemblyResolver());
            AreaRegistration.RegisterAllAreas();
            WebApiConfig.ApplyConfig(GlobalConfiguration.Configuration);
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);

            GlobalConfiguration.Configuration.Services.Replace(typeof(IDocumentationProvider), new DocProvider());
            GlobalConfiguration.Configuration.Services.Replace(typeof(IDocumentationProvider), new XmlCommentDocumentationProvider(HttpContext.Current.Server.MapPath("~/bin/")));
        }
    }
}