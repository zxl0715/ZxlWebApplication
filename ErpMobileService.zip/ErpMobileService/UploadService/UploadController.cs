﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Web.Http;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;
using System.ServiceModel.Activation;
using Nd.Erp.Mobile.Log;
using UploadService.Entity;

namespace Nd.Erp.Mobile.Service.Upload
{
    public class Upload : UploadController
    {
    }

    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, Namespace = "")]
    public class UploadController :ApiController
    {
        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;

        private LogMgr<UploadController> _logMgr = new LogMgr<UploadController>();

        /// <summary>
        /// 上传文件
        /// </summary>
        /// <param name="stream">文件流</param>
        /// <param name="fileName">文件名</param>
        /// <param name="newFilePath">新文件名</param>
        /// <param name="startPosition">起始位置</param>
        /// <returns></returns>
        public UploadResult uploadFile(string fileName, string newFilePath=null, long startPosition=0)
        {
            Stream stream = this.Request.Content.ReadAsStreamAsync().Result;
            string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(fileName);
            string fileExtension = Path.GetExtension(fileName);
            UploadResult uploadResult = new UploadResult();
            uploadResult.OldFilePath = fileName;
            if (string.IsNullOrEmpty(newFilePath)){
                uploadResult.NewFilePath = "\\" + DateTime.Now.Year + "\\" + DateTime.Now.ToString("MM") + "\\" + Guid.NewGuid().ToString() + fileExtension;
                string uploadRootPath = SQLiteAccess.GetSysArgValue("UploadRootPath");
                uploadResult.NewFilePath = uploadRootPath.TrimEnd('\\') + uploadResult.NewFilePath;
                string dir = Path.GetDirectoryName(uploadResult.NewFilePath);
                if (dir != null && !Directory.Exists(dir))
                    Directory.CreateDirectory(dir);
            }else
            {
                uploadResult.NewFilePath = newFilePath;
            }
           
            FileStream fs = new FileStream(uploadResult.NewFilePath, FileMode.OpenOrCreate);//打开文件
            try
            {
                BinaryReader reader = new BinaryReader(stream);

                byte[] buffer;

                BinaryWriter writer = new BinaryWriter(fs);
                long offset = fs.Length;
                if (startPosition > fs.Length)
                {
                    uploadResult.UploadSize = fs.Length;
                    return uploadResult;
                }
                writer.Seek((int)offset, SeekOrigin.Begin);
                long uploadSize = offset;
                do
                {
                    buffer = reader.ReadBytes(1024);

                    writer.Write(buffer);
                    uploadSize += buffer.Length;
                } while (buffer.Length > 0);

                uploadResult.IsSuccess = true;
                uploadResult.UploadSize = uploadSize;

            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("上传文件失败:{0},message:{1}", ex.StackTrace.ToString(), ex.Message);
            }
            finally
            {

                fs.Close();

            }
            return uploadResult;

        }

    }
}
