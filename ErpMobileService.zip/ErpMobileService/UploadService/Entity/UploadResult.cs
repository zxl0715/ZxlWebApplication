﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace UploadService.Entity
{
    [DataContract]
    public class UploadResult
    {
        /// <summary>
        /// 上传大小
        /// </summary>
        [DataMember]
        public long UploadSize { get; set; }

        /// <summary>
        /// 上传后的文件路径
        /// </summary>
        [DataMember]
        public string NewFilePath { get; set; }

        /// <summary>
        /// 上传之前的文件路径
        /// </summary>
        [DataMember]
        public string OldFilePath { get; set; }

        /// <summary>
        /// 是否成功
        /// </summary>
        [DataMember]
        public bool IsSuccess { get; set; }
    }
}
