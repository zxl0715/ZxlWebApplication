﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;

using System.IO;
using UploadService.Entity;

namespace Nd.Erp.Mobile.Service.Upload
{
    [ServiceContract]
    public interface IUploadJson
    {
        [OperationContract]
        [WebInvoke(Method = "*", UriTemplate = "uploadFile?fileName={fileName}&startPosition={startPosition}&newFilePath={newFilePath}", ResponseFormat = WebMessageFormat.Json)]
        UploadResult uploadFile(Stream stream, string fileName, string newFilePath, long startPosition);

    }



}
