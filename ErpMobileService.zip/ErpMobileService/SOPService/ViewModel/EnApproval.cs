﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SOPService
{
    /// <summary>
    /// 审批结果实体
    /// </summary>
    public class EnApproval
    {
        /// <summary>
        /// 单据编号
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// 姓名
        /// </summary>
        public string Name { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 到期时间
        /// </summary>
        public DateTime OverTime { get; set; }
    }
}
