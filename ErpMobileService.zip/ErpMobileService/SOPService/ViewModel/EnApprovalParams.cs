﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SOPService
{
    /// <summary>
    /// 审批选填参数实体
    /// </summary>
    public class EnAppListParamsCondition {

        public DateTime bDay { get; set; }

        public DateTime eDay { get; set; }
    }
    /// <summary>
    /// 审批参数实体
    /// </summary>
    public class EnAppListParams
    {
        public string UserCode { get; set; }

        public int PageIndex { get; set; }

        public int PageSize { get; set; }

        public string Type { get; set; }

        public EnAppListParamsCondition Condition { get; set; }
    }
}
