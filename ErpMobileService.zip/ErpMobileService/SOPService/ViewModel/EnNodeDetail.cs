﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SOPService
{

    public class EnESOPDetail {

        public EnApproval Data { get; set; }

        public List<EnNodeDetail> Steps { get; set; }
    }
    /// <summary>
    /// 审批结果实体
    /// </summary>
    public class EnNodeDetail
    {
        /// <summary>
        /// 单据编号
        /// </summary>
        public int Code { get; set; }

        /// <summary>
        /// 节点编号
        /// </summary>
        public int Appcode { get; set; }

        /// <summary>
        /// 审批意见
        /// </summary>
        public string Advice { get; set; }

        /// <summary>
        /// 审批状态
        /// </summary>
        public string Status { get; set; }

        /// <summary>
        /// 审批时间
        /// </summary>
        public DateTime OpTime { get; set; }

        /// <summary>
        /// 审批人员
        /// </summary>
        public string AppUser { get; set; }

        /// <summary>
        /// 是否当前节点
        /// </summary>
        public bool isCurrent { get; set; }


    }
}
