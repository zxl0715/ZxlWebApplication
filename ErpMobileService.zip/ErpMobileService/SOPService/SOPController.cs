﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Web.Http;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

namespace SOPService
{
    public class SOPController : ApiController
    {
        MobileSOP.MobileSOPSoapClient mobileSOPSoapClient = new MobileSOP.MobileSOPSoapClient();

        /// <summary>
        /// 获取待审批列表_数据  
        /// </summary>
        /// <param name="p_sPersonCode"></param>
        /// <param name="p_pageIndex"></param>
        /// <param name="p_pageSize"></param>
        /// <param name="p_where"></param>
        /// <returns></returns>
        public System.Data.DataSet GetUnAppListData(string p_sPersonCode, string p_sPersonCodeDep, int p_pageIndex, int p_pageSize, string p_where)
        {
            return mobileSOPSoapClient.GetUnAppListData(p_sPersonCode, p_sPersonCodeDep, p_pageIndex, p_pageSize, p_where);
        }
        /// <summary>
        /// 获取已审批列表_数据
        /// </summary>
        /// <param name="p_sPersonCode"></param>
        /// <param name="p_pageIndex"></param>
        /// <param name="p_pageSize"></param>
        /// <param name="p_where"></param>
        /// <returns></returns>
        public System.Data.DataSet GetYetAppListData(string p_sPersonCode, string p_sPersonCodeDep, int p_pageIndex, int p_pageSize, string p_where)
        {
            return mobileSOPSoapClient.GetYetAppListData(p_sPersonCode, p_sPersonCodeDep, p_pageIndex, p_pageSize, p_where);
        }
        /// <summary>
        /// 获取单据明细信息，返回DataTable数据类型
        /// </summary>
        /// <param name="p_autoCode"></param>
        /// <returns></returns>
        public SOPService.MobileSOP.ApplayDetailData GetDetialInfoData(string p_autoCode)
        {
            return mobileSOPSoapClient.GetDetialInfoData(p_autoCode);
        }

        /// <summary>
        /// 测试获取单据明细信息 单据编码：814059
        /// </summary>
        /// <returns></returns>
        public System.Data.DataSet GetDataTableInfo()
        {
            return mobileSOPSoapClient.GetDataTableInfo();
        }

        /// <summary>
        /// 单据节点处理
        /// </summary>
        /// <param name="applayCode"></param>
        /// <param name="clickName"></param>
        /// <param name="code"></param>
        /// <param name="p_userid"></param>
        /// <param name="p_userdept"></param>
        /// <returns></returns>
        [HttpGet]
        [HttpPost]
        public string AppalyNodeApprove(string applayCode, string clickName, string first, string code, string remark, string p_userid, string p_userdept)
        {
            if (string.IsNullOrEmpty(remark))
                remark = "";
            return mobileSOPSoapClient.AppalyNodeApprove(applayCode, clickName, first, code, remark, p_userid, p_userdept);
        }
        /// <summary>
        /// 获取待审批的数据统计 
        /// </summary>
        /// <param name="p_sPersonCode"></param>
        /// <returns></returns>
        public string GetUnApproveCount(string p_sPersonCode)
        {
            return mobileSOPSoapClient.GetUnApproveCount(p_sPersonCode);
        }

        /// <summary>
        /// 获取已审批的数据统计 
        /// </summary>
        /// <param name="p_sPersonCode"></param>
        /// <returns></returns>
        public string GetYetApproveCount(string p_sPersonCode)
        {
            return mobileSOPSoapClient.GetYetApproveCount(p_sPersonCode);
        }
        /// <summary>
        /// 表单作废
        /// </summary>
        /// <param name="p_pageCode"></param>
        /// <param name="p_formCode"></param>
        /// <param name="p_sPersonCode"></param>
        /// <returns></returns>
        [HttpGet]
        [HttpPost]
        public string FormFlowCancle(string p_pageCode, string p_formCode, string p_sPersonCode)
        {
            return mobileSOPSoapClient.FormFlowCancle(p_pageCode, p_formCode, p_sPersonCode);
        }
        /// <summary>
        /// 判断是否存在审批节点申请延单     /// </summary>
        /// <param name="p_pageCode"></param>
        /// <param name="p_voucherCode"></param>
        /// <param name="p_nodeCode"></param>
        /// <param name="p_personCode"></param>
        /// <returns></returns>
        [HttpGet]
        [HttpPost]
        public string ExistFormFlowApproveNodeDelay(string p_pageCode, string p_voucherCode, string p_nodeCode, string p_personCode)
        {
            return mobileSOPSoapClient.ExistFormFlowApproveNodeDelay(p_pageCode, p_voucherCode, p_nodeCode, p_personCode);
        }
        /// <summary>
        /// 进行延单操作 
        /// </summary>
        /// <param name="p_lVoucherCode"></param>
        /// <param name="p_lFormCode"></param>
        /// <param name="p_sPersonCode"></param>
        /// <param name="p_sDeptCode"></param>/// <param name="p_nodeCode"></param>
        /// <param name="p_dEditTime"></param>
        /// <param name="p_delayTime"></param>
        /// <param name="p_delayReason"></param>
        /// <param name="p_delayFormCC_Code"></param>
        /// <param name="p_delayFormCC_Name"></param>
        /// <returns></returns>
        [HttpGet]
        [HttpPost]
        public string FromFlowApproveNodeDelay(string p_lVoucherCode, string p_lFormCode, string p_sPersonCode, string p_sDeptCode, string p_nodeCode, string p_dEditTime, string p_delayTime, string p_delayReason, string p_delayFormCC_Code, string p_delayFormCC_Name)
        {
            return mobileSOPSoapClient.FromFlowApproveNodeDelay(p_lVoucherCode, p_lFormCode, p_sPersonCode, p_sDeptCode, p_nodeCode, p_dEditTime, p_delayTime, p_delayReason, p_delayFormCC_Code, p_delayFormCC_Name);
        }
 
    }
}
