﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using Nd.Erp.Mobile.Service.Common;
using Nd.Erp.Mobile;
using System.Data;
using System.Data.SqlClient;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

namespace TestPrj
{
    class Program
    {
        public static int GetInt(string name) {
            return 0;
        }

        public static string GetString(int i) {
            return i.ToString();
        }
        static void Main(string[] args)
        {
            //new LoginCheck().GetPersonInfo("34567");
            //LoginCheck chk = new LoginCheck();
            //chk.CheckPower("812506", "4c5ee20a16c8112b742f236397816509");
            //chk.GetPersonInfo("34567");
            //chk.GetAccountData();
              Dictionary<string, string> columns = new Dictionary<string, string>();
            IDataRecord dataRecord = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, "select 1 as a,2 as b", null);
            var a = new object();
            if (columns.ContainsKey("aa"))
            {
                a=dataRecord["aa"];
            }
               
            Host ht = new Host();
            ht.Start();
            Console.ReadLine();
            ht.Stop();
            Console.WriteLine("服务启动成功...");
            Console.ReadLine();
            
        }





    }
}
