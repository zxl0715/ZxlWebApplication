﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Windows.Forms;

namespace Monitor
{
    class Program
    {
        static void Main(string[] args)
        {

            
            HttpClient client = new HttpClient();

            while (true)
            {
                client.GetStringAsync("http://121.207.254.37:8732/ServiceHost/LoginCheck/json/CheckPowerWithPersonInfo?spersoncode=924450&spassword=4c5ee20a16c8112b742f236397816509&deviceUUIDHash=e0e27b135268194c1e3c6c491a598f1b4470c81d&deviceName=MEIZU+MX&osType=android&sdkVersion=10").ContinueWith(
                    getTask =>
                    {
                        if (getTask.IsCanceled||getTask.IsFaulted)
                        {
                            MessageBox.Show("访问服务器失败，请启动服务");
                        }
                        else
                        {
                            Console.WriteLine("服务运行正常: {0}", DateTime.Now);
                        }
                    });

                Thread.Sleep(15*60000);
            }
            Console.ReadLine();
        }
    }
}
