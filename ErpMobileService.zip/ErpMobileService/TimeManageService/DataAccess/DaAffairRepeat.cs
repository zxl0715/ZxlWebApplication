﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.Utility;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    public class DaAffairRepeat
    {

        #region 获取重复周期事件详情列表
        /// <summary>
        /// 获取重复周期事件详情列表
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="beginTime">开始日期</param>
        /// <param name="endTime">结束日期</param>
        /// <returns></returns>
        public List<EnAffairMemoRepeat> GetList(string userID, DateTime beginTime, DateTime endTime)
        {
            SqlParameter[] param = {
                                    new SqlParameter("@userId", userID),
                                    new SqlParameter("@BeginDate", beginTime),
                                    new SqlParameter("@endDate", endTime)
                                };

            IDataReader dr = null;
            List<EnAffairMemoRepeat> list = new List<EnAffairMemoRepeat>();
            string spName = "TM_spAffairRepeat_GetByUserAndTime";

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                while (dr.Read())
                {
                    EnAffairMemoRepeat obj = new EnAffairMemoRepeat();

                    EnAffair affair = new EnAffair();
                    EnAffairRepeat affairRepeat = new EnAffairRepeat();
                    string typeCode = dr["TypeCode"].ToString();

                    if (TMCommon.CheckIsType(typeCode, TMType.SendMeetingBespeak, TMType.InceptMeetingBespeak))
                    {
                        continue;
                    }

                    affair.IsMemoAvailability = Convert.ToInt32(dr["IsMemoAvailability"].ToString());


                    if (dr["AffairCode"].ToString() == "" || StrHelper.isNumeric(dr["AffairCode"].ToString()) == false)
                    {
                        continue;
                    }
                    affair.AffairCode = int.Parse(dr["AffairCode"].ToString());


                    if (dr["AffairAssistantCode"].ToString() == "" || StrHelper.isNumeric(dr["AffairAssistantCode"].ToString()) == false)
                    {
                        continue;
                    }
                    affair.AffairAssistantCode = int.Parse(dr["AffairAssistantCode"].ToString());


                    if (dr["RepeatCode"].ToString() == "" || StrHelper.isNumeric(dr["RepeatCode"].ToString()) == false)
                    {
                        continue;
                    }
                    affairRepeat.RepeatCode = int.Parse(dr["RepeatCode"].ToString());


                    #region 活动主体信息

                    affair.Title = dr["Title"].ToString();

                    affair.Address = dr["Address"].ToString();

                    affair.Memo = dr["Memo"].ToString();

                    if (dr["ParentCode"].ToString() != "")
                    {
                        affair.ParentCode = int.Parse(dr["ParentCode"].ToString());
                    }

                    if (dr["UserID"].ToString() != "")
                    {
                        affair.UserID = dr["UserID"].ToString();
                    }

                    if (dr["AgentUserID"].ToString() != "")
                    {
                        affair.AgentUserID = dr["AgentUserID"].ToString();
                    }

                    if (dr["IsRepeat"].ToString() != "")
                    {
                        affair.IsRepeat = int.Parse(dr["IsRepeat"].ToString());
                    }

                    if (dr["IsUsingCheck"].ToString() != "")
                    {
                        affair.IsUsingCheck = int.Parse(dr["IsUsingCheck"].ToString());
                    }

                    if (dr["IsAvailability"].ToString() != "")
                    {
                        affair.IsAvailability = int.Parse(dr["IsAvailability"].ToString());
                    }

                    affair.XMCode = dr["XMCode"].ToString();

                    affair.XMFCode = dr["XMFCode"].ToString();

                    #endregion

                    #region 活动详情信息

                    if (dr["BeginTime"].ToString() != "")
                    {
                        //可约束affair的beginTime类型为DateTime
                        affair.BeginTime = Convert.ToDateTime(dr["BeginTime"].ToString());
                    }

                    if (dr["EndTime"].ToString() != "")
                    {
                        DateTime dtEnd;
                        if (!DateTime.TryParse(dr["EndTime"].ToString(), out dtEnd))
                            dtEnd = new DateTime(2020, 12, 20);
                        affair.EndTime = dtEnd;
                    }

                    if (dr["MemoUserID"].ToString() != "")
                    {
                        affair.MemoUserID = dr["MemoUserID"].ToString();
                    }

                    if (dr["CalendarCode"].ToString() != "")
                    {
                        affair.CalendarCode = int.Parse(dr["CalendarCode"].ToString());
                    }

                    if (dr["ShareType"].ToString() != "")
                    {
                        affair.ShareType = int.Parse(dr["ShareType"].ToString());
                    }

                    if (dr["DruckerType"].ToString() != "")
                    {
                        affair.DruckerType = int.Parse(dr["DruckerType"].ToString());
                    }

                    if (dr["LevelType"].ToString() != "")
                    {
                        affair.LevelType = int.Parse(dr["LevelType"].ToString());
                    }

                    if (dr["IsAffairType"].ToString() != "")
                    {
                        affair.IsAffairType = int.Parse(dr["IsAffairType"].ToString());
                    }

                    affair.TypeCode = dr["TypeCode"].ToString();

                    if (dr["IsRemind"].ToString() != "")
                    {
                        affair.IsRemind = int.Parse(dr["IsRemind"].ToString());
                    }
                    if (dr["IsUsingKpi"].ToString() != "")
                    {
                        affair.IsUsingKpi = int.Parse(dr["IsUsingKpi"].ToString());
                    }

                    if (dr["IsCanEdit"].ToString() != "")
                    {
                        affair.IsCanEdit = int.Parse(dr["IsCanEdit"].ToString());
                    }

                    if (TMCommon.CheckIsType(dr["TypeCode"].ToString(), TMType.InceptCompanyDeadLine))
                    {
                        affair.IsCanEdit = 0;
                    }
                    #endregion

                    #region 重复周期

                    affairRepeat.AffairCode = affair.AffairCode;
                    affairRepeat.UserID = affair.UserID;

                    if (dr["RepeatMode"].ToString() != "")
                    {
                        affairRepeat.RepeatMode = int.Parse(dr["RepeatMode"].ToString());
                    }

                    affairRepeat.RepeatValue = dr["RepeatValue"].ToString();

                    if (dr["RepeatSpace"].ToString() != "")
                    {
                        affairRepeat.RepeatSpace = int.Parse(dr["RepeatSpace"].ToString());
                    }

                    if (dr["BeginDate"].ToString() != "")
                    {
                        affairRepeat.BeginDate = Convert.ToDateTime(dr["BeginDate"].ToString());
                    }

                    if (dr["EndDate"].ToString() != "")
                    {
                        DateTime dtEnd;
                        if (!DateTime.TryParse(dr["EndDate"].ToString(), out dtEnd))
                            dtEnd = new DateTime(2020, 12, 20);
                        affairRepeat.EndDate = dtEnd;
                    }
                    #endregion

                    obj.Affair = affair;
                    obj.AffairRepeat = affairRepeat;
                    list.Add(obj);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                    dr.Dispose();
            }

            return list;
        }
        #endregion



        public EnAffairMemoRepeat GetRepeatAffair(int affairCode)
        {
            SqlParameter[] param = {
                new SqlParameter("@AffairCode", SqlDbType.Int)
            };

            param[0].Value = affairCode;

            IDataReader dr = null;
            EnAffairMemoRepeat obj = new EnAffairMemoRepeat();
            string spName = "TM_spAffairRepeat_GetByAffairCode";

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                dr.Read();

                EnAffair affair = new EnAffair();
                EnAffairRepeat affairRepeat = new EnAffairRepeat();

                if (dr["AffairCode"].ToString() == "" || StrHelper.isNumeric(dr["AffairCode"].ToString()) == false)
                {
                    return null;
                }
                affair.AffairCode = int.Parse(dr["AffairCode"].ToString());

                if (dr["AffairAssistantCode"].ToString() == "" || StrHelper.isNumeric(dr["AffairAssistantCode"].ToString()) == false)
                {
                    return null;
                }
                affair.AffairAssistantCode = int.Parse(dr["AffairAssistantCode"].ToString());

                if (dr["RepeatCode"].ToString() == "" || StrHelper.isNumeric(dr["RepeatCode"].ToString()) == false)
                {
                    return null;
                }
                affairRepeat.RepeatCode = int.Parse(dr["RepeatCode"].ToString());


                #region 活动主体信息

                affair.Title = dr["Title"].ToString();

                affair.Address = dr["Address"].ToString();

                affair.Memo = dr["Memo"].ToString();

                if (dr["ParentCode"].ToString() != "")
                {
                    affair.ParentCode = int.Parse(dr["ParentCode"].ToString());
                }

                if (dr["IsRepeat"].ToString() != "")
                {
                    affair.IsRepeat = int.Parse(dr["IsRepeat"].ToString());
                }

                if (dr["IsAvailability"].ToString() != "")
                {
                    affair.IsAvailability = int.Parse(dr["IsAvailability"].ToString());
                }

                affair.XMCode = dr["XMCode"].ToString();

                affair.XMFCode = dr["XMFCode"].ToString();

                #endregion

                #region 活动详情信息

                if (dr["BeginTime"].ToString() != "")
                {
                    //可约束affair的beginTime类型为DateTime
                    affair.BeginTime = Convert.ToDateTime(dr["BeginTime"].ToString());
                }

                if (dr["EndTime"].ToString() != "")
                {
                    DateTime dtEnd;
                    if (!DateTime.TryParse(dr["EndTime"].ToString(), out dtEnd))
                        dtEnd = new DateTime(2020, 12, 20);
                    affair.EndTime = dtEnd;
                }

                affair.TypeCode = dr["TypeCode"].ToString();

                if (dr["IsRemind"].ToString() != "")
                {
                    affair.IsRemind = int.Parse(dr["IsRemind"].ToString());
                }
                #endregion

                #region 重复周期
                if (dr["RepeatMode"].ToString() != "")
                {
                    affairRepeat.RepeatMode = int.Parse(dr["RepeatMode"].ToString());
                }

                affairRepeat.RepeatValue = dr["RepeatValue"].ToString();

                if (dr["RepeatSpace"].ToString() != "")
                {
                    affairRepeat.RepeatSpace = int.Parse(dr["RepeatSpace"].ToString());
                }

                if (dr["BeginDate"].ToString() != "")
                {
                    affairRepeat.BeginDate = Convert.ToDateTime(dr["BeginDate"].ToString());
                }

                if (dr["EndDate"].ToString() != "")
                {
                    DateTime dtEnd;
                    if (!DateTime.TryParse(dr["EndDate"].ToString(), out dtEnd))
                        dtEnd = new DateTime(2020, 12, 20);
                    affairRepeat.EndDate = dtEnd;
                }
                #endregion

                obj.Affair = affair;
                obj.AffairRepeat = affairRepeat;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                    dr.Dispose();
            }

            return obj;
        }


        #region 根据活动编号，获取重复周期
        /// <summary>
        /// 根据活动编号，获取重复周期
        /// </summary>
        /// <param name="affairCode"></param>
        /// <returns></returns>
        public EnAffairRepeat GetEntity(int affairCode)
        {
            SqlParameter param = new SqlParameter("@AffairCode", affairCode);
            string spName = "TM_spAffairRepeat_GetModelByAffairCode";
            IDataReader dr = null;

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);

                IList<EnAffairRepeat> list = DynamicBuilder<EnAffairRepeat>.ConvertToList(dr);
                if (list.Count == 1)
                {
                    return list[0];
                }
                else
                {
                    return null;
                }

            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion
    }
}
