﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using ND.Lib.Data.SqlHelper;
using ND.Lib.PDec;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.Utility;


namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    class DaWorkLog
    {
        #region 获取时间表一键转日志所需要的ERP数据
        /// <summary>
        /// 获取时间表一键转日志所需要的ERP数据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="logDate">日志日期</param>
        /// <returns></returns>
        public DataSet getWorkLogData(string userID, string logDate)
        {
            DateTime date = Convert.ToDateTime(logDate);

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select a.code, (select sum(z.lTimeNum) from X5_YtaskNumbers z where z.code=a.code) as oldTotalHour from X5_YtaskNumber a where a.sPersonCode=@userid and a.dGdate=@logDate ");
            strSql.Append("select a.sPersonName, b.sDepCode, b.sDepName from A5_CWPerson as a, A5_Wdepartmentcls as b where a.sDepCode=b.sDepCode and a.sPersonCode=@userid ");
            strSql.Append("select 1 as logSet, isNull(a.bTaskExtend, 0) as bTaskExtend, isNull(a.bTaskExtNoUrl, 0) as bTaskExtNoUrl, isnull(a.bTaskPre,0) as bTaskPre from A0_RzDepSet as a, A5_CWPerson as b where a.sDepCode=b.sDepCode and b.sPersonCode=@userid and convert(char(10),getdate(),120)>a.dLogSetDate ");
            strSql.Append("select dEDate from a5_wKqMonth where sYear=@year and sMonth=@month ");
            strSql.Append("select convert(char(10), dFDate, 120) as dFDate from I1_glmend where isNull(bFlag_Rz, 0)=1 and sYear=@year and lPeriod=@month ");
            strSql.Append("select sKqCode from K1_wHolidayset where dDate=@logDate and sKQCode in ('03','04') ");
            strSql.Append("select b.lcode, b.sMeetCode, b.sTaskExplain from X5_YtaskNumber a, X5_YtaskNumbers b where a.code=b.code and a.sPersonCode=@userid and a.dGDate=@logDate ");
            strSql.Append("select count(*) from K1_wTurnResult where dDate between @logDate and '" + DateTime.Today.AddDays(-1).ToString("yyyy-MM-dd") + "' and sPersoncode=@userid and sDateType='01' ");

            SqlParameter[] param = {
                new SqlParameter("@userid", userID),
                new SqlParameter("@logDate", logDate),
                new SqlParameter("@year", date.Year),
                new SqlParameter("@month", date.Month)
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), param);

            return ds;
        }
        #endregion

        #region 一键转日志
        /// <summary>
        /// 一键转日志
        /// </summary>
        /// <param name="work">日志实体</param>
        /// <param name="oldLogData">旧的日志数据</param>
        public bool insertWorkLog(EnWorkLog work, DataTable oldLogData)
        {
            StringBuilder sqlStr = new StringBuilder();

            //取任务数据
            DataTable dt = new DataTable();
	    if (work.taskCodes != "")
	    {
		    sqlStr.Append("select 'task_'+cast(a.code as varchar), ");
		    sqlStr.Append("a.sOuPersonCode, a.sPersonCode, a.sXmName, a.sDepCode, ");
		    sqlStr.Append("(select count(b.code) from X5_WPeopleOrder as b where a.code=b.code and b.sPersoncode=b.sOuPersonCode), ");  //自己给自己下单？
		    sqlStr.Append("a.smark, a.lType, a.lFCode, a.lcode, a.code, a.lOrderGrade, ");
		    sqlStr.Append("(case when a.lFCode is not null then (select z.sPersoncode from X5_WpeopleOrder as z where z.code=a.lFCode) else (case when a.lType between 1010 and 1011 then (select z.sPersoncode from X5_WPeopleOrder as z where z.code=a.lcode) else '' end) end), ");
		    sqlStr.Append("(case when a.lFCode is not null then (select count(z.code) from X5_WpeopleOrder as z where z.lFCode=a.lFCode and isnull(z.lDel,0)=0 and z.smark not in (20,90,99) and z.code<>a.code) else (select count(z.code) from X5_WpeopleOrder as z where z.lcode=a.lcode and z.lFCode is null and isnull(z.lDel,0)=0 and z.lType between 1010 and 1011 and z.smark not in (20,90,99) and z.code<>a.code) end), ");
		    sqlStr.Append("(select z.sXMName from X5_WpeopleOrder as z where z.code=a.lFCode), ");
		    sqlStr.Append("(select z.sXMName from X5_WpeopleOrder as z where z.code=a.lcode), ");
		    sqlStr.Append("(select count(z.code) from X5_WpeopleOrder as z where z.lFCode=a.code and isnull(z.lDel,0)=0 and z.smark not in (20,90,99)) ");
		    sqlStr.Append("from X5_WpeopleOrder as a where a.code in (" + work.taskCodes + ") ");

                    dt = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr.ToString(), null).Tables[0];
	    }            

            //开始插入日志
            sqlStr = new StringBuilder();

            sqlStr.Append(" declare @code int, @maxdh int, @count int ");
            sqlStr.Append(" BEGIN TRAN T1 ");
            sqlStr.Append(" declare @sdepcode nvarchar(20), @speocode nvarchar(20) ");
            sqlStr.Append(" declare @sfdepcode nvarchar(20), @sfpeocode nvarchar(20) ");

            if (work.code == 0)
            {
                //添加时主表sql语句
                sqlStr.Append(" insert into X5_YtaskNumber (dPDate, dDate, sTyCode, dBDate, sMPeople, sPersoncode, sDepCode, sGwCode, sDepName, dGDate, dMDate, lTotalHour, bIllegal) values (");
                sqlStr.Append("'" + work.date.ToString("yyyy-MM-dd") + "', ");
                sqlStr.Append("Convert(char(10),getdate(),120), ");
                sqlStr.Append("'" + work.logType + "', ");
                sqlStr.Append(work.logType == "正常单据" ? "null, " : "Convert(char(10),getdate(),120), ");
                sqlStr.Append("'" + work.userName + "', ");
                sqlStr.Append("'" + work.userID + "', ");
                sqlStr.Append("'" + work.userDeptCode + "', ");
                sqlStr.Append("null, ");
                sqlStr.Append("'" + work.userDeptName + "', ");
                sqlStr.Append("'" + work.date.ToString("yyyy-MM-dd") + "', ");
                sqlStr.Append("getdate(), ");
                sqlStr.Append(work.totalHour + ", ");
                sqlStr.Append((work.isIllegal == true ? "1" : "null") + ") ");

                sqlStr.Append(" IF @@ERROR!=0 goto w_err ");
                sqlStr.Append(" select @code=@@IDENTITY ");
                sqlStr.Append(" IF @@ERROR!=0 goto w_err ");
            }
            else
            {
                //修改时主表sql语句
                sqlStr.Append(" select @code = " + work.code + " ");
                sqlStr.Append(" IF @@ERROR!=0 goto w_err ");
                sqlStr.Append(" update X5_YtaskNumber set sLastPeople='" + work.userName + "', sLastDate=getdate(), lTotalHour=" + work.totalHour + " where code=@code ");
                sqlStr.Append(" IF @@ERROR!=0 goto w_err ");
            }

            for (int i = 0, len = work.list.Count; i < len; i++)
            {
                EnWorkLogItem item = work.list[i];

                if (item.type == "1" || item.type == "3")
                {
                    DataRow[] m_tmpRows = oldLogData.Select("sTaskExplain='" + TMCommon.HtmlEncode(item.content) + "'");
                    if (m_tmpRows.Length > 0)
                        continue;
                }
                else if (item.type == "4")
                {
                    DataRow[] m_tmpRows = oldLogData.Select("sMeetCode=" + item.code);
                    if (m_tmpRows.Length > 0)
                        continue;
                }
                else
                {
                    DataRow[] m_tmpRows = oldLogData.Select("lcode=" + item.code);
                    if (m_tmpRows.Length > 0)
                        continue;
                }

                #region 日志子表SQL语句
                //获取数据相关表的行号
                int num = 0; 
                foreach (DataRow row in dt.Rows)
                {
                    if (row[10].ToString() == item.taskCode) 
                        break;
                    num++;
                }
                //开发时，测试数据和正式数据混在一起，其中一个库可能不存在另一个库的数据
                if (num >= dt.Rows.Count)
                    continue;

                sqlStr.Append(" insert into X5_YtaskNumbers (code,");
                sqlStr.Append("sTitle,");
                sqlStr.Append("sMeetCode,");
                sqlStr.Append("sPlanCode,");
                sqlStr.Append("sXMFCode,");
                sqlStr.Append("sXMCode,");
                sqlStr.Append("sDepCode,");
                sqlStr.Append("sTaskExplain,");
                sqlStr.Append("lPercent,");
                sqlStr.Append("bFinish,");
                sqlStr.Append("lcode,");
                sqlStr.Append("lpcode,");
                sqlStr.Append("sFettle,");
                sqlStr.Append("sState,");
                sqlStr.Append("lXMPercent,");
                sqlStr.Append("bsOutDate,");
                sqlStr.Append("bfOutDate,");
                sqlStr.Append("sTaskspersoncode,");
                sqlStr.Append("sUrl,");
                sqlStr.Append("sUrlTemp,");
                sqlStr.Append("sMemo,");
                sqlStr.Append("lTimeNum");
                sqlStr.Append(") values (");
                sqlStr.Append("@code, ");

                //日志标题
                if (item.type == "4")
                {
                    sqlStr.Append("'来自会议系统的日志', '" + item.code + "', ");
                }
                else
                {
                    if (item.type == "1" || item.type == "3" || num >= dt.Rows.Count)
                        sqlStr.Append("null, null, ");
                    else
                        sqlStr.Append("'" + dt.Rows[num][3].ToString().Replace("'", "''") + "', null, ");
                }

                sqlStr.Append("'01', ");
                sqlStr.Append("'" + item.xmFCode + "', ");
                sqlStr.Append("'" + item.xmCode + "', ");
                sqlStr.Append("'" + item.depCode + "', ");
                sqlStr.Append("'" + TMCommon.HtmlEncode(item.content) + "', ");
                if (work.isHour == true)
                    sqlStr.Append((work.totalHour == 0 || item.hour == 0) ? "null, " : ((item.hour * 100 / work.totalHour).ToString() + ", "));
                else
                    sqlStr.Append((item.percent == 0) ? "null, " : item.percent.ToString() + ", ");
                sqlStr.Append((item.hour != 0 || item.percent != 0) ? "1, " : "0, ");

                if (item.type == "1")
                    sqlStr.Append("null, null, ");
                else if (item.type == "2")
                    sqlStr.Append(item.code + ", null, ");
                else
                    sqlStr.Append("null, " + item.code + ", ");

                //任务状态
                if (item.state.Length == 2)
                    sqlStr.Append("'" + item.state + "', null, ");
                else
                    sqlStr.Append("'" + item.state.Substring(0, 2) + "', '" + item.state + "', ");

                //任务进度
                sqlStr.Append(item.xmPercent == 0 ? "null, " : (item.xmPercent + ", "));
                sqlStr.Append("null, null, ");

                //下单人
                if (item.type == "1" || item.type == "3" || item.type == "4")
                    sqlStr.Append("null, ");
                else
                    sqlStr.Append("'" + dt.Rows[num][2].ToString() + "', ");

                string m_urlStr = ""; //url链接地址字符串
                if (item.url.Trim() == "")
                    sqlStr.Append("null, null, ");
                else
                {
                    sqlStr.Append("'" + TMCommon.HtmlEncode(item.url) + "', ");
                    string m_tempstr = "";
                    m_urlStr = "'";
                    string[] m_arr = TMCommon.DBC2SBC(item.url).Split(';');
                    if (m_arr.Length > 0)
                    {
                        for (int j = 0; j <= m_arr.GetUpperBound(0); j++)
                        {
                            m_tempstr = TMCommon.HtmlEncode(m_arr[j]);
                            if (m_arr[j].IndexOf("www") > 0)
                            {
                                if (m_arr[j].IndexOf("http") > 0)
                                    m_urlStr += "<a class=\"Acss\" target=\"_blank\" href=\"" + m_tempstr + "\">" + m_tempstr + "</a><br>";
                                else
                                    m_urlStr += "<a class=\"Acss\" target=\"_blank\" href=\"" + "http://" + m_tempstr + "\">" + "http://" + m_tempstr + "</a><br>";
                            }
                            else
                            {
                                if (m_arr[j].IndexOf("http") == 0)
                                {
                                    m_urlStr += "<a class=\"Acss\" target=\"_blank\" href=\"" + m_tempstr + "\">" + m_tempstr + "</a><br>";
                                }
                                else
                                {
                                    if (m_arr[j].IndexOf(".") > 0 && m_arr[j].IndexOf("\\") > 0)
                                        m_urlStr += "<a class=\"Acss\" target=\"_blank\" href=\"" + "http://" + m_tempstr + "\">" + "http://" + m_tempstr + "</a><br>";
                                    else
                                        m_urlStr += "<a class=\"Acss\" target=\"_blank\" href=\"" + m_tempstr + "\">" + m_tempstr + "</a><br>";
                                }
                            }
                        }
                    }
                    m_urlStr += "'";
                    sqlStr.Append((m_urlStr == "" ? "null" : m_urlStr.Substring(0, m_urlStr.Length - 5) + "'") + ", ");
                }

                sqlStr.Append(item.memo == "" ? "null, " : "'" + TMCommon.HtmlEncode(item.memo) + "', ");

                if (work.isHour)
                    sqlStr.Append(item.hour == 0 ? "null" : item.hour + ") ");
                else
                    sqlStr.Append("null) ");

                sqlStr.Append(" IF @@ERROR!=0 goto w_err ");

                #endregion

                //如果是自己增行的日志 或 时间管理 或 任务已经结单，跳出继续循环
                if (item.type == "1" || item.type == "3" || item.type == "4" || dt.Rows[num][6].ToString() == "99" || dt.Rows[num][6].ToString() == "55") 
                    continue;

                #region 修改任务状态
                //如果是任务单据，并且有填任务进度
                if (item.type == "2" && item.xmPercent != 0)
                {
                    //任务进度反馈
                    if (dt.Rows[num][6].ToString() != "60" && dt.Rows[num][6].ToString() != "90")
                    {
                        sqlStr.Append(" insert into X5_YPeopleFeedback(lcode,lXMPercent,sPersoncode,dFdate,dGdate,sFettle,sState,sMemo,sUrl,sUrlTemp,sMpeople) values (");
                        sqlStr.Append(dt.Rows[num][10].ToString() + ", ");
                        sqlStr.Append(item.xmPercent + ", ");
                        sqlStr.Append("'" + work.userID + "', ");
                        sqlStr.Append("getdate(), ");
                        sqlStr.Append("'" + work.date.ToString("yyyy-MM-dd") + "', ");
                        if (item.state.Length == 2)
                            sqlStr.Append("'" + item.state + "', null, ");
                        else
                            sqlStr.Append("'" + item.state.Substring(0, 2) + "', '" + item.state + "', ");
                        sqlStr.Append("'从日志系统反馈进度', ");
                        if (item.url == "")
                            sqlStr.Append("null, null, ");
                        else
                            sqlStr.Append("'" + TMCommon.HtmlEncode(item.url) + "', " + (m_urlStr == "" ? "null" : m_urlStr.Substring(0, m_urlStr.Length - 5) + "'") + ", ");
                        sqlStr.Append("'" + work.mPeople + "') \n");
                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                    }

                    //如果今天完成任务，任务单还没标识完成(smark!=60)
                    if (item.state == "60" && item.xmPercent == 100 && dt.Rows[num][6].ToString() != "60")
                    {
                        sqlStr.Append(" update X5_WPeopleOrder set lXMPercent=100, smark='60' where code=" + dt.Rows[num][10].ToString() + " \n");
                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                    }
                    else if (work.logType == "正常单据")
                    {
                        //如果任务单已经标识完成(smark==60)，但今天填写的任务进度又不等于100%
                        if (dt.Rows[num][6].ToString() == "60" && item.xmPercent != 100)
                        {
                            sqlStr.Append(" delete from X5_TaskInfo where sMnuCode IN ('18192N','18192M')  and code=" + dt.Rows[num][10].ToString() + " \n");
                            sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                            //清空反馈完成的时间
                            sqlStr.Append("update X5_WPeopleOrder set dFTaskDate=null where code=" + dt.Rows[num][10] + " \n");
                            sqlStr.Append("IF @@ERROR!=0 goto w_err \n");

                            //任务插回在办中
                            sqlStr.Append(" select @sdepcode=sdepcode from a5_wzzzl where spersoncode='" + dt.Rows[num][2].ToString() + "' \n");
                            sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                            sqlStr.Append(" INSERT INTO X5_TaskInfo (sMnuCode, code, sODepCode, sOPersonCode, sIDepCode, sIPersonCode, sTitle, sLinkAdd, dDate, lState, bView) values(");
                            sqlStr.Append("'18192N'," + dt.Rows[num][10].ToString() + ",@sdepcode,'" + dt.Rows[num][2].ToString() + "','" + work.userDeptCode + "','" + work.userID + "','下单系统任务-" + dt.Rows[num][3].ToString() + "','" + "Order/K1_frmPeopleTaskInfo.aspx?code=" + PDesc.Encrypt(dt.Rows[num][10].ToString()) + "',getdate(),1,0) \n");
                            sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                        }

                        string m_tmpState = "";
                        if (item.state.Trim() != "" && item.state.Length > 2) m_tmpState = item.state;
                        sqlStr.Append(" if (select dSTaskDate from X5_WPeopleOrder where code=" + dt.Rows[num][10] + ") is null \n");
                        sqlStr.Append("	update X5_WPeopleOrder set lXMPercent=" + item.xmPercent + ", smark='" + (item.state == "" ? "50" : item.state.Substring(0, 2)) + "', sState=" + (m_tmpState == "" ? "null" : "'" + m_tmpState + "'") + ", dSTaskDate=getDate() where code=" + dt.Rows[num][10] + " \n");
                        sqlStr.Append(" else \n");
                        sqlStr.Append("	update X5_WPeopleOrder set lXMPercent=" + item.xmPercent + ", smark='" + (item.state == "" ? "50" : item.state.Substring(0, 2)) + "', sState=" + (m_tmpState == "" ? "null" : "'" + m_tmpState + "'") + " where code=" + dt.Rows[num][10] + " \n");
                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                    }

                    if (item.state == "60" && item.xmPercent == 100)
                    {
                        #region 如果今天完成任务

                        //任务单还没有标识完成或结单(smark!=60 && smark!=90)
                        if (dt.Rows[num][6].ToString() != "60" && dt.Rows[num][6].ToString() != "90")
                        {
                            //任务完成, 存在未结单的子任务
                            if (dt.Rows[num][16].ToString() != "0")
                            {
                                return false;
                            }
                            //完成任务后，应删除在办工作
                            sqlStr.Append(" delete from X5_TaskInfo where lState=1 and sMnuCode IN ('18192N','18192M','181927') and code=" + dt.Rows[num][10].ToString() + " \n");
                            sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                            //任务分配给自己
                            if (dt.Rows[num][7].ToString() == "1011")
                            {
                                //子任务结单
                                sqlStr.Append(" update X5_WPeopleOrder set dSTaskDate=getdate() where dSTaskDate is null and code=" + dt.Rows[num][10].ToString() + " \n");
                                sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                sqlStr.Append(" update X5_WPeopleOrder set dFTaskDate=getdate() where code=" + dt.Rows[num][10].ToString() + " \n");
                                sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                sqlStr.Append(" update X5_WPeopleOrderView set sMark='90', dEndDate=getdate() where code=" + dt.Rows[num][10].ToString() + " \n");
                                sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                //工作时间表状态更改(后来加上的)
                                sqlStr.Append(" update K5_WorkDistribute set sSCode='90' where lTaskCode=" + dt.Rows[num][10].ToString() + " \n");
                                sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                //插入任务结单的进度反馈
                                sqlStr.Append(" insert into X5_YPeopleFeedback(lcode,lXMPercent,sPersoncode,dFdate,dGdate,sFettle,smemo,sUrl,sUrlTemp,sMpeople) values (");
                                sqlStr.Append(dt.Rows[num][10].ToString() + ", ");
                                sqlStr.Append(item.xmPercent + ", ");
                                sqlStr.Append("'" + work.userID + "', ");
                                sqlStr.Append("getdate(), ");
                                sqlStr.Append("'" + work.date.ToString("yyyy-MM-dd") + "', ");
                                sqlStr.Append("'90', ");
                                sqlStr.Append("'由于该任务是分配给自己，该任务自动结单。', ");
                                if (item.url == "")
                                    sqlStr.Append("null, null, ");
                                else
                                    sqlStr.Append("'" + TMCommon.HtmlEncode(item.url) + "', " + (m_urlStr == "" ? "null" : m_urlStr.Substring(0, m_urlStr.Length - 5) + "'") + ", ");
                                sqlStr.Append("'" + work.mPeople + "') \n");
                                sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                //任务为第一级，除了自己以外还未完成的同级任务数 == 0，向上反馈
                                if (dt.Rows[num][11].ToString() == "1" && dt.Rows[num][13].ToString() == "0")
                                {
                                    //在办工作(订单)
                                    sqlStr.Append(" delete from X5_TaskInfo where sMnuCode='181911' and code=" + dt.Rows[num][9].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //sInDepCode下单部门,sOuDepCode接单部门
                                    sqlStr.Append(" select @sdepcode=sInDepCode,@speocode=sPersoncode,@sfdepcode=sOuDepCode ,@sfpeocode=sOuPersoncode from X5_WPeopleOrder as a where a.code=" + dt.Rows[num][9].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //sOPersonCode发送职员,sIPersonCode接受职员
                                    sqlStr.Append(" delete X5_TaskInfo where sMnuCode='18192L' and code=" + dt.Rows[num][9].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                    sqlStr.Append(" INSERT INTO X5_TaskInfo(sMnuCode, code, sODepCode, sOPersonCode, sIDepCode, sIPersonCode, sTitle, sLinkAdd, dDate, lState, bView) values(");
                                    sqlStr.Append("'18192L'," + dt.Rows[num][9].ToString() + ",@sfdepcode,@sfpeocode,@sdepcode,@speocode,'下单系统订单-请对" + dt.Rows[num][3] + "评分','" + "Order/K1_frmOrderInfo.aspx?code=" + PDesc.Encrypt(dt.Rows[num][9].ToString()) + "',getdate(),0,0) \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //对下单人(订单)进行反馈
                                    sqlStr.Append(" INSERT INTO X5_YOrderMsg (lcode, sPersoncode, lType, dDate, sMemo, sMark,sMpeople) ");
                                    sqlStr.Append("VALUES(");
                                    sqlStr.Append(dt.Rows[num][9].ToString() + ", ");
                                    sqlStr.Append("'" + dt.Rows[num][1].ToString() + "', ");
                                    sqlStr.Append("2, ");
                                    sqlStr.Append("'" + DateTime.Now + "', ");
                                    sqlStr.Append("'系统自动反馈，由于所有子任务结单，把此订单状态设为订单已完成。', ");
                                    sqlStr.Append("'60',"); //订单已完成
                                    sqlStr.Append("'" + work.mPeople + "'");
                                    sqlStr.Append(") \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //订单已完成
                                    //m_ssql+= "同时把订单号为"+s_tabarr.Tables[m_row].Rows[0][1,9]+"的订单设为订单已完成！";
                                    sqlStr.Append(" UPDATE X5_WPeopleOrder SET sMark='60', dFinDate=getdate(), lXMPercent=100 WHERE code=" + dt.Rows[num][9].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                }
                            }
                            else
                            {
                                //简易下单
                                if (dt.Rows[num][7].ToString() == "1030")
                                {
                                    sqlStr.Append(" update X5_WPeopleOrder set dSTaskDate=getdate() where dSTaskDate is null and code=" + dt.Rows[num][10].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                    sqlStr.Append(" update X5_WPeopleOrder set dFTaskDate=getdate() where code=" + dt.Rows[num][10].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                    sqlStr.Append(" update X5_WPeopleOrderView set sMark='90', dEndDate=getdate() where code=" + dt.Rows[num][10].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //工作时间表状态更改(后来加上的)
                                    sqlStr.Append(" update K5_WorkDistribute set sSCode='90' where lTaskCode=" + dt.Rows[num][10].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //插入任务结单的进度反馈
                                    sqlStr.Append(" insert into X5_YPeopleFeedback(lcode,lXMPercent,sPersoncode,dFdate,dGdate,sFettle,smemo,sUrl,sUrlTemp,sMpeople) values (");
                                    sqlStr.Append(dt.Rows[num][10].ToString() + ", ");
                                    sqlStr.Append(item.xmPercent + ", ");
                                    sqlStr.Append("'" + work.userID + "', ");
                                    sqlStr.Append("getdate(), ");
                                    sqlStr.Append("'" + work.date.ToString("yyyy-MM-dd") + "', ");
                                    sqlStr.Append("'90', ");
                                    sqlStr.Append("'由于该任务是简易下单，该任务自动结单。', ");
                                    if (item.url == "")
                                        sqlStr.Append("null, null, ");
                                    else
                                        sqlStr.Append("'" + TMCommon.HtmlEncode(item.url) + "', " + (m_urlStr == "" ? "null" : m_urlStr.Substring(0, m_urlStr.Length - 5) + "'") + ", ");
                                    sqlStr.Append("'" + work.mPeople + "') \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //子任务结单
                                    if (dt.Rows[num][11].ToString() != "1" && dt.Rows[num][13].ToString() == "0")
                                    {
                                        //插入任务结单的进度反馈
                                        sqlStr.Append(" insert into X5_YPeopleFeedback(lcode,lXMPercent,sPersoncode,dFdate,dGdate,sFettle,smemo,sUrl,sUrlTemp,sMpeople) values(");
                                        sqlStr.Append(dt.Rows[num][8].ToString() + ", ");
                                        sqlStr.Append(item.xmPercent + ", ");
                                        sqlStr.Append("'" + work.userID + "', ");
                                        sqlStr.Append("getdate(), ");
                                        sqlStr.Append("'" + work.date.ToString("yyyy-MM-dd") + "', ");
                                        sqlStr.Append("'60', ");
                                        sqlStr.Append("'系统自动反馈，由于所有子任务结单，把此任务状态设为任务已完成。', ");
                                        if (item.url == "")
                                            sqlStr.Append("null, null, ");
                                        else
                                            sqlStr.Append("'" + TMCommon.HtmlEncode(item.url) + "', " + (m_urlStr == "" ? "null" : m_urlStr.Substring(0, m_urlStr.Length - 5) + "'") + ", ");
                                        sqlStr.Append("'" + work.mPeople + "'");
                                        sqlStr.Append(") \n");
                                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                        sqlStr.Append(" update X5_WPeopleOrder set dSTaskDate=getdate() where dSTaskDate is null and code=" + dt.Rows[num][8].ToString() + " \n");
                                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                        sqlStr.Append(" update X5_WPeopleOrder set smark='60', dFTaskDate=getdate(), lXMPercent=100 where code=" + dt.Rows[num][8].ToString() + " \n");
                                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                        sqlStr.Append(" delete from X5_TaskInfo where sMnuCode='18192N' and code=" + dt.Rows[num][8].ToString() + " \n");
                                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                        sqlStr.Append(" select @sdepcode=sdepcode from a5_wzzzl where spersoncode='" + dt.Rows[num][12].ToString() + "' \n");
                                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                        sqlStr.Append(" INSERT INTO X5_TaskInfo (sMnuCode, code, sODepCode, sOPersonCode, sIDepCode, sIPersonCode, sTitle, sLinkAdd, dDate, lState, bView) values(");
                                        sqlStr.Append("'18192M'," + dt.Rows[num][8].ToString() + ",'" + work.userDeptCode + "','" + work.userID + "',@sdepcode,'" + dt.Rows[num][12].ToString() + "','下单系统任务-请对" + dt.Rows[num][14] + "结单','" + "Order/K1_frmPeopleTaskInfo.aspx?code=" + PDesc.Encrypt(dt.Rows[num][8].ToString()) + "',getdate(),0,0) \n");
                                        sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                    }
                                }
                                else
                                {
                                    sqlStr.Append(" select @sdepcode=sdepcode from a5_wzzzl where spersoncode='" + dt.Rows[num][2].ToString() + "' \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                    sqlStr.Append(" INSERT INTO X5_TaskInfo (sMnuCode, code, sODepCode, sOPersonCode, sIDepCode, sIPersonCode, sTitle, sLinkAdd, dDate, lState, bView) values(");
                                    sqlStr.Append("'18192M'," + dt.Rows[num][10].ToString() + ",'" + work.userDeptCode + "','" + work.userID + "',@sdepcode,'" + dt.Rows[num][2].ToString() + "','下单系统任务-请对" + dt.Rows[num][3] + "结单','" + "Order/K1_frmPeopleTaskInfo.aspx?code=" + PDesc.Encrypt(dt.Rows[num][10].ToString()) + "',getdate(),0,0) \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

                                    //子任务结单
                                    sqlStr.Append(" update X5_WPeopleOrder set dSTaskDate=getdate() where dSTaskDate is null and code=" + dt.Rows[num][10].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                    sqlStr.Append(" update X5_WPeopleOrder set dFTaskDate=getdate() where code=" + dt.Rows[num][10].ToString() + " \n");
                                    sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
                                }
                            }
                        }
                        #endregion
                    }
                }
                #endregion
            }

            sqlStr.Append(" declare @newTotalHour float \n");
            sqlStr.Append(" select @newTotalHour=sum(z.lTimeNum) from X5_YtaskNumbers z where z.code=@code");
            sqlStr.Append(" update X5_YtaskNumber set lTotalHour=@newTotalHour where code=@code \n");
            sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
            sqlStr.Append(" update X5_YtaskNumbers set lPercent=lTimeNum/@newTotalHour where code=@code \n");
            sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");

            if (work.taskCodes.Trim() != "")
            {
                sqlStr.Append(" update X5_WPeopleOrder set lWorkHours=(select sum(c.ltimenum) from X5_YtaskNumbers as c where c.lcode=a.code) from X5_WPeopleOrder as a where a.code in (" + work.taskCodes + ") \n");
                sqlStr.Append(" IF @@ERROR!=0 goto w_err \n");
            }

            sqlStr.Append(" select @code as code \n");
            sqlStr.Append(" COMMIT TRAN T1 \n");
            sqlStr.Append(" goto w_end \n");
            sqlStr.Append(" w_err: \n");
            sqlStr.Append("    ROLLBACK TRAN T1 \n");
            sqlStr.Append(" w_end: \n");

            sqlStr.Append(" select @count=count(*) from X5_YtaskNumber where dGDate='" + work.date.ToString("yyyy-MM-dd") + "' and sPersonCode='" + work.userID + "' \n");
            sqlStr.Append(" if (@count > 1 and @code <> 0)\n");
            sqlStr.Append(" begin \n");
            sqlStr.Append("	declare @ddd table (code int) \n");
            sqlStr.Append("	insert into @ddd select lCode from X5_YtaskNumbers where code=@code \n");
            sqlStr.Append("   delete from X5_YtaskNumber where code=@code \n");
            sqlStr.Append("   delete from X5_YtaskNumbers where code=@code \n");
            sqlStr.Append("   delete from X5_YtaskNumberState where lTNCode=@code \n");
            sqlStr.Append("   update X5_WPeopleOrder set lWorkHours=(select sum(c.ltimenum) from X5_YtaskNumbers as c where c.lcode=a.code) from X5_WPeopleOrder a, @ddd b where a.code=b.code \n");
            sqlStr.Append(" end \n");

            DataTable result = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr.ToString(), null).Tables[0];
            if (result != null && result.Rows.Count > 0)
                return true;
            else
                return false;
        }
        #endregion

    }
}
