﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    public class DaUserConfig
    {
        /// <summary>
        /// 获取时间表配置
        /// </summary>
        /// <param name="clockCode"></param>
        /// <returns></returns>
        public EnUserConfig GetConfig(string userID)
        {
            string sqlStr = @" SELECT AutoCode, UserID, LoadMode, BeginTime, EndTime, AddTime, DefaultXm 
                            FROM TM_UserConfig
                            WHERE UserID=@UserID ";

            SqlParameter[] param = new SqlParameter[1] { 
                        new SqlParameter("@UserID", userID) 
            };

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, param);
                IList<EnUserConfig> list = DynamicBuilder<EnUserConfig>.ConvertToList(dr);
               
                if (list != null && list.Count == 1)
                {
                    return list[0];
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
    }
}
