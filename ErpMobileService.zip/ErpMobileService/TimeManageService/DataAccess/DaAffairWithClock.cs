﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.Utility;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    public class DaAffairWithClock
    {
        public DaAffairWithClock()
        { }

        public IList<EnAlarmClock> GetList(string userID, DateTime beginDate, DateTime endDate)
        {
            SqlParameter[] param = {
                new SqlParameter("@userId", SqlDbType.NVarChar, 20),
	            new SqlParameter("@BeginDate", SqlDbType.DateTime),
	            new SqlParameter("@EndDate", SqlDbType.DateTime)
            };

            param[0].Value = userID;
            param[1].Value = beginDate;
            param[2].Value = endDate;

            //正常活动数据
            string spName = "TM_spAlarmClockGetByUserIDAndTime";

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                IList<EnAlarmClock> list = DynamicBuilder<EnAlarmClock>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }

        }

        public IList<EnAffairAssistantWithAlarmClock> GetAffairClock(string codes)
        {
            string strSql = @" SELECT  b.AutoCode, b.AffairAssistantCode, b.AlarmClockCode, b.UserID, b.AddTime
	                           FROM dbo.TM_AffairAssistantWithAlarmClock b left JOIN dbo.TM_AlarmClock a
                               ON a.ClockCode = b.AlarmClockCode
                               WHERE b.AffairAssistantCode in (" + codes + ") ";

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                IList<EnAffairAssistantWithAlarmClock> list = DynamicBuilder<EnAffairAssistantWithAlarmClock>.ConvertToList(dr);
                return list;      
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }

        /// <summary>
        /// 添加事件与闹铃关系
        /// </summary>
        /// <param name="trans">事务对象</param>
        /// <param name="en">事件与闹铃关系对象</param>
        /// <returns>新增编号</returns>
        public int Add(EnAffairAssistantWithAlarmClock affairClock)
        {
            try
            {
                int result = 1;

                SqlParameter[] param ={
                    new SqlParameter("@AutoCode", SqlDbType.Int),
                    new SqlParameter("@AffairAssistantCode", affairClock.AffairAssistantCode),
                    new SqlParameter("@AlarmClockCode", affairClock.AlarmClockCode),
                    new SqlParameter("@userID", affairClock.UserID)           
                };

                param[0].Direction = ParameterDirection.Output;
                string spName = "TM_spAffairAssistantWithAlarmClock_ADD";

                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);

                result = Convert.ToInt32(param[0].Value);

                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
