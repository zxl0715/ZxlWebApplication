﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using ND.Lib.Data.SqlHelper;
using ND.Lib.PDec;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.Utility;


namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    class DaTodoList
    {


        private static string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;
        #region 获取时间表的我的便签数据
        /// <summary>
        /// 获取时间表的我的便签数据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public List<EnTodoEvent> getTodoList(string userID)
        {
            string strSql = @"SELECT Title,ColorType FROM [TM_ToDoList] a WHERE UserID ='"+userID+"' AND  ToDoState < 2 AND a.IsToDoType = 0 ORDER BY OrderIndex desc";
      
            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                List<EnTodoEvent> list = DynamicBuilder<EnTodoEvent>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

       

    }

}
