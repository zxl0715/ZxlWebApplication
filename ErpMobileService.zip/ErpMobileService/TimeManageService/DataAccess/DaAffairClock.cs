﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    public class DaAffairClock
    {
        /// <summary>
        /// 获取闹铃
        /// </summary>
        /// <param name="clockCode"></param>
        /// <returns></returns>
        public EnAffairClock GetEntityByAffairMemoCode(int AffairAssistantCode)
        {
            SqlParameter param = new SqlParameter("@affairMemoCode", SqlDbType.Int, 4);
            param.Value = AffairAssistantCode;

            IDataReader dr = null;
            string spName = "TM_spAlarmClockGetByAffairMemoCode";
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                IList<EnAffairClock> list = DynamicBuilder<EnAffairClock>.ConvertToList(dr);
                if (list != null && list.Count == 1)
                {
                    return list[0];
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
    }
}
