﻿using System;
using System.Collections.Generic;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;


namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    public class DaCalendar
    {
        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;
        /// <summary>
        /// 返回 与userID相关的时间表的日历list
        /// </summary>
        /// <returns></returns>
        public List<EnCalendar> getCalendar(string userID)
        {

            String sqlStr = "select * from TM_Calendar where userID='" + userID + "' and isDelete=0";
            var dr = SqlHelper.ExecuteReader(_sqlCnnStr, CommandType.Text, sqlStr.ToString(), null);
            var result = DynamicBuilder<EnCalendar>.ConvertToList(dr);
            return result;
        }

        /// <summary>
        /// 返回 与userID和日历编号相关的时间表的日历项
        /// </summary>
        /// <returns></returns>
        public EnCalendar getCalendarByCode(string userID,int calendarCode)
        {
            EnCalendar result=null;
            String sqlStr = "select * from TM_Calendar where userID='" + userID + "' and calendarCode="+calendarCode;
            var dr = SqlHelper.ExecuteReader(_sqlCnnStr, CommandType.Text, sqlStr.ToString(), null);
             List<EnCalendar> listResult = DynamicBuilder<EnCalendar>.ConvertToList(dr);
            foreach(var item in listResult){
                result = item;
            }
             
             return result;
        }



    }
}
