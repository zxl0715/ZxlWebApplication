﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    /// <summary>
    /// 会议预约数据层
    /// </summary>
    public class DaAffairMeetingBespeak
    {
        #region 根据活动主表编号获取会议预约
        /// <summary>
        /// 根据活动主表编号获取会议预约
        /// </summary>
        /// <param name="code">活动编号</param>
        /// <returns>预约列表</returns>
        public IList<EnAffairMeetingBespeak> GetAffairMeetingBespeakByAffairCode(int code)
        {
            string strSql = @" SELECT AutoCode, AffairCode, InitiateUserID, InceptUserID, BespeakState, AddTime
	                           FROM TM_AffairMeetingBespeak WHERE AffairCode=@affairCode";

            SqlParameter[] param = {
                new SqlParameter("@affairCode", code)
            };

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, param);
                IList<EnAffairMeetingBespeak> list = DynamicBuilder<EnAffairMeetingBespeak>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion
    }
}
