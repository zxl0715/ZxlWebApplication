﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    public class DaAlarmClock
    {
        public DaAlarmClock()
        { }

        /// <summary>
        /// 新增闹铃
        /// </summary>
        /// <param name="trans">事务对象</param>
        /// <param name="en">实体对象</param>
        /// <returns>新增编号</returns>
        public int Add(EnAlarmClock clock)
        {
            int result = 0;

            SqlParameter[] param = {
				new SqlParameter("@ClockCode", SqlDbType.Int),
				new SqlParameter("@Title", SqlDbType.NVarChar, 500),
				new SqlParameter("@UserID", SqlDbType.NVarChar, 20),
				new SqlParameter("@ClockType", SqlDbType.TinyInt, 1),
				new SqlParameter("@ClockTime", SqlDbType.DateTime),
				new SqlParameter("@RepeatMode", SqlDbType.Int),
				new SqlParameter("@RepeatValue", SqlDbType.NVarChar, 50),
				new SqlParameter("@RepeatBeginDate", SqlDbType.DateTime),
				new SqlParameter("@RepeatEndDate", SqlDbType.DateTime),
				new SqlParameter("@SpaceMinute", SqlDbType.Int),
				new SqlParameter("@SpaceBtime", SqlDbType.DateTime),
				new SqlParameter("@SpaceEtime", SqlDbType.DateTime),
                new SqlParameter("@ClockSource",SqlDbType.Int),
                new SqlParameter("@SourceCode",SqlDbType.NVarChar,20)
            };

            param[0].Direction = ParameterDirection.Output;
            param[1].Value = clock.Title;
            param[2].Value = clock.UserID;
            param[3].Value = clock.ClockType;

            if (clock.ClockTime == DateTime.MinValue)
            {
                param[4].Value = DBNull.Value;
            }
            else
            {
                param[4].Value = clock.ClockTime;
            }


            param[5].Value = clock.RepeatMode;
            param[6].Value = clock.RepeatValue;

            if (clock.RepeatBeginDate == DateTime.MinValue)
            {
                param[7].Value = DBNull.Value;
            }
            else
            {
                param[7].Value = clock.RepeatBeginDate;
            }

            if (clock.RepeatEndDate == DateTime.MinValue)
            {
                param[8].Value = DBNull.Value;
            }
            else
            {
                param[8].Value = clock.RepeatEndDate;
            }

            param[9].Value = clock.SpaceMinute;

            if (clock.SpaceBtime == DateTime.MinValue)
            {
                param[10].Value = DBNull.Value;
            }
            else
            {
                param[10].Value = clock.SpaceBtime;
            }

            if (clock.SpaceEtime == DateTime.MinValue)
            {
                param[11].Value = DBNull.Value;
            }
            else
            {
                param[11].Value = clock.SpaceEtime;
            }

            param[12].Value = clock.ClockSource;
            param[13].Value = clock.SourceCode;

            string spName = "TM_spAlarmClock_ADD";
            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                result = Convert.ToInt32(param[0].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }


        /// <summary>
        /// 获取闹铃
        /// </summary>
        /// <param name="clockCode"></param>
        /// <returns></returns>
        public EnAlarmClock GetEntity(int clockCode)
        {
            SqlParameter param = new SqlParameter("@clockCode", SqlDbType.Int, 4);
            param.Value = clockCode;            

            IDataReader dr = null;
            string spName = "TM_spAlarmClock_Get";
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                IList<EnAlarmClock> list = DynamicBuilder<EnAlarmClock>.ConvertToList(dr);
                if (list != null && list.Count == 1)
                {
                    return list[0];
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        
    }
}
