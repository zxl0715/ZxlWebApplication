﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.Utility;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    public class DaRepeatModel
    {
        #region 获取重复周期实例信息
        /// <summary>
        ///获取重复周期实例信息
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="beginTime">开始日期</param>
        /// <param name="endTime">结束日期</param>
        /// <returns>相关列表集合</returns>
        public IList<EnRepeatModel> GetModelList(string userID, DateTime beginTime, DateTime endTime)
        {
            SqlParameter[] param = {
                                    new SqlParameter("@userId", userID),
                                    new SqlParameter("@BeginDate", beginTime),
                                    new SqlParameter("@endDate", endTime)
                                };

            IDataReader dr = null;
            string spName = "TM_spRepeatModelWithMemoCode_GetListByUserIdAndTime";
                        
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                
                IList<EnRepeatModel> list = DynamicBuilder<EnRepeatModel>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion




        #region 添加重复周期特例关系
        /// <summary>
        /// 添加重复周期特例关系
        /// </summary>
        /// <param name="trans">事务对象</param>
        /// <param name="en">实体对象</param>
        /// <returns>1：成功</returns>
        public int Add(EnRepeatModel model)
        {
            SqlParameter[] param = {
					new SqlParameter("@AutoCode", SqlDbType.Int),
					new SqlParameter("@ModelAffairCode", SqlDbType.Int),
					new SqlParameter("@RepeatCode", SqlDbType.Int),
					new SqlParameter("@UserID", SqlDbType.NVarChar, 20),
					new SqlParameter("@ModelDate", SqlDbType.DateTime)
            };

            param[0].Direction = ParameterDirection.Output;
            param[1].Value = model.ModelAffairCode;
            param[2].Value = model.RepeatCode;
            param[3].Value = model.UserId;
            param[4].Value = model.ModelDate;

            int result = 0;
            string spName = "TM_spRepeatModel_ADD";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                result = Convert.ToInt32(param[0].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        #endregion

        /// <summary>
        ///删除重复周期中由接收者取消的指定日期的预约特例
        /// </summary>
        /// <param name="affaircode">事件编号</param>
        /// <param name="userID">接收者工号</param>
        /// <returns>1:成功,其他失败</returns>
        public int ReSetByAffairCodeAndUserIDAndDate(int affiarCode, EnRepeatModel model)
        {
            try
            {
                int result = 1;

                SqlParameter[] param = {
                    new SqlParameter("@AutoCode", SqlDbType.Int),
                    new SqlParameter("@affaircode", SqlDbType.Int),
                    new SqlParameter("@userID", SqlDbType.NVarChar, 20),
                    new SqlParameter("@modelDate", SqlDbType.DateTime)
                };

                param[0].Direction = ParameterDirection.Output;
                param[1].Value = affiarCode;
                param[2].Value = model.UserId;
                param[3].Value = model.ModelDate.Date;

                string spName = "TM_spRepeatModel_UpdateByAffairCodeAndUserIDAndDate";

                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                result = Convert.ToInt32(param[0].Value);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
    }
}
