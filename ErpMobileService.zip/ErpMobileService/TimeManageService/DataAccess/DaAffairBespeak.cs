﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    /// <summary>
    /// 预约数据层
    /// </summary>
    public class DaAffairBespeak
    {
        #region 预约结果反馈
        /// 预约结果反馈
        /// </summary>
        /// <param name="en">实体编号,事件编号,接收者工号,预约状态</param>
        /// <returns>1：成功</returns>
        public int UpdateState(EnAffairBespeak respeak)
        {
            SqlParameter[] param = {
			    new SqlParameter("@inceptUserID", SqlDbType.BigInt),
			    new SqlParameter("@affairCode", SqlDbType.Int),
                new SqlParameter("@bespeakState", SqlDbType.Int)
            };

            param[0].Value = respeak.InceptUserID;
            param[1].Value = respeak.AffairCode;
            param[2].Value = respeak.BespeakState;

            int result = 0;
            string spName = "TM_spAffairBespeak_UpdateState";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                result = 1;
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        #endregion

        #region 根据接受用户工号和活动从表编号获取预约列表
        /// <summary>
        /// 根据接受用户工号和活动从表编号获取预约列表
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="codes"></param>
        /// <returns></returns>
        public IList<EnAffairBespeak> getAffairBespeak(string userID, string codes)
        {
            string strSql = @" SELECT a.AutoCode, a.AffairCode, a.InitiateUserID, a.InceptUserID, a.BespeakState, a.AddTime
	                           FROM TM_AffairBespeak a left join TM_AffairAssistant b
                               ON a.AffairCode=b.AffairCode
                               WHERE a.InceptUserID='" + userID + "' and b.AffairAssistantCode in (" + codes + ") ";

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                IList<EnAffairBespeak> list = DynamicBuilder<EnAffairBespeak>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

        #region 根据接受用户工号和活动主表编号获取预约
        /// <summary>
        /// 根据接受用户工号和活动主表编号获取预约列表
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="codes"></param>
        /// <returns></returns>
        public EnAffairBespeak getAffairBespeakByAffairCode(string userID, int code)
        {
            string strSql = @" SELECT a.AutoCode, a.AffairCode, a.InitiateUserID, a.InceptUserID, a.BespeakState, a.AddTime
	                           FROM TM_AffairBespeak a WHERE a.InceptUserID='" + userID + "' and a.AffairCode=" + code;

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                IList<EnAffairBespeak> list = DynamicBuilder<EnAffairBespeak>.ConvertToList(dr);
                return list[0];
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

        #region 根据活动主表编号获取预约
        /// <summary>
        /// 根据活动主表编号获取预约
        /// </summary>
        /// <param name="code">活动编号</param>
        /// <returns>预约列表</returns>
        public IList<EnAffairBespeak> getAffairBespeakByAffairCode(int code)
        {
            string strSql = @" SELECT AutoCode, AffairCode, InitiateUserID, InceptUserID, BespeakState, AddTime
	                           FROM TM_AffairBespeak WHERE AffairCode=@affairCode";

            SqlParameter[] param = {
                new SqlParameter("@affairCode", code)
            };

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, param);
                IList<EnAffairBespeak> list = DynamicBuilder<EnAffairBespeak>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion
    }
}
