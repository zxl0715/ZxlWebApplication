﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.Utility;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.TimeManage.DataAccess
{
    /// <summary>
    /// 时间表数据层
    /// </summary>
    public class DaAffair
    {
        #region 根据工号和日期范围获取事件列表
        /// <summary>
        /// 根据工号和日期范围获取事件列表
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="beginTime">开始日期</param>
        /// <param name="endTime">结束日期</param>        
        /// <returns>事件列表</returns>
        public IList<EnAffair> GetList(string userID, DateTime beginTime, DateTime endTime)
        {
            SqlParameter[] param = {
                                    new SqlParameter("@userId", userID),
                                    new SqlParameter("@BeginDate", beginTime),
                                    new SqlParameter("@endDate", endTime)
                                };

            IDataReader dr = null;
            string spName = "TM_spAffairMemo_GetListByUserAndTime";

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                IList<EnAffair> list = DynamicBuilder<EnAffairEx3>.ConvertToList(dr).ConvertAll(a => (EnAffair)a);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

        #region 根据用户ID和活动编号获取唯一实例
        /// <summary>
        /// 根据用户ID和活动编号获取唯一实例
        /// </summary>
        /// <param name="affairCode"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public EnAffair GetEntity(int affairCode, string userID)
        {
            SqlParameter[] param = {
                new SqlParameter("@userId", SqlDbType.NVarChar, 20),
                new SqlParameter("@Affaircode", SqlDbType.Int)
            };

            param[0].Value = userID;
            param[1].Value = affairCode;

            IDataReader dr = null;
            string spName = "TM_spAffairAssistant_GetModelByAffairCodeAndUserID";

            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);

                IList<EnAffair> list = DynamicBuilder<EnAffairEx2>.ConvertToList(dr).ConvertAll(a => (EnAffair)a);
                if (list.Count == 1)
                {
                    return list[0];
                }
                else
                {
                    return null;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

        #region 根据事件主表编号获取事件详情集合
        /// <summary>
        /// 根据事件主表编号获取事件详情集合
        /// </summary>
        /// <param name="trans">事务对象</param>
        /// <param name="affairCode">事件主表编号</param>
        /// <returns>事件详情列表</returns>
        public IList<EnAffair> GetListByAffairCode(int affairCode)
        {
            SqlParameter param = new SqlParameter("@AffairCode", SqlDbType.BigInt);
            param.Value = affairCode;

            IDataReader dr = null;
            string spName = "TM_spAffairAssistant_GetByAffairCode";

            try
            {
                //正常活动数据
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);

                IList<EnAffair> affairlist = DynamicBuilder<EnAffairEx1>.ConvertToList(dr).ConvertAll(a => (EnAffair)a);
                return affairlist;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

        #region 插入活动主表
        /// <summary>
        /// 插入活动主表
        /// </summary>
        /// <param name="affair"></param>
        /// <returns></returns>
        protected internal int AddAffairBody(EnAffair affair)
        {
            SqlParameter[] param = {
		        new SqlParameter("@AffairCode", SqlDbType.Int),
		        new SqlParameter("@Title", affair.Title),
		        new SqlParameter("@Address", affair.Address),
		        new SqlParameter("@Memo", affair.Memo),
		        new SqlParameter("@ParentCode", affair.ParentCode),
		        new SqlParameter("@UserID", affair.UserID),
		        new SqlParameter("@AgentUserID", affair.AgentUserID),
		        new SqlParameter("@IsAvailability", affair.IsAvailability),
		        new SqlParameter("@XMCode", affair.XMCode),
		        new SqlParameter("@XMFCode", affair.XMFCode),
                new SqlParameter("@MeetingPurpose", "")
		    };

            param[0].Direction = ParameterDirection.Output;
            int result = 0;
            string spName = "TM_spAffair_ADD";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                result = Convert.ToInt32(param[0].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        #endregion

        #region 添加事件详情
        /// <summary>
        /// 添加事件详情
        /// </summary>
        /// <param name="trans">事务对象</param>
        /// <param name="en">事件</param>
        /// <returns>新增编号</returns>
        public int AddAffairMemo(EnAffair affair)
        {
            SqlParameter[] param ={
                new SqlParameter("@AffairAssistantCode", SqlDbType.Int),
                new SqlParameter("@AffairCode", affair.AffairCode),
                new SqlParameter("@UserID", affair.UserID),
                new SqlParameter("@BeginTime", affair.BeginTime),
                new SqlParameter("@EndTime", affair.EndTime),
                new SqlParameter("@CalendarCode", 0),
                new SqlParameter("@ShareType", 0),
                new SqlParameter("@DruckerType", 1),
                new SqlParameter("@LevelType", 3),
                new SqlParameter("@IsAffairType", 1),
                new SqlParameter("@IsAvailability", 1),
                new SqlParameter("@IsCanEdit", 1) ,
                new SqlParameter("@TypeCode", affair.TypeCode),
                new SqlParameter("@SourceCode", "0"),
                new SqlParameter("@EventCodeSign", 0),
                new SqlParameter("@EventCodeEditSign", 0),
                new SqlParameter("@EventEditTime", DateTime.Now)
            };

            param[0].Direction = ParameterDirection.Output;
            string spName = "TM_spAffairAssistant_ADD";
            int result = 0;
            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, param);
                result = Convert.ToInt32(param[0].Value);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion

        #region 修改事件详情是否有效状态
        /// <summary>
        /// 修改事件详情是否有效状态
        /// </summary>
        /// <param name="trans"></param>
        /// <param name="en"></param>
        /// <returns></returns>
        public int UpdateIsAvailability(EnAffair affair)
        {
            int result = 0;

            string strSql = @" UPDATE [TM_AffairAssistant]
                                 SET  IsAvailability = @IsAvailability
                               WHERE  AffairAssistantCode = @AffairAssistantCode;";

            SqlParameter[] param = {
                new SqlParameter("@AffairAssistantCode", SqlDbType.Int),
                new SqlParameter("@IsAvailability",SqlDbType.Int) 
            };

            param[0].Value = affair.AffairAssistantCode;
            param[1].Value = affair.IsMemoAvailability;

            try
            {
                result = SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, param);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region 删除事件详情表
        /// <summary>
        /// 删除事件详情表
        /// </summary>
        /// <param name="trans"></param>
        /// <param name="en"></param>
        /// <returns></returns>
        public int DeleteAffairMemo(EnAffair affair)
        {

            int result = 0;

            string strSql = @"if EXISTS( SELECT 1 
                                           FROM TM_AffairAssistant 
                                          WHERE affairassistantcode = @affairMemoCode 
                                            AND userid = @userid )
                                BEGIN
                                  DELETE FROM TM_AffairAssistant
                                         WHERE affairassistantcode = @affairMemoCode 
                                     AND userid = @userid;

                                  DELETE FROM TM_AffairType 
                                        WHERE affairassistantcode = @affairMemoCode; 
                                END ";

            SqlParameter[] param = {
                new SqlParameter("@affairMemoCode", affair.AffairAssistantCode),
                new SqlParameter("@userid",affair.MemoUserID)
            };

            result = SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, param);

            return result;
        }
        #endregion
    }

}
