﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.Common;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.Business;
using Nd.Erp.Mobile.Service.TimeManage.Utility;
using System.Web.Http;

namespace Nd.Erp.Mobile.Service.TimeManage
{

    public class TimeManage : TimeManageController
    {//适配原来WCF
    }
    public class TimeManageController : ApiController, ITimeManageJson
    {
        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;
        private LogMgr<TimeManageController> _logMgr = new LogMgr<TimeManageController>("TMService");
        private ICacheClient _cache = CacheManager.CacheClient;

        /// <summary>
        /// 获取活动简单信息列表
        /// 主要用于客户端查看关注人的活动
        /// 不附带活动的其他详细信息，如：闹铃数据、特例数据等
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns></returns>
        public List<EnAffair> getEventList(string userID, string beginTime, string endTime)
        {
            var result = new List<EnAffair>();
            var list = BzAffair.GetList(userID, Convert.ToDateTime(beginTime), Convert.ToDateTime(endTime));

            for (int i = 0, len = list.Count; i < len; i++)
            {
                result.Add(list[i]);
            }
            
            result.Sort(BzAffair.SortByBeginTime);
            return result;
        }


        /// <summary>
        /// 获取活动简单信息列表
        /// 主要用于客户端查看关注人的活动
        /// 
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns></returns>
        public List<EnAffairWithCalendar> getEventListWithCalendar(string userID, string beginTime, string endTime)
        {
            var result = new List<EnAffairWithCalendar>();
            var list = BzAffair.GetList(userID, Convert.ToDateTime(beginTime), Convert.ToDateTime(endTime));
            var EnCalendarDic = BzCalcendar.getCalendar(userID).ToDictionary(c=>c.CalendarCode);
            for (int i = 0, len = list.Count; i < len; i++)
            {

                var item = new EnAffairWithCalendar();
                item.Affair=list[i];
                if(EnCalendarDic.ContainsKey(item.Affair.CalendarCode))
                    item.Calendar = EnCalendarDic[item.Affair.CalendarCode];
                result.Add(item);

            }

            result.Sort(BzAffair.SortByBeginTime);
            return result;
        }


        /// <summary>
        /// 获取一段时间中每天是否有活动
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns></returns>
        public string getHasEventList(string userID, string beginTime, string endTime)
        {
            DateTime bTime = Convert.ToDateTime(beginTime);
            bTime = bTime.Date;
            DateTime eTime = Convert.ToDateTime(endTime);
            eTime = eTime.Date;
            TimeSpan ts = eTime - bTime;
            int[] status = new int[(int)ts.TotalDays + 1];

            for (int i = 0, len = status.Length; i < len; i++)
                status[i] = 0;

            List<EnAffair> list = getEventList(userID, beginTime, endTime);
            foreach (EnAffair affair in list)
            {
                ts = affair.BeginTime.Date - bTime;
                if ((int)ts.TotalDays < status.Length)
                    status[(int)ts.TotalDays] = 1;
            }

            string result = "";
            for (int i = 0, len = status.Length; i < len; i++)
                result += status[i] + ",";
            if (result.Length > 0)
                result = result.Substring(0, result.Length - 1);

            return result;
        }

        /// <summary>
        /// 获取活动详细信息
        /// </summary>
        /// <param name="affairCode">活动号</param>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public EnAffair getEventEntity(string userID, string affairCode)
        {
            return BzAffair.GetEntity(Convert.ToInt32(affairCode), userID);
        }
        
        /// <summary>
        /// 获取活动详细信息列表
        /// 主要用于客户端获取或同步登录用户的前后几周的活动数据，保存到本地数据库
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        public EnTwoWeekAffair getAffairs(string userID, string beginTime, string endTime)
        {
            var key = "EnTwoWeekAffair_" + userID+"_"+beginTime+"_"+endTime;
            var latestSyncCodeKey = "latestSyncCodeKey_" + userID;
            var affairs = _cache.Get<EnTwoWeekAffair>(key);
            var syncCode = _cache.Get<int>(latestSyncCodeKey);
            var lastestSync= BzMobileSyncServer.GetLasteastOneMonthMobileSyncServerListInCacheByUserCode(userID);
            var lastestSyncCode =0;
            if (lastestSync!=null&&lastestSync.Any())
                 lastestSyncCode=lastestSync.Max(l => l.lSyncMainCode);
            if (affairs == null || syncCode < lastestSyncCode)
            {
                affairs = BzAffair.getAffairs(userID, Convert.ToDateTime(beginTime), Convert.ToDateTime(endTime));
                TimeSpan cacheTime=new TimeSpan(hours: 1, minutes: 0, seconds: 0);
                _cache.Set(key, affairs, cacheTime);
                _cache.Set(latestSyncCodeKey, lastestSyncCode, cacheTime);
            }

            return affairs;
        }

        /// <summary>
        /// 获取活动的闹钟数据
        /// </summary>
        /// <param name="codes">活动编号, 逗号隔开</param>
        /// <returns></returns>
        public List<EnAffairClock> getAffairClockListByAffairCodes(string codes)
        {
            List<EnAffairClock> result = new List<EnAffairClock>();
            IList<EnAffairClock> list = BzAffairWithClock.GetAffairClock(codes);

            for (int i = 0, len = list.Count; i < len; i++)
            {
                result.Add(list[i]);
            }

            return result;
        }

        /// <summary>
        /// 获取某个活动的详细信息
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="affairCode">活动编号</param>
        /// <returns></returns>
        public EnAffairDetail getAffairDetail(string userID, string affairCode)
        {
            return BzAffair.GetAffairDetail(userID, Convert.ToInt32(affairCode));
        }

        /// <summary>
        /// 获取活动详细信息
        /// </summary>
        /// <param name="code">活动编号</param>
        /// <returns></returns>
        public EventEntity getEventDetailInfo(string code)
        {
            StringBuilder sqlStr = new StringBuilder();
            sqlStr.Append("select a.AffairCode, a.Title, b.BeginTime, b.EndTime, a.Address, a.XMFCode, a.XMCode, a.Memo, ");
            sqlStr.Append("(select z.sXMName from A5_WXMcls z where z.sXMCode=a.XMFCode) as XMFName, ");
            sqlStr.Append("(select z.sXMName from A5_WXMcls z where z.sXMCode=a.XMCode) as XMName, ");
            sqlStr.Append("(select top 1 z.ClockTime from TM_AlarmClock z, TM_AffairAssistantWithAlarmClock x where z.ClockCode=x.alarmClockCode and x.AffairAssistantCode=b.AffairAssistantCode) as clockTime ");
            sqlStr.Append("from TM_Affair a inner join TM_AffairAssistant b on a.AffairCode=b.AffairCode ");
            sqlStr.Append("where a.AffairCode=@code");

            SqlParameter[] arPara = new SqlParameter[1];
            arPara[0] = new SqlParameter("@code", code);

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr.ToString(), arPara).Tables[0];

            if (dt != null && dt.Rows.Count > 0)
            {
                DataRow dr = dt.Rows[0];
                EventEntity obj = new EventEntity();

                obj.code = dr["AffairCode"].ToString();
                obj.title = dr["Title"].ToString();
                obj.startTime = dr["BeginTime"].ToString();
                obj.endTime = dr["EndTime"].ToString();
                obj.clockTime = dr["clockTime"].ToString();
                obj.address = dr["Address"].ToString();
                obj.XMFCode = dr["XMFCode"].ToString();
                obj.XMCode = dr["XMCode"].ToString();
                obj.XMFName = dr["XMFName"].ToString();
                obj.XMName = dr["XMName"].ToString();
                obj.memo = dr["Memo"].ToString();
                
                return obj;
            }
            else
                return null;
        }

        /// <summary>
        /// 新增简单活动
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="title">主题</param>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <param name="address">地点</param>
        /// <param name="XmCode">项目编号(一级项目和二级项目用‘-’号隔开)</param>
        /// <param name="memo">备注</param>
        /// <param name="alarm">是否闹铃</param>
        /// <param name="alarmTime">闹铃时间</param>
        /// <returns></returns>
        [HttpGet]
        public string addSimpleEvent(string userID, string title, string startTime, string endTime, string address, string XmCode, string memo, string alarm, string alarmTime)
        {
            string affairCode = "0";
            string sXmFCode = XmCode.Split('-')[0];
            string sXmCode = XmCode.Split('-')[1];
            startTime = startTime.Replace("$", " ");
            endTime = endTime.Replace("$", " ");
            memo = (memo??"").Replace("$", " ");


            SqlConnection conn = new SqlConnection(_sqlCnnStr);
            conn.Open();

            SqlTransaction tran = conn.BeginTransaction();

            try
            {
                //主表
                SqlParameter[] arPara = new SqlParameter[]{
                    new SqlParameter("@AffairCode", SqlDbType.Int) 
                        { Value = 0 },
                    new SqlParameter("@Title", SqlDbType.NVarChar, 200) 
                        { Value = title },
                    new SqlParameter("@Address", SqlDbType.NVarChar, 200) 
                        { Value = address },
                    new SqlParameter("@Memo", SqlDbType.NVarChar, 8000) 
                        { Value = memo },
                    new SqlParameter("@ParentCode", SqlDbType.Int) 
                        { Value = 0 },
                    new SqlParameter("@UserID", SqlDbType.NVarChar, 20) 
                        { Value = userID },
                    new SqlParameter("@AgentUserID", SqlDbType.NVarChar, 20) 
                        { Value = "" },
                    new SqlParameter("@IsAvailability", SqlDbType.TinyInt) 
                        { Value = 1 },
                    new SqlParameter("@XMCode", SqlDbType.NVarChar, 20)
                        { Value = sXmCode },
                    new SqlParameter("@XMFCode", SqlDbType.NVarChar, 20)
                        { Value = sXmFCode },
                    new SqlParameter("@MeetingPurpose", SqlDbType.NVarChar, 500)
                        { Value = "" }
                };

                string proName = "TM_spAffair_ADD";
                arPara[0].Direction = ParameterDirection.Output;
                SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                affairCode = arPara[0].Value.ToString();

                //活动详细表
                arPara = new SqlParameter[]{
                    new SqlParameter("@AffairAssistantCode", SqlDbType.Int) 
                        { Value = 0 },
                    new SqlParameter("@AffairCode", SqlDbType.Int)
                        { Value = Convert.ToInt32(affairCode) },
                    new SqlParameter("@UserID", SqlDbType.NVarChar, 20)
                        { Value = userID },
                    new SqlParameter("@BeginTime", SqlDbType.DateTime)
                        { Value = Convert.ToDateTime(startTime) },
                    new SqlParameter("@EndTime", SqlDbType.DateTime)
                        { Value = Convert.ToDateTime(endTime) },
                    new SqlParameter("@CalendarCode", SqlDbType.Int) 
                        { Value = 0 },
                    new SqlParameter("@ShareType", SqlDbType.TinyInt) 
                        { Value = 0 },                                                  //0 自己； 1 任何人；  2 部门；
                    new SqlParameter("@DruckerType", SqlDbType.TinyInt)
                        { Value = 1 },                                                  //1 一定要我才能做好；   2 可以让人代我做；  3 没有效益却又不得不做
                    new SqlParameter("@LevelType", SqlDbType.TinyInt)
                        { Value = 3 },                                                  //1 不紧急不重要； 2 紧急不重要；    3 正常；   4 重要不紧急；    5 紧急重要；
                    new SqlParameter("@IsAffairType", SqlDbType.TinyInt) 
                        { Value = 0 },                                                  //0 无标识；    1 有标识；
                    new SqlParameter("@IsAvailability", SqlDbType.TinyInt)
                        { Value = 1 },                                                  //0 无效； 1 有效；
                    new SqlParameter("@IsCanEdit", SqlDbType.TinyInt)
                        { Value = 1 },                                                  //1 完全修改；   0 部分修改；
                    new SqlParameter("@TypeCode", SqlDbType.NVarChar, 100)
                        { Value = "0" },
                    new SqlParameter("@SourceCode", SqlDbType.NVarChar, 50)
                        { Value = "0" },
                    new SqlParameter("@EventCodeSign", SqlDbType.TinyInt) 
                        { Value = 0 },
                    new SqlParameter("@EventCodeEditSign", SqlDbType.TinyInt) 
                        { Value = 0 },
                    new SqlParameter("@EventEditTime", SqlDbType.DateTime)
                        { Value = DateTime.Now }
                };

                proName = "TM_spAffairAssistant_ADD";
                arPara[0].Direction = ParameterDirection.Output;
                SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                string affairAssistantCode = arPara[0].Value.ToString();

                //闹铃提醒
                if (alarm == "true")
                {
                    DateTime now = DateTime.Now;
                    DateTime time = Convert.ToDateTime(startTime);
                    time = time.AddMinutes(0 - Convert.ToInt32(alarmTime));

                    arPara = new SqlParameter[]{
                        new SqlParameter("@ClockCode", SqlDbType.Int)
                            { Value = 0 },
                        new SqlParameter("@Title", SqlDbType.NVarChar, 500)
                            { Value = title },
                        new SqlParameter("@UserID", SqlDbType.NVarChar, 20)
                            { Value = userID },
                        new SqlParameter("@ClockType", SqlDbType.Int)
                            { Value = 0 },
                        new SqlParameter("@ClockTime", SqlDbType.DateTime)
                            { Value = time },
                        new SqlParameter("@RepeatMode", SqlDbType.Int)
                            { Value = 0 },
                        new SqlParameter("@RepeatValue", SqlDbType.NVarChar, 50)
                            { Value = DBNull.Value },
                        new SqlParameter("@RepeatBeginDate", SqlDbType.DateTime)
                            { Value = now },
                        new SqlParameter("@RepeatEndDate", SqlDbType.DateTime)
                            { Value = now },
                        new SqlParameter("@SpaceMinute", SqlDbType.Int)
                            { Value = 0 },
                        new SqlParameter("@SpaceBtime", SqlDbType.DateTime)
                            { Value = now },
                        new SqlParameter("@SpaceEtime", SqlDbType.DateTime)
                            { Value = now },
                        new SqlParameter("@ClockSource", SqlDbType.Int)
                            { Value = 1 },
                        new SqlParameter("@SourceCode", SqlDbType.NVarChar, 20)
                            { Value = "0" }
                    };

                    proName = "TM_spAlarmClock_ADD";
                    arPara[0].Direction = ParameterDirection.Output;

                    SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                    string clockCode = arPara[0].Value.ToString();


                    arPara = new SqlParameter[]{
                        new SqlParameter("@AutoCode", SqlDbType.Int)
                            { Value = 0 },
                        new SqlParameter("@AffairAssistantCode", SqlDbType.Int)
                            { Value = Convert.ToInt32(affairAssistantCode) },
                        new SqlParameter("@AlarmClockCode", SqlDbType.Int)
                            { Value = Convert.ToInt32(clockCode) },
                        new SqlParameter("@userID", SqlDbType.NVarChar, 20)
                            { Value = userID }
                    };

                    proName = "TM_spAffairAssistantWithAlarmClock_ADD";
                    SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                }

                tran.Commit();
            }
            catch (SqlException e)
            {
                tran.Rollback();
            }
            finally
            {
                conn.Close();
            }

            return affairCode;
        }

        /// <summary>
        /// 删除简单活动
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="affairCode">活动编号</param>
        /// <param name="isRepeat">是否重复周期</param>
        /// <param name="isAffairType">是否有活动类型标识</param>
        /// <param name="date">删除的活动日期</param>
        /// <returns></returns>
        [HttpGet]
        public string delSimpleEvent(string userID, string affairCode, string isRepeat, string isAffairType, string date)
        {
            if (isRepeat == "1" && isAffairType == "0")
            {
                EnAffair affair = new EnAffair();
                affair.AffairCode = int.Parse(affairCode);
                affair.UserID = userID;
                affair.BeginTime = Convert.ToDateTime(date);

                return BzAffair.DeleteModel(affair).ToString();
            }

            #region 删除普通活动
            string result = "0";
            StringBuilder sqlStr = new StringBuilder();
            
            SqlConnection conn = new SqlConnection(_sqlCnnStr);
            conn.Open();
           
            SqlTransaction tran = conn.BeginTransaction();

            try
            {
                //活动详细表
                sqlStr.Append(@"DELETE FROM TM_AffairAssistant
                                       WHERE affaircode = @affairCode;");

                SqlParameter[] arPara = new SqlParameter[] {
                    new SqlParameter("@affairCode", SqlDbType.Int) 
                        { Value = Convert.ToInt32(affairCode) }
                };

                SqlHelper.ExecuteNonQuery(tran, CommandType.Text, sqlStr.ToString(), arPara);

                //活动主表
                sqlStr = new StringBuilder();
                sqlStr.Append(@"DELETE FROM TM_Affair
                                        WHERE affairCode = @affairCode;");

                arPara = new SqlParameter[] {
                    new SqlParameter("@affairCode", SqlDbType.Int) 
                        { Value = Convert.ToInt32(affairCode) }
                };

                SqlHelper.ExecuteNonQuery(tran, CommandType.Text, sqlStr.ToString(), arPara);

                result = "1";
                tran.Commit();
            }
            catch (SqlException e)
            {
                tran.Rollback();
            }
            finally
            {
                conn.Close();
            }

            return result;
            #endregion
        }

        /// <summary>
        /// 修改简单活动
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="affairCode">活动编号</param>
        /// <param name="isRepeat">是否重复周期</param>
        /// <param name="isAffairType">是否有活动类型标识</param>
        /// <param name="title">主题</param>
        /// <param name="startTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <param name="address">地点</param>
        /// <param name="XmCode">项目编号(一级项目和二级项目用‘-’号隔开)</param>
        /// <param name="memo">备注</param>
        /// <param name="alarm">是否闹铃</param>
        /// <param name="alarmTime">闹铃时间</param>
        /// <returns></returns>
        [HttpGet]
        public string updateSimpleEvent(string userID, string affairCode, string isRepeat, string isAffairType, string title, string startTime, string endTime, string address, string XmCode, string memo, string alarm, string alarmTime)
        {
            if (isRepeat == "1" && isAffairType == "0")
            {
                //重复周期，修改特例
                EnAffair affair = new EnAffair();
                affair.UserID = userID;
                affair.AffairCode = 0;
                affair.ParentCode = int.Parse(affairCode);
                affair.IsRepeat = 1;
                affair.AffairAssistantCode = -1;
                affair.Title = title;
                affair.Address = address;
                affair.Memo = memo;
                affair.XMFCode = XmCode.Split('-')[0];
                affair.XMCode = XmCode.Split('-')[1];
                affair.BeginTime = Convert.ToDateTime(startTime.Replace("$", " "));
                affair.EndTime = Convert.ToDateTime(endTime.Replace("$", " "));


                IList<EnAlarmClock> clockList = new List<EnAlarmClock>();
                if (alarm == "true")
                {
                    EnAlarmClock clock = new EnAlarmClock();
                    clock.ClockCode = 0;
                    clock.Title = affair.Title;

                    DateTime tmpAlarmTim = Convert.ToDateTime(startTime.Replace("$", " "));
                    tmpAlarmTim = tmpAlarmTim.AddMinutes(0 - int.Parse(alarmTime));
                    clock.ClockTime = tmpAlarmTim;

                    clockList.Add(clock);
                }

                EnRepeatModel model = new EnRepeatModel();
                model.ModelDate = affair.BeginTime.Date;
                BzAffair.UpdateModel(affair, clockList, model);
                
                return affair.AffairCode.ToString();
            }

            #region 修改普通活动
            string result = "0";
            string sXmFCode = XmCode.Split('-')[0];
            string sXmCode = XmCode.Split('-')[1];
            startTime = startTime.Replace("$", " ");
            endTime = endTime.Replace("$", " ");
            memo = memo.Replace("$", " ");

            SqlConnection conn = new SqlConnection(_sqlCnnStr);
            conn.Open();

            //获取活动详细编号
            string AffairAssistantCode;
            string sqlStr = "SELECT AffairAssistantCode FROM TM_AffairAssistant WHERE AffairCode=" + affairCode + " ";
            sqlStr += "SELECT a.AlarmClockCode as ClockCode FROM TM_AffairAssistantWithAlarmClock a, TM_AffairAssistant b WHERE a.AffairAssistantCode=b.AffairAssistantCode AND b.AffairCode=" + affairCode;
            DataSet ds = SqlHelper.ExecuteDataset(conn, CommandType.Text, sqlStr);
            DataTable dt = ds.Tables[0];

            if (dt != null && dt.Rows.Count > 0)
                AffairAssistantCode = dt.Rows[0]["AffairAssistantCode"].ToString();
            else
                return result;

            SqlTransaction tran = conn.BeginTransaction();

            try
            {
                //主表
                SqlParameter[] arPara = new SqlParameter[]{
                    new SqlParameter("@AffairCode", SqlDbType.Int) 
                        { Value = Convert.ToInt32(affairCode) },
                    new SqlParameter("@Title", SqlDbType.NVarChar, 200) 
                        { Value = title },
                    new SqlParameter("@Address", SqlDbType.NVarChar, 200) 
                        { Value = address },
                    new SqlParameter("@Memo", SqlDbType.NVarChar, 8000) 
                        { Value = memo },
                    new SqlParameter("@XMCode", SqlDbType.NVarChar, 20)
                        { Value = sXmCode },
                    new SqlParameter("@XMFCode", SqlDbType.NVarChar, 20)
                        { Value = sXmFCode },
                    new SqlParameter("@UserID", SqlDbType.NVarChar, 20) 
                        { Value = userID },
                    new SqlParameter("@MeetingPurpose", SqlDbType.NVarChar, 300)
                        { Value = "" }
                };

                string proName = "TM_spAffair_Update";
                SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);

                //活动详细表
                arPara = new SqlParameter[]{
                    new SqlParameter("@AffairAssistantCode", SqlDbType.Int) 
                        { Value = Convert.ToInt32(AffairAssistantCode) },
                    new SqlParameter("@BeginTime", SqlDbType.DateTime)
                        { Value = Convert.ToDateTime(startTime) },
                    new SqlParameter("@EndTime", SqlDbType.DateTime)
                        { Value = Convert.ToDateTime(endTime) },
                     new SqlParameter("@CalendarCode", SqlDbType.Int) 
                        { Value = 0 },
                    new SqlParameter("@ShareType", SqlDbType.TinyInt) 
                        { Value = 0 },                                                  //0 自己； 1 任何人；  2 部门；
                    new SqlParameter("@DruckerType", SqlDbType.TinyInt)
                        { Value = 1 },                                                  //1 一定要我才能做好；   2 可以让人代我做；  3 没有效益却又不得不做
                    new SqlParameter("@LevelType", SqlDbType.TinyInt)
                        { Value = 3 },                                                  //1 不紧急不重要； 2 紧急不重要；    3 正常；   4 重要不紧急；    5 紧急重要；
                    new SqlParameter("@UserID", SqlDbType.NVarChar, 20)
                        { Value = userID },
                    new SqlParameter("@EventCodeEditSign", SqlDbType.TinyInt) 
                        { Value = 0 },
                    new SqlParameter("@EventEditTime", SqlDbType.DateTime)
                        { Value = DateTime.Now },
                    new SqlParameter("@IsRemind", SqlDbType.TinyInt)
                        { Value = (alarm=="true"?1:0) }
                };

                proName = "TM_spAffairAssistant_Update";
                SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);

                //提醒表
                if (alarm == "true")
                {
                    if (ds.Tables[1].Rows.Count == 0)
                    {
                        DateTime now = DateTime.Now;
                        DateTime time = Convert.ToDateTime(startTime);
                        time = time.AddMinutes(0 - Convert.ToInt32(alarmTime));

                        arPara = new SqlParameter[]{
                            new SqlParameter("@ClockCode", SqlDbType.Int)
                                { Value = 0 },
                            new SqlParameter("@Title", SqlDbType.NVarChar, 500)
                                { Value = title },
                            new SqlParameter("@UserID", SqlDbType.NVarChar, 20)
                                { Value = userID },
                            new SqlParameter("@ClockType", SqlDbType.Int)
                                { Value = 0 },
                            new SqlParameter("@ClockTime", SqlDbType.DateTime)
                                { Value = time },
                            new SqlParameter("@RepeatMode", SqlDbType.Int)
                                { Value = 0 },
                            new SqlParameter("@RepeatValue", SqlDbType.NVarChar, 50)
                                { Value = DBNull.Value },
                            new SqlParameter("@RepeatBeginDate", SqlDbType.DateTime)
                                { Value = now },
                            new SqlParameter("@RepeatEndDate", SqlDbType.DateTime)
                                { Value = now },
                            new SqlParameter("@SpaceMinute", SqlDbType.Int)
                                { Value = 0 },
                            new SqlParameter("@SpaceBtime", SqlDbType.DateTime)
                                { Value = now },
                            new SqlParameter("@SpaceEtime", SqlDbType.DateTime)
                                { Value = now },
                            new SqlParameter("@ClockSource", SqlDbType.Int)
                                { Value = 1 },
                            new SqlParameter("@SourceCode", SqlDbType.NVarChar, 20)
                                { Value = "0" }
                        };

                        proName = "TM_spAlarmClock_ADD";
                        arPara[0].Direction = ParameterDirection.Output;

                        SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                        string clockCode = arPara[0].Value.ToString();


                        arPara = new SqlParameter[]{
                            new SqlParameter("@AutoCode", SqlDbType.Int)
                                { Value = 0 },
                            new SqlParameter("@AffairAssistantCode", SqlDbType.Int)
                                { Value = Convert.ToInt32(AffairAssistantCode) },
                            new SqlParameter("@AlarmClockCode", SqlDbType.Int)
                                { Value = Convert.ToInt32(clockCode) },
                            new SqlParameter("@userID", SqlDbType.NVarChar, 20)
                                { Value = userID }
                        };

                        proName = "TM_spAffairAssistantWithAlarmClock_ADD";
                        SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                    }
                    else
                    {
                        DateTime now = DateTime.Now;
                        DateTime time = Convert.ToDateTime(startTime);
                        time = time.AddMinutes(0 - Convert.ToInt32(alarmTime));

                        arPara = new SqlParameter[]{
                            new SqlParameter("@ClockCode", SqlDbType.Int)
                                { Value = Convert.ToInt32(ds.Tables[1].Rows[0]["ClockCode"]) },
                            new SqlParameter("@userID", SqlDbType.NVarChar, 20)
                                { Value = userID },
                            new SqlParameter("@ClockTime", SqlDbType.DateTime)
                                { Value = time }
                        };

                        proName = "TM_spAlarmClock_UpdateTime";
                        SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                    }
                }
                else
                {
                    if (ds.Tables[1].Rows.Count > 0)
                    {
                        arPara = new SqlParameter[]{
                            new SqlParameter("@affairMemoCode", SqlDbType.Int)
                                { Value = AffairAssistantCode },
                            new SqlParameter("@alarmClockCode", SqlDbType.Int)
                                { Value = Convert.ToInt32(ds.Tables[1].Rows[0]["ClockCode"]) }
                        };

                        proName = "TM_spAffairAssistantWithAlarmClock_Delete";
                        SqlHelper.ExecuteNonQuery(tran, CommandType.StoredProcedure, proName, arPara);
                    }
                }
                result = affairCode;

                tran.Commit();
            }
            catch (SqlException e)
            {
                tran.Rollback();
            }
            finally
            {
                conn.Close();
            }

            return result;
            #endregion

        }

        /// <summary>
        /// 获取关注的对象
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public List<PersonEntity> getAttentionUsers(string sPersonCode)
        {
            var list = new List<PersonEntity>();

            list.Add(new PersonEntity {
                sPersonCode = sPersonCode,
                sPersonName = "我自己",
                sDepName = ""
            });

            string sqlStr = "select b.sPersonCode, b.sPersonName, c.sDepName from TM_UserAttentionList a, A5_CWPerson b, A5_Wdepartmentcls c where a.BeAttentionUserID=b.sPersoncode and b.sDepCode=c.sDepCode and a.AttentionUserID='" + sPersonCode + "'";
            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr).Tables[0];

            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    PersonEntity entity = new PersonEntity
                    {
                        sPersonCode = dr["sPersonCode"].ToString(),
                        sPersonName = dr["sPersonName"].ToString(),
                        sDepName = dr["sDepName"].ToString()
                    };

                    list.Add(entity);
                }
            }

            return list;
        }
        
        /// <summary>
        /// 获取时间表配置
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public EnUserConfig getUserConfig(string userID)
        {
            return BzUserConfig.getConfig(userID);
        }

        /// <summary>
        /// 接受预约
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="affairCode">活动编号</param>
        /// <returns></returns>
        [HttpGet]
        public bool acceptBespeak(string userID, string affairCode)
        {
            bool isPass = false;
            isPass = BzAffairBespeak.AcceptBespeak(userID, int.Parse(affairCode));
            return isPass;
        }

        /// <summary>
        /// 拒绝预约
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="affairCode">活动编号</param>
        /// <returns></returns>
        [HttpGet]
        public bool denyBespeak(string userID, string affairCode)
        {
            bool isPass = false;
            isPass = BzAffairBespeak.DenyBespeak(userID, int.Parse(affairCode));
            return isPass;
        }

        /// <summary>
        /// 返回会议室名称列表
        /// </summary>
        /// <returns></returns>
        public List<String> getMeetingRoom()
        {
            List<String> result = new List<string>();
            String sqlStr = "select sMRoomName from A9_MeetingRoom where sMRCode='01' and bMRoomState=1";
            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr.ToString(), null).Tables[0];

            if (dt != null && dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    result.Add(dt.Rows[i]["sMRoomName"].ToString());
                }
            }

            return result;
        }

        /// <summary>
        /// 时间表一键转日志
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="logDate">日志日期</param>
        /// <returns></returns>
        [HttpGet]
        public string[] insertERPDailyLog(string userID, string logDate)
        {
            string[] result = new string[2];
            result[0] = "0";
            result[1] = "保存失败";

            int tmpSDay = 20;
            int tmpFDay = 30;
            //已有的总工作时数
            double oldTotalHour = 0.0;            
            DataTable oldLogData = null;

            EnWorkLog work = new EnWorkLog();
            work.userID = userID;
            work.date = Convert.ToDateTime(logDate);
            work.logType = "正常单据";
            work.taskCodes = "";
            work.list = new List<EnWorkLogItem>();
            
            List<EnAffair> affairs = getEventList(userID, logDate, Convert.ToDateTime(logDate).AddDays(1).ToString("yyyy-MM-dd"));
            //获取校验数据
            DataSet ds = BzWorkLog.getWorkLogData(userID, logDate);

            //校验
            TimeSpan ts = DateTime.Today - Convert.ToDateTime(logDate);

            if (userID == null || logDate == null || userID.Trim() == "" || logDate.Trim() == "")
            {
                result[1] = "传入参数为空";
                return result;
            }

            if (ts.Days < 0 || ts.Days > 3)
            {
                result[1] = "无法填写今天之后或3个自然日之前的日志";
                return result;
            }

            if (ts.Days != 0)
                work.logType = "补填单据";

            if (ds != null)
            {
                if (ds.Tables[0].Rows.Count > 0)
                {
                    work.code = Convert.ToInt32(ds.Tables[0].Rows[0]["code"]);
                    oldTotalHour = Convert.ToDouble(ds.Tables[0].Rows[0]["oldTotalHour"]);
                }

                work.userName = ds.Tables[1].Rows[0]["sPersonName"].ToString();
                work.userDeptCode = ds.Tables[1].Rows[0]["sDepCode"].ToString();
                work.userDeptName = ds.Tables[1].Rows[0]["sDepName"].ToString();
                work.mPeople = work.userName + "(" + work.userDeptName + ")";

                if (ds.Tables[2].Rows.Count > 0)
                {
                    work.isHour = ds.Tables[2].Rows[0]["logSet"].ToString() == "1" ? true : false;
                    work.isExtend = ds.Tables[2].Rows[0]["bTaskExtend"].ToString() == "1" ? true : false;
                    work.isShowLink = ds.Tables[2].Rows[0]["bTaskExtNoUrl"].ToString() == "1" ? true : false;
                    work.isFinPercent = ds.Tables[2].Rows[0]["bTaskPre"].ToString() == "1" ? true : false;
                }

                if (ds.Tables[3].Rows.Count > 0)
                    tmpSDay = Convert.ToDateTime(ds.Tables[3].Rows[0]["dEDate"]).Day;
                if (ds.Tables[4].Rows.Count > 0)
                    tmpFDay = Convert.ToDateTime(ds.Tables[4].Rows[0]["dFDate"]).Day;

                DateTime tmpFDate;
                DateTime chkLogDate = Convert.ToDateTime(logDate);
                if (chkLogDate.Day > tmpSDay)
                {
                    chkLogDate = chkLogDate.AddMonths(1);
                    if (DateTime.DaysInMonth(chkLogDate.Year, chkLogDate.Month) >= tmpFDay)
                        tmpFDate = new DateTime(chkLogDate.Year, chkLogDate.Month, tmpFDay);
                    else
                        tmpFDate = new DateTime(chkLogDate.Year, chkLogDate.Month, DateTime.DaysInMonth(chkLogDate.Year, chkLogDate.Month));
                }
                else
                {
                    if (DateTime.DaysInMonth(chkLogDate.Year, chkLogDate.Month) >= tmpFDay)
                        tmpFDate = new DateTime(chkLogDate.Year, chkLogDate.Month, tmpFDay);
                    else
                        tmpFDate = new DateTime(chkLogDate.Year, chkLogDate.Month, DateTime.DaysInMonth(chkLogDate.Year, chkLogDate.Month));
                }

                if (DateTime.Today > tmpFDate)
                {
                    result[1] = logDate + "的日志不允许在" + tmpFDate.ToString("yyyy-MM-dd") + "之后操作！";
                    return result;
                }

                if (ds.Tables[5].Rows.Count == 0)
                {
                    ts = DateTime.Today - Convert.ToDateTime(logDate);
                    if (Convert.ToInt32(ds.Tables[7].Rows[0][0]) > 3) 
                        work.isIllegal = true;
                }

                oldLogData = ds.Tables[6];
                ds.Dispose();
            }
            else
            {
                ds.Dispose();
                result[1] = "保存失败";
                return result;
            }

            //填充活动数据
            if (affairs != null && affairs.Count > 0)
            {
                for (int i = 0; i < affairs.Count; i++)
                {
                    EnWorkLogItem item = new EnWorkLogItem();
                    EnAffair affair = affairs[i];

                    if (TMCommon.CheckIsType(affair.TypeCode, TMType.CompanyMeet))
                        item.type = "4";
                    else if (TMCommon.CheckIsType(affair.TypeCode, TMType.CompanyALERP))
                        item.type = "2";
                    else
                        item.type = "3";

                    item.code = affair.AffairCode.ToString();
                    item.taskCode = affair.SourceCode;
                    item.xmFCode = affair.XMFCode;
                    item.xmCode = affair.XMCode;
                    item.depCode = work.userDeptCode;
                    item.content = affair.Title;

                    ts = affair.EndTime - affair.BeginTime;
                    item.hour = ts.TotalHours;
                    item.percent = 0.0;

                    if (item.type != "2")
                        item.xmPercent = 100.0;
                    else
                        item.xmPercent = 0.0;

                    item.state = "60";
                    item.url = "";
                    item.memo = "";

                    work.list.Add(item);
                }
            }
            else
            {
                result[1] = "无活动可转日志";
                return result;
            }

            for (int i = 0; i < work.list.Count; i++)
            {
                EnWorkLogItem item = work.list[i];

                //编号、一二级项目、部门
                if (item.code.Trim() == "" || item.xmFCode.Trim() == "" || item.xmCode.Trim() == "" || item.depCode.Trim() == "" || item.content.Trim() == "")
                {
                    result[1] = "活动存在一二级项目为空的情况，请检查后再保存";
                    return result;
                }

                //一二级项目匹配
                if (item.xmFCode.Trim() != item.xmCode.Trim().Substring(0, item.xmFCode.Trim().Length))
                {
                    result[1] = "活动存在一二级项目不匹配的情况，请检查后再保存";
                    return result;
                }

                //工作时数
                if (item.hour <= 0)
                {
                    result[1] = "活动存在结束时间早于开始时间的情况，请检查后再保存";
                    return result;
                }

                //收集任务号
                if (item.type == "2" && item.taskCode != "" && item.taskCode != "0")
                    work.taskCodes += item.taskCode + ",";

                work.totalHour += item.hour;
                work.totalPercent += item.percent;
            }

            if (work.taskCodes != "")
                work.taskCodes = work.taskCodes.Substring(0, work.taskCodes.Length - 1);

            if (work.isHour && oldTotalHour != 0 && (oldTotalHour + work.totalHour) > 24)
            {
                result[1] = "若将活动转为日志，则当天日志工作时数超过24小时，请检查后再保存";
                return result;
            }

            if (work.isHour && work.totalHour > 24)
            {
                result[1] = "当天活动超过24小时，请检查后再保存";
                return result;
            }

            //插入日志
            bool isSuccess = BzWorkLog.insertWorkLog(work, oldLogData);
            if (!isSuccess)
                result[1] = "保存失败";
            else
            {
                result[0] = "1";
                result[1] = "";
            }

            return result;
        }


        /// <summary>
        /// 返回 与userID相关的便签数据
        /// </summary>
        /// <returns></returns>
        public List<EnTodoEvent> getTodoList(string userID)
        {
            List<EnTodoEvent> result = new List<EnTodoEvent>();
            String sqlStr = "SELECT Title,ColorType FROM [TM_ToDoList] a WHERE UserID ='" + userID + "' AND  ToDoState < 2 AND a.IsToDoType = 0 ORDER BY OrderIndex desc";
            IDataReader dr = SqlHelper.ExecuteReader(_sqlCnnStr, CommandType.Text, sqlStr.ToString(), null);
            return DynamicBuilder<EnTodoEvent>.ConvertToList(dr);
        }
        /// <summary>
        /// 根据userID插入便签数据
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public Boolean insertTodoList(String userID, String title,String colorType) {
            Boolean result = false;
            string startTimeString = "1900-01-01 00:00:00.000";
            DateTime startDate = DateTime.Parse(startTimeString);
            string enTimeString = "9999-12-31 00:00:00.000";
            DateTime endDate = DateTime.Parse(enTimeString);

            String sqlStr = "INSERT INTO TM_ToDoList(UserID,Title,ColorType,BeginDate,EndDate) VALUES (" + userID + ", '" + title + "'," + colorType + ",'" + startDate + "','" + endDate + "')";
            int iResult = SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.Text, sqlStr);
            if (iResult > 0) {
                result = true;  
            }
            return result;

        }


        /// <summary>
        /// 返回 与userID相关的时间表的日历list
        /// </summary>
        /// <returns></returns>
        public  List<EnCalendar> getCalendar(string userID)
        {
            return BzCalcendar.getCalendar(userID);
        }
    
    }
}
