﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage
{
    [DataContract]
    public class EventEntity
    {
        [DataMember]
        public string code { get; set; }
        [DataMember]
        public string title { get; set; }
        [DataMember]
        public string day { get; set; }
        [DataMember]
        public string startTime { get; set; }
        [DataMember]
        public string endTime { get; set; }
        [DataMember]
        public string address { get; set; }
        [DataMember]
        public string XMFCode { get; set; }
        [DataMember]
        public string XMCode { get; set; }
        [DataMember]
        public string XMFName { get; set; }
        [DataMember]
        public string XMName { get; set; }
        [DataMember]
        public string memo { get; set; }
        [DataMember]
        public string clockTime { get; set; }
    }


    [DataContract]
    public class PersonEntity
    {
        [DataMember]
        public string sPersonCode { get; set; }
        [DataMember]
        public string sPersonName { get; set; }
        [DataMember]
        public string sDepName { get; set; }
    }

}
