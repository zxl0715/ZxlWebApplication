﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;

namespace Nd.Erp.Mobile.Service.TimeManage.Utility
{
    public class TMCommon
    {
        public static bool CheckIsType(string typeCodes, string checkValue)
        {
            bool result = false;
            if (typeCodes != string.Empty)
            {
                string[] types = typeCodes.Split(',');

                foreach (string type in types)
                {
                    if (type == checkValue)
                    {
                        result = true;
                        break;
                    }
                }
            }

            return result;
        }

        public static bool CheckIsType(string typeCodes, params TMType[] types)
        {
            if (string.IsNullOrEmpty(typeCodes))
            {
                return false;
            }
            foreach (var type in types)
            {
                string checkValue = ((int)type).ToString();
                if(CheckIsType(typeCodes, checkValue))
                    return true;
            }

            return false;
        }

        /// <summary>
        /// 字符转换成HTML转义
        /// </summary>
        /// <param name="str"></param>
        /// <returns></returns>
        public static string HtmlEncode(string str)
        {
            String htmlStr = str;

            htmlStr = htmlStr.Replace("&", "&amp;");
            htmlStr = htmlStr.Replace(">", "&gt;");
            htmlStr = htmlStr.Replace("<", "&lt;");
            htmlStr = htmlStr.Replace("\"", "&quot;");
            htmlStr = htmlStr.Replace("'", "'+char(39)+'");
            htmlStr = htmlStr.Replace("|", "'+char(124)+'");
            htmlStr = htmlStr.Replace("\n", "<br>");

            return htmlStr;
        }

        /// <summary>
        /// 将HTML转义，转换成正确的字符
        /// </summary>
        /// <param name="htmlStr"></param>
        /// <returns></returns>
        public static string htmlDecode(string htmlStr)
        {
            String str = htmlStr;

            str.Replace("&nbsp;", " ");
            str.Replace("&amp;", "&");
            str.Replace("&apos;", "'");
            str.Replace("&quot;", "\"");
            str.Replace("&lt;", "<");
            str.Replace("&gt", ">");
            str.Replace("<br>", "\n");
            str.Replace("<BR>", "\n");

            return str;
        }

        public static string DBC2SBC(string str)
        {
            char[] chars = str.ToCharArray();
            for (int i = 0; i < chars.Length; i++)
            {
                byte[] bytes = Encoding.Unicode.GetBytes(chars, i, 1);
                if ((bytes.Length == 2) && (bytes[1] == 0xff))
                {
                    bytes[0] = (byte)(bytes[0] + 0x20);
                    bytes[1] = 0;
                    chars[i] = Encoding.Unicode.GetChars(bytes)[0];
                }
            }
            return new string(chars);
        }



        /// <summary>
        /// 日期拼接
        /// </summary>
        /// <param name="date">新date日期部分</param>
        /// <param name="time">新date时间部分</param>
        /// <returns>新的日期</returns>
        public static DateTime DateSpell(DateTime date, DateTime time)
        {
            return new DateTime(date.Year, date.Month, date.Day, time.Hour, time.Minute, time.Second);
        }

        /// <summary>
        /// 验证重复周期在指定日期中是否有效
        /// </summary>
        /// <param name="mode">重复模式</param>
        /// <param name="val">重复值</param>
        /// <param name="space">重复间隔</param>
        /// <param name="rbdate">重复周期开始日期</param>
        /// <param name="dDate">验证日期</param>
        /// <returns>true：有效，false 无效</returns>
        public static bool CheckRepeat(TMRepeatMode mode, string val, int space, DateTime rbdate, DateTime dDate)
        {
            bool result = true;
            int dayweek = (int)dDate.DayOfWeek;

            #region 重复周期值验证
            if (mode == TMRepeatMode.Day) //天模式
            {
                if (val == "1" && (dayweek == 0 || dayweek == 6)) //工作日
                {
                    return false;
                }
            }
            else if (mode == TMRepeatMode.Week) //周模式
            {

                if (CheckIsType(val, dayweek.ToString()) == false)
                {
                    return false;
                }

            }
            else if (mode == TMRepeatMode.Month) //月模式
            {
                DateTime modeDate = new DateTime();//指定的日期

                if (val.IndexOf(',') == -1) //指定日期
                {
                    try
                    {
                        modeDate = new DateTime(dDate.Year, dDate.Month, Convert.ToInt32(val));
                    }
                    catch //无效的日期
                    {
                        return false;
                    }
                }
                else
                {
                    try
                    {
                        DateTime firstDate = new DateTime(dDate.Year, dDate.Month, 1);
                        string[] modes = val.Split(',');
                        modeDate = firstDate.AddDays(-(int)firstDate.DayOfWeek);
                        int weeks = Convert.ToInt32(modes[0]);
                        int days = Convert.ToInt32(modes[1]);
                        if (days == 0)
                        {
                            weeks = weeks + 1;
                        }


                        modeDate = modeDate.AddDays((weeks - 1) * 7 + days);
                    }
                    catch
                    {
                        return false;
                    }
                }

                if (dDate.Date != modeDate.Date)
                {
                    result = false;
                }

            }
            #endregion

            #region 重复间隔验证
            if (space > 0)//存在重复间隔
            {
                if (mode == TMRepeatMode.Day || mode == TMRepeatMode.Week) //按周间隔
                {
                    DateTime dSunDate = dDate.AddDays((0 - (int)dDate.DayOfWeek));
                    DateTime repeatSunDate = rbdate.AddDays((0 - (int)rbdate.DayOfWeek));
                    int diffweeks = dSunDate.Date.Subtract(repeatSunDate.Date).Days / 7;    //相隔周数

                    if (dayweek == 0)
                    {
                        diffweeks = diffweeks + space;
                    }
                    if (diffweeks % (space + 1) > 0)//有余数则表示该日期与间隔不符
                    {

                        return false;
                    }


                }
                else if (mode == TMRepeatMode.Month)//按月间隔
                {
                    //重复开始周期至指定日期月份差
                    int diffMonths = (dDate.Year - rbdate.Year) * 12 + (dDate.Month - rbdate.Month);

                    if (diffMonths % (space + 1) > 0) //有余数则表示该日期与间隔不符
                    {
                        return false;
                    }
                }

            }
            #endregion

            return result;
        }
    }
}
