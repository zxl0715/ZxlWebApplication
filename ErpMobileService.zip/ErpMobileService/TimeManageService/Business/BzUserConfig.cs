﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzUserConfig
    {
        private static readonly DaUserConfig dal_config = new DaUserConfig();



        public static EnUserConfig getConfig(String userID)
        {
            return dal_config.GetConfig(userID);
        }
    }
}
