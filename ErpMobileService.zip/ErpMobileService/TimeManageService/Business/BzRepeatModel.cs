﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzRepeatModel
    {
        private static readonly DaRepeatModel dal = new DaRepeatModel();

        /// <summary>
        /// 获取重复周期实例事件列表
        /// </summary>
        /// <param name="userID">用户工号</param>
        /// <param name="beginTime">开始日期</param>
        /// <param name="endTime">结束日期</param>
        /// <returns>重复周期事件列表</returns>
        public static IList<EnRepeatModel> GetList(string userID, DateTime beginTime, DateTime endTime)
        {
            IList<EnRepeatModel> list = new List<EnRepeatModel>();
            try
            {
                list = dal.GetModelList(userID, beginTime, endTime);
            }
            catch (Exception ex)
            {
                list = new List<EnRepeatModel>();
            }

            return list;
        }

        /// <summary>
        /// 跟重复周期编号分组获取特例记录
        /// </summary>
        /// <param name="userID">用户工号</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns></returns>
        public static Dictionary<int, IList<EnRepeatModel>> GetDict(string userID, DateTime beginTime, DateTime endTime)
        {
            Dictionary<int, IList<EnRepeatModel>> dict = new Dictionary<int, IList<EnRepeatModel>>();
            IList<EnRepeatModel> list = GetList(userID, beginTime, endTime);
            foreach (EnRepeatModel enrm in list)
            {
                if (!dict.ContainsKey(enrm.RepeatCode))
                {
                    dict[enrm.RepeatCode] = new List<EnRepeatModel>();
                }
                dict[enrm.RepeatCode].Add(enrm);
            }

            return dict;
        }

        /// <summary>
        /// 检查该重复周期是否被实例
        /// </summary>
        /// <param name="listRepeatmodel">已实例周期集合</param>
        /// <param name="RepeatCode">重复周期编号</param>
        /// <param name="sdate">重复周期对应日期</param>
        /// <returns>true：已实例，false 未实例</returns>
        public static bool checkRepeatIsModel(IList<EnRepeatModel> repeatModelList, EnAffairRepeat affairRepeat, DateTime sdate, out int repeateModelState)
        {
            bool result = false;
            repeateModelState = 1;

            if (repeatModelList != null && repeatModelList.Count > 0)
            {
                foreach (EnRepeatModel model in repeatModelList)
                {
                    if (model.ModelDate.Date == sdate.Date
                        && model.RepeatCode == affairRepeat.RepeatCode)
                        //&& affairMemoUserID == model.UserID) //对象已实例
                    {
                        repeateModelState = model.ModelState;
                        return true;
                    }

                }
            }

            return result;
        }

        /// <summary>
        /// 添加重复周期实体关系
        /// </summary>
        /// <param name="trans"></param>
        /// <param name="en">实体</param>
        /// <returns>1：成功</returns>
        public static int Add(EnRepeatModel model)
        {
            try
            {
                return dal.Add(model);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        /// <summary>
        /// 删除由接收者预约的特例数据
        /// </summary>
        /// <param name="affaircode">事件编号</param>
        /// <param name="userID">接收者工号</param>
        /// <returns>1:成功,其他失败</returns>
        public static int ReSetByAffairCodeAndUserIDAndDate(int affiarCode, EnRepeatModel en)
        {
            int result = 0;
            try
            {
                result = dal.ReSetByAffairCodeAndUserIDAndDate(affiarCode, en);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
    }
}
