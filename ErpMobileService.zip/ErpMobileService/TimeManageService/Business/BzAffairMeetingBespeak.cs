﻿using System;
using System.Collections.Generic;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    /// <summary>
    /// 会议预约业务逻辑
    /// </summary>
    public class BzAffairMeetingBespeak
    {
        //数据层实体
        private static readonly DaAffairMeetingBespeak dal = new DaAffairMeetingBespeak();


        #region 获取会议预约数据
        /// <summary>
        /// 获取会议预约数据
        /// </summary>
        /// <param name="code">活动编号</param>
        /// <returns>会议预约列表</returns>
        public static IList<EnAffairMeetingBespeak> GetAffairMeetingBespeakByAffairCode(int code)
        {
            return dal.GetAffairMeetingBespeakByAffairCode(code);
        }
        #endregion

        #region 会议预约实体转成普通预约实体
        /// <summary>
        /// 会议预约实体转成普通预约实体
        /// </summary>
        /// <param name="bespeak">会议预约</param>
        /// <returns>普通预约</returns>
        public static EnAffairBespeak ConvertAffairBespeak(EnAffairMeetingBespeak bespeak)
        {
            EnAffairBespeak en = new EnAffairBespeak();

            en.AutoCode = bespeak.AutoCode;
            en.AffairCode = bespeak.AffairCode;
            en.InceptUserID = bespeak.InceptUserID;
            en.InitiateUserID = bespeak.InitiateUserID;
            en.BespeakState = bespeak.BespeakState;
            en.AddTime = bespeak.AddTime;

            return en;
        }
        #endregion
    }
}
