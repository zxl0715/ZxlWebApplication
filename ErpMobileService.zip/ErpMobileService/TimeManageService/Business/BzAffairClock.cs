﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzAffairClock
    {
        private static readonly DaAffairClock dal = new DaAffairClock();

        public static EnAffairClock GetEntityByAffairMemoCode(int AffairAssistantCode)
        {
            return dal.GetEntityByAffairMemoCode(AffairAssistantCode);
        }
    }
}
