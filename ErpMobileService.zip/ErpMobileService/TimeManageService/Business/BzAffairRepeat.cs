﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzAffairRepeat
    {
        private static readonly DaAffairRepeat dal = new DaAffairRepeat();


        /// <summary>
        /// 获取重复周期活动列表
        /// </summary>
        /// <param name="userID">用户工号</param>
        /// <param name="beginTime">开始日期</param>
        /// <param name="endTime">结束日期</param>
        /// <returns>重复周期活动列表</returns>
        public static IList<EnAffairMemoRepeat> GetList(string userID, DateTime beginTime, DateTime endTime)
        {
            return dal.GetList(userID, beginTime, endTime);
        }

        /// <summary>
        /// 获取重复周期活动
        /// </summary>
        /// <param name="affairCode"></param>
        /// <returns></returns>
        public static EnAffairMemoRepeat GetRepeatAffair(int affairCode)
        {
            return dal.GetRepeatAffair(affairCode);
        }

        /// <summary>
        /// 根据活动编号，获取重复周期
        /// </summary>
        /// <param name="affairCode"></param>
        /// <returns></returns>
        public static EnAffairRepeat GetEntity(int affairCode)
        {
            try
            {
                return dal.GetEntity(affairCode);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
    }
}
