﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzAlarmClock
    {
        private static readonly DaAlarmClock daClock = new DaAlarmClock();

        /// <summary>
        /// 新增闹铃
        /// </summary>
        /// <param name="enalarmClock">实体对象</param>
        /// <returns>新增编号</returns>
        public static int Add(EnAlarmClock clock)
        {
            int result = 0;

            try
            {
                result = daClock.Add(clock);
            }
            catch (Exception ex)
            {
                result = 0;
            }

            return result;
        }

        
    }
}
