﻿using System;
using System.Collections.Generic;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    /// <summary>
    /// deadline预约业务逻辑
    /// </summary>
    public class BzAffairDeadlineBespeak
    {
        //数据层实体
        private static readonly DaAffairDeadlineBespeak dal = new DaAffairDeadlineBespeak();


        #region 获取会议预约数据
        /// <summary>
        /// 获取deadline预约数据
        /// </summary>
        /// <param name="code">活动编号</param>
        /// <returns>deadline预约列表</returns>
        public static IList<EnAffairBespeak> GetAffairDeadlnieBespeakByAffairCode(int code)
        {
            return dal.GetAffairDeadlineBespeakByAffairCode(code);
        }
        #endregion
    }
}
