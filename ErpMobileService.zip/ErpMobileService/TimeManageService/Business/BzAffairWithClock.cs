﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzAffairWithClock
    {
        private static readonly DaAffairWithClock daClock = new DaAffairWithClock();

        /// <summary>
        /// 添加事件闹铃
        /// </summary>
        /// <param name="en">事件闹铃关系对象</param>
        /// <returns>关联编号</returns>
        public static int AddAffairClock(EnAffairAssistantWithAlarmClock en)
        {
            int result = 0;
            try
            {
                result = daClock.Add(en);
            }
            catch (Exception ex)
            {
                result = 0;
            }

            return result;
        }

        public static IList<EnAffairClock> GetAffairClock(string codes)
        {
            IList<EnAffairClock> result = null;
            DaAlarmClock dal_clock = new DaAlarmClock();
            IList<EnAffairAssistantWithAlarmClock> affairClockList = daClock.GetAffairClock(codes);

            if (affairClockList != null && affairClockList.Count > 0)
            {
                result = new List<EnAffairClock>();

                for (int i = 0; i < affairClockList.Count; i++)
                {
                    EnAffairClock en = new EnAffairClock();
                    en.AffairClock = affairClockList[i];
                    en.Clock = dal_clock.GetEntity(affairClockList[i].AlarmClockCode);

                    result.Add(en);
                }                
            }

            return result;
        }
    }
}
