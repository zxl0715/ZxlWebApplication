﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzWorkLog
    {
        private static readonly DaWorkLog da = new DaWorkLog();

        #region 获取时间表一键转日志所需要的ERP数据
        /// <summary>
        /// 获取时间表一键转日志所需要的ERP数据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="logDate">日志日期</param>
        /// <returns></returns>
        public static DataSet getWorkLogData(string userID, string logDate)
        {
            return da.getWorkLogData(userID, logDate);
        }
        #endregion

        #region 一键转日志
        /// <summary>
        /// 一键转日志
        /// </summary>
        /// <param name="work">日志实体</param>
        /// <param name="oldLogData">旧的日志数据</param>
        /// <returns></returns>
        public static bool insertWorkLog(EnWorkLog work, DataTable oldLogData)
        {
            return da.insertWorkLog(work, oldLogData);
        }
        #endregion
    }
}
