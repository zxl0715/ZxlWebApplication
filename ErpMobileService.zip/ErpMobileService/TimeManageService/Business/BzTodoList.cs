﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Utility;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    /// <summary>
    /// 时间表业务逻辑
    /// </summary>
    public class BzToDoList
    {
        private static readonly DaTodoList dal = new DaTodoList();

        #region 获取时间表的我的便签数据
        /// <summary>
        /// 获取时间表的我的便签数据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public static List<EnTodoEvent> getTodoList(string userID)
        {
            return dal.getTodoList(userID);
        }
        #endregion



    }
}
