﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzCalcendar
    {
        private static readonly DaCalendar dal = new DaCalendar();

     
         /// <summary>
        /// 返回 与userID相关的时间表的日历list
        /// </summary>
        /// <returns></returns>
        public static List<EnCalendar> getCalendar(string userID) {
           return dal.getCalendar(userID);
        }

         /// <summary>
        /// 返回 与userID和日历编号相关的时间表的日历项
        /// </summary>
        /// <returns></returns>
        public static EnCalendar getCalendarByCode(string userID, int calendarCode)
        {
            return dal.getCalendarByCode(userID, calendarCode);
        }



    }
}
