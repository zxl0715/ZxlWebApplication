﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    public class BzAffairBespeak
    {
        private static readonly DaAffairBespeak dal = new DaAffairBespeak();

        #region 接受预约
        /// <summary>
        /// 接受预约
        /// </summary>
        /// <param name="affairCode">时间主表编号</param>
        /// <param name="userId">用户工号</param>
        /// <param name="ebb">返回的结果对象</param>
        /// <param name="isDelete">是否要删除同一时段的其他预约（true:是，false：否）</param>
        /// <returns>true:成功，false 失败</returns>
        public static bool AcceptBespeak(string userID, int affairCode)
        {
            EnAffair oldAffair = BzAffair.GetEntity(affairCode, userID);
            
            if (oldAffair == null)
            {
                return false;
            }

            if (oldAffair.IsMemoAvailability == 1)
            {
                return false;
            }

            try
            {
                oldAffair.IsMemoAvailability = 1;
                BzAffair.UpdateIsAvailability(oldAffair);
                changeAffairBespeakState(oldAffair, true);
                return true;
            }
            catch (Exception ex)
            {
                // do nothing;
            }

            return false;
        }
        #endregion

        #region 拒绝预约
        /// <summary>
        /// 拒绝预约。
        /// </summary>
        /// <param name="userId">The user id.</param>
        /// <param name="affariCode">The affari code.</param>
        /// <param name="en">The en.</param>
        /// <returns></returns>
        public static bool DenyBespeak(string userID, int affairCode)
        {
            EnAffair oldAffair = BzAffair.GetEntity(affairCode, userID);

            if (oldAffair == null)
            {
                return false;
            }

            try
            {
                BzAffair.DeleteAffairMemo(oldAffair);
                changeAffairBespeakState(oldAffair, false);
                return true;
            }
            catch (Exception ex)
            {
                // do nothing
            }

            return false;
        }
        #endregion

        public static List<EnAffairBespeak> getAffairBespeak(string userID, string codes)
        {
            List<EnAffairBespeak> result = null;
            DaAffairBespeak dal_bespeak = new DaAffairBespeak();
            IList<EnAffairBespeak> affairBespeakList = dal_bespeak.getAffairBespeak(userID, codes);

            if (affairBespeakList != null && affairBespeakList.Count > 0)
            {
                result = new List<EnAffairBespeak>();

                for (int i = 0; i < affairBespeakList.Count; i++)
                {
                    EnAffairBespeak en = affairBespeakList[i];
                    result.Add(en);
                }

            }

            return result;
        }

        public static EnAffairBespeak getAffairBespeakByAffairCode(string userID, int code)
        {
            return dal.getAffairBespeakByAffairCode(userID, code);
        }

        public static IList<EnAffairBespeak> getAffairBespeakByAffairCode(int code)
        {
            return dal.getAffairBespeakByAffairCode(code);
        }

        #region 修改事件预约表的状态
        /// <summary>
        /// 修改事件预约表的状态
        /// </summary>
        /// <param name="trans"></param>
        /// <param name="ena"></param>
        /// <param name="state">true：接收；false：拒绝</param>
        private static int changeAffairBespeakState(EnAffair affair, bool state)
        {
            int result = 0;
            try
            {
                EnAffairBespeak respeak = new EnAffairBespeak();
                int statevale = state ? 1 : 2;
                respeak.InceptUserID = affair.MemoUserID;
                respeak.AffairCode = affair.AffairCode;
                respeak.BespeakState = statevale;
                result = UpdateState(respeak);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return result;
        }
        #endregion

        #region 接收者反馈预约
        /// <summary>
        /// 预约结果反馈
        /// </summary>
        /// <param name="entity">实体编号,用户工号,预约状态</param>
        /// <returns>1：成功</returns>
        public static int UpdateState(EnAffairBespeak respeak)
        {
            int result = 0;
            try
            {
                result = dal.UpdateState(respeak);
            }
            catch (Exception ex)
            {
                //do nothing;
            }
            return result;
        }
        #endregion
    }
}
