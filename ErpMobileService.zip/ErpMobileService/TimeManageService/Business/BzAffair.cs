﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.TimeManage.Utility;
using Nd.Erp.Mobile.Service.TimeManage.Entity;
using Nd.Erp.Mobile.Service.TimeManage.DataAccess;

namespace Nd.Erp.Mobile.Service.TimeManage.Business
{
    /// <summary>
    /// 时间表业务逻辑
    /// </summary>
    public class BzAffair
    {
        private static readonly DaAffair dal = new DaAffair();

        #region 获取两周数据导入客户端
        /// <summary>
        /// 获取具体的活动数据
        /// 用于导入两个星期的活动数据
        /// 包括重复周期、特列、闹铃、预约的数据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns></returns>
        public static EnTwoWeekAffair getAffairs(string userID, DateTime beginTime, DateTime endTime)
        {
            EnTwoWeekAffair result = new EnTwoWeekAffair();

            //活动列表
            List<EnAffair> affairs = new List<EnAffair>();
            IList<EnAffair> affairList = dal.GetList(userID, beginTime, endTime);

            //重复周期列表
            List<EnAffairMemoRepeat> repeats = new List<EnAffairMemoRepeat>();
            IList<EnAffairMemoRepeat> repeatObjList = BzAffairRepeat.GetList(userID, beginTime, endTime);

            //重复周期实例列表
            List<EnRepeatModel> models = new List<EnRepeatModel>();
            IList<EnRepeatModel> repeatModelList = BzRepeatModel.GetList(userID, beginTime, endTime);

            string codes = "";
            for (int i = 0; i < affairList.Count; i++)
            {
                codes += affairList[i].AffairAssistantCode + ",";
                affairs.Add(affairList[i]);
            }
            for (int i = 0; i < repeatObjList.Count; i++)
            {
                codes += repeatObjList[i].Affair.AffairAssistantCode + ",";
                repeats.Add(repeatObjList[i]);
            }
            for (int i = 0; i < repeatModelList.Count; i++)
            {
                codes += repeatModelList[i].ModelAffairAssistantCode + ",";
                models.Add(repeatModelList[i]);
            }

            //闹铃
            List<EnAffairClock> clocks = new List<EnAffairClock>();
            if (codes != "")
            {
                codes = codes.Substring(0, codes.Length - 1);
                IList<EnAffairClock> clockList = BzAffairWithClock.GetAffairClock(codes);

                if (clockList != null)
                {
                    clocks.AddRange(clockList);
                }
            }

            //预约
            List<EnAffairBespeak> bespeaks = new List<EnAffairBespeak>();
            if (codes != "")
            {
                List<EnAffairClock> tmpClocks = new List<EnAffairClock>();
                List<EnAffairBespeak> tmpBespeaks = new List<EnAffairBespeak>();
                bespeaks = BzAffairBespeak.getAffairBespeak(userID, codes);

                //获取发起人是自己的预约的其他活动
                if (bespeaks != null)
                {
                    for (int i = 0; i < bespeaks.Count; i++)
                    {
                        if (bespeaks[i].InitiateUserID == bespeaks[i].InceptUserID)
                        {
                            IList<EnAffair> list = dal.GetListByAffairCode(bespeaks[i].AffairCode);
                            for (int j = 0; j < list.Count; j++)
                            {
                                if (list[j].MemoUserID != userID)
                                {
                                    affairs.Add(list[j]);
                                    EnAffairBespeak bes = BzAffairBespeak.getAffairBespeakByAffairCode(list[j].MemoUserID, list[j].AffairCode);
                                    if (bes != null)
                                        tmpBespeaks.Add(bes);
                                    IList<EnAffairClock> clockList = BzAffairWithClock.GetAffairClock("'" + list[j].AffairAssistantCode + "'");
                                    if (clockList != null)
                                        tmpClocks.AddRange(clockList);
                                }
                            }
                        }
                    }

                    bespeaks.AddRange(tmpBespeaks);
                    clocks.AddRange(tmpClocks);
                }
            }

            result.Affairs = affairs;
            result.RepeatAffairs = repeats;
            result.ModelAffairs = models;
            result.AffairClocks = clocks;
            result.AffairBespeaks = bespeaks;

            return result;
        }
        #endregion

        #region 根据用户ID和时间范围获取活动列表
        /// <summary>
        /// 获取活动数据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <returns></returns>
        public static IList<EnAffair> GetList(string userID, DateTime beginTime, DateTime endTime)
        {
            IList<EnAffair> list = new List<EnAffair>();

            try
            {
                //活动列表
                IList<EnAffair> affairList = dal.GetList(userID, beginTime, endTime);
                //重复周期列表
                IList<EnAffairMemoRepeat> repeatObjList = BzAffairRepeat.GetList(userID, beginTime, endTime);
                //重复周期实例列表

                //因为存储过程使用ModelDate进行between过滤，需要放大时间范围
                DateTime tmpBeginTime = beginTime.Date;
                DateTime tmpEndTime = endTime.AddDays(1).Date;

                IList<EnRepeatModel> repeatModelList = BzRepeatModel.GetList(userID, tmpBeginTime, tmpEndTime);

                if (repeatObjList.Count > 0)
                {
                    List<EnAffair> tmpList = new List<EnAffair>();
                    List<EnAffair> repeatAffairList = GetRepeatAffair(beginTime, endTime, repeatObjList, repeatModelList);
                    
                    //取重复周期的SQL存储过程的Where条件语句是按日期来筛选的，如果时间表有设置一天的开始时间，需要再次过滤
                    for (int i = 0, len = repeatAffairList.Count; i < len; i++)
                    {
                        EnAffair affair = repeatAffairList[i];

                        if (affair.BeginTime < endTime && affair.EndTime > beginTime)
                            tmpList.Add(affair);
                    }

                    DynamicBuilder<EnAffair>.mergeList(list, tmpList);
                }

                foreach (EnAffair affair in affairList)
                {
                    //重复周期数据
                    if (affair.IsRepeat == 1 && affair.ParentCode == 0)
                        continue;

                    string typeCode = affair.TypeCode;
                    //if (TMCommon.CheckIsType(typeCode, TMType.SendMeetingBespeak, TMType.InceptMeetingBespeak))
                    //    continue;

                    list.Add(affair);
                }
            }
            catch (Exception ex)
            {
                // do nothing
            }

            return list;
        }
        #endregion

        #region 获取重复周期活动的多条数据
        /// <summary>
        /// 获取重复周期活动的多条数据
        /// </summary>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <param name="repeatObjList">重复周期活动列表</param>
        /// <param name="repeatModelList">特例活动列表</param>
        /// <returns></returns>
        public static List<EnAffair> GetRepeatAffair(DateTime beginTime, DateTime endTime, IList<EnAffairMemoRepeat> repeatObjList, IList<EnRepeatModel> repeatModelList)
        {
            List<EnAffair> list = new List<EnAffair>();

            foreach (EnAffairMemoRepeat obj in repeatObjList)
            {
                if (obj.AffairRepeat.BeginDate > obj.AffairRepeat.EndDate)
                {
                    continue;
                }

                int modelState = 1;

                if (obj.Affair.BeginTime < endTime && obj.Affair.EndTime > beginTime)
                {
                    if (!BzRepeatModel.checkRepeatIsModel(repeatModelList, obj.AffairRepeat, obj.Affair.BeginTime.Date, out modelState))
                    {
                        list.Add(obj.Affair);
                    }
                    else if (modelState == 0)
                    {
                        EnAffair other = obj.Affair.Copy();
                        list.Add(other);
                    }
                }

                EnAffairRepeat affairRepeat = obj.AffairRepeat;
                EnAffair affair = obj.Affair;
                GetRepeatAffairList(list, beginTime, endTime, affairRepeat, affair, repeatModelList);
            }

            return list;
        }
        #endregion

        #region 拆分重复周期活动
        /// <summary>
        /// 拆分重复周期活动
        /// </summary>
        /// <param name="list">结果集</param>
        /// <param name="beginTime">开始时间</param>
        /// <param name="endTime">结束时间</param>
        /// <param name="affairRepeat">重复周期信息</param>
        /// <param name="affair">活动信息</param>
        /// <param name="repeatModelList">特例信息</param>
        public static void GetRepeatAffairList(List<EnAffair> list, DateTime beginTime, DateTime endTime, EnAffairRepeat affairRepeat, EnAffair affair, IList<EnRepeatModel> repeatModelList)
        {
            int spanDays = (affair.EndTime.Date - affair.BeginTime.Date).Days;
            DateTime repeatBDate = affairRepeat.BeginDate < beginTime ? beginTime : affairRepeat.BeginDate;
            DateTime repeatEDate = affairRepeat.EndDate > endTime ? endTime : affairRepeat.EndDate;

            repeatBDate = repeatBDate.AddDays(0 - spanDays);

            for (DateTime sdate = repeatBDate.Date; sdate <= repeatEDate.Date; sdate = sdate.AddDays(1))
            {
                if (sdate.Date < affairRepeat.BeginDate.Date) continue; //验证日期小于开始重复日期
                //重复周期验证
                if (!TMCommon.CheckRepeat(
                                        (TMRepeatMode)affairRepeat.RepeatMode,
                                        affairRepeat.RepeatValue,
                                        affairRepeat.RepeatSpace,
                                        affairRepeat.BeginDate, sdate))
                {
                    continue;
                }
                //重复周期实体验证
                int modelstate = 1;
                if (BzRepeatModel.checkRepeatIsModel(repeatModelList, affairRepeat, sdate, out  modelstate))
                {
                    if (modelstate == 1)
                    {
                        continue; //验证日期已被特例
                    }
                }

                if (sdate.Date == affair.BeginTime.Date || sdate.Date >= endTime) continue; //验证日期和事件同一天（已加载）（时间超出）

                EnAffair other = affair.Copy();
                if (modelstate == 0)
                {
                    other.RepeatModelState = 0;
                    //enAffair.IsMemoAvailability = 0;
                }
                int dayweek = (int)sdate.DayOfWeek;
                other.ParentCode = affair.AffairCode;
                other.BeginTime = TMCommon.DateSpell(sdate, affair.BeginTime);
                other.EndTime = TMCommon.DateSpell(sdate, affair.EndTime);
                other.EndTime = other.EndTime.AddDays(spanDays);//跨天天数差
                list.Add(other);

            }
        }
        #endregion

        #region 根据用户ID和活动编号获取唯一实例
        /// <summary>
        /// 根据用户ID和活动编号获取唯一实例
        /// </summary>
        /// <param name="affairCode"></param>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static EnAffair GetEntity(int affairCode, string userID)
        {
            try
            {
                return dal.GetEntity(affairCode, userID);
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        #endregion

        #region 获取某个活动的详细信息
        /// <summary>
        /// 获取某个活动的详细信息
        /// </summary>
        /// <param name="affairCode">活动编号</param>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public static EnAffairDetail GetAffairDetail(string userID, int affairCode)
        {
            EnAffairDetail detail = new EnAffairDetail();
            detail.affair = dal.GetEntity(affairCode, userID);
            detail.bespeakList = new List<EnAffairBespeak>();

            if (TMCommon.CheckIsType(detail.affair.TypeCode, TMType.InceptBespeak, TMType.SendBespeak))
            {
                IList<EnAffairBespeak> list = BzAffairBespeak.getAffairBespeakByAffairCode(affairCode);

                if (list != null)
                {
                    for (int i = 0; i < list.Count; i++)
                        detail.bespeakList.Add(list[i]);
                }
            }
            else if (TMCommon.CheckIsType(detail.affair.TypeCode, TMType.InceptMeetingBespeak, TMType.SendMeetingBespeak))
            {
                IList<EnAffairMeetingBespeak> list = BzAffairMeetingBespeak.GetAffairMeetingBespeakByAffairCode(affairCode);

                if (list != null)
                {
                    for (int i = 0; i < list.Count; i++)
                        detail.bespeakList.Add(BzAffairMeetingBespeak.ConvertAffairBespeak(list[i]));
                }
            }
            else if (TMCommon.CheckIsType(detail.affair.TypeCode, TMType.InceptCompanyDeadLine,TMType.InceptUserDeadLine,TMType.SendCompanyDeadLine,TMType.SendUserDeadLine))
            {
                IList<EnAffairBespeak> list = BzAffairDeadlineBespeak.GetAffairDeadlnieBespeakByAffairCode(affairCode);
                if (list != null)
                {
                    for (int i = 0; i < list.Count; i++)
                        detail.bespeakList.Add(list[i]);
                }
             
            }            

            return detail;
        }
        #endregion

        #region 修改重复周期，创建特例
        /// <summary>
        /// 修改重复周期特例
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="update"></param>
        /// <param name="repeatModel"></param>
        /// <returns></returns>
        public static EnAffair UpdateModel(EnAffair update, IList<EnAlarmClock> clockList, EnRepeatModel repeatModel)
        {
            EnAffair result = null;
            EnAffair oldAffair = BzAffair.GetEntity(update.ParentCode, update.UserID);
            if (oldAffair == null)
            {
                return result;
            }

            try
            {
                EnAffairRepeat repeat = BzAffairRepeat.GetEntity(update.ParentCode);

                if (repeat == null)
                {
                    throw new Exception("无法创建特例，因为父事件重复周期不存在");
                }

                repeatModel.RepeatCode = repeat.RepeatCode;
                result = Add(update, repeat, clockList, repeatModel);
            }
            catch (Exception ex)
            {
                // do nothing;
            }

            return result;
        }
        #endregion

        #region 修改重复周期，创建删除的特例
        /// <summary>
        /// 修改重复周期，创建删除的特例
        /// </summary>
        /// <param name="affair"></param>
        /// <returns></returns>
        public static int DeleteModel(EnAffair affair)
        {
            int result = 0;

            try
            {
                EnAffairRepeat affairRepeat = BzAffairRepeat.GetEntity(affair.AffairCode);

                EnRepeatModel repeatModel = new EnRepeatModel();
                repeatModel.ModelAffairCode = 0;
                repeatModel.RepeatCode = affairRepeat.RepeatCode;
                repeatModel.UserId = affair.UserID;
                repeatModel.ModelDate = affair.BeginTime;

                result = BzRepeatModel.Add(repeatModel);
            }
            catch (Exception ex)
            {
                // do nothing
            }

            return result;
        }
        #endregion

        #region 添加活动
        /// <summary>
        /// 添加活动
        /// </summary>
        /// <param name="trans">事务对象</param>
        /// <param name="enAffair">事件实体对象</param>
        /// <param name="memoList">事件详情列表</param>
        /// <param name="enAffairRepeat">重复周期</param>
        /// <param name="clockList">闹铃集合</param>
        /// <param name="checkList">检查表集合</param>
        /// <param name="kpiList">kpi集合</param>
        /// <param name="enRepeatModel">重复周期实体对象</param>
        /// <returns>新生成的事件主表Code</returns>
        protected internal static EnAffair Add(EnAffair affair, EnAffairRepeat affairRepeat, IList<EnAlarmClock> clockList, EnRepeatModel repeatModel)
        {
            try
            {
                #region 添加事件主表

                if (affairRepeat != null || affairRepeat != null)
                {
                    affair.IsRepeat = 1;
                }
                affair.IsAvailability = 1;
                affair.AffairCode = dal.AddAffairBody(affair);

                //实例化重复周期
                if (affair.ParentCode != 0 && repeatModel != null)
                {
                    repeatModel.ModelAffairCode = affair.AffairCode;
                    repeatModel.UserId = affair.UserID;
                    BzRepeatModel.Add(repeatModel);
                }

                #endregion

                //添加闹钟
                if (clockList != null && clockList.Count > 0)
                {
                    EnAlarmClock clock = clockList[0];
                    clock.ClockCode = BzAlarmClock.Add(clock);
                    affair.IsRemind = 1;
                }

                //事件详情相关添加操作
                affair.AffairAssistantCode = dal.AddAffairMemo(affair);

                //关联闹钟
                if (clockList.Count > 0)
                {
                    foreach (EnAlarmClock clock in clockList)
                    {
                        EnAffairAssistantWithAlarmClock affairClock = new EnAffairAssistantWithAlarmClock();
                        affairClock.AffairAssistantCode = affair.AffairAssistantCode;
                        affairClock.AlarmClockCode = clock.ClockCode;
                        affairClock.UserID = affair.UserID;

                        BzAffairWithClock.AddAffairClock(affairClock);
                    }

                }

                return affair;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region 修改事件详情是否有效状态
        /// <summary>
        /// 修改事件详情是否有效状态
        /// </summary>
        /// <param name="trans">事务对象</param>
        /// <param name="en">事件详情</param>
        /// <returns>1：成功</returns>
        protected internal static int UpdateIsAvailability(EnAffair affair)
        {
            try
            {
                return dal.UpdateIsAvailability(affair);
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region 删除事件详情表
        /// <summary>
        /// 删除事件详情表
        /// </summary>
        /// <param name="trans"></param>
        /// <param name="en"></param>
        /// <returns></returns>
        protected internal static int DeleteAffairMemo(EnAffair affair)
        {
            try
            {
                /*
                if (en.IsRemind == 1) //删除事件闹铃信息
                {
                    BzAffairWithClock.DeleteClockByAffairMemoCode(en.AffairAssistantCode);
                }

                if (en.IsUsingKpi == 1)//删除事件绑定kpi项
                {
                    DaAffairAssistantKpi dalAffairKpi = new DaAffairAssistantKpi();
                    BzAffairAssistantKpi.Delete(en.MemoUserID, en.AffairAssistantCode);
                }

                if (en.IsUsingCheck == 1) //删除用户检查表确认项
                {
                    BzAffairCheckConfirm.DeleteByAffairMemoCode(en.AffairAssistantCode, en.MemoUserID);
                }

                if (en.IsRepeat == 1 && en.ParentCode == 0) //删除该任务对应的重复周期特例事件     
                {
                    BzRepeatModel.DeleteByAffairCodeAndUserID(en.AffairCode, en.MemoUserID);
                }
                */

                return dal.DeleteAffairMemo(affair);

            }
            catch (Exception ex)
            {
                throw ex;
            }
        }
        #endregion

        #region 根据活动开始时间对List排序
        /// <summary>
        /// 根据活动开始时间对List排序
        /// </summary>
        /// <param name="a1"></param>
        /// <param name="a2"></param>
        /// <returns></returns>
        public static int SortByBeginTime(EnAffair a1, EnAffair a2)
        {
            return a1.BeginTime.CompareTo(a2.BeginTime);
        }
        #endregion

        #region 根据活动开始时间对List排序
        /// <summary>
        /// 根据活动开始时间对List排序
        /// </summary>
        /// <param name="a1"></param>
        /// <param name="a2"></param>
        /// <returns></returns>
        public static int SortByBeginTime(EnAffairWithCalendar a1, EnAffairWithCalendar a2)
        {
            return a1.Affair.BeginTime.CompareTo(a2.Affair.BeginTime);
        }
        #endregion
    }
}
