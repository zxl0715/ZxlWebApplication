﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using Nd.Erp.Mobile.Service.TimeManage.Entity;

namespace Nd.Erp.Mobile.Service.TimeManage
{
    [ServiceContract]
    [ServiceKnownType(typeof(EnAffairEx))]
    public interface ITimeManageJson
    {
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getEventList?userID={userID}&beginTime={beginTime}&endTime={endTime}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnAffair> getEventList(string userID, string beginTime, string endTime);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getEventListWithCalendar?userID={userID}&beginTime={beginTime}&endTime={endTime}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnAffairWithCalendar> getEventListWithCalendar(string userID, string beginTime, string endTime);


        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getHasEventList?userID={userID}&beginTime={beginTime}&endTime={endTime}", BodyStyle = WebMessageBodyStyle.Bare)]
        string getHasEventList(string userID, string beginTime, string endTime);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getAffairs?userID={userID}&beginTime={beginTime}&endTime={endTime}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnTwoWeekAffair getAffairs(string userID, string beginTime, string endTime);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getAffairClockListByAffairCodes?codes={codes}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnAffairClock> getAffairClockListByAffairCodes(string codes);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getUserConfig?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnUserConfig getUserConfig(string userID);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getAttentionUsers?sPersonCode={sPersonCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<PersonEntity> getAttentionUsers(string sPersonCode);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getEventEntity?userID={userID}&affairCode={affairCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnAffair getEventEntity(string userID, string affairCode);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getMeetingRoom", BodyStyle = WebMessageBodyStyle.Bare)]
        List<String> getMeetingRoom();

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getAffairDetail?userID={userID}&affairCode={affairCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnAffairDetail getAffairDetail(string userID, string affairCode);






        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getEventDetailInfo?code={code}", BodyStyle = WebMessageBodyStyle.Bare)]
        EventEntity getEventDetailInfo(string code);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "addSimpleEvent?userID={userID}&title={title}&startTime={startTime}&endTime={endTime}&address={address}&XmCode={XmCode}&memo={memo}&alarm={alarm}&alarmTime={alarmTime}", BodyStyle = WebMessageBodyStyle.Bare)]
        string addSimpleEvent(string userID, string title, string startTime, string endTime, string address, string XmCode, string memo, string alarm, string alarmTime);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "delSimpleEvent?userID={userID}&affairCode={affairCode}&isRepeat={isRepeat}&isAffairType={isAffairType}&date={date}", BodyStyle = WebMessageBodyStyle.Bare)]
        string delSimpleEvent(string userID, string affairCode, string isRepeat, string isAffairType, string date);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "updateSimpleEvent?userID={userID}&affairCode={affairCode}&isRepeat={isRepeat}&isAffairType={isAffairType}&title={title}&startTime={startTime}&endTime={endTime}&address={address}&XmCode={XmCode}&memo={memo}&alarm={alarm}&alarmTime={alarmTime}", BodyStyle = WebMessageBodyStyle.Bare)]
        string updateSimpleEvent(string userID, string affairCode, string isRepeat, string isAffairType, string title, string startTime, string endTime, string address, string XmCode, string memo, string alarm, string alarmTime);
                
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "acceptBespeak?userID={userID}&affairCode={affairCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        bool acceptBespeak(string userID, string affairCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "denyBespeak?userID={userID}&affairCode={affairCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        bool denyBespeak(string userID, string affairCode);
        
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "insertERPDailyLog?userID={userID}&logDate={logDate}", BodyStyle = WebMessageBodyStyle.Bare)]
        string[] insertERPDailyLog(string userID, string logDate);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getTodoList?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnTodoEvent> getTodoList(string userID);

        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "insertTodoList?userID={userID}&title={title}&colorType={colorType}", BodyStyle = WebMessageBodyStyle.Bare)]
        bool insertTodoList(string userID, string title, string colorType);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getCalendar?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnCalendar> getCalendar(string userID);
    }

}
