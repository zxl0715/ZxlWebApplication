﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /// <summary>
    /// 简单的便签实体
    /// </summary>
    [DataContract]
    public class EnTodoEvent
    {
  
    
        [DataMember]
        public string Title { get; set; }

        [DataMember]
        public string ColorType { get; set; }

 
    }
}
