﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnRepeatModel
    {
        public EnRepeatModel()
        { }

        private int m_autoCode;

        private int m_modelAffairCode;

        private int m_modelAffairAssistantCode;

        private int m_repeatCode;

        private int m_affairCode;

        private string m_userId;

        private DateTime m_modelDate;

        private DateTime? m_addTime;

        private int m_modelState;

        #region 所在数据表的自动编号
        [DataMember]
        public int AutoCode
        {
            get { return m_autoCode; }
            set { m_autoCode = value; }
        }
        #endregion

        #region 实例活动主表编号
        [DataMember]
        public int ModelAffairCode
        {
            get { return m_modelAffairCode; }
            set { m_modelAffairCode = value; }
        }
        #endregion

        [DataMember]
        public int ModelAffairAssistantCode
        {
            get { return m_modelAffairAssistantCode; }
            set { m_modelAffairAssistantCode = value; }
        }

        #region 重复周期编号
        [DataMember]
        public int RepeatCode
        {
            get { return m_repeatCode; }
            set { m_repeatCode = value; }
        }
        #endregion

        [DataMember]
        public int AffairCode
        {
            get { return m_affairCode; }
            set { m_affairCode = value; }
        }

        #region 所属员工工号
        [DataMember]
        public string UserId
        {
            get { return m_userId; }
            set { m_userId = value; }
        }
        #endregion

        #region 实例活动发生日期
        [DataMember]
        public DateTime ModelDate
        {
            get { return m_modelDate; }
            set { m_modelDate = value; }
        }
        #endregion

        [DataMember]
        public DateTime? AddTime
        {
            get { return m_addTime; }
            set { m_addTime = value; }
        }
        
        #region 特例是否有效 1:有效 0:无效
        [DataMember]
        public int ModelState
        {
            get { return m_modelState; }
            set { m_modelState = value; }
        }
        #endregion
       
    }
}
