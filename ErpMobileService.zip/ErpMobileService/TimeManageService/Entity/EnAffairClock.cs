﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnAffairClock
    {
        public EnAffairClock()
        { }

        private EnAffairAssistantWithAlarmClock m_affairClock;

        private EnAlarmClock m_clock;


        #region 活动闹铃关系
        [DataMember]
        public EnAffairAssistantWithAlarmClock AffairClock
        {
            get { return m_affairClock; }
            set { m_affairClock = value; }
        }
        #endregion


        #region 闹铃
        [DataMember]
        public EnAlarmClock Clock
        {
            get { return m_clock; }
            set { m_clock = value; }
        }
        #endregion
    }
}
