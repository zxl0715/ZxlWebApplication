﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnAffairBespeak
    {
        private int m_autoCode;

        private int m_affairCode;

        private string m_initiateUserID;

        private string m_inceptUserID;

        private int m_bespeakState;

        private DateTime m_addTime;


        #region 编号
        [DataMember]
        public int AutoCode
        {
            get { return m_autoCode; }
            set { m_autoCode = value; }
        }
        #endregion

        #region 事件主表编号
        [DataMember]
        public int AffairCode
        {
            get { return m_affairCode; }
            set { m_affairCode = value; }
        }
        #endregion

        #region 预约发起者
        [DataMember]
        public string InitiateUserID
        {
            get { return m_initiateUserID; }
            set { m_initiateUserID = value; }
        }
        #endregion

        #region 预约接收者
        [DataMember]
        public string InceptUserID
        {
            get { return m_inceptUserID; }
            set { m_inceptUserID = value; }
        }
        #endregion

        #region 预约状态0：未确定，1：已确定，2：已拒绝
        [DataMember]
        public int BespeakState
        {
            get { return m_bespeakState; }
            set { m_bespeakState = value; }
        }
        #endregion

        #region 添加时间
        [DataMember]
        public DateTime AddTime
        {
            get { return m_addTime; }
            set { m_addTime = value; }
        }
        #endregion

        

        

        

        

        

        
    }
}
