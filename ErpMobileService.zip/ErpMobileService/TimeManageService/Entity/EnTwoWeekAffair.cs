﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnTwoWeekAffair
    {
        /// <summary>
        /// 非重复活动
        /// </summary>
        private List<EnAffair> m_affairs;

        /// <summary>
        /// 重复活动
        /// </summary>
        private List<EnAffairMemoRepeat> m_repeatAffairs;

        /// <summary>
        /// 特例活动
        /// </summary>
        private List<EnRepeatModel> m_modelAffairs;

        /// <summary>
        /// 闹铃
        /// </summary>
        private List<EnAffairClock> m_affairClocks;

        /// <summary>
        /// 预约
        /// </summary>
        private List<EnAffairBespeak> m_affairBespeaks;


        [DataMember]
        public List<EnAffair> Affairs
        {
            get { return m_affairs; }
            set { m_affairs = value; }
        }

        [DataMember]
        public List<EnAffairMemoRepeat> RepeatAffairs
        {
            get { return m_repeatAffairs; }
            set { m_repeatAffairs = value; }
        }

        [DataMember]
        public List<EnRepeatModel> ModelAffairs
        {
            get { return m_modelAffairs; }
            set { m_modelAffairs = value; }
        }

        [DataMember]
        public List<EnAffairClock> AffairClocks
        {
            get { return m_affairClocks; }
            set { m_affairClocks = value; }
        }

        [DataMember]
        public List<EnAffairBespeak> AffairBespeaks
        {
            get { return m_affairBespeaks; }
            set { m_affairBespeaks = value; }
        }
    }
}
