﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /// <summary>
    /// 会议预约实体
    /// </summary>
    [DataContract]
    public class EnAffairMeetingBespeak : EnAffairBespeak
    {
        //备注
        [DataMember]
        public String Memo { get; set; }
    }
}
