﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /// <summary>
    /// 日历数据实体
    /// </summary>
    [DataContract]
    public partial class EnCalendar
    {
        
		/// <summary>
		/// 日历编号
		/// </summary>
        [DataMember]
		public int CalendarCode{ get; set; }
			
        
		/// <summary>
		/// 日历名称
		/// </summary>
        [DataMember]
		public string CalendarName{ get; set; }
			
        
		/// <summary>
		/// 0：自己，1：任何人，2：部门
		/// </summary>
        [DataMember]
		public Int16 ShareType{ get; set; }
			
        
		/// <summary>
		/// 0：表示系统日历 索引
		/// </summary>
        [DataMember]
		public string UserID{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public int CalendarType{ get; set; }
			
        
		/// <summary>
		/// 颜色类型
		/// </summary>
        [DataMember]
		public int ColorType{ get; set; }
			
        
		/// <summary>
		/// 0：不显示，1：显示
		/// </summary>
        [DataMember]
		public Int16 IsShow{ get; set; }
			
        
		/// <summary>
		/// 0：未作废1：已作废
		/// </summary>
        [DataMember]
		public Int16 IsDelete{ get; set; }
			
        
		/// <summary>
		/// 删除时间
		/// </summary>
        [DataMember]
		public DateTime DeleteTime{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
		
	}
}
