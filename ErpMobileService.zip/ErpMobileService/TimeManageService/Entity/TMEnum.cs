﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    #region 活动类型枚举
    public enum TMType
    {
        //Currently
        None = 0,

        /// <summary>
        /// 我发起的公司DeadLine
        /// </summary>
        SendCompanyDeadLine = 1,

        /// <summary>
        /// 我接收的公司DeadLine
        /// </summary>
        InceptCompanyDeadLine = 2,

        /// <summary>
        /// 我发起的个人DeadLine
        /// </summary>
        SendUserDeadLine = 3,

        /// <summary>
        /// 我接收的个人DeadLine
        /// </summary>
        InceptUserDeadLine = 4,

        /// <summary>
        /// 我发起的预约
        /// </summary>
        SendBespeak = 5,

        /// <summary>
        /// 我接受的预约
        /// </summary>
        InceptBespeak = 6,

        /// <summary>
        /// ERP下单
        /// </summary>
        CompanyERP = 7,

        /// <summary>
        /// 会议系统
        /// </summary>
        CompanyMeet = 8,

        /// <summary>
        /// 网龙大学培训
        /// </summary>
        CompanyCulture = 9,

        /// <summary>
        /// KM相关
        /// </summary>
        KM = 10,

        /// <summary>
        /// 网龙大学ELearning
        /// </summary>
        ELearning = 11,

        /// <summary>
        /// 我发起的会议预约
        /// </summary>
        SendMeetingBespeak = 12,

        /// <summary>
        /// 我接受的会议预约
        /// </summary>
        InceptMeetingBespeak = 13,

        /// <summary>
        /// 已纳入安排的ERP单据
        /// </summary>
        CompanyALERP = 14
    };
    #endregion

    #region 重复模式
    public enum TMRepeatMode
    {
        /// <summary>天模式 </summary>
        Day = 1,
        /// <summary>周模式 </summary>
        Week = 2,
        /// <summary>月模式 </summary>
        Month = 3,
    }
    #endregion
}
