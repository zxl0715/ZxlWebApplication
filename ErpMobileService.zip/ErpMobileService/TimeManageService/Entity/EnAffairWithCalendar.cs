﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /// <summary>
    /// 简单的活动实体和日历的组合
    /// </summary>
    [DataContract]
    public class EnAffairWithCalendar
    {
        /// <summary>
        /// 普通活动
        /// </summary>
        private EnAffair m_affair;

        /// <summary>
        /// 普通活动的calendarId对应的日历类
        /// </summary>
        private EnCalendar m_calendar;

        [DataMember]
        public EnAffair Affair
        {
            get { return m_affair; }
            set { m_affair = value; }
        }

        [DataMember]
        public EnCalendar Calendar
        {
            get { return m_calendar; }
            set { m_calendar = value; }
        }

    }
}
