﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /// <summary>
    /// 简单的活动实体
    /// </summary>
    [DataContract]
    public class EnAffair
    {
        private int m_affairCode;

        private string m_title;

        private string m_address;

        private string m_memo;

        private int m_parentCode;

        private string m_userID;

        private string m_agentUserID;

        private int m_isRepeat;

        private int m_isUsingCheck;

        private int m_isUsingMeetingDecision;

        private int m_isAvailability = 1;

        private string m_XMFCode;

        private string m_XMCode;

        private string m_meetingPurpose;

        private int m_affairAssistantCode;

        private DateTime m_beginTime;

        private DateTime m_endTime;

        private string m_memoUserID;

        private int m_calendarCode;

        private int m_shareType = 1;

        private int m_druckerType = 1;

        private int m_levelType = 3;

        private int m_isAffairType;

        private string m_typeCode = "";

        private int m_isRemind;

        private int m_isUsingKpi;

        private int m_isMemoAvailability = 1;

        private DateTime? m_addTime;

        private int m_isCanEdit;

        private int m_isToErpLog;

        private int m_eventCodeSign;

        private int m_eventCodeEditSign;

        private DateTime? m_eventEditTime;

        private string m_sourceCode = "0";

        private int m_repeatModelState = 1;


        public EnAffair()
        { }

        #region 活动编号
        [DataMember]
        public int AffairCode
        {
            get { return m_affairCode; }
            set { m_affairCode = value; }
        }
        #endregion

        #region 主题
        [DataMember]
        public string Title
        {
            get { return m_title; }
            set { m_title = value; }
        }
        #endregion

        #region 地点
        [DataMember]
        public string Address
        {
            get { return m_address; }
            set { m_address = value; }
        }
        #endregion

        #region 内容
        [DataMember]
        public string Memo
        {
            get { return m_memo; }
            set { m_memo = value; }
        }
        #endregion

        #region 父编号，重复活动
        [DataMember]
        public int ParentCode
        {
            get { return m_parentCode; }
            set { m_parentCode = value; }
        }
        #endregion

        #region 创建用户ID
        [DataMember]
        public string UserID
        {
            get { return m_userID; }
            set { m_userID = value; }
        }
        #endregion

        #region 代理用户ID
        [DataMember]
        public string AgentUserID
        {
            get { return m_agentUserID; }
            set { m_agentUserID = value; }
        }
        #endregion

        #region 是否重复
        [DataMember]
        public int IsRepeat
        {
            get { return m_isRepeat; }
            set { m_isRepeat = value; }
        }
        #endregion

        #region 是否使用检查表
        [DataMember]
        public int IsUsingCheck
        {
            get { return m_isUsingCheck; }
            set { m_isUsingCheck = value; }
        }
        #endregion

        #region 是否使用会议议程
        [DataMember]
        public int IsUsingMeetingDecision
        {
            get { return m_isUsingMeetingDecision; }
            set { m_isUsingMeetingDecision = value; }
        }
        #endregion

        #region 是否有效
        [DataMember]
        public int IsAvailability
        {
            get { return m_isAvailability; }
            set { m_isAvailability = value; }
        }
        #endregion

        #region 二级项目编码
        [DataMember]
        public string XMCode
        {
            get { return m_XMCode; }
            set { m_XMCode = value; }
        }
        #endregion

        #region 一级项目编码
        [DataMember]
        public string XMFCode
        {
            get { return m_XMFCode; }
            set { m_XMFCode = value; }
        }
        #endregion

        #region 会议目的
        [DataMember]
        public string MeetingPurpose
        {
            get { return m_meetingPurpose; }
            set { m_meetingPurpose = value; }
        }
        #endregion

        #region 活动详情编号
        [DataMember]
        public int AffairAssistantCode
        {
            get { return m_affairAssistantCode; }
            set { m_affairAssistantCode = value; }
        }
        #endregion

        #region 开始时间
        [DataMember]
        public DateTime BeginTime
        {
            get { return m_beginTime; }
            set { m_beginTime = value; }
        }
        #endregion

        #region 结束时间
        [DataMember]
        public DateTime EndTime
        {
            get { return m_endTime; }
            set { m_endTime = value; }
        }
        #endregion

        #region 活动用户ID
        [DataMember]
        public string MemoUserID
        {
            get { return m_memoUserID; }
            set { m_memoUserID = value; }
        }
        #endregion

        #region 日历编号
        [DataMember]
        public int CalendarCode
        {
            get { return m_calendarCode; }
            set { m_calendarCode = value; }
        }
        #endregion

        #region 共享类型
        [DataMember]
        public int ShareType
        {
            get { return m_shareType; }
            set { m_shareType = value; }
        }
        #endregion

        #region 德鲁克类型
        [DataMember]
        public int DruckerType
        {
            get { return m_druckerType; }
            set { m_druckerType = value; }
        }
        #endregion

        #region 重要紧急程度
        [DataMember]
        public int LevelType
        {
            get { return m_levelType; }
            set { m_levelType = value; }
        }
        #endregion

        #region 是否有标识 1:有标识 0:无标识
        [DataMember]
        public int IsAffairType
        {
            get { return m_isAffairType; }
            set { m_isAffairType = value; }
        }
        #endregion

        #region 活动类型
        [DataMember]
        public string TypeCode
        {
            get { return m_typeCode; }
            set { m_typeCode = value; }
        }
        #endregion

        #region 是否闹铃提醒
        [DataMember]
        public int IsRemind
        {
            get { return m_isRemind; }
            set { m_isRemind = value; }
        }
        #endregion

        #region 是否使用KPI
        [DataMember]
        public int IsUsingKpi
        {
            get { return m_isUsingKpi; }
            set { m_isUsingKpi = value; }
        }
        #endregion

        #region 是否有效 1:有效 0:无效
        [DataMember]
        public int IsMemoAvailability
        {
            get { return m_isMemoAvailability; }
            set { m_isMemoAvailability = value; }
        }
        #endregion

        #region 创建时间
        [DataMember]
        public DateTime? AddTime
        {
            get { return m_addTime; }
            set { m_addTime = value; }
        }
        #endregion

        #region 是否可编辑
        [DataMember]
        public int IsCanEdit
        {
            get { return m_isCanEdit; }
            set { m_isCanEdit = value; }
        }
        #endregion

        #region 是否转ERP日志
        [DataMember]
        public int IsToErpLog
        {
            get { return m_isToErpLog; }
            set { m_isToErpLog = value; }
        }
        #endregion

        [DataMember]
        public int EventCodeSign
        {
            get { return m_eventCodeSign; }
            set { m_eventCodeSign = value; }
        }

        [DataMember]
        public int EventCodeEditSign
        {
            get { return m_eventCodeEditSign; }
            set { m_eventCodeEditSign = value; }
        }

        #region 编辑时间
        [DataMember]
        public DateTime? EventEditTime
        {
            get { return m_eventEditTime; }
            set { m_eventEditTime = value; }
        }
        #endregion

        #region 活动来源编号
        [DataMember]
        public string SourceCode
        {
            get { return m_sourceCode; }
            set { m_sourceCode = value; }
        }
        #endregion

        #region 是否为有效的特例 1:有效 0:失效
        [DataMember]
        public int RepeatModelState
        {
            get { return m_repeatModelState; }
            set { m_repeatModelState = value; }
        }
        #endregion


        /// <summary>
        /// 拷贝实体
        /// </summary>
        /// <returns>拷贝后的副本</returns>
        public EnAffair Copy()
        {
            EnAffair affair = new EnAffair();

            affair.AffairCode = m_affairCode;
            affair.Title = m_title;
            affair.Address = m_address;
            affair.Memo = m_memo;
            affair.ParentCode = m_parentCode;
            affair.UserID = m_userID;
            affair.AgentUserID = m_agentUserID;
            affair.IsRepeat = m_isRepeat;
            affair.IsUsingCheck = m_isUsingCheck;
            affair.IsAvailability = m_isAvailability;
            affair.AddTime = m_addTime;
            affair.XMCode = m_XMCode;
            affair.XMFCode = m_XMFCode;
            affair.MeetingPurpose = m_meetingPurpose;
            affair.IsUsingMeetingDecision = m_isUsingMeetingDecision;
            affair.AffairAssistantCode = m_affairAssistantCode;
            affair.MemoUserID = m_memoUserID;
            affair.BeginTime = m_beginTime;
            affair.EndTime = m_endTime;
            affair.CalendarCode = m_calendarCode;
            affair.ShareType = m_shareType;
            affair.DruckerType = m_druckerType;
            affair.LevelType = m_levelType;
            affair.IsAffairType = m_isAffairType;
            affair.IsRemind = m_isRemind;
            affair.IsUsingKpi = m_isUsingKpi;
            affair.IsMemoAvailability = m_isMemoAvailability;
            affair.IsCanEdit = m_isCanEdit;
            affair.IsToErpLog = m_isToErpLog;
            affair.EventCodeSign = m_eventCodeSign;
            affair.EventCodeEditSign = m_eventCodeEditSign;
            affair.EventEditTime = m_eventEditTime;
            affair.TypeCode = m_typeCode;
            affair.SourceCode = m_sourceCode;
            affair.RepeatModelState = m_repeatModelState;

            return affair;
        }

    }
}
