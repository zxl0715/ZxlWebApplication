﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnAlarmClock
    {
        public EnAlarmClock()
        { }

        private int m_clockCode;

        private string m_title;

        private string m_userID;

        private int m_clockType = 0;

        private DateTime m_clockTime;

        private int m_clockSource = 1;

        private int m_repeatMode = 0;

        private string m_repeatValue;

        private DateTime m_repeatBeginDate = DateTime.Now;

        private DateTime m_repeatEndDate = DateTime.Now;

        private int m_spaceMinute = 0;

        private DateTime m_spaceBtime = DateTime.Now;

        private DateTime m_spaceEtime = DateTime.Now;

        private DateTime? m_addTime;

        private string m_sourceCode = "0";
        
        


        #region 闹铃编号
        [DataMember]
        public int ClockCode
        {
            get { return m_clockCode; }
            set { m_clockCode = value; }
        }
        #endregion

        #region 标题
        [DataMember]
        public string Title
        {
            get { return m_title; }
            set { m_title = value; }
        }
        #endregion

        #region 用户ID
        [DataMember]
        public string UserID
        {
            get { return m_userID; }
            set { m_userID = value; }
        }
        #endregion

        #region 提醒方式
        [DataMember]
        public int ClockType
        {
            get { return m_clockType; }
            set { m_clockType = value; }
        }
        #endregion

        #region 提醒时间
        [DataMember]
        public DateTime ClockTime
        {
            get { return m_clockTime; }
            set { m_clockTime = value; }
        }
        #endregion

        [DataMember]
        public int ClockSource
        {
            get { return m_clockSource; }
            set { m_clockSource = value; }
        }

        [DataMember]
        public int RepeatMode
        {
            get { return m_repeatMode; }
            set { m_repeatMode = value; }
        }

        [DataMember]
        public string RepeatValue
        {
            get { return m_repeatValue; }
            set { m_repeatValue = value; }
        }

        [DataMember]
        public DateTime RepeatBeginDate
        {
            get { return m_repeatBeginDate; }
            set { m_repeatBeginDate = value; }
        }

        [DataMember]
        public DateTime RepeatEndDate
        {
            get { return m_repeatEndDate; }
            set { m_repeatEndDate = value; }
        }

        [DataMember]
        public int SpaceMinute
        {
            get { return m_spaceMinute; }
            set { m_spaceMinute = value; }
        }

        [DataMember]
        public DateTime SpaceBtime
        {
            get { return m_spaceBtime; }
            set { m_spaceBtime = value; }
        }

        [DataMember]
        public DateTime SpaceEtime
        {
            get { return m_spaceEtime; }
            set { m_spaceEtime = value; }
        }

        [DataMember]
        public DateTime? AddTime
        {
            get { return m_addTime; }
            set { m_addTime = value; }
        }

        [DataMember]
        public string SourceCode
        {
            get { return m_sourceCode; }
            set { m_sourceCode = value; }
        }
    }
}
