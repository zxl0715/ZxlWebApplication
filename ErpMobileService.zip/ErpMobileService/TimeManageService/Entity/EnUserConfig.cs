﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnUserConfig
    {
        private int m_autoCode;

        private string m_userID;

        private int m_loadMode;

        private string m_beginTime;

        private string m_endTime;

        private DateTime? m_addTime;

        private string m_defaultXm;

        #region
        [DataMember]
        public int AutoCode
        {
            get { return m_autoCode; }
            set { m_autoCode = value; }
        }
        #endregion

        #region
        [DataMember]
        public string UserID
        {
            get { return m_userID; }
            set { m_userID = value; }
        }
        #endregion

        #region
        [DataMember]
        public int LoadMode
        {
            get { return m_loadMode; }
            set { m_loadMode = value; }
        }
        #endregion

        #region
        [DataMember]
        public string BeginTime
        {
            get { return m_beginTime; }
            set { m_beginTime = value; }
        }
        #endregion

        #region
        [DataMember]
        public string EndTime
        {
            get { return m_endTime; }
            set { m_endTime = value; }
        }
        #endregion

        #region
        [DataMember]
        public DateTime? AddTime
        {
            get { return m_addTime; }
            set { m_addTime = value; }
        }
        #endregion

        #region
        [DataMember]
        public string DefaultXm
        {
            get { return m_defaultXm; }
            set { m_defaultXm = value; }
        }
        #endregion

    }
}
