﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnAffairMemoRepeat
    {
        public EnAffairMemoRepeat()
        { }

        private EnAffair m_affair;

        private EnAffairRepeat m_affairRepeat;

        [DataMember]
        public EnAffair Affair
        {
            get { return m_affair; }
            set { m_affair = value; }
        }

        [DataMember]
        public EnAffairRepeat AffairRepeat
        {
            get { return m_affairRepeat; }
            set { m_affairRepeat = value; }
        }
    }
    
    /**
     * 重复周期
     **/
    [DataContract]
    public class EnAffairRepeat
    {
        public EnAffairRepeat()
        { }

        private int m_repeatCode;

        private int m_affairCode;

        private string m_userID;

        private int m_repeatMode;

        private string m_repeatValue;

        private int m_repeatSpace;

        private DateTime m_beginDate;

        private DateTime m_endDate;

        private DateTime? m_addTime;

        #region 重复周期编号
        [DataMember]
        public int RepeatCode
        {
            get { return m_repeatCode; }
            set { m_repeatCode = value; }
        }
        #endregion

        #region 活动编号
        [DataMember]
        public int AffairCode
        {
            get { return m_affairCode; }
            set { m_affairCode = value; }
        }
        #endregion
        
        #region 所属员工编号
        [DataMember]
        public string UserID
        {
            get { return m_userID; }
            set { m_userID = value; }
        }
        #endregion
        
        #region 重复模式（1天模式 2周模式 3月模式）
        [DataMember]
        public int RepeatMode
        {
            get { return m_repeatMode; }
            set { m_repeatMode = value; }
        }
        #endregion

        #region 重复值
        [DataMember]
        public string RepeatValue
        {
            get { return m_repeatValue; }
            set { m_repeatValue = value; }
        }
        #endregion

        #region 重复间隔
        [DataMember]
        public int RepeatSpace
        {
            get { return m_repeatSpace; }
            set { m_repeatSpace = value; }
        }
        #endregion

        #region 开始日期
        [DataMember]
        public DateTime BeginDate
        {
            get { return m_beginDate; }
            set { m_beginDate = value; }
        }
        #endregion

        #region 结束日期
        [DataMember]
        public DateTime EndDate
        {
            get { return m_endDate; }
            set { m_endDate = value; }
        }
        #endregion

        #region 添加时间
        [DataMember]
        public DateTime? AddTime
        {
            get { return m_addTime; }
            set { m_addTime = value; }
        }
        #endregion
    }
}
