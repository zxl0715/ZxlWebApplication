﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /// <summary>
    /// 活动详情
    /// </summary>
    [DataContract]
    public class EnAffairDetail
    {
        //活动
        [DataMember]
        public EnAffair affair { get; set; }

        //预约
        [DataMember]
        public List<EnAffairBespeak> bespeakList { get; set; }
    }
}
