﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /// <summary>
    /// ERP工作日志
    /// </summary>
    public class EnWorkLog
    {
        /// <summary>
        /// 日志编号
        /// </summary>
        public int code { get; set; }

        /// <summary>
        /// 日志日期
        /// </summary>
        public DateTime date { get; set; }

        /// <summary>
        /// 单据类型：正常单据、补填单据
        /// </summary>
        public string logType { get; set; }

        /// <summary>
        /// 用户ID
        /// </summary>
        public string userID { get; set; }

        /// <summary>
        /// 用户
        /// </summary>
        public string userName { get; set; }

        /// <summary>
        /// 所属部门编号
        /// </summary>
        public string userDeptCode { get; set; }

        /// <summary>
        /// 所属部门
        /// </summary>
        public string userDeptName { get; set; }

        /// <summary>
        /// 全称：姓名(部门)
        /// </summary>
        public string mPeople { get; set; }

        /// <summary>
        /// 总工时
        /// </summary>
        public double totalHour { get; set; }

        /// <summary>
        /// 总工作量百分比
        /// </summary>
        public double totalPercent { get; set; }

        /// <summary>
        /// 违规标识
        /// </summary>
        public bool isIllegal { get; set; }

        /// <summary>
        /// 日志内容
        /// </summary>
        public List<EnWorkLogItem> list { get; set; }

        /// <summary>
        /// 其中的任务编号
        /// </summary>
        public string taskCodes { get; set; }

        public bool isHour = true;
        public bool isExtend = false;
        public bool isShowLink = true;
        public bool isFinPercent = false;
    }

    /// <summary>
    /// ERP工作日志内容项
    /// </summary>
    public class EnWorkLogItem
    {
        /// <summary>
        /// 内容类型：1、新增行 2、任务单据 3、时间管理 4、会议管理
        /// </summary>
        public string type { get; set; }

        /// <summary>
        /// 编号
        /// </summary>
        public string code { get; set; }

        /// <summary>
        /// 任务号
        /// </summary>
        public string taskCode { get; set; }

        /// <summary>
        /// 一级项目编号
        /// </summary>
        public string xmFCode { get; set; }

        /// <summary>
        /// 二级项目编号
        /// </summary>
        public string xmCode { get; set; }

        /// <summary>
        /// 部门编号
        /// </summary>
        public string depCode { get; set; }

        /// <summary>
        /// 日志内容
        /// </summary>
        public string content { get; set; }

        /// <summary>
        /// 工作时数
        /// </summary>
        public double hour { get; set; }

        /// <summary>
        /// 工作量
        /// </summary>
        public double percent { get; set; }

        /// <summary>
        /// 任务进度
        /// </summary>
        public double xmPercent { get; set; }

        /// <summary>
        /// 任务状态
        /// </summary>
        public string state { get; set; }

        /// <summary>
        /// 链接地址
        /// </summary>
        public string url { get; set; }

        /// <summary>
        /// 备注
        /// </summary>
        public string memo { get; set; }
    }
}
