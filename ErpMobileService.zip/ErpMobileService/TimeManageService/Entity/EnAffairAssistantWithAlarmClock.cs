﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    [DataContract]
    public class EnAffairAssistantWithAlarmClock
    {
        public EnAffairAssistantWithAlarmClock()
        {}

        [DataMember]
        public int AutoCode { get; set; }

        [DataMember]
        public int AffairAssistantCode { get; set; }

        [DataMember]
        public int AlarmClockCode { get; set; }

        [DataMember]
        public DateTime? AddTime { get; set; }

        [DataMember]
        public string UserID { get; set; }


    }
}
