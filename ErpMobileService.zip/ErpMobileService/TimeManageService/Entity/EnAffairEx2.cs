﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.TimeManage.Entity
{
    /**
     * 继承EnAffair实体，避免DynamicBuilder缓存实体结构
     **/
    public class EnAffairEx2 : EnAffair
    {
        //do nothing
    }
}
