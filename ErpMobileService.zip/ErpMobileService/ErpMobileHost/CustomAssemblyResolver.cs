using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Web.Http.Dispatcher;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;

namespace Nd.ERPMobile.WebApi.SelfHost
{
    public class CustomAssemblyResolver : IAssembliesResolver
    {
        private LogMgr<CustomAssemblyResolver> _logMgr = new LogMgr<CustomAssemblyResolver>();
        public ICollection<Assembly> GetAssemblies()
        {

            List<ServiceArgEntity> lstArg = SQLiteAccess.FetchServiceArg();
            List<Assembly> baseAssemblies = AppDomain.CurrentDomain.GetAssemblies().ToList();
            if (lstArg != null && lstArg.Count > 0)
            {
                lstArg.ForEach(arg =>
                    {
                        //List<ServiceClassArgEntity> lstSubArg = SQLiteAccess.FetchServiceClassArg(arg.ID);
                        //if (lstSubArg != null && lstSubArg.Count > 0)
                        //{
                            string fileName = (arg.AddressPath == "" ? BaseHelper.StartPath + @"\" + arg.ServiceCode : arg.AddressPath + @"\" + arg.ServiceCode);
                            FileInfo oFile = new FileInfo(fileName);
                            if (!oFile.Exists)
                            {
                                fileName += ".dll";
                                oFile = new FileInfo(fileName);
                                if (!oFile.Exists)
                                {
                                    string errInfo = string.Format("δ���֣�{0}�������Ӧ�����{1}���޷���������", arg.ServiceName, fileName);
                                    throw new ApplicationException(errInfo);
                                }
                            }

                            Assembly asm = Assembly.Load(Path.GetFileNameWithoutExtension(fileName));
                            _logMgr.WriteLogToLocal(false, "Assembly.Load " + asm.FullName);
                            baseAssemblies.Add(asm);
                        //}
                    }
                    );
            }
            //Assembly asm = Assembly.Load("TMService");
            //         baseAssemblies.Add(asm);
            return baseAssemblies;
        }
    }
}