﻿using System;
using System.Reflection;
using System.ServiceModel;
using System.ServiceModel.Description;
using ND.Lib.DocXMLOpe;
using System.Data;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using System.Collections.Generic;
using System.IO;
using ND.Lib.PDec;
using System.ServiceModel.Dispatcher;

namespace Nd.Erp.Mobile
{
    public class Host
    {
        /// <summary>
        /// 服务的基础地址
        /// </summary>
        private string _baseAddress = "";
        /// <summary>
        /// 服务启动路径
        /// </summary>
        private string _startPath = "";
        /// <summary>
        /// 服务集合
        /// </summary>
        private List<ServiceHostEntity> _wcfHost;
        private LogMgr<Host> _logMgr = new LogMgr<Host>();
        public Host()
        {
            try
            {
                _startPath = BaseHelper.StartPath;
                _baseAddress = BaseHelper.ServiceBaseAddress;
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("服务初始化失败：{0}", ex.ToString());
                throw;
            }
        }

        public void Start()
        {
            try
            {
                _wcfHost = new List<ServiceHostEntity>() { };
                List<ServiceArgEntity> lstArg = SQLiteAccess.FetchServiceArg();
                if (lstArg != null && lstArg.Count > 0)
                {
                    lstArg.ForEach(arg =>
                    {
                        List<ServiceClassArgEntity> lstSubArg = SQLiteAccess.FetchServiceClassArg(arg.ID);
                        if (lstSubArg != null && lstSubArg.Count > 0)
                        {
                            string fileName = (arg.AddressPath == "" ? _startPath + @"\" + arg.ServiceCode : arg.AddressPath + @"\" + arg.ServiceCode);
                            FileInfo oFile = new FileInfo(fileName);
                            if (!oFile.Exists)
                            {
                                fileName += ".dll";
                                oFile = new FileInfo(fileName);
                                if (!oFile.Exists)
                                {
                                    string errInfo = string.Format("未发现（{0}）服务对应组件：{1}，无法启动服务。", arg.ServiceName, fileName);
                                    throw new ApplicationException(errInfo);
                                }
                            }
                            Assembly asm = Assembly.LoadFile(fileName);

                            lstSubArg.ForEach(subArg =>
                            {
                                Type[] objTypes = asm.GetTypes();
                                object objService = asm.CreateInstance(subArg.NameSpace + "." + subArg.ClassName);
                                Type serviceType = GetTypeByName(objTypes, subArg.ClassName);
                                if (serviceType != null)
                                {
                                    string hostAddress = _baseAddress + (_baseAddress.EndsWith("/") == true ? "" : "/") + (subArg.BaseAddress == "" ? subArg.ClassName : subArg.BaseAddress);
                                    //System.ServiceModel.ServiceHost host = new ServiceHost(serviceType, new Uri(hostAddress));
                                    CustomServiceHost host = new CustomServiceHost(serviceType, new Uri(hostAddress));
                                    
                                    int num = 0;
                                    List<ServiceInterfaceArgEntity> lstIntArg = SQLiteAccess.FetchServiceInterfaceArg(subArg.ID);
                                    if (lstIntArg != null && lstIntArg.Count > 0)
                                    {
                                        lstIntArg.ForEach(intArg =>
                                        {
                                            Type interfaceType = GetTypeByName(objTypes, intArg.InterfaceName);
                                            if (interfaceType != null)
                                            {
                                                var webHttpBinding = new WebHttpBinding();
                                                webHttpBinding.TransferMode = TransferMode.Streamed;
                                                webHttpBinding.MaxReceivedMessageSize = 100L * 1024 * 1024;//最大上传文件为2G
                                                var binding=new GZipWebHttpBinding(webHttpBinding);
                                                ServiceEndpoint se = host.AddServiceEndpoint(interfaceType, binding, intArg.EndPointAddress);
                                                
                                                se.Behaviors.Add(new WebHttpBehavior());
                                                num++;
                                            }
                                            else
                                                _logMgr.WriteErrorFormat("服务接口名称({1})设置有误，在服务动态库({0})中不存在。", arg.ServiceCode, intArg.InterfaceName);
                                        });
                                    }

                                    if (num > 0)
                                        _wcfHost.Add(new ServiceHostEntity { ServiceName = arg.ServiceName, SvrHost = host, ServiceAddress = hostAddress });
                                }
                                else
                                    _logMgr.WriteErrorFormat("服务参数设置有误，服务动态库：{0}，命名空间：{1}，类名称：{2}。", arg.ServiceCode, subArg.NameSpace, subArg.ClassName);
                            });
                        }
                    }
                    );
                }

                if (_wcfHost != null && _wcfHost.Count > 0)
                {
                    _wcfHost.ForEach(svrHost =>
                    {
                        //对每个服务增加身份验证行为
                        svrHost.SvrHost.Authorization.ServiceAuthorizationManager = new ServicePowerManager();

                        _logMgr.WriteInfoFormat("开始启动服务（{1}），服务地址：{0}。", svrHost.ServiceAddress, svrHost.ServiceName);
                        svrHost.SvrHost.Open();

                        ////对每个服务增加异常处理机制,应放在服务打开之后
                        //foreach (ChannelDispatcher dispatcher in svrHost.SvrHost.ChannelDispatchers)
                        //{
                        //    dispatcher.ErrorHandlers.Add(new ErrorHandlerBehavior().ErrorHandler);
                        //}

                        _logMgr.WriteInfo("服务已经启动，并接受连接");
                    }
                    );
                }
                else
                {
                    throw new Exception("还没有配置需要对外发布的服务。");
                }
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("服务启动失败：{0}", ex.ToString());
                throw;
            }
        }

        public void Stop()
        {
            try
            {
                _logMgr.WriteInfo("开始停止服务...");
                if (_wcfHost != null && _wcfHost.Count > 0)
                {
                    _wcfHost.ForEach(svrHost =>
                    {
                        _logMgr.WriteInfoFormat("正在停止服务（{0}）...", svrHost.ServiceName);
                        svrHost.SvrHost.Close();
                        _logMgr.WriteInfo("服务已成功停止。");
                    }
                    );
                }
                _logMgr.WriteInfo("完成所有服务已停止。");
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("停止服务失败：{0}", ex.ToString());
            }
        }

        private Type GetTypeByName(Type[] objTypes, string typeName)
        {
            foreach (Type t in objTypes)
            {
                if (t.Name.Equals(typeName))
                    return t;
            }
            return null;
        }
    }
}