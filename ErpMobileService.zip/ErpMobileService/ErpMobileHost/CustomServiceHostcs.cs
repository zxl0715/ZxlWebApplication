﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;

namespace Nd.Erp.Mobile
{
    public class CustomServiceHost : ServiceHost
    {
        public CustomServiceHost()
        {
        }

        public CustomServiceHost(Type serviceType, params Uri[] baseAddresses)
            : base(serviceType, baseAddresses)
        {
        }

        protected override void OnOpening()
        {
            Description.Behaviors.Add(new MessageDiagnosticsServiceBehavior());

            base.OnOpening();
        }
    }  
}
