﻿using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile
{
    /// <summary>
    /// Resolves member mappings for a type, lower casing property names.
    /// </summary>
    public class LowerCasePropertyNamesContractResolver : DefaultContractResolver
    {
        /// <summary>
        /// Initializes a new instance of the <see cref="LowerCasePropertyNamesContractResolver"/> class.
        /// </summary>
        public LowerCasePropertyNamesContractResolver()
            : base(true)
        {
        }

        /// <summary>
        /// Resolves the name of the property.
        /// </summary>
        /// <param name="propertyName">Name of the property.</param>
        /// <returns>The property name lower cased.</returns>
        protected override string ResolvePropertyName(string propertyName)
        {
            // lower case the passed in name
            return propertyName.ToLowerInvariant();
        }
    }
}