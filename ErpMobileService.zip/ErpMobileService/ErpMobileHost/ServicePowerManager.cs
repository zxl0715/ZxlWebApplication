﻿using System.Net;
using System.ServiceModel;
using System.ServiceModel.Web;
using System;
using System.Text;
using Nd.Erp.Mobile.Base;

namespace Nd.Erp.Mobile
{
    public class ServicePowerManager : ServiceAuthorizationManager
    {
        private SysEventLog<ServicePowerManager> _logMgr = new SysEventLog<ServicePowerManager>();
        public override bool CheckAccess(OperationContext operationContext, ref System.ServiceModel.Channels.Message message)
        {
            var ctx = WebOperationContext.Current;
            try
            {

                string via = message.Properties["Via"].ToString();
                _logMgr.WriteInfoFormat("客户端请求：{0}", via);
                if (via.Contains("RefreshConfigInfomation") || via.Contains("ShowLogInfomation") || via.Contains("GetLastestAPK"))
                {
                    return true;
                }
#if NOT_CHECK
                return true;
#endif
                
                var osType = ctx.IncomingRequest.Headers["OSTYPE"];
                var userID = ctx.IncomingRequest.Headers["USERID"];
                if (string.IsNullOrEmpty(osType) || string.IsNullOrEmpty(userID))
                {
                    return SetErrorStatusInfo(ctx, "Call Service Error:OSTYPE or USERID is null.");
                }


                string opeName = message.Properties["HttpOperationName"].ToString();
                if (via.IndexOf("LoginCheck") > -1 && via.EndsWith("LoginCheck") == false && (opeName == "CheckPower" || opeName == "CheckPowerWithPersonInfo"))
                {
                    return true;       //如果是调用登录验证服务，则底层不做权限验证判断
                }
                else
                {
                    var userGUID = ctx.IncomingRequest.Headers["USERGUID"];
                    if (string.IsNullOrEmpty(userGUID))
                    {
                        return SetErrorStatusInfo(ctx, "Call Service Error:USERGUID is null."); ;
                    }

                    string newGUID = string.Format("{0}_{1}", userID, userGUID);
                    var usr = UserCache.Get(newGUID);
                    if (usr == null)        //如果缓存中没有存在登录,则拒绝访问
                    {
                        return SetErrorStatusInfo(ctx, "Cache does not exist,Service Not Allowed.");
                    }
                    else
                    {
                        if (usr.LifeTime != DateTime.MaxValue && usr.LifeTime <= DateTime.Now)
                        {
                            return SetErrorStatusInfo(ctx, "Login cache has expired,please re-login.");
                        }
                    }
                    return true;
                }
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("服务调用权限验证失败:{0}", ex.ToString());
                return SetErrorStatusInfo(ctx, ex.Message);
            }
        }

        private bool SetErrorStatusInfo(WebOperationContext ctx, string errorInfo)
        {
            ctx.OutgoingResponse.StatusCode = HttpStatusCode.MethodNotAllowed;
            ctx.OutgoingResponse.StatusDescription = errorInfo;

            _logMgr.WriteError(errorInfo);
            return false;
        }
    }
}
