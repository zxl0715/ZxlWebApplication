﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;

namespace Nd.Erp.Mobile.ERPAuthorize
{
    public interface IERPProvidePrincipal
    {
        IPrincipal CreatePrincipal(string username, string password,string userguid);
    }
}
