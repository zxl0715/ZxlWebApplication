using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http.Filters;

namespace Nd.ERPMobile.WebApi.SelfHost
{

    public class CorsExceptionFilterAttribute : ExceptionFilterAttribute
    { 
        const string Origin = "Origin";
        const string AccessControlRequestMethod = "Access-Control-Request-Method";
        const string AccessControlRequestHeaders = "Access-Control-Request-Headers";
        const string AccessControlAllowOrigin = "Access-Control-Allow-Origin";
        const string AccessControlAllowMethods = "Access-Control-Allow-Methods";
        const string AccessControlAllowHeaders = "Access-Control-Allow-Headers";

        public override void OnException(HttpActionExecutedContext context)
        {
            context.Response.Headers.Add(AccessControlAllowOrigin, context.Request.Headers.GetValues(Origin).First());
        }
       

    }
}
