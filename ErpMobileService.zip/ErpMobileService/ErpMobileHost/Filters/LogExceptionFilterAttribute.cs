using System.Web.Http.Filters;
using Nd.Erp.Mobile.Log;
using System.Diagnostics;

namespace Nd.ERPMobile.WebApi.SelfHost
{
    public class LogExceptionFilterAttribute : ExceptionFilterAttribute
    {
        private LogMgr<LogExceptionFilterAttribute> _logMgr = new LogMgr<LogExceptionFilterAttribute>("LogExceptionFilterAttribute");
        public override void OnException(HttpActionExecutedContext context)
        {
            string error = string.Format("ActionContext:{0},Exception:{1},ExceptionStack{2},RequestUrl:{3}", context.ActionContext, context.Exception.Message, context.Exception.StackTrace,
                                         context.Request.ToString());
            _logMgr.WriteError(error);
            Debug.WriteLine(error);
            throw context.Exception;
        }
    }
}