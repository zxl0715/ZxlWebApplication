﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Http.Filters;
namespace Nd.Erp.Mobile.Service.Common.Filters
{
    public class NoZipAttribute : ActionFilterAttribute
    {
        public override void OnActionExecuted(HttpActionExecutedContext actionExecutedContext)
        {
            actionExecutedContext.Request.Headers.TryAddWithoutValidation("NOTZIP", "True");
            base.OnActionExecuted(actionExecutedContext);
        }
    }
}
