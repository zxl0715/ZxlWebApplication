﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Dispatcher;
using System.ServiceModel.Channels;
using System.Xml;
using System.Diagnostics;
using System.ServiceModel;

namespace Nd.Erp.Mobile
{
    class MessageDiagnosticsInterceptor: IClientMessageInspector, IDispatchMessageInspector  
    {
        public object BeforeSendRequest(ref Message request, IClientChannel channel)
        {
            return null;
        }

        public object AfterReceiveRequest(ref Message request, IClientChannel channel, InstanceContext instanceContext)
        {
            return null;
        }

        public void AfterReceiveReply(ref Message reply, object correlationState)
        {

        }

        public void BeforeSendReply(ref Message reply, object correlationState)
        {
           
        }

        private void DetermineAndLogMessageDiagnostics(string messageBody)
        {
            double bodySizeInBytes = Encoding.UTF8.GetByteCount(messageBody);

            var asKiloBytes = bodySizeInBytes / 1024;

            Debug.WriteLine("Message size in KBytes {0}", asKiloBytes);
        }

    }
}
