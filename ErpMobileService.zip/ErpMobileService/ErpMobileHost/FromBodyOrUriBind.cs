﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.ModelBinding;
using System.Net.Http;
namespace Nd.Erp.Mobile.Service.Common
{
    public class FromBodyOrUriBind : IModelBinder
    {
        public bool BindModel(System.Web.Http.Controllers.HttpActionContext actionContext, ModelBindingContext bindingContext)
        {
            string querystringValue=actionContext.Request.RequestUri.ParseQueryString()[bindingContext.ModelName];
            if (querystringValue == null)
                bindingContext.Model = actionContext.Request.Content.ReadAsStringAsync().Result;
            else
                bindingContext.Model = querystringValue;
            return true;
        }
    }
   
}