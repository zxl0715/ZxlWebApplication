using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Nd.ERPMobile.WebApi.SelfHost
{
    public class CompressionHandler : DelegatingHandler
    {
        protected override Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        {
            return base.SendAsync(request, cancellationToken).ContinueWith((responseToCompleteTask) =>
                {
                    HttpResponseMessage response = responseToCompleteTask.Result;
                    IEnumerable<string> notZip = null;
                    if (response.RequestMessage!=null
                        &&response.RequestMessage.Headers.AcceptEncoding != null 
                        && response.RequestMessage.Headers.AcceptEncoding.Count()>0
                        && !response.RequestMessage.Headers.TryGetValues("NOTZIP", out notZip)
                        &&response.Content!=null)
                    {
                        string encodingType = response.RequestMessage.Headers.AcceptEncoding.First().Value;

                        response.Content = new CompressedContent(response.Content, encodingType);
                    }

                    return response;
                },
                TaskContinuationOptions.OnlyOnRanToCompletion);
        }
    }
}