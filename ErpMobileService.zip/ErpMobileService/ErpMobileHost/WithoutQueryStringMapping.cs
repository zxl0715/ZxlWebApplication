﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Net.Http.Formatting;
using System.Text;

namespace Nd.Erp.Mobile
{
    /// <summary>
    /// match it when the querystring without this parameter name 
    /// </summary>
    public class WithoutQueryStringMapping : MediaTypeMapping
    {
        /// <summary>
        /// Quality factor to indicate a perfect match.
        /// </summary>
        public const double Match = 1.0;

        /// <summary>
        /// Quality factor to indicate no match.
        /// </summary>
        public const double NoMatch = 0.0;


        private static readonly Type _withoutQueryStringMapping = typeof(WithoutQueryStringMapping);
        /// <summary>
        /// Gets the query string parameter name.
        /// </summary>
        public string QueryStringParameterName { get; private set; }

        public WithoutQueryStringMapping(string queryStringParameterName, string mediaType)
            : base(mediaType)
        {
            if (String.IsNullOrWhiteSpace(queryStringParameterName))
            {
                throw new ArgumentNullException("queryStringParameterName");
            }
            QueryStringParameterName = queryStringParameterName.Trim();
        }
        private static NameValueCollection GetQueryString(Uri uri)
        {
            if (uri == null)
            {
                throw new InvalidOperationException(".NonNullUriRequiredForMediaTypeMapping:" + _withoutQueryStringMapping.Name);
            }

            return new FormDataCollection(uri).ReadAsNameValueCollection();
        }
        public override double TryMatchMediaType(System.Net.Http.HttpRequestMessage request)
        {
            NameValueCollection queryString = GetQueryString(request.RequestUri);
            return DoesQueryStringMatch(queryString) ? Match : NoMatch;
        }
        private bool DoesQueryStringMatch(NameValueCollection queryString)
        {
            if (queryString != null)
            {
                foreach (string queryParameter in queryString.AllKeys)
                {
                    if (String.Equals(queryParameter, QueryStringParameterName, StringComparison.OrdinalIgnoreCase))
                    {
                        return false;
                    }
                }
            }

            return true;
        }
    }
}
