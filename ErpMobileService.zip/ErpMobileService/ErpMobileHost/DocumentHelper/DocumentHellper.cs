﻿using Nd.Erp.Mobile.Service.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Formatting;
using System.Web;
using System.Web.Http.Controllers;
using System.Web.Http.Description;
using System.Web.Http.ModelBinding;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DocumentHellper
    {

        public static Dictionary<Type, object> _sampleData = new Dictionary<Type, object>() { 
           
        };
        /// <summary>
        /// 获取action返回类型
        /// </summary>
        /// <param name="action"></param>
        /// <returns></returns>
        static Type GetResponseType(HttpActionDescriptor action)
        {
            return action.ReturnType;
        }

        public static T GetSampleByType<T>()
        {
            return (T)_sampleData[typeof(T)];
        }

        /// <summary>
        /// 获取类型名称
        /// </summary>
        /// <param name="type"></param>
        /// <returns></returns>
        public static string GetTypeName(Type type)
        {
            //if (!type.IsGenericType)
            //    return type.Name;
            if (type == null)
                return "";
            return type.FullName;
        }

        /// <summary>
        /// 获取返回值的JSON格式
        /// </summary>
        /// <param name="api"></param>
        /// <param name="mediaType"></param>
        /// <returns></returns>
        public static string GetSampleResponseBody(ApiDescription api, string mediaType)
        {
            string body = null;
            Type returnType = GetResponseType(api.ActionDescriptor);
            object o;
            if (returnType != null && _sampleData.TryGetValue(returnType, out o))
            {
                var formatters = api.SupportedResponseFormatters;
                MediaTypeFormatter formatter = formatters.FirstOrDefault(
                    f => f.SupportedMediaTypes.Any(m => m.MediaType == mediaType));
                if (formatter != null)
                {
                    var content = new ObjectContent(returnType, o, formatter);
                    body = content.ReadAsStringAsync().Result;
                }
            }
            return body;
        }
        /// <summary>
        /// 获取返回值的JSON格式
        /// </summary>
        /// <param name="api"></param>
        /// <param name="mediaType"></param>
        /// <returns></returns>
        public static string GetSampleParamBody(ApiDescription api,ApiParameterDescription param)
        {
            string body = null;
            Type returnType = param.ParameterDescriptor.ParameterType;
            object o;
            if (returnType != null && _sampleData.TryGetValue(returnType, out o))
            {
                var formatters = api.SupportedResponseFormatters;
                MediaTypeFormatter formatter = formatters.FirstOrDefault(
                    f => f.SupportedMediaTypes.Any(m => m.MediaType == "application/json"));
                if (formatter != null)
                {
                    var content = new ObjectContent(returnType, o, formatter);
                    body = content.ReadAsStringAsync().Result;
                }
            }

            return body;

        }
        public static string GetDefaultValue(ApiParameterDescription param)
        {
            if (param.ParameterDescriptor.IsOptional)
            {
                if (param.ParameterDescriptor.DefaultValue == null)
                    return "[ = null]";
                if (param.ParameterDescriptor.DefaultValue is string)
                    return "[ = \"" + param.ParameterDescriptor.DefaultValue + "\"]";
                return "[ = " + param.ParameterDescriptor.DefaultValue + "]";
            }
            return "";
        }

        public static string GetSource(ApiParameterDescription param)
        {
            if (param.ParameterDescriptor.ParameterBinderAttribute != null && param.ParameterDescriptor.ParameterBinderAttribute.GetBinding(param.ParameterDescriptor) is ModelBinderParameterBinding
                &&
                ((ModelBinderParameterBinding)param.ParameterDescriptor.ParameterBinderAttribute.GetBinding(param.ParameterDescriptor)).Binder is FromBodyOrUriBind)
                return "FromUriOrBody";
            return param.Source.ToString();
        }
    }
}