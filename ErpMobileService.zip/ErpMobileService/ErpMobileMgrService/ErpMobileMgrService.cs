﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using Nd.Erp.Mobile.Base;

namespace Nd.Erp.Mobile.Service
{
    public partial class ErpMobileMgrService : ServiceBase
    {       
        /// <summary>
        /// 日志
        /// </summary>
        private static SysEventLog<BaseHelper> _logMgr = new SysEventLog<BaseHelper>();

        Host _host = new Host();
        public ErpMobileMgrService()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            try
            {
                _host.Start();
            }
            catch (Exception ex) {
                _logMgr.WriteErrorFormat("服务启动失败:{0}", ex.ToString());
                throw;
            }
        }

        protected override void OnStop()
        {
            _host.Stop();
        }
    }
}