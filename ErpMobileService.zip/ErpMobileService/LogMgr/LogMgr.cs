﻿using System;
using System.Collections.Concurrent;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Reflection;
using log4net;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Log
{
    public class LogMgr<T>
    {
        private static ConcurrentDictionary<Type, ILog> logMgrDictionary = new ConcurrentDictionary<Type, ILog>();
        /// <summary>
        /// 日志
        /// </summary>
        private log4net.ILog _logMgr;
        /// <summary>
        /// 服务名称
        /// </summary>
        private string _serviceName;

        /// <summary>
        /// 构造函数
        /// </summary>
        public LogMgr()
            : this("ErpMobileService")
        {

        }

        /// <summary>
        /// 构造函数
        /// </summary>
        /// <param name="serviceName">服务名称</param>
        public LogMgr(string serviceName)
        {
            Type t = typeof (T);
            if(logMgrDictionary.ContainsKey(t))
            {
                _logMgr = logMgrDictionary[t];
                return;
            }
            try
            {
                string path = Assembly.GetExecutingAssembly().Location;
                string filePath = path.Substring(0, path.LastIndexOf("\\")) + "\\log4net.config";
                FileInfo file = new FileInfo(filePath);
                if (!file.Exists)
                    throw new ApplicationException("日志配置文件(log4net.config)不存在。");
                log4net.Config.XmlConfigurator.ConfigureAndWatch(file);
            }
            catch (Exception)
            {
            }
           
            _logMgr = LogManager.GetLogger(t);
            logMgrDictionary[t] = _logMgr;
            if (serviceName.Trim().Length == 0)
                throw new ArgumentException("服务名称参数不可为空！");
            else
                _serviceName = serviceName;
        }

        /// <summary>
        /// 只写入本地文本日志
        /// </summary>
        /// <param name="isError">是否为错误日志</param>
        /// <param name="format">格式化日志信息</param>
        /// <param name="args">格式化参数</param>
        public void WriteLogFormatToLocal(bool isError, string format, params object[] args)
        {
            if (isError)
                _logMgr.ErrorFormat(format, args);
            else
                _logMgr.InfoFormat(format, args);
        }

        public void WriteLogToLocal(bool isError, string logInfo)
        {
            if (isError)
                _logMgr.Error(logInfo);
            else
                _logMgr.Info(logInfo);
        }

        /// <summary>
        /// 写入错误日志
        /// </summary>
        /// <param name="logInfo">日志信息</param>
        public void WriteError(string logInfo)
        {
            _logMgr.Error(logInfo);
            if (BaseHelper.IsWriteLogToDataBase)
                WriteLogFormatToDB("04", logInfo);
        }

        /// <summary>
        /// 写入格式化错误日志
        /// </summary>
        /// <param name="format">格式化日志信息</param>
        /// <param name="args">格式化参数</param>
        public void WriteErrorFormat(string format, params object[] args)
        {
            _logMgr.ErrorFormat(format, args);
            if (BaseHelper.IsWriteLogToDataBase)
                WriteLogFormatToDB("04", format, args);
        }

        /// <summary>
        /// 写入日志
        /// </summary>
        /// <param name="logInfo">日志信息</param>
        public void WriteInfo(string logInfo)
        {
            _logMgr.Info(logInfo);
            if (BaseHelper.IsWriteLogToDataBase)
                WriteLogToDB("03", logInfo);
        }

        /// <summary>
        /// 写入格式化日志
        /// </summary>
        /// <param name="format">格式化日志信息</param>
        /// <param name="args">格式化参数</param>
        public void WriteInfoFormat(string format, params object[] args)
        {
            _logMgr.InfoFormat(format, args);
            if (BaseHelper.IsWriteLogToDataBase)
                WriteLogFormatToDB("03", format, args);
        }

        /// <summary>
        /// 日志写入数据库
        /// </summary>
        /// <param name="logType">日志类型(03:正常日志;04:异常日志;)</param>
        /// <param name="format">格式化日志信息</param>
        /// <param name="args">格式化参数</param>
        private void WriteLogFormatToDB(string logType, string format, params object[] args)
        {
            string logInfo = string.Format(format, args);
            WriteLogToDB(logType, logInfo);
        }

        /// <summary>
        /// 日志写入数据库
        /// </summary>
        /// <param name="logType">日志类型(03:正常日志;04:异常日志;)</param>
        /// <param name="logInfo">日志信息</param>
        private void WriteLogToDB(string logType, string logInfo)
        {
            try
            {
                SqlParameter[] arParam = new SqlParameter[4];
                arParam[0] = new SqlParameter("@ServiceCode", SqlDbType.NVarChar, 100);
                arParam[0].Value = _serviceName;
                arParam[1] = new SqlParameter("@LogTime", SqlDbType.DateTime);
                arParam[1].Value = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                arParam[2] = new SqlParameter("@LogType", SqlDbType.Char, 2);
                arParam[2].Value = logType;
                arParam[3] = new SqlParameter("@LogInfo", SqlDbType.NVarChar, 3000);
                arParam[3].Value = logInfo;

                string cmdTxt = "Insert Into M7_ServiceLogInfo(ServiceCode,LogTime,LogType,LogInfo) values(@ServiceCode,@LogTime,@LogType,@LogInfo)";
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, cmdTxt, arParam);
            }
            catch (Exception ex)
            {
                _logMgr.ErrorFormat("日志写入数据库失败：{0}。", ex.Message);
            }
        }
    }
}