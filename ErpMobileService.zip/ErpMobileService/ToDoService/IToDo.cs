﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using UploadService.Entity;
using ToDoService.Entity;

namespace Nd.Erp.Mobile.Service.ToDo
{
    [ServiceContract]
    interface IToDoJson
    {
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "addToDoTask?userID={userID}&OuPerson={sPersonCode}&endDate={dEndDate}&content={content}", BodyStyle = WebMessageBodyStyle.Bare)]
        string addToDoTask(string userID, string sPersonCode, string dEndDate, string content, List<UploadResult> uploadResultList);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getMyToDoList?userID={userID}&xmNameFilter={xmNameFilter}&listFilter={listFilter}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnPeopleOrder> getMyToDoList(string userID, string xmNameFilter, string listFilter);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getMyTaskList?userID={userID}&xmNameFilter={xmNameFilter}&listFilter={listFilter}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnPeopleOrder> getMyTaskList(string userID, string xmNameFilter, string listFilter);
        
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getData?userID={userID}&dataType={dataType}&codes={codes}&wcodes={wcodes}&lcode={lcode}&anchor={anchor}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnPeopleOrders getData(string userID, int dataType, string codes, string wcodes, string lcode, string anchor);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "accetpOrder?userID={userID}&OrderCode={OrderCode}&XmCode={XmCode}&CompleteType={CompleteType}", BodyStyle = WebMessageBodyStyle.Bare)]
        int accetpOrder(string userID, int OrderCode, string XmCode, string CompleteType);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "taskFeedback?userID={userID}&OrderCode={OrderCode}&XMPercent={XMPercent}&message={message}", BodyStyle = WebMessageBodyStyle.Bare)]
        int taskFeedback(string userID, int OrderCode, float XMPercent, string message);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "applyDelay?userID={userID}&OrderCode={OrderCode}&finishDate={finishDate}&message={message}", BodyStyle = WebMessageBodyStyle.Bare)]
        int applyDelay(string userID, int OrderCode, string finishDate, string message);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "acceptDelay?userID={userID}&OrderCode={OrderCode}&delayDate={delayDate}", BodyStyle = WebMessageBodyStyle.Bare)]
        int acceptDelay(string userID, int OrderCode, string delayDate);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "rejectDelay?userID={userID}&OrderCode={OrderCode}&message={message}", BodyStyle = WebMessageBodyStyle.Bare)]
        int rejectDelay(string userID, int OrderCode, string message);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "applyPause?userID={userID}&OrderCode={OrderCode}&message={message}", BodyStyle = WebMessageBodyStyle.Bare)]
        int applyPause(string userID, int OrderCode, string message);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getCurrentEnFeedback?userID={userID}&OrderCode={OrderCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnPeopleFeedback getCurrentEnFeedback(string userID, int OrderCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "acceptPause?userID={userID}&OrderCode={OrderCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        int acceptPause(string userID, int OrderCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "rejectPause?userID={userID}&OrderCode={OrderCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        int rejectPause(string userID, int OrderCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "finishOrder?userID={userID}&OrderCode={OrderCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        int finishOrder(string userID, int OrderCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "rejectOrder?userID={userID}&OrderCode={OrderCode}&message={message}", BodyStyle = WebMessageBodyStyle.Bare)]
        int rejectOrder(string userID, int OrderCode, string message);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "reworkOrder?userID={userID}&OrderCode={OrderCode}&message={message}", BodyStyle = WebMessageBodyStyle.Bare)]
        int reworkOrder(string userID, int OrderCode, string message);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "stopOrder?userID={userID}&OrderCode={OrderCode}&message={message}", BodyStyle = WebMessageBodyStyle.Bare)]
        int stopOrder(string userID, int OrderCode, string message);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "acceptRework?userID={userID}&OrderCode={OrderCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        int acceptRework(string userID, int OrderCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getPeopleOrderById?userID={userID}&OrderCode={OrderCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnPeopleOrder getPeopleOrderById(string userID, int OrderCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "editOrder?userID={userID}&orderCode={orderCode}&title={title}&message={message}&finishDate={finishDate}&peopleCode={peopleCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        string editOrder(string userID, int orderCode, String title, String message, String finishDate, String peopleCode);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getEnPeopleOrderById?userID={userID}&OrderCode={OrderCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnPeopleOrder getEnPeopleOrderById(string userID, int OrderCode);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "PostFeedbackList?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        int PostFeedbackList(string userID, List<EnFeedback> feedBackList);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "PostUsingLogList?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        int PostUsingLogList(string userID, List<EnUsingLog> usingLogs);
    }


}
