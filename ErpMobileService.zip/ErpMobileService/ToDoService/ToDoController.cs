﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Text.RegularExpressions;
using System.Web.Http;
using ND.Lib.Data.SqlHelper;
using ND.Lib.PDec;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Base;
using UploadService.Entity;
using System.IO;
using ToDoService.Entity;
using ToDoService.Business;
using ToDoService.DataAccess;

namespace Nd.Erp.Mobile.Service.ToDo
{
    /// <summary>
    /// ToDo类
    /// </summary>
    public class ToDo : ToDoController
    {
        //do nothing
    }

    /// <summary>
    /// ToDo下单模块
    /// </summary>
    public class ToDoController :ApiController, IToDoJson
    {
        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;
        private LogMgr<ToDoController> _logMgr = new LogMgr<ToDoController>("ToDoService");

        #region 获取未完成的ToDo单据
        /// <summary>
        /// 获取未完成的ToDo单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public EnPeopleOrders getNotFinishedToDo(string userID)
        {
            EnPeopleOrders result = new EnPeopleOrders();
            IList<EnPeopleOrder> tmpOrders = BzPeopleOrder.getNotFinishedToDo(userID);
            IList<EnPeopleFeedback> tmpFeedbacks = BzPeopleFeedback.getNotFinishedToDo_FeedBack(userID, null);

            List<EnPeopleOrder> orders = new List<EnPeopleOrder>();
            for (int i = 0; i < tmpOrders.Count; i++)
                orders.Add(tmpOrders[i]);

            List<EnPeopleFeedback> feedbacks = new List<EnPeopleFeedback>();
            for (int i = 0; i < tmpFeedbacks.Count; i++)
                feedbacks.Add(tmpFeedbacks[i]);

            result.AddOrders = orders;
            result.FeedBacks = feedbacks;

            if (orders.Count > 0)
            {
                result.LastSyncCode = orders[orders.Count - 1].Code.ToString();
                result.LastSyncConfirmCode = BzPeopleOrder.getLastToDoConfirmAuto().ToString();
            }

            if (feedbacks.Count > 0)
                result.LastSyncFeedbackCode = feedbacks[feedbacks.Count - 1].AutoCode.ToString();

            return result;
        }
        #endregion

        #region 刷新未完成的ToDo单据
        /// <summary>
        /// 刷新未完成的ToDo单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="maxCode">SQLite上未完成单据的最大编号</param>
        /// <param name="maxFeedBackAuto">SQLite上未完成单据的反馈的最大编号</param>
        /// <param name="maxConfirmAuto">SQLite上记录的确认自动编号</param>
        /// <returns></returns>
        [HttpGet]
        public EnPeopleOrders refreshToDo(string userID, int maxCode, int maxFeedBackAuto, int maxConfirmAuto)
        {
            //第一次加载没有数据，一段时间后刷新，重新加载
            if (maxCode == 0 && maxFeedBackAuto == 0 && maxConfirmAuto == 0)
                return getNotFinishedToDo(userID);

            EnPeopleOrders result = new EnPeopleOrders();

            //获取新增的未完成的单据
            IList<EnPeopleOrder> tmpOrders = BzPeopleOrder.getNewToDoBySQLiteCode(userID, maxCode);
            List<EnPeopleOrder> newOrders = new List<EnPeopleOrder>();
            for (int i = 0; i < tmpOrders.Count; i++)
            {
                newOrders.Add(tmpOrders[i]);
            }

            int[] codes = null;
            IList<EnPeopleFeedback> tmpFeedbacks = null;
            List<EnPeopleFeedback> feedbacks = new List<EnPeopleFeedback>();

            //获取新增的未完成的单据的反馈
            if (newOrders.Count > 0)
            {
                codes = new int[tmpOrders.Count];

                for (int i = 0; i < tmpOrders.Count; i++)
                    codes[i] = Convert.ToInt32(tmpOrders[i].Code);

                tmpFeedbacks = BzPeopleFeedback.getNotFinishedToDo_FeedBack(userID, codes);
                for (int i = 0; i < tmpFeedbacks.Count; i++)
                {
                    feedbacks.Add(tmpFeedbacks[i]);
                }
            }

            //获取有更新的未完成的单据
            tmpOrders = BzPeopleOrder.getUpdateToDoBySQLiteCode(userID, maxFeedBackAuto, maxConfirmAuto);
            List<EnPeopleOrder> updateOrders = new List<EnPeopleOrder>();
            for (int i = 0; i < tmpOrders.Count; i++)
            {
                bool flag = true;

                for (int j = 0; j < newOrders.Count; j++)
                {
                    if (newOrders[j].Code == tmpOrders[i].Code)
                    {
                        flag = false;
                        break;
                    }
                }
                
                if (flag)
                    updateOrders.Add(tmpOrders[i]);
            }

            //获取有更新的未完成的单据的反馈
            if (updateOrders.Count > 0)
            {
                codes = new int[updateOrders.Count];

                for (int i = 0; i < updateOrders.Count; i++)
                    codes[i] = Convert.ToInt32(updateOrders[i].Code);

                tmpFeedbacks = BzPeopleFeedback.getNotFinishedToDo_FeedBack(userID, codes);
                for (int i = 0; i < tmpFeedbacks.Count; i++)
                {
                    feedbacks.Add(tmpFeedbacks[i]);
                }
            }

            //feedback排序
            feedbacks.Sort(sortFeedBacks);
            
            result.AddOrders = newOrders;
            result.UpdateOrders = updateOrders;
            result.FeedBacks = feedbacks;

            if (newOrders.Count > 0)
                result.LastSyncCode = newOrders[newOrders.Count - 1].Code.ToString();
                
            if (newOrders.Count > 0 || updateOrders.Count > 0)
                result.LastSyncConfirmCode = BzPeopleOrder.getLastToDoConfirmAuto().ToString();

            if (feedbacks.Count > 0)
                result.LastSyncFeedbackCode = feedbacks[feedbacks.Count - 1].AutoCode.ToString();

            return result;
        }
        #endregion

        #region 任务反馈排序
        /// <summary>
        /// 任务反馈排序
        /// </summary>
        /// <param name="a1"></param>
        /// <param name="a2"></param>
        /// <returns></returns>
        private int sortFeedBacks(EnPeopleFeedback a1, EnPeopleFeedback a2)
        {
            return a1.AutoCode.CompareTo(a2.AutoCode);
        }
        #endregion

        #region ToDo单据搜索
        /// <summary>
        /// ToDo单据搜索
        /// </summary>
        /// <param name="type">搜索类型，只接单、只下单、全部  1 只下单  2 只接单  否则 全部</param>
        /// <param name="sort">排序类型  1 按截止  2 按下单  否则  按编号</param>
        /// <param name="userID">用户ID</param>
        /// <param name="name">关键字</param>
        /// <param name="mark">任务状态(逗号隔开)，传空，全状态</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        [HttpGet]
        public IList<EnPeopleOrder> searchToDo(int type, int sort, string userID, string name, string mark, int pageIndex)
        {
            if (mark == null)
                mark = "";

            return BzPeopleOrder.searchToDo(type, sort, userID, name, mark, pageIndex);
        }
        #endregion

        #region 获取已完成的单据
        /// <summary>
        /// 获取已完成的单据
        /// </summary>
        /// <param name="type">搜索类型，只接单、只下单、全部  1 只下单  2 只接单  否则 全部</param>
        /// <param name="sort">排序类型  1 按截止  2 按下单  否则  按编号</param>
        /// <param name="userID">用户ID</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public IList<EnPeopleOrder> getEndToDo(int type, int sort, string userID, int pageIndex)
        {
            return BzPeopleOrder.getEndToDo(type, sort, userID, pageIndex);
        }
        #endregion

        #region ToDo下单
        /// <summary>
        /// ToDo下单
        /// </summary>
        /// <param name="userID">下单人ID</param>
        /// <param name="ouPerson">接单人ID</param>
        /// <param name="endDate">完成时间</param>
        /// <param name="content">单据内容</param>
        /// <param name="uploadResultList">上传文件列表</param>
        /// <returns>单据号，失败为0</returns>
        [HttpGet]
        [HttpPost]
        public string addToDoTask(string userID, string ouPerson, string endDate, string content, List<UploadResult> uploadResultList)
        {
            //完成时间参数从URL传过来，无法空格，需要转义
            endDate = endDate.Replace("$", " ");

            //获取接单人所属部门
            string result = "0";
            string sDepCode = "";
            string sPersonName = "";
            string sqlStr = @"SELECT sDepCode, sPersonName FROM A5_CWPerson WHERE sPersonCode=@sPersonCode";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = ouPerson }
            };

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
            {
                sDepCode = dt.Rows[0]["sDepCode"].ToString();
                sPersonName = dt.Rows[0]["sPersonName"].ToString();
            }
            else
            {
                return result;
            }

            //下单
            string proName = "p_Task_InsertTask";
            string title = content;

            //生成单据标题
            Regex reg = new Regex(@"(^\s*)|(\s*$)");
            title = reg.Replace(title, "");
            reg = new Regex(@"(http:|ftp:|https:)*\/\/[A-Za-z0-9\u4E00-\u9FA5\./=\?%\-&_~`@':;#+!]+\b", RegexOptions.IgnoreCase);
            title = reg.Replace(title, "");
            reg = new Regex(@"(^\s*)|(\s*$)");
            title = reg.Replace(title, "");
            reg = new Regex(@"[a-zA-Z0-9\u4E00-\u9FA5]+");
            //标点符号分割
            MatchCollection matchs = reg.Matches(title);
            if (matchs.Count > 0)
            {
                string tmpTitle = "";
                reg = new Regex(@"(http|https|ftp|file)$", RegexOptions.IgnoreCase);

                //原本只截取到第一个标点符号，有的时候文字很短，更改为循环拼接，超过限定字符后停止
                int i = 0;
                for (; i < matchs.Count; i++)
                {
                    tmpTitle += matchs[i].ToString() + "&";
                    tmpTitle = reg.Replace(tmpTitle, "");

                    if (tmpTitle.Length > 10)
                        break;
                }

                i = (i >= matchs.Count) ? (matchs.Count - 1) : i;
                title = title.Substring(0, matchs[i].Index + matchs[i].Length);

                if (title == "")
                {
                    if (content.Trim().Length > 0)
                    {
                        int len = content.Trim().Length;
                        title = content.Trim().Substring(0, (len > 10 ? 10 : len));
                    }
                    else
                        return result;
                }
            }
            else
            {
                if (content.Trim().Length > 0)
                {
                    int len = content.Trim().Length;
                    title = content.Trim().Substring(0, (len > 10 ? 10 : len));
                }
                else
                    return result;
            }
            title = "TODO:" + title;

            string nohtmlContent = content;
            reg = new Regex(@"<[^>]+>");
            nohtmlContent = reg.Replace(nohtmlContent, "");

            //开始下单
            arPara = new SqlParameter[] {
                new SqlParameter("@sPersoncode", SqlDbType.NVarChar, 20) 
                    { Value = userID },
                new SqlParameter("@lcode", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@lType", SqlDbType.Int)
                    { Value = 1030 },
                new SqlParameter("@lFcode", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@sOuCotCode", SqlDbType.NVarChar, 12)
                    { Value = null },
                new SqlParameter("@sOuDepCode", SqlDbType.NVarChar, 12)
                    { Value = sDepCode },
                new SqlParameter("@sOuPersonCode", SqlDbType.NVarChar, 20)
                    { Value = ouPerson },
                new SqlParameter("@sOuPeople", SqlDbType.NVarChar, 80)
                    { Value = sPersonName },
                new SqlParameter("@dDemDate", SqlDbType.DateTime)
                    { Value = Convert.ToDateTime(endDate) },
                new SqlParameter("@sFettle", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@sQuality", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@sXmCode", SqlDbType.NVarChar, 12)
                    { Value = null },
                new SqlParameter("@sXmName", SqlDbType.NVarChar, 100)
                    { Value = title },
                new SqlParameter("@sDepDemand", SqlDbType.NVarChar, 8000)
                    { Value = content },
                new SqlParameter("@sDepDemandTemp", SqlDbType.NVarChar, 8000)
                    { Value = nohtmlContent },
                new SqlParameter("@sDeputyPeo", SqlDbType.NVarChar, 80)
                    { Value = null },
                new SqlParameter("@lTotalHours", SqlDbType.Float)
                    { Value = null },
                new SqlParameter("@lTaskPoint", SqlDbType.Float)
                    { Value = null },
                new SqlParameter("@lsubjoinPoint", SqlDbType.Float)
                    { Value = null },
                new SqlParameter("@lValue", SqlDbType.Float)
                    { Value = null },
                new SqlParameter("@sNeedLevel", SqlDbType.NVarChar, 60)
                    { Value = null },
                new SqlParameter("@lCheckDay", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@lOrderPrice", SqlDbType.Float)
                    { Value = null },
                new SqlParameter("@lTaskAutoCode", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@sUpload", SqlDbType.NVarChar, 8000)
                    { Value = null },
                new SqlParameter("@sTitleNum", SqlDbType.NVarChar, 10)
                    { Value = null },
                new SqlParameter("@dPeoSDate", SqlDbType.DateTime)
                    { Value = null },
                new SqlParameter("@sBTCode", SqlDbType.NVarChar, 12)
                    { Value = null },
                new SqlParameter("@sRating", SqlDbType.NVarChar, 20)
                    { Value = null },
                new SqlParameter("@sPriority", SqlDbType.NVarChar, 20)
                    { Value = null },
                new SqlParameter("@sCopyPeo", SqlDbType.NVarChar, 1000)
                    { Value = null },
                new SqlParameter("@sWGCode", SqlDbType.NVarChar, 1000)
                    { Value = null },
                new SqlParameter("@sGFCode", SqlDbType.NVarChar, 1000)
                    { Value = null },
                new SqlParameter("@lDoType", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@sDocumentCode", SqlDbType.NVarChar, 30)
                    { Value = null },
                new SqlParameter("@sDocumentVer", SqlDbType.NVarChar, 20)
                    { Value = null },
                new SqlParameter("@lXMResCode", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@sVerCode", SqlDbType.NVarChar, 30)
                    { Value = null },
                new SqlParameter("@lSkCodeBz", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@lWorkload", SqlDbType.Float)
                    { Value = null },
                new SqlParameter("@bFinish", SqlDbType.Bit)
                    { Value = null },
                new SqlParameter("@sResInfo", SqlDbType.NVarChar, 1000)
                    { Value = null },
                new SqlParameter("@lBtnType", SqlDbType.Int)
                    { Value = null },
                new SqlParameter("@sTCode", SqlDbType.NVarChar, 12)
                    { Value = null },
                new SqlParameter("@sDocTypeCode", SqlDbType.NVarChar, 12)
                    { Value = null },
                new SqlParameter("@ERPDocDefaultPriority", SqlDbType.Float)
                    { Value = 90 },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar, 500)
                    { Value = "" },
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 }
            };

            arPara[46].Direction = ParameterDirection.Output;
            arPara[47].Direction = ParameterDirection.ReturnValue;
            SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, proName, arPara);

            //ToDo外扩表
            if ((int)arPara[47].Value == 1 && arPara[46].Value.ToString() != "")
            {
                sqlStr = "INSERT INTO X5_ToDoTaskInfo(lTaskCode, dDate) VALUES (" + arPara[46].Value + ", getDate())";
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.Text, sqlStr);
            }

            //插入附件表
            if ((int)arPara[47].Value == 1 && arPara[46].Value.ToString() != "" && uploadResultList != null)
            {
                string uploadRootPath = SQLiteAccess.GetSysArgValue("UploadRootPath");
                string isNotOuter = SQLiteAccess.GetSysArgValue("isNotOuter");
                StringBuilder uploadFileSql = new StringBuilder();
                foreach (var uploadResult in uploadResultList)
                {
                    FileInfo fi = new FileInfo(uploadResult.NewFilePath);

                    string code = arPara[46].Value.ToString();
                    uploadFileSql.AppendLine(" INSERT dbo.X5_YOrderUpload ( lServerCode , code , lFcode , lcode , lType , sFileName , sNewFileName , sOldFileName , sOldAddress , lFileType , sPersoncode , sMpeople , sFileSize , sMemo , sUrl , dDate , lParentFile , lSource ) VALUES ( ");
                    uploadFileSql.AppendLine(" 1 , -- lServerCode - int ");
                    uploadFileSql.AppendLine(" " + code + " , -- code - int ");
                    uploadFileSql.AppendLine(" " + code + " , -- lFcode - int ");
                    uploadFileSql.AppendLine(" " + code + " , -- lcode - int ");
                    uploadFileSql.AppendLine(" 1040 , -- lType - int ");
                    uploadFileSql.AppendLine(" NULL , -- sFileName - nvarchar(100) ");
                    uploadFileSql.AppendLine(" '" + uploadResult.NewFilePath.Substring(uploadRootPath.Length, uploadResult.NewFilePath.Length - uploadRootPath.Length).TrimStart('\\') + "' , -- sNewFileName - nvarchar(50) ");
                    uploadFileSql.AppendLine(" '" + Path.GetFileName(uploadResult.OldFilePath) + "' , -- sOldFileName - nvarchar(100) ");
                    uploadFileSql.AppendLine(" '" + uploadResult.OldFilePath + "' , -- sOldAddress - nvarchar(200) ");
                    uploadFileSql.AppendLine(" 21 , -- lFileType - tinyint ");//下单文件
                    uploadFileSql.AppendLine(" '" + ouPerson + "' , -- sPersoncode - nvarchar(20) ");
                    uploadFileSql.AppendLine(" '" + sPersonName + "' , -- sMpeople - nvarchar(20) ");
                    uploadFileSql.AppendLine(" '" + CountSize(fi.Length) + "B' , -- sFileSize - nvarchar(20) ");
                    uploadFileSql.AppendLine(" NULL , -- sMemo - nvarchar(100) ");
                    uploadFileSql.AppendLine(" NULL , -- sUrl - nvarchar(200) ");
                    uploadFileSql.AppendLine(" getdate() , -- dDate - smalldatetime ");
                    uploadFileSql.AppendLine(" 0 , -- lParentFile - tinyint ");
                    if ((isNotOuter ?? "").ToLower() != "true")
                        uploadFileSql.AppendLine(" 0  -- lSource - tinyint ");
                    else
                        uploadFileSql.AppendLine(" 1  -- lSource - tinyint ");
                    uploadFileSql.Append(" ) ");

                }
                if (uploadFileSql.Length != 0)
                    SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.Text, uploadFileSql.ToString());
            }

            //91U提醒
            if ((int)arPara[47].Value == 1 && arPara[46].Value.ToString() != "")
            {
                StringBuilder noticeSql = new StringBuilder();
                noticeSql.Append("DECLARE @userName nvarchar(20);");
                noticeSql.Append("SELECT @userName=sPersonName FROM A5_CWPerson WHERE sPersonCode='" + userID + "'; ");
                noticeSql.Append("INSERT INTO A9_MsgNotify (sMnuName, sOPeoCode, sIPeoCode, sTitle, sContent, dAddTime, lTime, bRead, bODel, bIDel, bSend, lType) VALUES (");
                noticeSql.Append("'下单', ");
                noticeSql.Append("'666666666', ");
                noticeSql.Append("'" + ouPerson + "', ");
                noticeSql.Append("'ERP移动平台ToDo下单', ");
                noticeSql.Append("@userName+'给您下任务【" + title + "】\n请查看：" + SQLiteAccess.GetSysArgValue("WebServerUrl") + "/Order/K1_frmPeopleTaskInfo.aspx?UserId=" + ouPerson + "&code=" + PDesc.Encrypt(arPara[46].Value.ToString()) + "', ");
                noticeSql.Append("getDate(), ");
                noticeSql.Append("0, NULL, NULL, NULL, NULL, ");
                noticeSql.Append("1");
                noticeSql.Append(")");

                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.Text, noticeSql.ToString());
            }

            if ((int)arPara[47].Value == 1)
            {
                result = arPara[46].Value.ToString();
            }

            return result;
        }
        #endregion

        #region 计算文件大小函数(保留两位小数),Size为字节大小
        /// <summary>
        /// 计算文件大小函数(保留两位小数),Size为字节大小
        /// </summary>
        /// <param name="Size">初始文件大小</param>
        /// <returns></returns>
        [NonAction]
        public static string CountSize(long Size)
        {
            string m_strSize = "";
            long FactSize = 0;
            FactSize = Size;
            if (FactSize < 1024.00)
                m_strSize = FactSize.ToString("F2") + "B";
            else if (FactSize >= 1024.00 && FactSize < 1048576)
                m_strSize = (FactSize / 1024.00).ToString("F2") + "K";
            else if (FactSize >= 1048576 && FactSize < 1073741824)
                m_strSize = (FactSize / 1024.00 / 1024.00).ToString("F2") + "M";
            else if (FactSize >= 1073741824)
                m_strSize = (FactSize / 1024.00 / 1024.00 / 1024.00).ToString("F2") + "G";
            return m_strSize;
        }
        #endregion

        #region 接单确认
        /// <summary>
        /// 接单确认
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="OrderCode">任务号</param>
        /// <param name="XmCode">二级项目编号</param>
        /// <param name="CompleteType">接单类型 （Self：自己完成 Other：他人完成）</param>
        /// <returns>完成返回1，没完成返回0</returns>
        [HttpGet]
        public int accetpOrder(string userID, int OrderCode, string XmCode, string CompleteType)
        {
            bool result = false;

            if (CompleteType.Trim().Equals("Self"))
                result = BzPeopleOrder.acceptOrderBySelf(userID, OrderCode, XmCode);
            else if (CompleteType.Trim().Equals("Other"))
                result = BzPeopleOrder.acceptOrderByOther(userID, OrderCode, XmCode);

            return (result ? 1 : 0);
        }
        #endregion

        #region 拒绝单据
        /// <summary>
        /// 拒绝单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="OrderCode">任务号</param>
        /// <param name="message">反馈内容</param>
        /// <returns></returns>
        [HttpGet]
        public int rejectOrder(string userID, int OrderCode, string message)
        {
            if (BzPeopleOrder.RejectOrder(userID, OrderCode, message))
                return 1;
            else
                return 0;
        }
        #endregion

        #region 进度反馈
        /// <summary>
        /// 进度反馈
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="OrderCode">单据ID</param>
        /// <param name="XMPercent">进度</param>
        /// <returns>完成返回1，没完成返回0</returns>
        [HttpGet]
        public int taskFeedback(string userID, int OrderCode, float XMPercent, string message)
        {
            if (BzPeopleOrder.taskFeedback(userID, OrderCode, XMPercent, message))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion



        #region 根据任务编号获取任务详细信息
        /// <summary>
        /// 根据任务编号获取任务详细信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        public EnPeopleOrder getEnPeopleOrderById(string userID, int OrderCode)
        {
            return BzPeopleOrder.getEnPeopleOrderById(OrderCode);
        }
        #endregion

        #region 根据任务编号获取申请延单的反馈信息实体
        /// <summary>
        /// 根据任务编号获取申请延单的反馈信息实体
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        public EnPeopleFeedback getCurrentEnFeedback(string userID, int OrderCode)
        {
            return BzPeopleFeedback.getCurrentEnFeedback(userID, OrderCode);
        }
        #endregion




        #region 获取TODO数据
        /// <summary>
        /// 获取我的下单单据
        /// </summary>
        public EnPeopleOrders getData(string userID, int dataType = 0, string codes = null, string wcodes = null, string lcode = null, string anchor = null)
        {
            return BzPeopleOrder.getDataFromDB(userID, dataType, codes, wcodes, lcode, anchor);
        }
        #endregion

        [HttpPost]
        public int PostFeedbackList(string userID, List<EnFeedback> feedBackList)
        {
            if (feedBackList == null)
            {
                feedBackList = new List<EnFeedback>();
            }
            return BzFeedback.AddFeedback(feedBackList) ? 1 : 0;
        }

        [HttpPost]
        public int PostUsingLogList(string userID, List<EnUsingLog> usingLogs)
        {
            if (usingLogs == null)
            {
                usingLogs = new List<EnUsingLog>();
            }
            return BzUsingLog.AddUsingLogs(usingLogs) ? 1 : 0;
        }

        [HttpGet]
        public string editOrder(string userID, int orderCode, string title, string message, string finishDate = null, string peopleCode = null)
        {
            DateTime? finish = null;
            if (!string.IsNullOrWhiteSpace(finishDate))
            {
                finish = DateTime.ParseExact(finishDate, "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.CurrentCulture);
            }
            return BzPeopleOrder.editOrder(userID, orderCode, title, message, finish, peopleCode);
        }

        /// <summary>
        /// 获取ToDo订单实体
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        public EnPeopleOrder getPeopleOrderById(string userID, int OrderCode)
        {
            return BzPeopleOrder.getEntity(OrderCode);

        }

        [HttpGet]
        public int acceptRework(string userID, int OrderCode)
        {
            return (BzPeopleOrder.acceptRework(userID, OrderCode) ? 1 : 0);
        }

        /// <summary>
        /// 下单人终止订单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        [HttpGet]
        public int stopOrder(string userID, int OrderCode, string message)
        {
            return (BzPeopleOrder.stopOrder(userID, OrderCode, message) ? 1 : 0);
        }

        /// <summary>
        /// 下单人返工操作
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        [HttpGet]
        public int reworkOrder(string userID, int OrderCode, string message)
        {
            return (BzPeopleOrder.ReworkOrder(userID, OrderCode, message) ? 1 : 0);
        }

        

        #region 下单人结单
        /// <summary>
        /// 下单人结单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        [HttpGet]
        public int finishOrder(string userID, int OrderCode)
        {
            if (BzPeopleOrder.finishOrder(userID, OrderCode))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region 下单人拒绝暂停
        /// <summary>
        /// 下单人拒绝暂停
        /// </summary>
        /// <param name="userID">验收人工号</param>
        /// <param name="OrderCode">任务编号</param>
        /// <returns></returns>
        [HttpGet]
        public int rejectPause(string userID, int OrderCode)
        {
            if (BzPeopleOrder.rejectPause(userID, OrderCode))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region 下单人接受暂停
        /// <summary>
        /// 下单人接受暂停
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        [HttpGet]
        public int acceptPause(string userID, int OrderCode)
        {
            if (BzPeopleOrder.acceptPause(userID, OrderCode))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region 拒绝延单
        /// <summary>
        /// 拒绝延单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        [HttpGet]
        public int rejectDelay(string userID, int OrderCode, string message)
        {
            if (BzPeopleOrder.rejectDelay(userID, OrderCode, message))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region 接受延单
        /// <summary>
        /// 接受延单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="delayDate"></param>
        /// <returns></returns>
        [HttpGet]
        public int acceptDelay(string userID, int OrderCode, string delayDate)
        {
            if (BzPeopleOrder.acceptDelay(userID, OrderCode, delayDate))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        

        #region 申请暂停
        /// <summary>
        /// 申请暂停
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        [HttpGet]
        public int applyPause(string userID, int OrderCode, string message)
        {
            if (BzPeopleOrder.applyPause(userID, OrderCode, message))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        #region 申请延单
        /// <summary>
        /// 申请延单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="finishDate"></param>
        /// <param name="message"></param>
        /// <returns>完成返回1，没完成返回0</returns>
        [HttpGet]
        public int applyDelay(string userID, int OrderCode, string finishDate, string message)
        {
            if (BzPeopleOrder.applyDelay(userID, OrderCode, finishDate, message))
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        #endregion

        

        

        #region 获取我的下单单据
        /// <summary>
        /// 获取我的下单单据
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="xmNameFilter"></param>
        /// <param name="listFilter"></param>
        /// <returns></returns>
        public List<EnPeopleOrder> getMyToDoList(string userID, string xmNameFilter, string listFilter)
        {
            return BzPeopleOrder.getMyToDoList(userID, xmNameFilter, listFilter);
        }
        #endregion

        #region 获取我的接单单据
        /// <summary>
        /// 获取我的接单单据
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="xmNameFilter"></param>
        /// <param name="listFilter"></param>
        /// <returns></returns>
        public List<EnPeopleOrder> getMyTaskList(string userID, string xmNameFilter, string listFilter)
        {
            return BzPeopleOrder.getMyTaskList(userID, xmNameFilter, listFilter);
        }
        #endregion

        

        
    }
}
