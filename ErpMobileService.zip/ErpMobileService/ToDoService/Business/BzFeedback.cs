﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToDoService.Entity;

namespace ToDoService.DataAccess
{
    public class BzFeedback
    {
        private static readonly DaFeedback dal = new DaFeedback();

        /// <summary>
        /// 添加反馈信息到数据库
        /// </summary>
        /// <param name="feedbacks"></param>
        /// <returns></returns>
        public static bool AddFeedback(List<EnFeedback> feedbacks)
        {
            return dal.AddFeedback(feedbacks);
        }
    }
}
