﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToDoService.Entity;
using ToDoService.DataAccess;

namespace ToDoService.Business
{
    /// <summary>
    /// 任务的业务逻辑
    /// </summary>
    public class BzPeopleOrder
    {
        private static readonly DaPeopleOrder dal = new DaPeopleOrder();

        #region 获取未完成的单据
        /// <summary>
        /// 获取未完成的单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public static IList<EnPeopleOrder> getNotFinishedToDo(string userID)
        {
            return dal.getNotFinishedToDo(userID);
        }
        #endregion

        #region 获取新增的未完成的单据
        /// <summary>
        /// 获取新增的未完成的单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="maxCode">SQLite上未完成单据的最大编号</param>
        /// <returns></returns>
        public static IList<EnPeopleOrder> getNewToDoBySQLiteCode(string userID, int maxCode)
        {
            return dal.getNewToDo(userID, maxCode);
        }
        #endregion

        #region 获取有更新的未完成的单据(可能包含新增的未完成)
        /// <summary>
        /// 获取有更新的未完成的单据(可能包含新增的未完成)
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="isOu">接单或下单类型  1:接单  0:下单</param>
        /// <param name="maxFeedBackAuto">SQLite上未完成单据的反馈的最大编号</param>
        /// <param name="maxConfirmAuto">SQLite上记录的确认自动编号</param>
        /// <returns></returns>
        public static IList<EnPeopleOrder> getUpdateToDoBySQLiteCode(string userID, int maxFeedBackAuto, int maxConfirmAuto)
        {
            return dal.getUpdateToDo(userID, maxFeedBackAuto, maxConfirmAuto);
        }
        #endregion

        #region 获取ToDo单据的确认表中最大的AutoCode
        /// <summary>
        /// 获取ToDo单据的确认表中最大的AutoCode
        /// </summary>
        /// <returns></returns>
        public static int getLastToDoConfirmAuto()
        {
            return dal.getLastToDoConfirmAuto();
        }
        #endregion

        #region ToDo单据搜索
        /// <summary>
        /// ToDo单据搜索
        /// </summary>
        /// <param name="type">搜索类型，只接单、只下单、全部  1 只下单  2 只接单  否则 全部</param>
        /// <param name="sort">排序类型  1 按截止  2 按下单  否则  按编号</param>
        /// <param name="userID">用户ID</param>
        /// <param name="name">关键字</param>
        /// <param name="mark">任务状态(逗号隔开)，传空，全状态</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static IList<EnPeopleOrder> searchToDo(int type, int sort, string userID, string name, string mark, int pageIndex)
        {
            string strMark = "";

            if (mark != "")
            {                
                string[] marks = mark.Split(',');

                for (int i = 0; i < marks.Length; i++)
                    strMark += "'" + marks[i] + "',";

                if (strMark.Length > 0)
                    strMark = strMark.Substring(0, strMark.Length - 1);
            }

            return dal.searchToDo(type, sort, userID, name, strMark, pageIndex);
        }
        #endregion

        #region 获取已完成的单据
        /// <summary>
        /// 获取已完成的单据
        /// </summary>
        /// <param name="type">搜索类型，只接单、只下单、全部  1 只下单  2 只接单  否则 全部</param>
        /// <param name="sort">排序类型  1 按截止  2 按下单  否则  按编号</param>
        /// <param name="userID">用户ID</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static IList<EnPeopleOrder> getEndToDo(int type, int sort, string userID, int pageIndex)
        {
            return dal.getEndToDo(type, sort, userID, pageIndex);
        }
        #endregion





        public static EnPeopleOrder getEnPeopleOrderById(int OrderCode)
        {
            return dal.getEntity(OrderCode);
        }

        public static EnPeopleOrders getDataFromDB(string userID, int dataType, string codes, string wcodes, string lcode, string anchor)
        {
            return dal.getOrders(userID, dataType, codes, wcodes, lcode, anchor);
        }

        public static string editOrder(string userID, int orderCode, string title, string message, DateTime? finish, string peopleCode)
        {
            bool editTitle = false;
            bool editMessage = false;
            bool editFinishDate = false;
            bool editOuPeople = false;

            if (!string.IsNullOrWhiteSpace(title))
                editTitle = true;
            if (!string.IsNullOrWhiteSpace(message))
                editMessage = true;
            if (finish != null)
                editFinishDate = true;
            if (!string.IsNullOrWhiteSpace(peopleCode))
                editOuPeople = true;
            return dal.editOrder(orderCode, userID, editTitle, title, editMessage, message, editFinishDate, finish, editOuPeople, peopleCode); ;
        }

        /*
         * 接受返工
         */
        public static bool acceptRework(string userID, int OrderCode)
        {
            String str = dal.acceptRework(userID, OrderCode, "");
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 取得实体类
         */
        public static EnPeopleOrder getEntity(int orderID)
        {
            return dal.getEntity(orderID);
        }

        /*
         * 终止单据
         */
        public static bool stopOrder(string userID, int OrderCode, string message)
        {
            String str = dal.stopOrder(userID, OrderCode, message);
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 返工
         */
        public static bool ReworkOrder(string userID, int OrderCode, string message)
        {
            String str = dal.ReworkOrder(userID, OrderCode, message);
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 拒绝接单
         */
        public static bool RejectOrder(string userID, int OrderCode, string message)
        {
            String str = dal.RejectOrder(userID, OrderCode, message);
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 单据完成
         */
        public static bool finishOrder(string userID, int OrderCode)
        {
            String str = dal.finishOrder(userID, OrderCode, "");
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 拒绝暂停
         */
        public static bool rejectPause(string userID, int OrderCode)
        {
            String str = dal.rejectPause(userID, OrderCode, "");
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /*
         * 接受暂停
         */
        public static bool acceptPause(string userID, int OrderCode)
        {
            String str = dal.acceptPause(userID, OrderCode, "");
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 接受延单
         */
        public static bool acceptDelay(string userID, int OrderCode, string delayDate)
        {
            DateTime delay = DateTime.ParseExact(delayDate, "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.CurrentCulture);

            String str = dal.acceptDelay(userID, OrderCode, delay, "");
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /*
         * 拒绝延单
         */
        public static bool rejectDelay(string userID, int OrderCode, string message)
        {
            String str = dal.rejectDelay(userID, OrderCode, message);
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 接单人申请暂停
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool applyPause(string userID, int OrderCode, string message)
        {
            String str = dal.applyPause(userID, OrderCode, message);
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 申请延单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="finishDate"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public static bool applyDelay(string userID, int OrderCode, string finishDate, string message)
        {
            DateTime finish = DateTime.ParseExact(finishDate, "yyyy-MM-dd HH:mm", System.Globalization.CultureInfo.CurrentCulture);
            String str = dal.applyDelay(userID, OrderCode, finish, message);
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }


        /// <summary>
        /// 进度反馈
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="XMPercent"></param>
        /// <returns></returns>
        public static bool taskFeedback(string userID, int OrderCode, float XMPercent, string message)
        {
            if (XMPercent < 0)
            {
                XMPercent = 0.0f;
            }
            else if (XMPercent > 100)
            {
                XMPercent = 100.0f;
            }
            String str = dal.taskFeedback(userID, OrderCode, XMPercent, message);
            if (str.Trim().Equals("1"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// 自己完成
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="OrderCode">任务号</param>
        /// <param name="XmCode">二级项目编号</param>
        /// <returns></returns>
        public static bool acceptOrderBySelf(string userID, int OrderCode, string XmCode)
        {
            String str = dal.acceptOrder(userID, OrderCode, XmCode, true);

            if (str.Trim().Equals("1"))
                return true;
            else
                return false;
        }

        /// <summary>
        /// 他人完成
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="OrderCode">任务号</param>
        /// <param name="XmCode">二级项目编号</param>
        /// <returns></returns>
        public static bool acceptOrderByOther(string userID, int OrderCode, string XmCode)
        {
            String str = dal.acceptOrder(userID, OrderCode, XmCode, false);

            if (str.Trim().Equals("1"))
                return true;
            else
                return false;
        }

        /// <summary>
        /// 获得下单单据列表
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="xmNameFilter"></param>
        /// <param name="listFilter"></param>
        /// <returns></returns>
        public static List<EnPeopleOrder> getMyToDoList(string userID, string xmNameFilter, string listFilter)
        {
            string sMark = "";
            string whereStr = "";
            List<EnPeopleOrder> list = null;
            xmNameFilter = xmNameFilter.Trim();

            switch (listFilter)
            {
                case "doing":
                    sMark = "00";
                    whereStr = "sMark<='80' and sMark!='20' and sMark!='55'";
                    break;
                case "stop":
                    sMark = "55";
                    break;
                case "done":
                    sMark = "90";
                    break;
                case "end":
                    sMark = "99";
                    break;
                case "cancel":
                    sMark = "20";
                    break;
            }

            list = dal.getMyToDoList(userID, xmNameFilter, sMark, whereStr);
            return list;
        }

        /// <summary>
        /// 获得接单单据列表
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="xmNameFilter"></param>
        /// <param name="listFilter"></param>
        /// <returns></returns>
        public static List<EnPeopleOrder> getMyTaskList(string userID, string xmNameFilter, string listFilter)
        {
            string sMark = "";
            string whereStr = "";
            List<EnPeopleOrder> list = null;
            xmNameFilter = xmNameFilter.Trim();

            switch (listFilter)
            {
                case "doing":
                    sMark = "00";
                    whereStr = "sMark<='80' and sMark!='20' and sMark!='55'";
                    break;
                case "stop":
                    sMark = "55";
                    break;
                case "done":
                    sMark = "90";
                    break;
                case "end":
                    sMark = "99";
                    break;
                case "cancel":
                    sMark = "20";
                    break;
            }

            list = dal.getMyTaskList(userID, xmNameFilter, sMark, whereStr);
            return list;
        }

    }
}
