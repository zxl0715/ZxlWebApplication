﻿using System;
using System.Collections.Generic;
using System.Text;
using ToDoService.Entity;
using ToDoService.DataAccess;

namespace ToDoService.Business
{
    /// <summary>
    /// 积分领取系统
    /// </summary>
    public class BzReceivePoint
    {
        #region 获取积分列表
        /// <summary>
        /// 获取积分列表
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public static List<EnReceivePoint> getReceivePointList(string userID)
        {
            List<EnReceivePoint> result = null;

            DaReceivePoint dal = new DaReceivePoint();
            result = dal.getReceivePointList(userID);

            if (result != null)
                return result;
            else
                return new List<EnReceivePoint>();
        }
        #endregion

        #region 领取积分
        /// <summary>
        /// 领取积分
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="auto">编号</param>
        /// <returns>1：成功， 0：失败 </returns>
        public static int receivePoint(string userID, int auto)
        {
            DaReceivePoint dal = new DaReceivePoint();
            EnSign en = dal.receivePoint(userID, auto);

            if (en.code != "-1" && en.code != "0" && en.Lot > 0)
            {
                //抽奖
                Da91UServer dal1 = new Da91UServer();
                dal1.addLot(userID, en.Lot.ToString());

                return 1;
            }

            return 0;
        }
        #endregion
    }
}
