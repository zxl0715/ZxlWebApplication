﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToDoService.Entity;
using ToDoService.Business;
using ToDoService.DataAccess;
using ToDoService.Entity._91U;

namespace ToDoService.Business
{
    /// <summary>
    /// 养成系统
    /// </summary>
    public class BzToDoList
    {
        #region 获取日事日清的任务数据
        /// <summary>
        /// 获取日事日清的任务数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public static List<EnToDoListItem> getToDoList_Task(string userID)
        {
            List<EnToDoListItem> result = null;

            DaToDoList dal = new DaToDoList();
            result = dal.getToDoList_Task(userID);

            if (result != null)
                return result;
            else
                return new List<EnToDoListItem>();
        }
        #endregion

        #region 获取日事日清的任务数据，有分页
        /// <summary>
        /// 获取日事日清的任务数据，有分页
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static List<EnToDoListItem> getToDoList_Task(string userID, string pageIndex)
        {
            int pageSize = 10;
            List<EnToDoListItem> result = null;

            DaToDoList dal = new DaToDoList();
            result = dal.getToDoList_Task(userID, pageSize, Convert.ToInt32(pageIndex));

            if (result != null)
                return result;
            else
                return new List<EnToDoListItem>();
        }
        #endregion

        #region 获取日事日清的SOP数据
        /// <summary>
        /// 获取日事日清的SOP数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public static List<EnToDoListItem> getToDoList_SOP(string userID)
        {
            List<EnToDoListItem> result = null;

            DaToDoList dal = new DaToDoList();
            result = dal.getToDoList_SOP(userID);

            if (result != null)
                return result;
            else
                return new List<EnToDoListItem>();
        }
        #endregion

        #region 获取日事日清的会议数据
        /// <summary>
        /// 获取日事日清的会议数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public static List<EnToDoListItem> getToDoList_Meeting(string userID)
        {
            List<EnToDoListItem> result = null;

            DaToDoList dal = new DaToDoList();
            result = dal.getToDoList_Meeting(userID);

            if (result != null)
                return result;
            else
                return new List<EnToDoListItem>();
        }
        #endregion

        #region 获取日事日清的全部数据
        /// <summary>
        /// 获取日事日清的全部数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public static List<EnToDoListItem> getToDoList(string userID)
        {
            List<EnToDoListItem> result = null;

            DaToDoList dal = new DaToDoList();
            result = dal.getToDoList(userID);

            if (result != null)
                return result;
            else
                return new List<EnToDoListItem>();
        }
        #endregion

        #region 获取日事日清的全部数据，有分页
        /// <summary>
        /// 获取日事日清的全部数据，有分页
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public static List<EnToDoListItem> getToDoList(string userID, string pageIndex)
        {
            int pageSize = 10;
            List<EnToDoListItem> result = null;

            DaToDoList dal = new DaToDoList();
            result = dal.getToDoList(userID, pageSize, Convert.ToInt32(pageIndex));

            if (result != null)
                return result;
            else
                return new List<EnToDoListItem>();
        }
        #endregion

        #region 获取日事日清数据_签退
        /// <summary>
        /// 获取日事日清数据_签退
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public static List<EnToDoListItem> getToDoList_SignOut(string userID)
        {
            List<EnToDoListItem> result = new List<EnToDoListItem>();

            DaToDoList dal = new DaToDoList();
            IList<EnToDoListItem> list = dal.getToDoList_SignOut(userID);

            foreach (EnToDoListItem en in list)
            {
                result.Add(en);
            }

            return result;
        }
        #endregion

        #region 获取某个月的签到统计情况
        /// <summary>
        /// 获取某个月的签到统计情况
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="year">年份</param>
        /// <param name="month">月份</param>
        /// <returns></returns>
        public static string getSignInList(string userID, int year, int month)
        {
            DaToDoList dal = new DaToDoList();
            return dal.getSignInList(userID, year, month);
        }
        #endregion
        
        

        #region 获取成长数据
        /// <summary>
        /// 获取成长数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public static EnGrowUp getGrowUpInfo(string userID)
        {
            DaGrowUp dal = new DaGrowUp();
            return dal.getGrowUpInfo(userID);
        }
        #endregion

        #region 获取成长数据
        /// <summary>
        /// 获取成长数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="sid">sid</param>
        /// <returns></returns>
        public static EnGrowUp getGrowUpInfo(string userID, string sid)
        {
            DaGrowUp dal = new DaGrowUp();
            EnGrowUp en = dal.getGrowUpInfo(userID);
            //有新活动啦
            en.HasNew = 1;

            Da91UServer dal1 = new Da91UServer();
            en.Gifts = dal1.getGiftNum(sid, userID);
            en.LotteryDraw = dal1.getLotNum(userID);

            return en;           
        }
        #endregion
             



        #region 签到操作
        /// <summary>
        /// 签到操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签到日期</param>
        /// <returns></returns>
        public static string signIn(string userID, DateTime date)
        {
            DaToDoList dal = new DaToDoList();
            return dal.signIn(userID, date);
        }
        #endregion

        #region 签退操作
        /// <summary>
        /// 签退操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签退日期</param>
        /// <returns></returns>
        public static string signOut(string userID, DateTime date)
        {
            DaToDoList dal = new DaToDoList();
            return dal.signOut(userID, date);
        }
        #endregion

        #region 签到操作
        /// <summary>
        /// 签到操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签到日期</param>
        /// <param name="sid">sid</param>
        /// <returns></returns>
        public static EnSign signIn(string userID, DateTime date, string sid)
        {
            DaToDoList dal = new DaToDoList();
            EnSign en = dal.signIn_StoredProcedure(userID, date);

            if (sid != null && sid.Trim() != "" && en.code != "-1" && en.code != "0")
            {
                //送花
                Da91UServer dal1 = new Da91UServer();
                bool result = dal1.addGift(sid, userID);
                if (result)
                    en.Gifts = 3;

                //抽奖
                if (en.Lot > 0)
                    dal1.addLot(userID, en.Lot.ToString());
            }

            return en;
        }
        #endregion

        #region 签退操作
        /// <summary>
        /// 签退操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签退日期</param>
        /// <param name="sid">sid</param>
        /// <returns></returns>
        public static EnSign signOut(string userID, DateTime date, string sid)
        {
            DaToDoList dal = new DaToDoList();
            EnSign en = dal.signOut_StoredProcedure(userID, date);

            if (en.code != "-1" && en.code != "0" && en.Lot > 0)
            {
                //抽奖
                Da91UServer dal1 = new Da91UServer();
                dal1.addLot(userID, en.Lot.ToString());
            }

            return en;
        }
        #endregion

        #region 是否签到
        /// <summary>
        /// 是否签到
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">日期</param>
        /// <returns>1：已签到；0：未签到</returns>
        public static int isSigned(string userID, DateTime date)
        {
            DaToDoList dal = new DaToDoList();
            string[] result = dal.getSignTime(userID, date);

            if (result != null && result[0] != "")
                return 1;
            else
                return 0;
        }
        #endregion

        #region 更多积分界面的活动列表
        /// <summary>
        /// 更多积分界面的活动列表
        /// 
        /// 1、日事日清 2、积分领取 3、生日祝福 4、摄影 5、书法 6、绘画 7、我型我酷 8、悬赏任务 9、二维码签到 10、每日签到
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="sid">sid</param>
        /// <returns></returns>
        public static List<EnPointActivity> getPointActivityList(string userID, string sid)
        {
            DaToDoList dal = new DaToDoList();
            string[] times = dal.getSignTime(userID, DateTime.Today);

            //艺术展数据
            Da91UServer dal1 = new Da91UServer();
            EnGetArtTaskList list = null;
            /*
            try
            {
                list = dal1.getArtTaskList(sid);
            } catch (Exception e) {
                list = null;
            }
            */

            EnGrowUp grow = BzToDoList.getGrowUpInfo(userID, sid);
            List<EnPointActivity> result = new List<EnPointActivity>();

            //日事日清
            EnPointActivity act = new EnPointActivity();
            act.Auto = 1;
            act.Order = 1;
            act.Title = "日事日清";
            act.Type = 1;
            act.Content = dal.getPoint("04") + "积分";
            act.State = (grow.IsSignOuted == 1 ? 2 : 0);
            act.IsNew = 0;
            if (times != null && times[1] != "")
                act.FinishTime = Convert.ToDateTime(times[1]);
            else
                act.FinishTime = null;
            result.Add(act);

            //积分领取
            if (grow.ReceiveJiFen > 0)
            {
                act = new EnPointActivity();
                act.Auto = 2;
                act.Order = 2;
                act.Title = "积分领取";
                act.Type = 1;
                act.Content = grow.ReceiveJiFen + "积分";
                act.State = 0;
                act.IsNew = 0;
                act.FinishTime = null;
                result.Add(act);
            }

            //生日祝福
            act = new EnPointActivity();
            act.Auto = 3;
            act.Order = 3;
            act.Title = "生日祝福";
            act.Type = 1;
            act.State = 1;
            act.IsNew = 0;
            result.Add(act);

            if (list != null && list.rows.Count > 0)
            {
                #region 艺术展有数据
                list.rows.Sort(BzToDoList.SortArtList);

                #region 摄影
                EnGetArtTask task = list.rows[0];
                if (DateTime.Today <= Convert.ToDateTime(task.dueDate).AddDays(1))
                {
                    act = new EnPointActivity();
                    act.Auto = 4;
                    act.Order = 4;
                    act.Title = "艺术展(摄影)";
                    act.Type = 2;
                    act.Link = Da91UServer.Art_Detail_Url.Replace("@sid", sid).Replace("@category", "1");
                    act.Content = task.points + ";" + task.percent + ";" + Convert.ToDateTime(task.dueDate).ToString("MM.dd");

                    string[] percents = task.percent.Split('/');
                    bool isFinish = (percents[0] == percents[1] ? true : false);
                    act.State = (isFinish ? 2 : 0);
                    act.IsNew = (isFinish ? 0 : 1);

                    result.Add(act);
                }
                #endregion

                #region 书法
                task = list.rows[1];
                if (DateTime.Today <= Convert.ToDateTime(task.dueDate).AddDays(1))
                {
                    act = new EnPointActivity();
                    act.Auto = 5;
                    act.Order = 5;
                    act.Title = "艺术展(书法)";
                    act.Type = 2;
                    act.Link = Da91UServer.Art_Detail_Url.Replace("@sid", sid).Replace("@category", "2");
                    act.Content = task.points + ";" + task.percent + ";" + Convert.ToDateTime(task.dueDate).ToString("MM.dd");

                    string[] percents = task.percent.Split('/');
                    bool isFinish = (percents[0] == percents[1] ? true : false);
                    act.State = (isFinish ? 2 : 0);
                    act.IsNew = (isFinish ? 0 : 1);

                    result.Add(act);
                }
                #endregion

                #region 绘画
                task = list.rows[2];
                if (DateTime.Today <= Convert.ToDateTime(task.dueDate).AddDays(1))
                {
                    act = new EnPointActivity();
                    act.Auto = 6;
                    act.Order = 6;
                    act.Title = "艺术展(绘画)";
                    act.Type = 2;
                    act.Link = Da91UServer.Art_Detail_Url.Replace("@sid", sid).Replace("@category", "3");
                    act.Content = task.points + ";" + task.percent + ";" + Convert.ToDateTime(task.dueDate).ToString("MM.dd");

                    string[] percents = task.percent.Split('/');
                    bool isFinish = (percents[0] == percents[1] ? true : false);
                    act.State = (isFinish ? 2 : 0);
                    act.IsNew = (isFinish ? 0 : 1);

                    result.Add(act);
                }
                #endregion

                #region 我型我酷
                task = list.rows[3];
                if (DateTime.Today <= Convert.ToDateTime(task.dueDate).AddDays(1))
                {
                    act = new EnPointActivity();
                    act.Auto = 7;
                    act.Order = 7;
                    act.Title = "艺术展(我型我酷)";
                    act.Type = 2;
                    act.Link = Da91UServer.Art_Detail_Url.Replace("@sid", sid).Replace("@category", "4");
                    act.Content = task.points + ";" + task.percent + ";" + Convert.ToDateTime(task.dueDate).ToString("MM.dd");

                    string[] percents = task.percent.Split('/');
                    bool isFinish = (percents[0] == percents[1] ? true : false);
                    act.State = (isFinish ? 2 : 0);
                    act.IsNew = (isFinish ? 0 : 1);

                    result.Add(act);
                }
                #endregion

                #endregion
            }
            else
            {
                #region 艺术展没有数据

                #region 摄影
                act = new EnPointActivity();
                act.Auto = 4;
                act.Order = 4;
                act.Title = "艺术展(摄影)";
                act.Type = 1;
                act.Link = "";
                act.Content = "";
                act.State = 1;
                act.IsNew = 0;

                result.Add(act);
                #endregion

                #region 书法
                act = new EnPointActivity();
                act.Auto = 5;
                act.Order = 5;
                act.Title = "艺术展(书法)";
                act.Type = 2;
                act.Link = "";
                act.Content = "";
                act.State = 1;
                act.IsNew = 0;

                result.Add(act);
                #endregion

                #region 绘画
                act = new EnPointActivity();
                act.Auto = 6;
                act.Order = 6;
                act.Title = "艺术展(绘画)";
                act.Type = 2;
                act.Link = "";
                act.Content = "";
                act.State = 1;
                act.IsNew = 0;

                result.Add(act);
                #endregion

                #region 我型我酷
                act = new EnPointActivity();
                act.Auto = 7;
                act.Order = 7;
                act.Title = "艺术展(我型我酷)";
                act.Type = 2;
                act.Link = "";
                act.Content = "";
                act.State = 1;
                act.IsNew = 0;

                result.Add(act);
                #endregion

                #endregion
            }

            //悬赏任务
            act = new EnPointActivity();
            act.Auto = 8;
            act.Order = 8;
            act.Title = "悬赏任务";
            act.Type = 1;
            act.State = 1;
            act.IsNew = 0;
            result.Add(act);

            //二维码签到
            if (DateTime.Now < Convert.ToDateTime("2013-09-01 22:00:00"))
            {
                act = new EnPointActivity();
                act.Auto = 9;
                act.Order = 9;
                act.Title = "91狂欢节二维码签到";
                act.Type = 1;

                int isFinish = dal1.is91Checkin(userID);
                act.State = (isFinish == 1 ? 2 : 0);
                act.IsNew = (isFinish == 1 ? 0 : 1);

                result.Add(act);
            }

            //每日签到
            act = new EnPointActivity();
            act.Auto = 10;
            act.Order = 10;
            act.Title = "每日签到";
            act.Type = 1;
            act.State = 2;
            act.IsNew = 0;
            if (times != null && times[0] != "")
                act.FinishTime = Convert.ToDateTime(times[0]);
            else
                act.FinishTime = null;
            result.Add(act);

            result.Sort(BzToDoList.SortPointActivity);
            return result;
        }

        #region 艺术展排序
        /// <summary>
        /// 艺术展排序
        /// </summary>
        /// <param name="e1"></param>
        /// <param name="e2"></param>
        /// <returns></returns>
        public static int SortArtList(EnGetArtTask e1, EnGetArtTask e2)
        {
            return (e1.categoryId > e2.categoryId ? 1 : -1);
        }
        #endregion

        #region 积分活动排序
        /// <summary>
        /// 积分活动排序
        /// </summary>
        /// <param name="e1">积分活动</param>
        /// <param name="e2">积分活动</param>
        /// <returns></returns>
        public static int SortPointActivity(EnPointActivity e1, EnPointActivity e2)
        {
            if (e1.State < e2.State)
                return -1;
            else if (e1.State > e2.State)
                return 1;
            else
            {
                if (e1.FinishTime == null || e1.FinishTime == null)
                    return (e1.Auto < e2.Auto ? -1 : 1);
                else if (e1.FinishTime < e2.FinishTime)
                    return -1;
                else
                    return 1;
            }
        }
        #endregion

        #endregion

    }
}