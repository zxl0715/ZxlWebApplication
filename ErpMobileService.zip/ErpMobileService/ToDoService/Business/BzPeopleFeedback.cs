﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToDoService.DataAccess;
using ToDoService.Entity;

namespace ToDoService.Business
{
    /// <summary>
    /// 任务反馈的业务逻辑
    /// </summary>
    public class BzPeopleFeedback
    {
        private static readonly DaPeopleFeedback dal = new DaPeopleFeedback();

        #region 获取未完成的单据的反馈
        /// <summary>
        /// 获取未完成的单据的反馈
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="codes">指定任务号</param>
        /// <returns></returns>
        public static IList<EnPeopleFeedback> getNotFinishedToDo_FeedBack(string userID, int[] codes)
        {
            return dal.getNotFinishedToDo_FeedBack(userID, codes);
        }
        #endregion

        #region 获取Sstate匹配的反馈表信息
        /// <summary>
        /// 获取Sstate匹配的反馈表信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        public static EnPeopleFeedback getCurrentEnFeedback(string userID, int OrderCode)
        {
            return dal.getCurrentEnFeedback(userID, OrderCode);
        }
        #endregion
    }
}
