﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToDoService.DataAccess;
using ToDoService.Entity;

namespace ToDoService.Business
{
    public class BzUsingLog
    {
        private static readonly DaUsingLog dal = new DaUsingLog();

        public static bool AddUsingLogs(List<EnUsingLog> usingLogs)
        {
            return dal.AddUsingLogs(usingLogs);
        }
    }
}
