﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using ToDoService.Entity;
using ND.Lib.Data.SqlHelper;
using System.Data;

namespace ToDoService.DataAccess
{
    public class DaUsingLog
    {
        private static string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;

        public bool AddUsingLogs(List<EnUsingLog> usingLogs)
        {
            bool result = false;
            String sql = "";
            foreach (EnUsingLog item in usingLogs)
            {
                String sUserID = item.SUserID;
                String dDate = item.DDate.ToString();
                String lType = item.LType.ToString();
                String sVersion = item.SVersion;
                String sSDK = item.SSDK ;
                String Memo = item.Memo;
                sql += " INSERT INTO dbo.TM_UsingLog (sUserID ,dDate ,lType , sVersion , sSDK, Memo ) ";
                sql += " VALUES ( '" + sUserID + "','" + dDate + "'," + lType + ",'" + sVersion + "','"+sSDK+ "','" + Memo + "') ";
            }
            if (sql.Trim() != "")
            {
                int i = 0;
                try
                {
                    i = SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.Text, sql);
                    if (i == usingLogs.Count)
                    {
                        result = true;
                    }
                }
                catch (Exception)
                {
                    result = false;
                    throw;
                }

            }
            return result;
        }
    }
}
