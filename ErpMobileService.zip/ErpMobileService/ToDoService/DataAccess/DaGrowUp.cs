﻿using System;
using System.Collections.Generic;
using System.Text;
using Nd.Erp.Mobile.Base;
using ToDoService.Entity;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;

namespace ToDoService.DataAccess
{
    public class DaGrowUp
    {
        private static string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;

        //签到统计的月份
        private string[] SignMonth = new string[] { "lJanNum", "lFebNum", "lMarNum", "lAprNum", "lMayNum", "lJunNum", "lJulNum", "lAugNum", "lSepNum", "lOctNum", "lNovNum", "lDecNum" };

        #region 获取成长数据
        /// <summary>
        /// 获取成长数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public EnGrowUp getGrowUpInfo(string userID)
        {
            EnGrowUp en = null;
            DateTime today = DateTime.Today;

            SqlParameter[] arPara = {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", today.ToString("yyyy-MM-dd"))
            };

            string spName = "Grow_GetGrowUpInfo";

            DataSet ds = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.StoredProcedure, spName, arPara);
            if (ds != null)
            {
                en = new EnGrowUp();

                //工号
                en.UserID = userID;

                //游戏星级
                if (ds.Tables[0].Rows.Count > 0)
                    en.GameStar = Convert.ToInt32(ds.Tables[0].Rows[0]["lTotalPoint"]);
                else
                    en.GameStar = 0;

                //签到积分、网龙币
                if (ds.Tables[1].Rows.Count > 0)
                {
                    en.SignJiFen = Convert.ToInt32(ds.Tables[1].Rows[0]["lValue"]);

                    if (ds.Tables[1].Rows[0]["lMoney"].ToString() != "")
                        en.Coin = Convert.ToInt32(ds.Tables[1].Rows[0]["lMoney"]);
                }
                else
                {
                    en.SignJiFen = 0;
                    en.Coin = 0;
                }

                //荣誉积分
                if (ds.Tables[2].Rows.Count > 0)
                    en.JiFen = Convert.ToInt32(ds.Tables[2].Rows[0]["Point"]);
                else
                    en.JiFen = 0;      

                //等级积分数据
                if (ds.Tables[3].Rows.Count == 2)
                {
                    en.Grade = Convert.ToInt32(ds.Tables[3].Rows[0]["lLevel"]);
                    en.ThisGradeJF = Convert.ToInt32(ds.Tables[3].Rows[0]["lValue"]);
                    en.NextGradeJF = Convert.ToInt32(ds.Tables[3].Rows[1]["lValue"]);
                }
                else if (ds.Tables[3].Rows.Count == 1)
                {
                    en.Grade = Convert.ToInt32(ds.Tables[3].Rows[0]["lLevel"]);
                    en.ThisGradeJF = Convert.ToInt32(ds.Tables[3].Rows[0]["lValue"]);
                    en.NextGradeJF = 99999999;
                }
                else
                {
                    en.Grade = 1;
                    en.ThisGradeJF = 0;
                    en.NextGradeJF = 0;
                }

                //入司日期和生日
                if (ds.Tables[4].Rows.Count > 0)
                {
                    en.JoinDay = Convert.ToDateTime(ds.Tables[4].Rows[0]["dYGJoin"]).ToString("yyyy-MM-dd HH:mm:ss");
                    en.Birthday = Convert.ToDateTime(ds.Tables[4].Rows[0]["Birthday"]).ToString("yyyy-MM-dd HH:mm:ss");
                    en.Sex = (ds.Tables[4].Rows[0]["sYGSex"].ToString() == "男" ? "M" : "F");
                }
                else
                {
                    en.JoinDay = "";
                    en.Birthday = "";
                    en.Sex = "M";
                }

                //当月签到次数和当天是否签到
                if (ds.Tables[5].Rows.Count > 0)
                {
                    string numField = SignMonth[today.Month - 1];
                    if (ds.Tables[5].Rows[0][numField].ToString() == "")
                        en.SignNum = 0;
                    else
                        en.SignNum = Convert.ToInt32(ds.Tables[5].Rows[0][numField]);
                }
                else
                    en.SignNum = 0;

                if (ds.Tables[6].Rows.Count > 0)
                    en.IsSigned = 1;
                else
                    en.IsSigned = 0;

                if (ds.Tables[7].Rows.Count > 0)
                    en.IsSignOuted = 1;
                else
                    en.IsSignOuted = 0;

                //可抽奖次数
                if (ds.Tables[8].Rows.Count > 0)
                    en.LotteryDraw = Convert.ToInt32(ds.Tables[8].Rows[0]["lAddNum"]);
                else
                    en.LotteryDraw = 0;

                //未领取积分
                if (ds.Tables[9].Rows.Count > 0)
                    en.ReceiveJiFen = Convert.ToInt32(ds.Tables[9].Rows[0]["lPoint"]);
                else
                    en.ReceiveJiFen = 0;

                en.Gifts = 0;
            }

            return en;
        }
        #endregion
    }
}
