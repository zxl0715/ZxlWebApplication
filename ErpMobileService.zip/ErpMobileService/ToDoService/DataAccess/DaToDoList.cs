﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using ToDoService.Entity;
using System.Data.SqlClient;
using System.Data;
using ND.Lib.Data.SqlHelper;

namespace ToDoService.DataAccess
{
    public class DaToDoList
    {
        //事务列表的类型编号
        private int TODOLIST_TASK = 1;
        private int TODOLIST_SOP = 2;
        private int TODOLIST_MEETING = 3;


        //签到统计的月份字段名称
        private string[] SignMonth = new string[] { "sJanValue", "sFebValue", "sMarValue", "sAprValue", "sMayValue", "sJunValue", "sJulValue", "sAugValue", "sSepValue", "sOctValue", "sNovValue", "sDecValue" };
        private string[] SignMonth_NUM = new string[] { "lJanNum", "lFebNum", "lMarNum", "lAprNum", "lMayNum", "lJunNum", "lJulNum", "lAugNum", "lSepNum", "lOctNum", "lNovNum", "lDecNum" };
        

        //积分系统插入的类型编号和名称
        private string JiFen_SignIn_Type = "20";
        private string JiFen_SignIn_TypeName = "职员签到";
        private string JiFen_SignOut_Type = "21";
        private string JiFen_SignOut_TypeName = "职员日事日清";


        #region 获取指定类型的积分标准
        /// <summary>
        /// 获取指定类型的积分标准
        /// </summary>
        /// <param name="type">类型编号</param>
        /// <returns></returns>
        public string getPoint(string type)
        {
            string strSql = "select lValue from K5_wQDJlEventType where sJlCode=@type";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@type", type)
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, arPara);

            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                return ds.Tables[0].Rows[0]["lValue"].ToString();
            }

            return "";
        }
        #endregion

        #region 获取签到和日清的时间
        /// <summary>
        /// 是否签到
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">日期</param>
        /// <returns> [ 签到时间, 日清时间 ] </returns>
        public string[] getSignTime(string userID, DateTime date)
        {
            string strSql = "SELECT sJlCode, dDate FROM K5_wQDJlInfo WHERE (sJlCode='01' or sJlCode='04') AND sPersonCode=@userID AND ISNULL(bDel,0)=0 AND CONVERT(CHAR(10),dDate,120)=@date; ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd"))
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);

            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                string[] result = new string[2];

                //签到
                DataRow[] rows = ds.Tables[0].Select("sJlCode='01'");
                if (rows != null && rows.Length > 0)
                    result[0] = rows[0]["dDate"].ToString();
                else
                    result[0] = "";

                //日清
                rows = ds.Tables[0].Select("sJlCode='04'");
                if (rows != null && rows.Length > 0)
                    result[1] = rows[0]["dDate"].ToString();
                else
                    result[1] = "";

                return result;
            }

            return new string[] {"", ""};
        }
        #endregion




        #region 获取日事日清的任务数据
        /// <summary>
        /// 获取日事日清的任务数据
        /// Author: wqz
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList_Task(string userID)
        {
            List<EnToDoListItem> list = null;

            /**
             * 18192N: 需确认的任务(含M岗)
             * 18192M：需结单的任务(含M岗)
             * 181927：需处理的申请延单任务(含M岗)
             * 181928：需处理的申请暂停任务(含M岗)
             **/
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select a.code, a.sOPersonCode as userID, " + TODOLIST_TASK + " as type, a.sTitle, b.sMark, b.lType, b.sOuPersonCode, b.sPersonCode ");
            strSql.Append(" from X5_TaskInfo a, X5_WPeopleOrder b where a.code=b.code and a.sIPersonCode=@userID and a.lState=0 and a.sMnuCode in ('18192N','18192M','181927','181928'); ");
            strSql.Append("select code, sPersonCode as userID, " + TODOLIST_TASK + " as type, sXmName as sTitle, sMark, lType, sOuPersonCode, sPersonCode ");
            strSql.Append(" from X5_WPeopleOrder where sOuPersonCode=@userID and sMark not in ('10','55','60') and dDemDate <= @date;");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", DateTime.Today.AddDays(1).ToString("yyyy-MM-dd"))
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);

            if (ds != null)
            {
                list = new List<EnToDoListItem>();

                foreach (DataTable dt in ds.Tables)
                {
                    foreach (DataRow row in dt.Rows)
                    {
                        EnToDoListItem en = new EnToDoListItem();
                        en.Code = row["code"].ToString();
                        en.UserID = row["userID"].ToString();
                        en.Type = Convert.ToInt32(row["type"]);
                        en.Title = row["sTitle"].ToString();
                        en.Mark = row["sMark"].ToString();
                        en.OrderType = row["lType"].ToString();
                        en.OuPersonCode = row["sOuPersonCode"].ToString();
                        en.InPersonCode = row["sPersonCode"].ToString();

                        list.Add(en);
                    }
                }
            }

            return list;
        }
        #endregion

        #region 获取日事日清的任务数据，有分页
        /// <summary>
        /// 获取日事日清的任务数据，有分页
        /// Author: wqz
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="pageSize">页的大小</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList_Task(string userID, int pageSize, int pageIndex)
        {
            List<EnToDoListItem> list = null;

            //获取总数
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(a.code) from X5_TaskInfo a, X5_WPeopleOrder b where a.code=b.code and a.sIPersonCode=@userID and a.lState=0 and a.sMnuCode in ('18192N','18192M','181927','181928'); ");
            strSql.Append("select count(code) from X5_WPeopleOrder where sOuPersonCode=@userID and sMark not in ('10','55','60') and dDemDate <= @date; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", DateTime.Today.AddDays(1).ToString("yyyy-MM-dd"))
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            int countNum = 0;

            if (ds != null && ds.Tables.Count > 0)
                countNum = Convert.ToInt32(ds.Tables[0].Rows[0][0]) + Convert.ToInt32(ds.Tables[1].Rows[0][0]);

            //判断页数是否溢出
            if (pageIndex == 0 || Math.Ceiling(Convert.ToDouble(countNum * 1.0f / pageSize)) < pageIndex)
                return list;

            //拼凑表格
            strSql = new StringBuilder();
            strSql.Append("(select x.code, x.sOPersonCode as userID, " + TODOLIST_TASK + " as type, x.sTitle, y.sMark, y.lType, y.sOuPersonCode, y.sPersonCode ");
            strSql.Append("     from X5_TaskInfo x, X5_WPeopleOrder y where x.code=y.code and x.sIPersonCode='" + userID + "' and x.lState=0 and x.sMnuCode in ('18192N','18192M','181927','181928') ");
            strSql.Append("union all ");
            strSql.Append("select code, sPersonCode as userID, " + TODOLIST_TASK + " as type, sXmName as sTitle, sMark, lType, sOuPersonCode, sPersonCode ");
            strSql.Append("     from X5_WPeopleOrder where sOuPersonCode='" + userID + "' and sMark not in ('10','55','60') and dDemDate <= '" + DateTime.Today.AddDays(1).ToString("yyyy-MM-dd") + "') ");
            
            //分页取数
            arPara = new SqlParameter[]
            {
                new SqlParameter("@tblName", strSql.ToString() + " z"), 
                new SqlParameter("@strGetFields", "z.code, z.userID, z.type, z.sTitle, z.sMark, z.lType, z.sOuPersonCode, z.sPersonCode"),
                new SqlParameter("@fldName", "code"),
                new SqlParameter("@PageSize", pageSize),
                new SqlParameter("@PageIndex", pageIndex),
                new SqlParameter("@doCount", 0),
                new SqlParameter("@RecordCount", SqlDbType.BigInt),
                new SqlParameter("@OrderType", 1),
                new SqlParameter("@strWhere", "1=1")
            };
            arPara[6].Direction = ParameterDirection.Output;

            try
            {
                string spName = "ProPageHelper";
                DataTable dt = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, arPara).Tables[0];

                if (dt != null && dt.Rows.Count > 0)
                {
                    list = new List<EnToDoListItem>();

                    foreach (DataRow row in dt.Rows)
                    {
                        EnToDoListItem en = new EnToDoListItem();
                        en.Code = row["code"].ToString();
                        en.UserID = row["userID"].ToString();
                        en.Type = Convert.ToInt32(row["type"]);
                        en.Title = row["sTitle"].ToString();
                        en.Mark = row["sMark"].ToString();
                        en.OrderType = row["lType"].ToString();
                        en.OuPersonCode = row["sOuPersonCode"].ToString();
                        en.InPersonCode = row["sPersonCode"].ToString();

                        list.Add(en);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
        #endregion

        #region 获取日事日清的SOP数据
        /// <summary>
        /// 获取日事日清的SOP数据
        /// Author: wqz
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList_SOP(string userID)
        {
            List<EnToDoListItem> list = null;

            StringBuilder strSql = new StringBuilder();
            strSql.Append("declare @Flows table (lPageCode int, sVoucherCode nvarchar(32), code int, lFlowCode int, smunucode nvarchar(15)); ");

            strSql.Append("insert into @Flows select tm.lPageCode, t.sVoucherCode, ts.code, t.lFlowCode, tc.smunucode ");
            strSql.Append("from X8_Flow t, X8_Node ts, X8_FlowModel tm, K0_formConfig tc ");
            strSql.Append("where t.code=ts.lFlowRunCode and t.lflowcode=tm.code and tm.lPageCode=tc.lVoucherCode and ts.sapprover=@userID and ts.streecode>'1' and ts.lstate=1 and tc.sVoucherType='000'; ");

            strSql.Append("select a.code, sOPersonCode as userID, " + TODOLIST_SOP + " as type, sTitle, null as sMark, null as lType, null as sOuPersonCode, null as sPersonCode, b.lPageCode, b.sVoucherCode, b.code as bCode, b.lFlowCode ");
            strSql.Append("from X5_TaskInfo a left join @Flows b ON a.code=b.sVoucherCode and a.sMnuCode=b.smunucode ");
            strSql.Append("where a.sIPersonCode=@userID and a.lState=3; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);

            if (ds != null && ds.Tables.Count > 0)
            {
                list = new List<EnToDoListItem>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    EnToDoListItem en = new EnToDoListItem();

                    if (row["lPageCode"].ToString() == "")
                        en.Code = row["code"].ToString();
                    else
                        en.Code = row["lPageCode"] + "$" + row["sVoucherCode"] + "$" + row["code"] + "$" + row["bCode"] + "$" + row["lFlowCode"];

                    en.UserID = row["userID"].ToString();
                    en.Type = Convert.ToInt32(row["type"]);
                    en.Title = row["sTitle"].ToString();
                    en.Mark = row["sMark"].ToString();
                    en.OrderType = row["lType"].ToString();
                    en.OuPersonCode = row["sOuPersonCode"].ToString();
                    en.InPersonCode = row["sPersonCode"].ToString();

                    list.Add(en);
                }
            }

            return list;
        }
        #endregion

        #region 获取日事日清的会议数据
        /// <summary>
        /// 获取日事日清的会议数据
        /// Author: wqz
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList_Meeting(string userID)
        {
            List<EnToDoListItem> list = null;

            StringBuilder strSql = new StringBuilder();
            strSql.Append("select sMeetCode as code, sPersonCode as userID, " + TODOLIST_MEETING + " as type, sMeetTopic as sTitle, null as sMark, null as lType, null as sOuPersonCode, null as sPersonCode, dMeetDate, sMeetSTime, sMeetFTime ");
            strSql.Append("from A9_Meetings where isnull(bdel,0)=0 and dMeetDate=@date and charindex(','+@userID+',', ','+sMeetParticipant+',')<>0; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", DateTime.Today.ToString("yyyy-MM-dd"))
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);

            if (ds != null && ds.Tables.Count > 0)
            {
                list = new List<EnToDoListItem>();

                foreach (DataRow row in ds.Tables[0].Rows)
                {
                    EnToDoListItem en = new EnToDoListItem();
                    en.Code = row["code"].ToString();
                    en.UserID = row["userID"].ToString();
                    en.Type = Convert.ToInt32(row["type"]);
                    en.Title = row["sTitle"].ToString();
                    en.Mark = row["sMark"].ToString();
                    en.OrderType = row["lType"].ToString();
                    en.OuPersonCode = row["sOuPersonCode"].ToString();
                    en.InPersonCode = row["sPersonCode"].ToString();

                    if (row["dMeetDate"].ToString() != "")
                    {
                        en.BeginTime = Convert.ToDateTime(row["dMeetDate"].ToString().Split(' ')[0] + " " + row["sMeetSTime"]);
                        en.EndTime = Convert.ToDateTime(row["dMeetDate"].ToString().Split(' ')[0] + " " + row["sMeetFTime"]);
                    }

                    list.Add(en);
                }
            }

            return list;
        }
        #endregion

        #region 获取日事日清的全部数据
        /// <summary>
        /// 获取日事日清的全部数据
        /// Author: wqz
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList(string userID)
        {
            List<EnToDoListItem> list = new List<EnToDoListItem>();
            List<EnToDoListItem> data = null;
            
            data = getToDoList_Task(userID);
            if (data != null)
                list.AddRange(data);

            data = getToDoList_SOP(userID);
            if (data != null)
                list.AddRange(data);

            data = getToDoList_Meeting(userID);
            if (data != null)
                list.AddRange(data);

            return list;
        }
        #endregion

        #region 获取日事日清的全部数据，有分页
        /// <summary>
        /// 获取日事日清的全部数据，有分页
        /// Author: wqz
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="pageSize">页的大小</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList(string userID, int pageSize, int pageIndex)
        {
            List<EnToDoListItem> list = null;

            //获取总数
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select count(a.code) from X5_TaskInfo a, X5_WPeopleOrder b where a.code=b.code and a.sIPersonCode=@userID and a.lState=0 and a.sMnuCode in ('18192N','18192M','181927','181928'); ");
            strSql.Append("select count(code) from X5_WPeopleOrder where sOuPersonCode=@userID and sMark not in ('10','55','60') and dDemDate <= @date; ");
            strSql.Append("select count(code) from X5_TaskInfo where sIPersonCode=@userID and lState=3; ");
            strSql.Append("select count(sMeetCode) from A9_Meetings where dMeetDate=@meetingDate and charindex(','+@userID+',', ','+sMeetParticipant+',')<>0; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", DateTime.Today.AddDays(1).ToString("yyyy-MM-dd")),
                new SqlParameter("@meetingDate", DateTime.Today.ToString("yyyy-MM-dd"))
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            int countNum = 0;

            if (ds != null && ds.Tables.Count > 0)
            {
                foreach (DataTable dt in ds.Tables)
                    countNum += Convert.ToInt32(dt.Rows[0][0]);
            }

            //判断页数是否溢出
            if (pageIndex == 0 || Math.Ceiling(Convert.ToDouble(countNum * 1.0f / pageSize)) < pageIndex)
                return list;

            //拼凑表格
            strSql = new StringBuilder();
            strSql.Append("(select x.code, x.sOPersonCode as userID, " + TODOLIST_TASK + " as type, x.sTitle, y.sMark, y.lType, y.sOuPersonCode, y.sPersonCode ");
            strSql.Append("     from X5_TaskInfo x, X5_WPeopleOrder y where x.code=y.code and x.sIPersonCode='" + userID + "' and x.lState=0 and x.sMnuCode in ('18192N','18192M','181927','181928') ");
            strSql.Append("union all ");
            strSql.Append("select code, sPersonCode as userID, " + TODOLIST_TASK + " as type, sXmName as sTitle, sMark, lType, sOuPersonCode, sPersonCode ");
            strSql.Append("     from X5_WPeopleOrder where sOuPersonCode='" + userID + "' and sMark not in ('10','55','60') and dDemDate <= '" + DateTime.Today.AddDays(1).ToString("yyyy-MM-dd") + "' ");
            strSql.Append("union all ");
            strSql.Append("select code, sOPersonCode as userID, " + TODOLIST_SOP + " as type, sTitle, null as sMark, null as lType, null as sOuPersonCode, null as sPersonCode ");
            strSql.Append("     from X5_TaskInfo where sIPersonCode='" + userID + "' and lState=3 ");
            strSql.Append("union all ");
            strSql.Append("select sMeetCode as code, sPersonCode as userID, " + TODOLIST_MEETING + " as type, sMeetTopic as sTitle, null as sMark, null as lType, null as sOuPersonCode, null as sPersonCode ");
            strSql.Append("     from A9_Meetings where dMeetDate='" + DateTime.Today.ToString("yyyy-MM-dd") + "' and charindex(','+'" + userID + "'+',', ','+sMeetParticipant+',')<>0) ");

            //分页取数
            arPara = new SqlParameter[]
            {
                new SqlParameter("@tblName", strSql.ToString() + " z"), 
                new SqlParameter("@strGetFields", "z.code, z.userID, z.type, z.sTitle, z.sMark, z.lType, z.sOuPersonCode, z.sPersonCode"),
                new SqlParameter("@fldName", "code"),
                new SqlParameter("@PageSize", pageSize),
                new SqlParameter("@PageIndex", pageIndex),
                new SqlParameter("@doCount", 0),
                new SqlParameter("@RecordCount", SqlDbType.BigInt),
                new SqlParameter("@OrderType", 1),
                new SqlParameter("@strWhere", "1=1")
            };
            arPara[6].Direction = ParameterDirection.Output;

            try
            {
                string spName = "ProPageHelper";
                DataTable dt = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, arPara).Tables[0];

                if (dt != null && dt.Rows.Count > 0)
                {
                    list = new List<EnToDoListItem>();

                    foreach (DataRow row in dt.Rows)
                    {
                        EnToDoListItem en = new EnToDoListItem();
                        en.Code = row["code"].ToString();
                        en.UserID = row["userID"].ToString();
                        en.Type = Convert.ToInt32(row["type"]);
                        en.Title = row["sTitle"].ToString();
                        en.Mark = row["sMark"].ToString();
                        en.OrderType = row["lType"].ToString();
                        en.OuPersonCode = row["sOuPersonCode"].ToString();
                        en.InPersonCode = row["sPersonCode"].ToString();

                        list.Add(en);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
        #endregion

        #region 获取日事日清数据_签退
        /// <summary>
        /// 获取日事日清数据_签退   by wqz
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public IList<EnToDoListItem> getToDoList_SignOut(string userID)
        {
            IList<EnToDoListItem> list = null;

            /*
             * 18192N: 需确认的任务(含M岗)
             * 18192M：需结单的任务(含M岗)
             * 181927：需处理的申请延单任务(含M岗)
             * 181928：需处理的申请暂停任务(含M岗)
             * */
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select a.code, a.sOPersonCode as userID, 1 as type, a.sTitle, b.sMark, b.lType, b.sOuPersonCode, b.sPersonCode from X5_TaskInfo a, X5_WPeopleOrder b where a.code=b.code and a.sIPersonCode=@userID and lState=0 and sMnuCode in ('18192N','18192M','181927','181928');");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            if (ds != null)
            {
                list = new List<EnToDoListItem>();
                for (int i = 0, len = ds.Tables.Count; i < len; i++)
                {
                    foreach (DataRow row in ds.Tables[i].Rows)
                    {
                        EnToDoListItem en = new EnToDoListItem();
                        en.Code = row["code"].ToString();
                        en.UserID = row["userID"].ToString();
                        en.Type = Convert.ToInt32(row["type"]);
                        en.Title = row["sTitle"].ToString();
                        en.Mark = row["sMark"].ToString();
                        en.OrderType = row["lType"].ToString();
                        en.OuPersonCode = row["sOuPersonCode"].ToString();
                        en.InPersonCode = row["sPersonCode"].ToString();

                        list.Add(en);
                    }
                }
            }

            return list;
        }
        #endregion
        
        #region 获取某个月的签到统计情况
        /// <summary>
        /// 获取某个月的签到统计情况
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="year">年份</param>
        /// <param name="month">月份，从0开始</param>
        /// <returns></returns>
        public string getSignInList(string userID, int year, int month)
        {
            string result = "0000000000000000000000000000000";
            string strSql = "select " + SignMonth[month-1] + " from K5_wQDPersonAssess where sPersonCode=@userID and sYear=@year; ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@year", year)
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, arPara);
            if (ds != null && ds.Tables[0].Rows.Count > 0)
            {
                if (ds.Tables[0].Rows[0][0].ToString().Trim() != "")
                    result = ds.Tables[0].Rows[0][0].ToString();
            }

            return result;
        }
        #endregion




        #region 旧版签到签退操作

        #region 签到操作
        /// <summary>
        /// 签到操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签到日期</param>
        /// <returns></returns>
        public string signIn(string userID, DateTime date)
        {
            //签到统计初始化
            DaGrowUp dal = new DaGrowUp();
            EnGrowUp grow = dal.getGrowUpInfo(userID);

            bool bPersonInfo = false;
            bool SignInList_insert = true;
            string SignInList = "0000000000000000000000000000000";
            string SignMonth_d = SignMonth[date.Month - 1];
            string SignMonth1_d = SignMonth_NUM[date.Month - 1];

            StringBuilder strSql = new StringBuilder();

            //判断是否已经签到过，获取积分设置
            strSql.Append("select AutoCode from K5_wQDJlInfo where sJlCode='01' and sPersonCode=@userID and isnull(bDel,0)=0 and Convert(char(10),dDate,120)=@date; ");
            strSql.Append("select sJlCode, lJlType, lValue, lMoney from K5_wQDJlEventType where isnull(bDel,0)=0; ");
            strSql.Append("select " + SignMonth_d + ", " + SignMonth1_d + " from K5_wQDPersonAssess where sPersonCode=@userID and sYear='" + date.Year + "'; ");
            strSql.Append("select dYGJoin, (select dYGBirthday from A5_CWPerson WHERE A5_wZZzl.sPersoncode=A5_CWPerson.sPersoncode) as Birthday from A5_wZZzl where sPersonCode=@userID; ");
            strSql.Append("select AutoCode from K5_wQDPersonInfo where sPersonCode=@userID; ");
            //判断生日和入司的积分是否已经获取
            strSql.Append("select sJlCode, dDate from K5_wQDJlInfo where sPersonCode=@userID and sJlCode in ('02','03') and DATEPART(yyyy, dDate)=" + date.Year + "; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd"))
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            if (ds != null && ds.Tables[0].Rows.Count > 0)
                return "0";
            //return "0,今天已经签到过";

            //获取积分数和奖励类型
            DataRow[] JiFen_rows;
            DataTable JiFen_dt = ds.Tables[1];
            List<string[]> JiFens = new List<string[]>();

            JiFen_rows = JiFen_dt.Select("sJlCode='01'");
            JiFens.Add(new string[] { "01", JiFen_rows[0]["lValue"].ToString(), JiFen_rows[0]["lMoney"].ToString() });

            if (date.Month == 1 && date.Day == 1)
            {
                JiFen_rows = JiFen_dt.Select("sJlCode='05'");
                JiFens.Add(new string[] { "05", JiFen_rows[0]["lValue"].ToString(), JiFen_rows[0]["lMoney"].ToString() });
            }
            else if (date.Month == 9 && date.Day == 1)
            {
                JiFen_rows = JiFen_dt.Select("sJlCode='07'");
                JiFens.Add(new string[] { "07", JiFen_rows[0]["lValue"].ToString(), JiFen_rows[0]["lMoney"].ToString() });
            }
            else if (date.Month == 5 && date.Day == 18)
            {
                JiFen_rows = JiFen_dt.Select("sJlCode='06'");
                JiFens.Add(new string[] { "06", JiFen_rows[0]["lValue"].ToString(), JiFen_rows[0]["lMoney"].ToString() });
            }

            //入司和生日
            if (ds != null && ds.Tables[3].Rows.Count > 0)
            {
                DataRow[] signed_join = null;
                DataRow[] signed_birth = null;

                if (ds.Tables[5].Rows.Count > 0)
                {
                    signed_join = ds.Tables[5].Select("sJlCode='03'");
                    signed_birth = ds.Tables[5].Select("sJlCode='02'");
                }

                //判断今年是否已经获取过积分， 保留5个自然日
                DateTime joinDay = Convert.ToDateTime(ds.Tables[3].Rows[0]["dYGJoin"]);
                DateTime original_joinDay = new DateTime(joinDay.Year, joinDay.Month, joinDay.Day);

                //处理闰年
                if (joinDay.Month == 2 && joinDay.Day == 29)
                    joinDay = new DateTime(date.Year, joinDay.Month, 28);
                else
                    joinDay = new DateTime(date.Year, joinDay.Month, joinDay.Day);

                if (joinDay != null && (signed_join == null || signed_join.Length == 0) && date >= joinDay && date <= joinDay.AddDays(4) && date.Year != original_joinDay.Year)
                {
                    JiFen_rows = JiFen_dt.Select("sJlCode='03'");
                    JiFens.Add(new string[] { "03", JiFen_rows[0]["lValue"].ToString(), JiFen_rows[0]["lMoney"].ToString() });
                }

                DateTime birthday = Convert.ToDateTime(ds.Tables[3].Rows[0]["Birthday"]);
                birthday = new DateTime(date.Year, birthday.Month, birthday.Day);
                if (birthday != null && (signed_birth == null || signed_birth.Length == 0) && date >= birthday && date <= birthday.AddDays(4))
                {
                    JiFen_rows = JiFen_dt.Select("sJlCode='02'");
                    JiFens.Add(new string[] { "02", JiFen_rows[0]["lValue"].ToString(), JiFen_rows[0]["lMoney"].ToString() });
                }
            }

            //是否有个人信息
            if (ds != null && ds.Tables[4].Rows.Count > 0)
                bPersonInfo = true;

            //获取签到统计数据
            if (ds != null && ds.Tables[2].Rows.Count > 0)
            {
                SignInList_insert = false;
                if (ds.Tables[2].Rows[0][0].ToString() == "")
                    SignInList = "0000000000000000000000000000000";
                else
                    SignInList = ds.Tables[2].Rows[0][0].ToString();
            }
            else
            {
                SignInList_insert = true;
            }
            char[] arr = SignInList.ToCharArray();
            arr[date.Day - 1] = '1';
            SignInList = new string(arr);

            //插入积分
            int JiFen_Total = 0;
            int Money_Total = 0;
            strSql = new StringBuilder();
            strSql.Append("begin tran t1; ");
            strSql.Append("set xact_abort on; ");

            for (int i = 0; i < JiFens.Count; i++)
            {
                strSql.Append("insert into K5_wQDJlInfo (sPersonCode, sJlCode, dDate, lJlType, lValue, lMoney, bDel) ");
                strSql.Append("select @userID, sJlCode, @date, lJlType, lValue, lMoney, 0 from K5_wQDJlEventType where sJlCode='" + JiFens[i][0] + "'; ");
                strSql.Append("if @@error!=0 goto w_err; ");

                JiFen_Total += Convert.ToInt32(JiFens[i][1] == "" ? "0" : JiFens[i][1]);
                Money_Total += Convert.ToInt32(JiFens[i][2] == "" ? "0" : JiFens[i][2]);
            }

            //统计表
            if (SignInList_insert)
            {
                strSql.Append("insert into K5_wQDPersonAssess (sPersonCode, sYear, " + SignMonth_d + ", " + SignMonth1_d + ") values (@userID, '" + date.Year + "', '" + SignInList + "', 1); ");
                strSql.Append("if @@error!=0 goto w_err; ");
            }
            else
            {
                strSql.Append("update K5_wQDPersonAssess set " + SignMonth1_d + "=" + SignMonth1_d + "+1, " + SignMonth_d + "='" + SignInList + "' where sPersonCode=@userID and sYear='" + date.Year + "'; ");
                strSql.Append("if @@error!=0 goto w_err; ");
            }

            strSql.Append("declare @sLevelCode nvarchar(20); ");
            strSql.Append("set @sLevelCode = (select top 1 sLevelCode from K5_wQDLevelCls where lValue<=" + (grow.JiFen + JiFen_Total) + " order by lValue desc); ");
            strSql.Append("if @@error!=0 goto w_err; ");

            //个人信息表
            if (bPersonInfo)
            {
                strSql.Append("update K5_wQDPersonInfo set sLevelCode=@sLevelCode, lValue=lValue+" + JiFen_Total + ", sMonQDData='" + date.ToString("yyyy-MM") + "~'+(select top 1 cast(" + SignMonth1_d + " as nvarchar(10)) from K5_wQDPersonAssess z where z.sPersonCode=@userID and z.sYear='" + date.Year + "'), dLatestQdDate=getDate() where sPersonCode=@userID; ");
                strSql.Append("if @@error!=0 goto w_err; ");
            }
            else
            {
                strSql.Append("insert into K5_wQDPersonInfo (sPersonCode, sLevelCode, lValue, lMoney, dLatestQdDate, sMonQDData) select top 1 @userID, @sLevelCode, " + JiFen_Total + ", 0, getDate(), '" + date.ToString("yyyy-MM") + "~'+cast(" + SignMonth1_d + " as nvarchar(10)) from K5_wQDPersonAssess where sPersonCode=@userID and sYear='" + date.Year + "'; ");
                strSql.Append("if @@error!=0 goto w_err; ");
            }

            if (JiFen_Total > 0)
            {
                strSql.Append("insert into X3_Points (sPersonCode, lBatchCode, sDepCode, lType, lPoint, lState, dDate, sOper, sContent, sMemo, lInNum, slink, lCode) ");
                strSql.Append("select @userID, null, (select z.sDepCode from A5_wZzzL z where z.sPersonCode=@userID), @Type, @JiFen, 1, Convert(char(10),getDate(),120), null, @TypeName, null, null, null, null; ");
                strSql.Append("if @@error!=0 goto w_err; ");
            }

            strSql.Append("commit tran t1 ");
            strSql.Append("goto w_end ");
            strSql.Append("w_err:  ");
            strSql.Append("    rollback tran t1  ");
            strSql.Append("w_end:  ");

            if (JiFen_Total > 0)
                strSql.Append(" Execute X3_updatePoint @userID; ");

            arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd HH:mm:ss")),
                new SqlParameter("@Type", JiFen_SignIn_Type),
                new SqlParameter("@JiFen", JiFen_Total),
                new SqlParameter("@TypeName", JiFen_SignIn_TypeName)
            };

            int result = SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            return (result > 0 ? "1" : "0");
        }
        #endregion

        #region 签退操作
        /// <summary>
        /// 签退操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签退日期</param>
        /// <returns></returns>
        public string signOut(string userID, DateTime date)
        {
            DaGrowUp dal = new DaGrowUp();
            EnGrowUp grow = dal.getGrowUpInfo(userID);

            //获取积分数和奖励类型
            int JiFen_Total = 0;
            int Money_Total = 0;
            string signTypeCode = "04";
            string SignMonth_d = SignMonth[date.Month - 1];
            string SignMonth1_d = SignMonth_NUM[date.Month - 1];

            StringBuilder strSql = new StringBuilder();

            //判断是否已经签退过
            strSql.Append("select AutoCode from K5_wQDJlInfo where sJlCode='04' and sPersonCode=@userID and isnull(bDel,0)=0 and Convert(char(10),dDate,120)=@date; ");
            strSql.Append("select sJlCode, lJlType, lValue, lMoney from K5_wQDJlEventType where isnull(bDel,0)=0 and sJlCode='" + signTypeCode + "'; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd"))
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            if (ds != null && ds.Tables[0].Rows.Count > 0)
                return "0";

            //设置要添加的积分
            if (ds != null && ds.Tables[1].Rows.Count > 0)
            {
                if (ds.Tables[1].Rows[0]["lValue"].ToString() != "")
                    JiFen_Total = Convert.ToInt32(ds.Tables[1].Rows[0]["lValue"]);

                if (ds.Tables[1].Rows[0]["lMoney"].ToString() != "")
                    Money_Total = Convert.ToInt32(ds.Tables[1].Rows[0]["lMoney"]);
            }

            strSql = new StringBuilder();
            strSql.Append("begin tran t1; ");
            strSql.Append("set xact_abort on; ");
            strSql.Append("insert into K5_wQDJlInfo (sPersonCode, sJlCode, dDate, lJlType, lValue, lMoney, bDel) ");
            strSql.Append("select @userID, sJlCode, @date, lJlType, lValue, lMoney, 0 from K5_wQDJlEventType where sJlCode=@signTypeCode; ");
            strSql.Append("if @@error!=0 goto w_err; ");

            strSql.Append("declare @sLevelCode nvarchar(20); ");
            strSql.Append("set @sLevelCode = (select top 1 sLevelCode from K5_wQDLevelCls where lValue<=" + (grow.JiFen + JiFen_Total) + " order by lValue desc); ");
            strSql.Append("if @@error!=0 goto w_err; ");

            if (JiFen_Total > 0)
            {
                strSql.Append("insert into X3_Points (sPersonCode, lBatchCode, sDepCode, lType, lPoint, lState, dDate, sOper, sContent, sMemo, lInNum, slink, lCode) ");
                strSql.Append("select @userID, null, (select z.sDepCode from A5_wZzzL z where z.sPersonCode=@userID), @Type, @JiFen, 1, Convert(char(10),getDate(),120), null, @TypeName, null, null, null, null; ");
                strSql.Append("if @@error!=0 goto w_err; ");
            }

            strSql.Append("commit tran t1 ");
            strSql.Append("goto w_end ");
            strSql.Append("w_err:  ");
            strSql.Append("    rollback tran t1  ");
            strSql.Append("w_end:  ");

            if (JiFen_Total > 0)
                strSql.Append(" Execute X3_updatePoint @userID; ");

            arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd HH:mm:ss")),
                new SqlParameter("@signTypeCode", signTypeCode),
                new SqlParameter("@Type", JiFen_SignOut_Type),
                new SqlParameter("@JiFen", JiFen_Total),
                new SqlParameter("@TypeName", JiFen_SignOut_TypeName)
            };

            int result = SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            return (result > 0 ? "1" : "0");
        }
        #endregion

        #endregion        

        #region 通过存储过程，签到操作
        /// <summary>
        /// 通过存储过程，签到操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签到日期</param>
        /// <returns></returns>
        public EnSign signIn_StoredProcedure(string userID, DateTime date)
        {
            //返回结果实体
            EnSign result = new EnSign();

            //存储过程参数
            int signInState = -1;
            string signInType = "";
            string signInList = "0000000000000000000000000000000";
            string signMonthField = SignMonth[date.Month - 1];
            string signMonthNumField = SignMonth_NUM[date.Month - 1];

            //基础数据
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select " + signMonthField + ", " + signMonthNumField + " from K5_wQDPersonAssess where sPersonCode=@userID and sYear='" + date.Year + "'; ");
            strSql.Append("select sJlCode, lJlType, lValue, lMoney from K5_wQDJlEventType where isnull(bDel,0)=0; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            if (ds != null && ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Rows[0][0].ToString() != "")
            {
                signInList = ds.Tables[0].Rows[0][0].ToString();
            }

            //设置签到情况字符串
            char[] arr = signInList.ToCharArray();
            arr[date.Day - 1] = '1';
            signInList = new string(arr);

            //执行签到存储过程
            arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd")),
                new SqlParameter("@signMonthField", signMonthField),
                new SqlParameter("@signInList", signInList),
                new SqlParameter("@signMonthNumField", signMonthNumField),
                new SqlParameter("@signInState", SqlDbType.Int),
                new SqlParameter("@signInType", SqlDbType.NVarChar, 20),
                new SqlParameter("@lotNum", SqlDbType.Int)

            };

            arPara[5].Direction = ParameterDirection.Output;
            arPara[6].Direction = ParameterDirection.Output;
            arPara[7].Direction = ParameterDirection.Output;
            string spName = "Grow_SignIn";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, arPara);

                //执行成功
                if (arPara[5].Value != null)
                {
                    signInState = Convert.ToInt32(arPara[5].Value);
                    signInType = arPara[6].Value.ToString();

                    result.Gifts = 0;
                    result.code = signInState.ToString();

                    if (arPara[7].Value.ToString() != "")
                        result.Lot = Convert.ToInt32(arPara[7].Value);
                    else
                        result.Lot = 0;

                    //调整积分系统
                    strSql = new StringBuilder("Execute X3_updatePoint @userID;");

                    arPara = new SqlParameter[] {
                        new SqlParameter("@userID", userID)
                    };

                    SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            //返回信息
            if (signInState == -1)
                result.msg = "签到失败";
            else if (signInState == 0)
                result.msg = "今天已经签到过了";
            else
            {
                DataTable dt = ds.Tables[1];
                DataRow[] rows = dt.Select("sJlCode='01'");
                result.msg = "成功签到！";

                if (rows != null && rows.Length > 0)
                {
                    result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                    if (rows[0]["lMoney"].ToString() != "")
                        result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                }

                //元旦
                if (signInType.IndexOf("05") != -1)
                {
                    rows = dt.Select("sJlCode='05'");
                    result.msg = "今天很特别哦！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //公司周年庆
                if (signInType.IndexOf("06") != -1)
                {
                    rows = dt.Select("sJlCode='06'");
                    result.msg = "今天很特别哦！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //9.1
                if (signInType.IndexOf("07") != -1)
                {
                    rows = dt.Select("sJlCode='07'");
                    result.msg = "今天很特别哦！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //入司
                if (signInType.IndexOf("03") != -1)
                {
                    rows = dt.Select("sJlCode='03'");
                    result.msg = "入司周年！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //生日
                if (signInType.IndexOf("02") != -1)
                {
                    rows = dt.Select("sJlCode='02'");
                    result.msg = "生日快乐！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }
            }

            return result;
        }
        #endregion

        #region 通过存储过程，签退操作
        /// <summary>
        /// 通过存储过程，签退操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签退日期</param>
        /// <returns></returns>
        public EnSign signOut_StoredProcedure(string userID, DateTime date)
        {
            //返回结果实体
            EnSign result = new EnSign();

            //存储过程参数
            int signInState = -1;

            //基础数据
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select sJlCode, lJlType, lValue, lMoney from K5_wQDJlEventType where isnull(bDel,0)=0; ");
            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString());


            //执行签到存储过程
            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd")),
                new SqlParameter("@signInState", SqlDbType.Int),
                new SqlParameter("@lotNum", SqlDbType.Int)

            };

            arPara[2].Direction = ParameterDirection.Output;
            arPara[3].Direction = ParameterDirection.Output;
            string spName = "Grow_SignOut";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, arPara);

                //执行成功
                if (arPara[2].Value != null)
                {
                    signInState = Convert.ToInt32(arPara[2].Value);

                    result.Gifts = 0;
                    result.code = signInState.ToString();

                    if (arPara[3].Value.ToString() != "")
                        result.Lot = Convert.ToInt32(arPara[3].Value);
                    else
                        result.Lot = 0;

                    //调整积分系统
                    strSql = new StringBuilder("Execute X3_updatePoint @userID;");

                    arPara = new SqlParameter[] {
                        new SqlParameter("@userID", userID)
                    };

                    SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            //返回信息
            if (signInState == -1)
                result.msg = "日事日清失败";
            else if (signInState == 0)
                result.msg = "今天已经日事日清过了";
            else
            {
                DataTable dt = ds.Tables[0];
                DataRow[] rows = dt.Select("sJlCode='04'");
                result.msg = "恭喜你今天日事日清！";

                if (rows != null && rows.Length > 0)
                {
                    result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                    if (rows[0]["lMoney"].ToString() != "")
                        result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                }
            }

            return result;
        }
        #endregion

        




        #region 通过存储过程，签到操作
        /// <summary>
        /// 通过存储过程，签到操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签到日期</param>
        /// <returns></returns>
        public EnSign signIn_Test(string userID, DateTime date)
        {
            //返回结果实体
            EnSign result = new EnSign();

            //存储过程参数
            int signInState = -1;
            string signInType = "";
            string signInList = "0000000000000000000000000000000";
            string signMonthField = SignMonth[date.Month - 1];
            string signMonthNumField = SignMonth_NUM[date.Month - 1];

            //基础数据
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select " + signMonthField + ", " + signMonthNumField + " from K5_wQDPersonAssess where sPersonCode=@userID and sYear='" + date.Year + "'; ");
            strSql.Append("select sJlCode, lJlType, lValue, lMoney from K5_wQDJlEventType where isnull(bDel,0)=0; ");

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
            if (ds != null && ds.Tables[0].Rows.Count > 0 && ds.Tables[0].Rows[0][0].ToString() != "")
            {
                signInList = ds.Tables[0].Rows[0][0].ToString();
            }

            //设置签到情况字符串
            char[] arr = signInList.ToCharArray();
            arr[date.Day - 1] = '1';
            signInList = new string(arr);

            //执行签到存储过程
            arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd")),
                new SqlParameter("@signMonthField", signMonthField),
                new SqlParameter("@signInList", signInList),
                new SqlParameter("@signMonthNumField", signMonthNumField),
                new SqlParameter("@signInState", SqlDbType.Int),
                new SqlParameter("@signInType", SqlDbType.NVarChar, 20),
                new SqlParameter("@lotNum", SqlDbType.Int)

            };

            arPara[5].Direction = ParameterDirection.Output;
            arPara[6].Direction = ParameterDirection.Output;
            arPara[7].Direction = ParameterDirection.Output;
            string spName = "Grow_SignIn_Test";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, arPara);

                //执行成功
                if (arPara[5].Value != null)
                {
                    signInState = Convert.ToInt32(arPara[5].Value);
                    signInType = arPara[6].Value.ToString();

                    result.Gifts = 0;
                    result.code = signInState.ToString();

                    if (arPara[7].Value.ToString() != "")
                        result.Lot = Convert.ToInt32(arPara[7].Value);
                    else
                        result.Lot = 0;

                    //调整积分系统
                    strSql = new StringBuilder("Execute X3_updatePoint @userID;");

                    arPara = new SqlParameter[] {
                        new SqlParameter("@userID", userID)
                    };

                    SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            //返回信息
            if (signInState == -1)
                result.msg = "签到失败";
            else if (signInState == 0)
                result.msg = "今天已经签到过了";
            else
            {
                DataTable dt = ds.Tables[1];
                DataRow[] rows = dt.Select("sJlCode='01'");
                result.msg = "成功签到！";

                if (rows != null && rows.Length > 0)
                {
                    result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                    if (rows[0]["lMoney"].ToString() != "")
                        result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                }

                //元旦
                if (signInType.IndexOf("05") != -1)
                {
                    rows = dt.Select("sJlCode='05'");
                    result.msg = "今天很特别哦！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //公司周年庆
                if (signInType.IndexOf("06") != -1)
                {
                    rows = dt.Select("sJlCode='06'");
                    result.msg = "今天很特别哦！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //9.1
                if (signInType.IndexOf("07") != -1)
                {
                    rows = dt.Select("sJlCode='07'");
                    result.msg = "今天很特别哦！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //入司
                if (signInType.IndexOf("03") != -1)
                {
                    rows = dt.Select("sJlCode='03'");
                    result.msg = "入司周年！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }

                //生日
                if (signInType.IndexOf("02") != -1)
                {
                    rows = dt.Select("sJlCode='02'");
                    result.msg = "生日快乐！";

                    if (rows != null && rows.Length > 0)
                    {
                        result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                        if (rows[0]["lMoney"].ToString() != "")
                            result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                    }
                }
            }

            return result;
        }
        #endregion

        #region 通过存储过程，签退操作
        /// <summary>
        /// 通过存储过程，签退操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="date">签退日期</param>
        /// <returns></returns>
        public EnSign signOut_Test(string userID, DateTime date)
        {
            //返回结果实体
            EnSign result = new EnSign();

            //存储过程参数
            int signInState = -1;

            //基础数据
            StringBuilder strSql = new StringBuilder();
            strSql.Append("select sJlCode, lJlType, lValue, lMoney from K5_wQDJlEventType where isnull(bDel,0)=0; ");
            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString());


            //执行签到存储过程
            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", date.ToString("yyyy-MM-dd")),
                new SqlParameter("@signInState", SqlDbType.Int),
                new SqlParameter("@lotNum", SqlDbType.Int)

            };

            arPara[2].Direction = ParameterDirection.Output;
            arPara[3].Direction = ParameterDirection.Output;
            string spName = "Grow_SignOut_Test";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, arPara);

                //执行成功
                if (arPara[2].Value != null)
                {
                    signInState = Convert.ToInt32(arPara[2].Value);

                    result.Gifts = 0;
                    result.code = signInState.ToString();

                    if (arPara[3].Value.ToString() != "")
                        result.Lot = Convert.ToInt32(arPara[3].Value);
                    else
                        result.Lot = 0;

                    //调整积分系统
                    strSql = new StringBuilder("Execute X3_updatePoint @userID;");

                    arPara = new SqlParameter[] {
                        new SqlParameter("@userID", userID)
                    };

                    SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            //返回信息
            if (signInState == -1)
                result.msg = "日事日清失败";
            else if (signInState == 0)
                result.msg = "今天已经日事日清过了";
            else
            {
                DataTable dt = ds.Tables[0];
                DataRow[] rows = dt.Select("sJlCode='04'");
                result.msg = "恭喜你今天日事日清！";

                if (rows != null && rows.Length > 0)
                {
                    result.SignJiFen = Convert.ToInt32(rows[0]["lValue"]);

                    if (rows[0]["lMoney"].ToString() != "")
                        result.Coin = Convert.ToInt32(rows[0]["lMoney"]);
                }
            }

            return result;
        }
        #endregion
    }
}
