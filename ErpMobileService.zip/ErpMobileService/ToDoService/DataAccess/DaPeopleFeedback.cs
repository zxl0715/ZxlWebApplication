﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using ToDoService.Entity;
using System.Data.SqlClient;
using System.Data;
using ND.Lib.Data.SqlHelper;

namespace ToDoService.DataAccess
{
    public class DaPeopleFeedback
    {
        private static string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;

        #region 获取未完成的单据的反馈
        /// <summary>
        /// 获取未完成的单据的反馈
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="codes">指定任务号</param>
        /// <returns></returns>
        public IList<EnPeopleFeedback> getNotFinishedToDo_FeedBack(string userID, int[] codes)
        {
            string strSql = "";
            IList<EnPeopleFeedback> list = new List<EnPeopleFeedback>();

            if (codes == null)
            {
                strSql = "select b.AutoCode, b.lcode, b.lXMPercent, b.sMemo, b.sPersoncode, b.lType, b.dFdate, b.dFTime, b.sFettle, b.sState into #ddd "
                    + "from X5_WPeopleOrder a, X5_YPeopleFeedback b, X5_ToDoTaskInfo c where a.code=b.lcode and a.code=c.lTaskCode and (a.sOuPersonCode=@userID or a.sInPersonCode=@userID) "
                    + "insert into #ddd select b.AutoCode, b.lcode, b.lXMPercent, b.sMemo, b.sPersoncode, b.lType, b.dFdate, b.dFTime, b.sFettle, b.sState "
                    + "from X5_WPeopleOrderView a, X5_YPeopleFeedback b, X5_ToDoTaskInfo c where a.code=b.lcode and a.code=c.lTaskCode and a.sMark='20' and (a.sOuPersonCode=@userID or a.sInPersonCode=@userID) ";
            }
            else
            {
                strSql = "select b.AutoCode, b.lcode, b.lXMPercent, b.sMemo, b.sPersoncode, b.lType, b.dFdate, b.dFTime, b.sFettle, b.sState into #ddd "
                    + "from X5_WPeopleOrderView a, X5_YPeopleFeedback b, X5_ToDoTaskInfo c where a.code=b.lcode and a.code=c.lTaskCode and (a.sOuPersonCode=@userID or a.sInPersonCode=@userID) ";

                string select = "";
                for (int i = 0; i < codes.Length; i++)
                    select += codes[i] + ",";

                if (select.Length > 0)
                    select = select.Substring(0, select.Length - 1);

                strSql += " and a.code in (" + select + ") ";
            }

            strSql += "select a.AutoCode, a.lcode, a.lXMPercent, a.sMemo, a.sPersoncode, a.lType, a.dFdate, a.dFTime, a.sFettle, a.sState from #ddd a, (select max(AutoCode) as AutoCode from #ddd group by lcode) b where a.AutoCode=b.AutoCode order by a.AutoCode ";
            strSql += "drop table #ddd ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, arPara);
                list = DynamicBuilder<EnPeopleFeedback>.ConvertToList(dr);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }

            return list;
        }
        #endregion

        #region 获取Sstate匹配的反馈表信息
        /// <summary>
        /// 获取Sstate匹配的反馈表信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        public EnPeopleFeedback getCurrentEnFeedback(string userID, int OrderCode)
        {

            string strSql = @"SELECT top 1 a.* ";
            strSql += "FROM dbo.X5_YPeopleFeedback a, dbo.X5_WPeopleOrder b ";
            strSql += "WHERE a.lcode=b.code AND a.sFettle=b.sMark and ISNULL(a.sState,'')=ISNULL(b.sState,'')";
            strSql += ("and b.code=" + OrderCode + " ORDER BY AutoCode DESC");

            string strF = @"SELECT top 1 a.* ";
            strF += "FROM dbo.X5_YPeopleFeedback a, dbo.X5_WPeopleOrderView b ";
            strF += "WHERE a.lcode=b.code AND a.sFettle=b.sMark and ISNULL(a.sState,'')=ISNULL(b.sState,'')";
            strF += ("and b.code=" + OrderCode + " ORDER BY AutoCode DESC");

            DataTable dt = null;
            try
            {
                dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strSql, null).Tables[0];
                if (dt == null || dt.Rows.Count == 0)
                {
                    dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strF, null).Tables[0];
                }
                foreach (DataRow dr in dt.Rows)
                {
                    EnPeopleFeedback item = new EnPeopleFeedback();

                    item.AutoCode = Convert.ToInt32(dr["AutoCode"].ToString());
                    if (!dr["BAffirm"].ToString().Trim().Equals(""))
                    {
                        item.BAffirm = Convert.ToInt32(dr["BAffirm"].ToString());
                    }

                    item.DFdate = (dr["DFdate"].ToString().Equals("") ? null : (DateTime?)Convert.ToDateTime(dr["DFdate"].ToString().Trim()));
                    item.DFTime = (dr["DFTime"].ToString().Equals("") ? null : (DateTime?)Convert.ToDateTime(dr["DFTime"].ToString().Trim()));
                    item.DgDate = (dr["DgDate"].ToString().Equals("") ? null : (DateTime?)Convert.ToDateTime(dr["DgDate"].ToString().Trim()));
                    item.DSTime = (dr["DSTime"].ToString().Equals("") ? null : (DateTime?)Convert.ToDateTime(dr["DSTime"].ToString().Trim()));
                    if (!dr["LCheckType"].ToString().Trim().Equals(""))
                    {
                        item.LCheckType = Convert.ToInt32(dr["LCheckType"].ToString());
                    }

                    if (!dr["Lcode"].ToString().Trim().Equals(""))
                    {
                        item.Lcode = Convert.ToInt32(dr["Lcode"].ToString());
                    }

                    if (!dr["LLast"].ToString().Trim().Equals(""))
                    {
                        item.LLast = Convert.ToInt32(dr["LLast"].ToString());
                    }

                    if (!dr["LSubjoinHours"].ToString().Trim().Equals(""))
                    {
                        item.LSubjoinHours = Convert.ToDouble(dr["LSubjoinHours"].ToString());
                    }

                    if (!dr["LsubjoinPoint"].ToString().Trim().Equals(""))
                    {
                        item.LsubjoinPoint = Convert.ToDouble(dr["LsubjoinPoint"].ToString());
                    }

                    if (!dr["LTaskPoint"].ToString().Trim().Equals(""))
                    {
                        item.LTaskPoint = Convert.ToDouble(dr["LsubjoinPoint"].ToString());
                    }

                    if (!dr["LType"].ToString().Trim().Equals(""))
                    {
                        item.LType = Convert.ToInt32(dr["LType"].ToString());
                    }

                    if (!dr["LXMPercent"].ToString().Trim().Equals(""))
                    {
                        item.LXMPercent = Convert.ToDouble(dr["LXMPercent"].ToString());
                    }

                    item.SCode = dr["SCode"].ToString();
                    item.SFettle = dr["SFettle"].ToString();
                    item.SHfettle = dr["SHfettle"].ToString();
                    item.SMemo = dr["SMemo"].ToString();
                    item.SMpeople = dr["SMpeople"].ToString();
                    item.SOrderCode = dr["SOrderCode"].ToString();
                    item.SPersoncode = dr["SPersoncode"].ToString();
                    item.SState = dr["SState"].ToString();
                    item.SUrl = dr["SUrl"].ToString();
                    item.SUrlTemp = dr["SUrlTemp"].ToString();

                    return item;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dt != null)
                {
                    dt.Dispose();
                }
            }
            return null;
        }
        #endregion
    }
}
