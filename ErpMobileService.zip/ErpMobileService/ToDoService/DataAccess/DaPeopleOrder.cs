﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using ToDoService.Entity;
using System.Data.SqlClient;
using System.Data;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;
using System.Diagnostics;
using System.Globalization;
using System.Text.RegularExpressions;

namespace ToDoService.DataAccess
{
    /// <summary>
    /// ToDo数据访问层
    /// </summary>
    public class DaPeopleOrder
    {
        private static string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;

        #region 获取未完成的单据
        /// <summary>
        /// 获取未完成的单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public IList<EnPeopleOrder> getNotFinishedToDo(string userID)
        {
            IList<EnPeopleOrder> list = new List<EnPeopleOrder>();

            string strSql = "select code, sXmName, sMark, sState, lXMPercent, dDemDate, sDepDemandTemp, sInDepCode, sInPersoncode, sMPeople, sOuDepCode, sOuPersonCode, sOuPeople, lFCode, sXmCode, lType, sXMFCode, a.dDate "
                + "from X5_WPeopleOrder a, X5_ToDoTaskInfo b where a.code=b.lTaskCode and (sOuPersonCode=@userID or sInPersonCode=@userID) "
                + "union all select code, sXmName, sMark, sState, lXMPercent, dDemDate, sDepDemandTemp, sInDepCode, sInPersoncode, sMPeople, sOuDepCode, sOuPersonCode, sOuPeople, lFCode, sXmCode, lType, sXMFCode, a.dDate "
                + "from X5_WPeopleOrderView a, X5_ToDoTaskInfo b where a.code=b.lTaskCode and a.sMark='20' and (sOuPersonCode=@userID or sInPersonCode=@userID) "
                + "order by code ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strSql, arPara).Tables[0];
                addDataTableToList(dt, list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
        #endregion

        #region 获取新增的未完成的单据
        /// <summary>
        /// 获取新增的未完成的单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="maxCode">SQLite上未完成单据的最大编号</param>
        /// <returns></returns>
        public IList<EnPeopleOrder> getNewToDo(string userID, int maxCode)
        {
            IList<EnPeopleOrder> list = new List<EnPeopleOrder>();

            string strSql = "select code, sXmName, sMark, sState, lXMPercent, dDemDate, sDepDemandTemp, sInDepCode, sInPersoncode, sMPeople, sOuDepCode, sOuPersonCode, sOuPeople, lFCode, sXmCode, lType, sXMFCode, a.dDate "
                + "from X5_WPeopleOrder a, X5_ToDoTaskInfo b where a.code=b.lTaskCode and code>@code and (sOuPersonCode=@userID or sInPersonCode=@userID) "
                + "union all select code, sXmName, sMark, sState, lXMPercent, dDemDate, sDepDemandTemp, sInDepCode, sInPersoncode, sMPeople, sOuDepCode, sOuPersonCode, sOuPeople, lFCode, sXmCode, lType, sXMFCode, a.dDate "
                + "from X5_WPeopleOrderView a, X5_ToDoTaskInfo b where a.code=b.lTaskCode and code>@code and sMark='20' and (sOuPersonCode=@userID or sInPersonCode=@userID) "
                + "order by code";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@code", maxCode)
            };

            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strSql, arPara).Tables[0];
                addDataTableToList(dt, list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
        #endregion

        #region 获取反馈表有更新的未完成的单据(可能包含新增的未完成)
        /// <summary>
        /// 获取反馈表有更新的未完成的单据(可能包含新增的未完成)
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="maxFeedBackAuto">SQLite上未完成单据的反馈的最大编号</param>
        /// <param name="maxConfirmAuto">SQLite上记录的确认自动编号</param>
        /// <returns></returns>
        public IList<EnPeopleOrder> getUpdateToDo(string userID, int maxFeedBackAuto, int maxConfirmAuto)
        {
            IList<EnPeopleOrder> list = new List<EnPeopleOrder>();

            string strSql =string.Format( @"
DECLARE @userid NVARCHAR(100),@confirm INT ,@feedback int
SET @userid='{0}'
SET @confirm={1}
SET @feedback={2};
WITH ddd AS (
        SELECT  c.lcode
        FROM    X5_WPeopleOrderView a ,
                X5_ToDoTaskInfo b ,
                X5_YPeopleFeedback c
        WHERE   a.code = b.lTaskCode
                AND a.code = c.lcode
                AND ( a.sOuPersonCode = @userID
                      OR a.sInPersonCode = @userID
                    )
                AND c.AutoCode > @feedback
        GROUP BY c.lcode
        UNION ALL
        SELECT  c.lcode
        FROM    X5_WPeopleOrderView a ,
                X5_ToDoTaskInfo b ,
                X5_WPeopleTask c
        WHERE   a.code = b.lTaskCode
                AND a.code = c.lcode
                AND ( a.sOuPersonCode = @userID
                      OR a.sInPersonCode = @userID
                    )
                AND c.AutoCode > @confirm
        GROUP BY c.lcode
		)

SELECT  code ,
        sXmName ,
        sMark ,
        sState ,
        lXMPercent ,
        dDemDate ,
        sDepDemandTemp ,
        sInDepCode ,
        sInPersoncode ,
        sMPeople ,
        sOuDepCode ,
        sOuPersonCode ,
        sOuPeople ,
        lFCode ,
        sXmCode ,
        lType ,
        sXMFCode ,
        a.dDate
FROM    X5_WPeopleOrderView a join X5_ToDoTaskInfo b on a.code = b.lTaskCode
        join  ddd c on a.code = c.lcode
      where      ( a.sOuPersonCode = @userID
            or  a.sInPersonCode = @userID
            )
ORDER BY code ", userID, maxConfirmAuto, maxFeedBackAuto);
            
            SqlParameter[] arPara = new SqlParameter[] {
                //new SqlParameter("@feedback", maxFeedBackAuto),
                //new SqlParameter("@confirm", maxConfirmAuto),
                //new SqlParameter("@userID", userID)
            };

            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strSql, arPara).Tables[0];
                addDataTableToList(dt, list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
        #endregion

        #region 获取ToDo单据的确认表中最大的AutoCode
        /// <summary>
        /// 获取ToDo单据的确认表中最大的AutoCode
        /// </summary>
        /// <returns></returns>
        public int getLastToDoConfirmAuto()
        {
            string strSql = "select top 1 c.AutoCode from X5_WPeopleOrderView a, X5_ToDoTaskInfo b, X5_WPeopleTask c where a.code=b.lTaskCode and a.code=c.lcode order by c.AutoCode desc";

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strSql).Tables[0];
            if (dt != null && dt.Rows.Count > 0)
                return Convert.ToInt32(dt.Rows[0]["AutoCode"]);
            else
                return 0;
        }
        #endregion

        #region ToDo单据搜索
        /// <summary>
        /// ToDo单据搜索
        /// </summary>
        /// <param name="type">搜索类型，只接单、只下单、全部  1 只下单  2 只接单  否则 全部</param>
        /// <param name="sort">排序类型  1 按截止  2 按下单  否则  按编号</param>
        /// <param name="userID">用户ID</param>
        /// <param name="name">关键字</param>
        /// <param name="mark">任务状态(逗号隔开)，传空，全状态</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public IList<EnPeopleOrder> searchToDo(int type, int sort, string userID, string name, string mark, int pageIndex)
        {
            int pageSize = 10;
            IList<EnPeopleOrder> list = new List<EnPeopleOrder>();

            //配置搜索接单、下单、全部，默认全部
            string personType = "";
            switch (type)
            {
                case 1:
                    personType = "sInPersonCode='" + userID + "'";
                    break;
                case 2:
                    personType = "sOuPersonCode='" + userID + "'";
                    break;
                default:
                    personType = "(sOuPersonCode='" + userID + "' or sInPersonCode='" + userID + "')";
                    break;
            }

            //配置排序方式
            string sortType = "";
            int orderType = 0;
            switch (sort)
            {
                case 1:
                    sortType = "a.dDemDate";
                    orderType = 0;
                    break;
                case 2:
                    sortType = "a.dDate";
                    orderType = 1;
                    break;
                default:
                    sortType = "a.code";
                    orderType = 1;
                    break;
            }

            //任务表
            string table = "X5_WPeopleOrder";
            if (mark == "" || mark.IndexOf("'20'") != -1 || mark.IndexOf("'90'") != -1 || mark.IndexOf("'99'") != -1)
                table = "X5_WPeopleOrderView";

            //获取总数
            string strSql = "select count(code) from " + table + " a, X5_ToDoTaskInfo b where a.code=b.lTaskCode and " + personType + (mark == "" ? "" : "and sMark in (" + mark + ")") + " and sXmName like '%" + name + "%'";
            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strSql).Tables[0];
            int countNum = 0;

            if (dt != null && dt.Rows.Count > 0)
                countNum = Convert.ToInt32(dt.Rows[0][0]);

            //判断页数是否溢出
            if (pageIndex == 0 || Math.Ceiling(Convert.ToDouble(countNum * 1.0f / pageSize)) < pageIndex)
                return list;

            SqlParameter[] arPara = new SqlParameter[]
            {
                new SqlParameter("@tblName", table + " a, X5_ToDoTaskInfo b"), 
                new SqlParameter("@strGetFields", "code, sXmName, sMark, sState, lXMPercent, dDemDate, '' as sDepDemandTemp, sInDepCode, sInPersoncode, sMPeople, sOuDepCode, sOuPersonCode, sOuPeople, lFCode, sXmCode, lType, sXMFCode, a.dDate"),
                new SqlParameter("@fldName", sortType),
                new SqlParameter("@PageSize", pageSize),
                new SqlParameter("@PageIndex", pageIndex),
                new SqlParameter("@doCount", 0),
                new SqlParameter("@RecordCount", SqlDbType.BigInt),
                new SqlParameter("@OrderType", orderType),
                new SqlParameter("@strWhere", "a.code=b.lTaskCode and " + personType + (mark == "" ? "" : "and sMark in (" + mark + ")") + " and sXmName like '%" + name + "%'")
            };
            arPara[6].Direction = ParameterDirection.Output;

            try
            {
                string spName = "ProPageHelper";
                dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.StoredProcedure, spName, arPara).Tables[0];
                addDataTableToList(dt, list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
        #endregion

        #region 获取已完成的单据
        /// <summary>
        /// 获取已完成的单据
        /// </summary>
        /// <param name="type">搜索类型，只接单、只下单、全部  1 只下单  2 只接单  否则 全部</param>
        /// <param name="sort">排序类型  1 按截止  2 按下单  否则  按编号</param>
        /// <param name="userID">用户ID</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public IList<EnPeopleOrder> getEndToDo(int type, int sort, string userID, int pageIndex)
        {
            int pageSize = 10;
            IList<EnPeopleOrder> list = new List<EnPeopleOrder>();

            //配置搜索接单、下单、全部，默认全部
            string personType = "";
            switch (type)
            {
                case 1:
                    personType = "sInPersonCode='" + userID + "'";
                    break;
                case 2:
                    personType = "sOuPersonCode='" + userID + "'";
                    break;
                default:
                    personType = "(sOuPersonCode='" + userID + "' or sInPersonCode='" + userID + "')";
                    break;
            }

            //配置排序方式
            string sortType = "";
            int orderType = 0;
            switch (sort)
            {
                case 1:
                    sortType = "a.dDemDate";
                    orderType = 1;
                    break;
                case 2:
                    sortType = "a.dDate";
                    orderType = 1;
                    break;
                default:
                    sortType = "a.code";
                    orderType = 1;
                    break;
            }

            //获取总数
            string strSql = "select count(a.code) from X5_WPeopleOrderView a, X5_ToDoTaskInfo b where a.code=b.lTaskCode and a.sMark='90' and " + personType;
            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, strSql).Tables[0];
            int countNum = 0;

            if (dt != null && dt.Rows.Count > 0)
                countNum = Convert.ToInt32(dt.Rows[0][0]);

            //判断页数是否溢出
            if (pageIndex == 0 || Math.Ceiling(Convert.ToDouble(countNum * 1.0f / pageSize)) < pageIndex)
                return list;

            SqlParameter[] arPara = new SqlParameter[]
            {
                new SqlParameter("@tblName", "X5_WPeopleOrderView a, X5_ToDoTaskInfo b"), 
                new SqlParameter("@strGetFields", "code, sXmName, sMark, sState, lXMPercent, dDemDate, '' as sDepDemandTemp, sInDepCode, sInPersoncode, sMPeople, sOuDepCode, sOuPersonCode, sOuPeople, lFCode, sXmCode, lType, sXMFCode, a.dDate"),
                new SqlParameter("@fldName", sortType),
                new SqlParameter("@PageSize", pageSize),
                new SqlParameter("@PageIndex", pageIndex),
                new SqlParameter("@doCount", 0),
                new SqlParameter("@RecordCount", SqlDbType.BigInt),
                new SqlParameter("@OrderType", orderType),
                new SqlParameter("@strWhere", "a.code=b.lTaskCode and a.sMark='90' and " + personType)
            };
            arPara[6].Direction = ParameterDirection.Output;

            try
            {
                string spName = "ProPageHelper";
                dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.StoredProcedure, spName, arPara).Tables[0];
                addDataTableToList(dt, list);
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return list;
        }
        #endregion

        #region 将DataTable数据转换成EnPeopleOrder插入列表
        /// <summary>
        /// 将DataTable数据转换成EnPeopleOrder插入列表
        /// </summary>
        /// <param name="dt">DataTable</param>
        /// <param name="list">列表</param>
        public void addDataTableToList(DataTable dt, IList<EnPeopleOrder> list)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    EnPeopleOrder en = new EnPeopleOrder();
                    en.Code = Convert.ToInt32(dr["code"]);
                    en.DemDate = Convert.ToDateTime(dr["dDemDate"]);
                    en.DDate = Convert.ToDateTime(dr["dDate"]);

                    if (!dr["lXMPercent"].ToString().Equals(""))
                        en.lXMPercent = Convert.ToDouble(dr["lXMPercent"].ToString());

                    en.Mark = dr["sMark"].ToString();
                    en.State = dr["sState"].ToString();
                    en.XmName = dr["sXmName"].ToString();
                    en.XmCode = dr["sXMCode"].ToString();

                    if (!dr["lType"].ToString().Equals(""))
                        en.LType = Convert.ToInt32(dr["lType"]);

                    en.DepDemandTemp = dr["sDepDemandTemp"].ToString();
                    en.SInDepCode = dr["sInDepCode"].ToString();
                    en.SInPersoncode = dr["sInPersoncode"].ToString();
                    en.SMPeople = dr["sMPeople"].ToString();
                    en.SOuDepCode = dr["sOuDepCode"].ToString();
                    en.SOuPersonCode = dr["sOuPersonCode"].ToString();
                    en.SOuPeople = dr["sOuPeople"].ToString();

                    if (!dr["lFCode"].ToString().Equals(""))
                        en.LFcode = Convert.ToInt32(dr["lFCode"].ToString());

                    list.Add(en);
                }
            }
        }
        #endregion

        #region 接单确认
        /// <summary>
        /// 接单确认
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="Tcode">任务号</param>
        /// <param name="sXmCode">二级项目编号</param>
        /// <param name="BySelf">是否自己完成</param>
        /// <returns></returns>
        public string acceptOrder(string userID, int Tcode, string sXmCode, bool BySelf)
        {
            //取数
            string strSql = @"select lcode, lType, sOuPersonCode, dDemDate, dPeoSDate, lTotalHours, sRating, sDepDemand, sXmName, sQuality from X5_WPeopleOrder where code=" + Tcode;
            DataSet ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);

            if (ds != null && ds.Tables.Count > 0)
            {
                string sOuPersonCode = ds.Tables[0].Rows[0]["sOuPersonCode"].ToString();

                //接单确认
                string spName = "p_Task_TaskAffirm";
                SqlParameter[] param = {
                    new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                        {Value = sOuPersonCode},
                    new SqlParameter("@lTcode", SqlDbType.Int)
                        {Value = Tcode},
                    new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                        {Value = "40"},
                    new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                        {Value = "确认"},
                    new SqlParameter("@sXmCode", SqlDbType.NVarChar,12)
                        {Value = sXmCode},
                    new SqlParameter("@lAllotType", SqlDbType.Int)
                        {Value = (BySelf == true ? 1 : 2)},
                    new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                        {Value = null , Direction = ParameterDirection.Output},
                    new SqlParameter("@proceReturn", SqlDbType.Int)
                        {Value = -1 , Direction = ParameterDirection.ReturnValue }
                };

                try
                {
                    SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
                }
                catch (Exception ex)
                {
                    return param[6].Value.ToString();
                }

                //分配子单
                if (BySelf == false && param[7].Value.ToString() != "-1")
                {
                    DataRow dr = ds.Tables[0].Rows[0];
                    spName = "p_Task_InsertTask";

                    param = new SqlParameter[] {
                        new SqlParameter("@lcode", dr["lcode"].ToString()),
                        new SqlParameter("@lFcode", Tcode),
                        new SqlParameter("@lType", dr["lType"].ToString()),
                        new SqlParameter("@sOuPersonCode", userID),
                        new SqlParameter("@sPersoncode", sOuPersonCode),
                        new SqlParameter("@dDemDate", dr["dDemDate"].ToString()),
                        new SqlParameter("@dPeoSDate", dr["dPeoSDate"].ToString()),
                        new SqlParameter("@lTotalHours", dr["lTotalHours"].ToString()),
                        new SqlParameter("@sRating", dr["sRating"].ToString()),
                        new SqlParameter("@sDepDemand", dr["sDepDemand"].ToString()),
                        new SqlParameter("@sXmName", dr["sXmName"].ToString()),
                        new SqlParameter("@sQuality", dr["sQuality"].ToString()),
                        new SqlParameter("@sCopyPeo", ""),
                        new SqlParameter("@sReturnStr", SqlDbType.NVarChar, 50)
                            {Value = -1 , Direction = ParameterDirection.Output}
                    };

                    try
                    {
                        SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
                        int subCode = Convert.ToInt32(param[13].Value.ToString());
                        return "1";
                    }
                    catch (Exception ex)
                    {
                        return "-1";
                    }
                }
                else
                {
                    return param[7].Value.ToString();
                }
            }
            else
            {
                return "-1";
            }
        }
        #endregion






        #region 获取实体对象
        /// <summary>
        /// 获取实体对象
        /// </summary>
        /// <param name="Code"></param>
        /// <returns></returns>
        public EnPeopleOrder getEntity(int Code)
        {
            List<EnPeopleOrder> list = new List<EnPeopleOrder>();
            string sqlStr = " select top 2 code, sXmName, sXMCode, lType, sMark, sState, sDepDemandTemp , ISNULL(lXMPercent,0) as lXMPercent, ";
            sqlStr += " dDemDate , dDate, sDepCode ,sPersonCode ,sMPeople ,sOuDepCode ,sOuPersonCode ,sOuPeople ,lFCode ";
            sqlStr += "from X5_WPeopleOrderView where code=@Code";


            SqlParameter[] arPara = new SqlParameter[1];
            arPara[0] = new SqlParameter("@Code", Code);

            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara).Tables[0];
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        EnPeopleOrder entity = new EnPeopleOrder
                        {
                            Code = Convert.ToInt32(dr["code"]),
                            DemDate = Convert.ToDateTime(dr["dDemDate"].ToString().Trim()),
                            DDate = Convert.ToDateTime(dr["dDate"].ToString().Trim()),
                            lXMPercent = Convert.ToDouble(dr["lXMPercent"].ToString()),
                            Mark = dr["sMark"].ToString(),
                            State = dr["sState"].ToString(),
                            XmName = dr["sXmName"].ToString(),
                            XmCode = dr["sXMCode"].ToString(),
                            LType = Convert.ToInt32(dr["lType"]),
                            DepDemandTemp = dr["sDepDemandTemp"].ToString(),
                            SInDepCode = dr["sDepCode"].ToString(),
                            SInPersoncode = dr["sPersonCode"].ToString(),
                            SMPeople = dr["sMPeople"].ToString(),
                            SOuDepCode = dr["sOuDepCode"].ToString(),
                            SOuPersonCode = dr["sOuPersonCode"].ToString(),
                            SOuPeople = dr["sOuPeople"].ToString(),
                            LFcode = dr["lFCode"].ToString().Equals("") ? 0 : Convert.ToInt32(dr["lFCode"].ToString())
                        };
                        return entity;
                    }
                }

            }
            catch (Exception ex) { }
            return null;
        }
        #endregion

        #region 单据终止
        /// <summary>
        /// 单据终止
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public string stopOrder(string userID, int OrderCode, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "99"},
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                    { Value = null},
                new SqlParameter("@sMemo", SqlDbType.VarChar,8000)
                    { Value = message.Trim().Equals("")?"任务终止":message.Trim()},
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar,20)
                    { Value = userID},
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null,Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1, Direction = ParameterDirection.ReturnValue}
            };

            string spName = "p_Task_TaskMsg";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[5].Value.ToString();
            }

            return param[6].Value.ToString();
        }
        #endregion

        #region 下单人返工操作
        /// <summary>
        /// 下单人返工操作
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public string ReworkOrder(string userID, int OrderCode, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "70"},
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                    { Value = null},
                new SqlParameter("@sMemo", SqlDbType.VarChar,8000)
                    { Value = message.Trim().Equals("")?"任务返工":message.Trim()},
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar,20)
                    { Value = userID},
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null,Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1, Direction = ParameterDirection.ReturnValue}
            };

            string spName = "p_Task_TaskMsg";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[5].Value.ToString();
            }

            return param[6].Value.ToString();
        }
        #endregion

        #region 接受返工
        /// <summary>
        /// 接受返工
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public string acceptRework(string userID, int OrderCode, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "80" },
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                    { Value = null},
                new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                    { Value = message.Trim().Equals("")?"接受返工":message.Trim() },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };
            string spName = "p_Task_TaskFeedback";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[5].Value.ToString();
            }
            return param[6].Value.ToString();
        }
        #endregion

        #region 接单人拒绝接单
        /// <summary>
        /// 接单人拒绝接单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="message"></param>
        /// <returns></returns>
        public string RejectOrder(string userID, int OrderCode, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "20" },
                new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                    { Value = message },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };
            string spName = "p_Task_TaskAffirm";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[4].Value.ToString();
            }
            return param[5].Value.ToString();
        }
        #endregion

        #region 下单人结单
        /// <summary>
        /// 下单人结单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        public string finishOrder(string userID, int OrderCode, string memo)
        {
            // 90.任务结单
            SqlParameter[] param = {
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "90"},
                new SqlParameter("@sMemo", SqlDbType.VarChar,8000)
                    { Value = memo.Trim().Equals("")?"结单":memo.Trim()},
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar,20)
                    { Value = userID},
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.NVarChar,8000)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };

            string spName = "p_Task_TaskMsg";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[4].Value.ToString();
            }

            return param[5].Value.ToString();
        }
        #endregion

        #region 接受暂停
        /// <summary>
        /// 接受暂停
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="memo"></param>
        /// <returns></returns>
        public string acceptPause(string userID, int OrderCode, string memo)
        {
            // 状态变成sMark==55, sState==null
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "55" },
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                    { Value = null },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue },
                new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                    { Value = memo.Trim().Equals("")?"接受暂停":memo.Trim() }
            };
            string spName = "p_Task_TaskMsg";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[4].Value.ToString();
            }
            return param[5].Value.ToString();
        }
        #endregion

        #region 拒绝暂停
        /// <summary>
        /// 拒绝暂停
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="memo"></param>
        /// <returns></returns>
        public string rejectPause(string userID, int OrderCode, string memo)
        {
            // sState==06005 

            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "50" },
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                    { Value = "06005" },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue },
                new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                    { Value = memo.Trim().Equals("")?"拒绝暂停":memo.Trim() }
            };

            string spName = "p_Task_TaskMsg";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[4].Value.ToString();
            }
            return param[5].Value.ToString();
        }
        #endregion

        #region 下单人接受延单
        /// <summary>
        /// 下单人接受延单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <param name="finishDate"></param>
        /// <param name="memo"></param>
        /// <returns></returns>
        public string acceptDelay(string userID, int OrderCode, DateTime finishDate, string memo)
        {
            //finishDate暂时没用
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@dDeferDate", SqlDbType.DateTime)
                    { Value = finishDate },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };
            string spName = "p_Task_AcceptDefer";

            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[3].Value.ToString();
            }
            return param[4].Value.ToString();
        }
        #endregion

        #region 下单人拒绝延单
        /// <summary>
        /// 下单人拒绝延单
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="OrderCode"></param>
        /// <returns></returns>
        public string rejectDelay(string userID, int OrderCode, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                     { Value = "50" },
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                     { Value = "06002" },
                new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                     { Value = message },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };

            string spName = "p_Task_TaskMsg";

            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[5].Value.ToString();
            }
            return param[6].Value.ToString();
        }
        #endregion

        #region 接单人申请暂停
        /// <summary>
        /// 接单人申请暂停
        /// </summary>
        /// <param name="userID">申请人ID</param>
        /// <param name="OrderCode">单据ID</param>
        /// <param name="message">意见内容</param>
        /// <returns></returns>
        public string applyPause(string userID, int OrderCode, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "50" },
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                    { Value = "06004" },
                new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                    { Value = message },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };

            string spName = "p_Task_TaskFeedback";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[5].Value.ToString();
            }
            return param[6].Value.ToString();
        }
        #endregion

        #region 申请延单
        /// <summary>
        /// 申请延单
        /// </summary>
        /// <param name="userID">申请用户ID</param>
        /// <param name="OrderCode">单据ID</param>
        /// <param name="finishDate">申请完成时间</param>
        /// <param name="message">意见内容</param>
        /// <returns></returns>
        public string applyDelay(string userID, int OrderCode, DateTime finishDate, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID },
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = OrderCode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12)
                    { Value = "50"},
                new SqlParameter("@sState", SqlDbType.NVarChar,12)
                    { Value = "06001"},
                new SqlParameter("@sMemo", SqlDbType.NVarChar,8000)
                    { Value = message},
                new SqlParameter("@dETime", SqlDbType.DateTime)
                    { Value = finishDate},
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };

            string spName = "p_Task_TaskFeedback";

            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[6].Value.ToString();
            }
            return param[7].Value.ToString();
        }
        #endregion

        #region 项目进度反馈完成
        /// <summary>
        /// 项目进度反馈完成
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="Tcode">单据ID</param>
        /// <returns></returns>
        public string taskFeedback(string userID, int Tcode, float XMPercent, string message)
        {
            SqlParameter[] param = {
                new SqlParameter("@sPersonCode", SqlDbType.NVarChar, 20)
                    { Value = userID},
                new SqlParameter("@lTcode", SqlDbType.Int)
                    { Value = Tcode },
                new SqlParameter("@sMark", SqlDbType.NVarChar,12),
                new SqlParameter("@sMemo", SqlDbType.VarChar,8000)
                    { Value = message },
                new SqlParameter("@lXMPercent", SqlDbType.Float)
                    { Value = XMPercent },
                new SqlParameter("@sReturnStr", SqlDbType.NVarChar,500)
                    { Value = null , Direction = ParameterDirection.Output},
                new SqlParameter("@proceReturn", SqlDbType.Int)
                    { Value = -1 , Direction = ParameterDirection.ReturnValue }
            };
            if (XMPercent == 100.0)
            {
                param[2].Value = "60";
            }
            else
            {
                param[2].Value = "50";
            }

            string spName = "p_Task_TaskFeedback";

            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, param);
            }
            catch (Exception ex)
            {
                return param[5].Value.ToString();
            }
            return param[6].Value.ToString();
        }
        #endregion        

        #region 获取我下的订单单据列表 getMyToDoList
        /// <summary>
        /// 获取我下的订单单据列表
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="xmNameFilter">项目名称（模糊匹配）</param>
        /// <param name="sMark">任务状态</param>
        /// <param name="whereStr">过滤条件</param>
        /// <returns></returns>
        /// 
        public List<EnPeopleOrder> getMyToDoList(string userID, string xmNameFilter, string sMark, string whereStr)
        {
            string tableName = "X5_WPeopleOrder";
            List<EnPeopleOrder> list = new List<EnPeopleOrder>();

            if (sMark == "90" || sMark == "99" || sMark == "20" || sMark.Trim() == "")
            {
                tableName = "X5_WPeopleOrderView";
            }

            string sqlStr = "";
            sqlStr += "select a.code, a.sXmName, a.sMark, a.sState, ISNULL(a.lXMPercent,0) as lXMPercent, a.dDemDate, a.dDate ";
            sqlStr += "from " + tableName + " as a, X5_ToDoTaskInfo as b ";
            sqlStr += "where a.code=b.lTaskCode and a.sInPersonCode=@sInPersonCode and a.dDate>='2011-01-01' ";


            if (sMark.Trim() != "" && sMark != "00")
            {
                sqlStr += "and a.sMark='" + sMark + "' ";
            }

            if (!xmNameFilter.Trim().Equals(""))
            {
                sqlStr += "and a.sXmName like '%" + xmNameFilter + "%' ";
            }

            if (whereStr.Trim() != "")
            {
                sqlStr += "and " + whereStr + " ";
            }

            sqlStr += "order by a.dDemDate, a.code desc ";

            SqlParameter[] arPara = new SqlParameter[1];
            arPara[0] = new SqlParameter("@sInPersonCode", userID);

            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara).Tables[0];
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        EnPeopleOrder entity = new EnPeopleOrder
                        {
                            Code = Convert.ToInt32(dr["code"]),
                            DemDate = Convert.ToDateTime(dr["dDemDate"].ToString().Trim()),
                            DDate = Convert.ToDateTime(dr["dDate"].ToString().Trim()),
                            lXMPercent = Convert.ToDouble(dr["lXMPercent"].ToString()),
                            Mark = dr["sMark"].ToString(),
                            State = (dr["sState"] == null) ? "" : dr["sState"].ToString(),
                            XmName = dr["sXmName"].ToString()
                        };
                        list.Add(entity);
                    }
                }

            }
            catch (Exception ex)
            {
                return null;
            }
            return list;
        }
        #endregion

        #region 获取完成或未完成的接单单据 getMyTaskList
        /// <summary>
        /// 获取完成或未完成的接单单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="xmNameFilter">项目名称过滤STR</param>
        /// <param name="sMark">任务状态</param>
        /// <param name="whereStr">过滤条件</param>
        /// <returns></returns>
        public List<EnPeopleOrder> getMyTaskList(string userID, string xmNameFilter, string sMark, string whereStr)
        {
            string tableName = "X5_WPeopleOrder";
            List<EnPeopleOrder> list = new List<EnPeopleOrder>();

            if (sMark == "90" || sMark == "99" || sMark == "20" || sMark.Trim() == "")
            {
                tableName = "X5_WPeopleOrderView";
            }

            string sqlStr = "";
            sqlStr += "select a.code, a.sXmName, a.sMark, a.sState, ISNULL(a.lXMPercent,0) as lXMPercent, a.dDemDate, a.dDate ";
            sqlStr += "from " + tableName + " as a, X5_ToDoTaskInfo as b ";
            sqlStr += "where a.code=b.lTaskCode and a.sOuPersonCode=@sOuPersonCode and a.dDate>='2011-01-01' ";

            if (sMark.Trim() != "" && sMark != "00")
            {
                sqlStr += "and a.sMark='" + sMark + "' ";
            }

            if (!xmNameFilter.Trim().Equals(""))
            {
                sqlStr += "and a.sXmName like '%" + xmNameFilter + "%' ";
            }

            if (whereStr.Trim() != "")
            {
                sqlStr += "and " + whereStr + " ";
            }

            sqlStr += "order by a.dDemDate, a.code desc ";

            SqlParameter[] arPara = new SqlParameter[1];
            arPara[0] = new SqlParameter("@sOuPersonCode", userID);

            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara).Tables[0];
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        EnPeopleOrder entity = new EnPeopleOrder
                        {
                            Code = Convert.ToInt32(dr["code"]),
                            DemDate = Convert.ToDateTime(dr["dDemDate"].ToString().Trim()),
                            DDate = Convert.ToDateTime(dr["dDate"].ToString().Trim()),
                            lXMPercent = Convert.ToDouble(dr["lXMPercent"].ToString()),
                            Mark = dr["sMark"].ToString(),
                            State = (dr["sState"] == null) ? "" : dr["sState"].ToString(),
                            XmName = dr["sXmName"].ToString()
                        };
                        list.Add(entity);
                    }
                }

            }
            catch (Exception ex)
            {
                return null;
            }
            return list;
        }
        #endregion

        #region 从数据库获取到三类数据，新增数据，修改数据和要删除的数据 getOrders
        /// <summary>
        /// 获取完成或未完成的接单单据
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <param name="dataType">数据类型,0为MyToDo,1为MyTask</param>
        /// <param name="codes">客户端发出的任务号串，用于比对更新项目</param>
        /// <param name="ldate">服务端最后更新的时间</param>
        /// <returns></returns>
        public EnPeopleOrders getOrders(string userID, int dataType, string codes, string wcodes, string lcode, string anchor)
        {
            // 任务状态(10.任务未确认, 20.任务拒绝, 30.任务待定, 40.接受任务,45.任务排单, 50.任务制作, 55.任务暂停,
            // 60.完成任务, 70.任务返工, 80.任务修改, 90.任务结单, 99.任务已终止)
            // 解析同步锚
            string[] an = (anchor ?? "").Split(new char[] { ',' });
            string ddatefrom = "", ddateto = "", singlecode = "";
            // 0表示刷新全部其他条件都不考虑
            if (!an[0].Equals("0") && an.Length > 1)
            {
                if (an[1] != null && !an[1].Equals("") && an[2] != null && !an[2].Equals(""))
                {
                    ddatefrom = an[1];
                    ddateto = an[2];
                }
                if (an[3] != null && !an[3].Equals(""))
                {
                    singlecode = an[3];
                    codes = singlecode;
                }
            }
            EnPeopleOrders data = new EnPeopleOrders();
            //data.LastSyncCode = lcode;
            //data.LastSyncDate = ldate;
            data.AddOrders = new List<EnPeopleOrder>();
            data.ComOrders = new List<EnPeopleOrder>();
            data.UpdateOrders = new List<EnPeopleOrder>();
            data.DeleteOrders = new List<EnPeopleOrder>();
            data.FeedBacks = new List<EnPeopleFeedback>();

            string tableName = "X5_WPeopleOrderView";
            string tableName2 = "X5_ToDoTaskInfo";
            string tableName3 = "X5_YPeopleFeedback";
            string tableName4 = "X5_WPeopleTask";
            string table_peopleorder = "X5_WPeopleOrder";

            // 需要新增的数据
            string sqlStr = "";
            sqlStr += " SELECT a.code, a.sXmName,a.sXMCode, a.lType, a.sMark, a.sState, ISNULL(a.lXMPercent,0) AS lXMPercent,a.dDate,a.dDemDate,a.dDemDate,";
            sqlStr += " a.sDepDemandTemp,a.sInDepCode,a.sInPersoncode,a.sInName,a.sOuDepCode,a.sOuPersonCode,a.sOuPeople,a.lFcode ";
            sqlStr += " FROM " + table_peopleorder + " a where (a.sInPersonCode= '" + userID + "' OR a.sOuPersonCode= '" + userID + "' ) ";
            if (!singlecode.Equals(""))
            {
                sqlStr += " AND  a.code = '" + singlecode + "' ";
            }

            sqlStr += " UNION ALL ";

            sqlStr += " SELECT a.code, a.sXmName,a.sXMCode, a.lType, a.sMark, a.sState, ISNULL(a.lXMPercent,0) AS lXMPercent,a.dDate,a.dDemDate,a.dEndDate,";
            sqlStr += " a.sDepDemandTemp,a.sInDepCode,a.sInPersoncode,a.sInName,a.sOuDepCode,a.sOuPersonCode,a.sOuPeople,a.lFcode ";
            sqlStr += " FROM " + tableName + " a ";
            sqlStr += " where ";
            if (codes != null && !codes.Equals(""))
            {
                sqlStr += " ( a.code in ( " + codes + " ) AND (a.sInPersonCode='" + userID + "' OR a.sOuPersonCode='" + userID + "') ) OR";
            }
            sqlStr += " ((a.sInPersonCode='" + userID + "' OR a.sOuPersonCode='" + userID + "') ";
            sqlStr += " AND (a.smark='90' ";
            if (ddatefrom.Equals("") && ddateto.Equals(""))
            {
                sqlStr += " AND a.dEndDate>= '" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-01' ";
                sqlStr += " OR a.sMark IN ('20','99') AND a.dDate>='" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-1')) ";
            }
            else
            {
                bool hasDayForddatefrom = Regex.IsMatch(ddatefrom, @"\d{4}\-\d{1,2}\-\d{1,2}") || string.IsNullOrEmpty(ddatefrom);
                bool hasDayForddateto = Regex.IsMatch(ddateto, @"\d{4}\-\d{1,2}\-\d{1,2}") || string.IsNullOrEmpty(ddatefrom);
                if (!hasDayForddatefrom)
                    ddatefrom += "-01";
                if (!hasDayForddateto)
                    ddateto += "-01";
                sqlStr += " AND (a.dEndDate>='" + ddatefrom + "' AND a.dEndDate< '" + ddateto + "' ) OR a.sMark IN ('20','99') ";
                sqlStr += " AND (a.dDate>='" + ddatefrom + "' AND a.dDate<'" + ddateto + "')))";
            }
            if (!singlecode.Equals(""))
            {
                sqlStr += " AND  a.code = '" + singlecode + "' ";
            }

            // 需要更新的反馈
            sqlStr += " SELECT lcode ,sMemo,sPersoncode,dFdate,dFTime,sFettle,sState FROM " + tableName3;
            sqlStr += " WHERE AutoCode IN ( ";
            sqlStr += " SELECT MAX(AutoCode) FROM X5_YPeopleFeedback WHERE ";
            if (codes != null && !codes.Equals(""))
            {
                sqlStr += " lcode IN (" + codes + ") GROUP BY lcode )";
            }
            else
            {
                sqlStr += " lcode IN (SELECT a.code FROM X5_WPeopleOrderView a, X5_ToDoTaskInfo b WHERE a.code=b.lTaskCode AND (a.sInPersonCode='" + userID + "' OR a.sOuPersonCode='" + userID + "'))  GROUP BY lcode )";
            }
            if (!singlecode.Equals(""))
            {
                sqlStr += " AND lcode = '" + singlecode + "' ";
            }

            if (codes != null && !codes.Equals(""))
            {
                //// 更新被确认的任务
                //sqlStr += " SELECT a.code, a.sXmName,a.sXMCode, a.lType, a.sMark, a.sState, ISNULL(a.lXMPercent,0) AS lXMPercent,a.dDate,a.dDemDate, ";
                //sqlStr += " a.sDepDemandTemp,a.sInDepCode,a.sInPersoncode,a.sInName,a.sOuDepCode,a.sOuPersonCode,a.sOuPeople,a.lFcode ";
                //sqlStr += " FROM " + tableName + " a," + tableName4 + " b ";
                //if (wcodes.Equals(""))
                //{
                //    sqlStr += " WHERE b.lcode in (0) AND a.code = b.lcode ";
                //}
                //else
                //{
                //    sqlStr += " WHERE b.lcode in (" + wcodes + ") AND a.code = b.lcode ";
                //}

                //// 需要更新的数据
                //sqlStr += "SELECT DISTINCT  a.code, a.sXmName,a.sXMCode, a.lType, a.sMark, a.sState, ISNULL(a.lXMPercent,0) AS lXMPercent,a.dDate,a.dDemDate,";
                //sqlStr += " cast(a.sDepDemandTemp AS NVARCHAR(max)) AS sDepDemandTemp, a.sInDepCode,a.sInPersoncode,a.sInName,a.sOuDepCode,a.sOuPersonCode,a.sOuPeople,a.lFcode ,b.dFdate";
                //sqlStr += " FROM " + tableName + " a join (select lcode,max(c.dfdate) as dfdate  from " + tableName3 + " c group by c.lcode) as b on a.code = b.lcode  ";
                //if (codes.Equals(""))
                //{
                //    sqlStr += " WHERE a.code IN (0) ";
                //}
                //else
                //{
                //    sqlStr += " WHERE a.code IN (" + codes + ") ";
                //}
                //sqlStr += " AND (a.sInPersonCode='" + userID + "' OR a.sOuPersonCode='" + userID + "') ";
                //if (ldate != null)
                //{
                //    DateTime date = (DateTime)ldate;
                //    sqlStr += " AND b.dFdate > '" + date.ToString("yyyy-MM-dd HH:mm:ss.fff", DateTimeFormatInfo.InvariantInfo) + "' ";
                //}
                //sqlStr += " ORDER BY  b.dFdate DESC ";
                // 需要删除的数据
                sqlStr += " SELECT DISTINCT a.code, a.sXmName,a.sXMCode, a.lType, a.sMark, a.sState, ISNULL(a.lXMPercent,0) AS lXMPercent,a.dDate,a.dDemDate,";
                sqlStr += " cast(a.sDepDemandTemp AS NVARCHAR(max)) AS sDepDemandTemp, a.sInDepCode,a.sInPersoncode,a.sInName,a.sOuDepCode,a.sOuPersonCode,a.sOuPeople,a.lFcode";
                sqlStr += " FROM " + tableName + " a ";
                if (codes == null || codes.Equals(""))
                {
                    sqlStr += " WHERE a.code IN (0) ";
                }
                else
                {
                    sqlStr += " WHERE a.code IN (" + codes + ") ";
                }
                sqlStr += " AND a.sOupersonCode <> '" + userID + "' AND a.sInpersonCode <> '" + userID + "' ";
                sqlStr += " AND (a.sMark NOT IN (90,99) ";
                sqlStr += "OR (a.sMark IN (90,99) ";
                bool hasDayForddatefrom = Regex.IsMatch(ddatefrom, @"\d{4}\-\d{1,2}\-\d{1,2}") || string.IsNullOrEmpty(ddatefrom);
               
                if (!hasDayForddatefrom)
                    ddatefrom += "-01";
                if (ddatefrom.Equals("") && ddateto.Equals(""))
                {
                    sqlStr += " AND a.dDate >= '" + DateTime.Now.Year + "-" + DateTime.Now.Month + "-1'))";
                }
                else
                {
                    sqlStr += " AND a.dDate >= '" + ddatefrom + "' AND a.dDate < '" + ddateto + "'))";
                }
                if (!singlecode.Equals(""))
                {
                    sqlStr += " AND a.code = '" + singlecode + "' ";
                }
            }
            DataSet ds = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, null);
            try
            {
                // 取得最后的日期作为标记
                DataTable dt = ds.Tables[0];
                //if (dt != null && dt.Rows.Count > 0)
                //{
                //    foreach (DataRow dr in dt.Rows)
                //    {
                //        data.LastSyncCode = Convert.ToString(dr["code"]);
                //        break;
                //    }
                //}
                putOrders(dt, data.AddOrders);
                // 取得用户的任务反馈信息
                dt = ds.Tables[1];
                putFeedBacks(dt, data.FeedBacks);
                if (ds.Tables.Count > 2)
                {
                    //// 取得被确认的任务
                    //dt = ds.Tables[2];
                    //putOrders(dt, data.ComOrders);
                    //// 取得最后被更新任务的时间戳
                    //dt = ds.Tables[3];
                    //if (dt != null && dt.Rows.Count > 0)
                    //{
                    //    foreach (DataRow dr in dt.Rows)
                    //    {
                    //        data.LastSyncDate = Convert.ToDateTime(dr["dFdate"]);
                    //        break;
                    //    }
                    //}
                    //putOrders(dt, data.UpdateOrders);
                    // 取得被删除的任务
                    dt = ds.Tables[2];
                    putOrders(dt, data.DeleteOrders);

                }
            }
            catch (Exception ex)
            {
                return null;
            }
            return data;
        }
        #endregion

        #region 把从数据库中获得的数据加入到对应的三类实体中
        /// <summary>
        /// 获取完成或未完成的接单单据
        /// </summary>
        /// <param name="dt">数据库表</param>
        /// <param name="list">要分装的数据列表</param>
        /// <returns></returns>
        public void putOrders(DataTable dt, List<EnPeopleOrder> list)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    EnPeopleOrder entity = new EnPeopleOrder
                    {
                        Code = Convert.ToInt32(dr["code"]),
                        XmName = dr["sXmName"].ToString(),
                        XmCode = dr["sXMCode"].ToString(),
                        LType = Convert.ToInt32(dr["lType"]),
                        Mark = dr["sMark"].ToString(),
                        State = (dr["sState"] == null) ? "" : dr["sState"].ToString(),
                        lXMPercent = Convert.ToDouble(dr["lXMPercent"].ToString()),
                        DemDate = Convert.ToDateTime(dr["dDemDate"].ToString().Trim()),
                        DDate = Convert.ToDateTime(dr["dDate"].ToString().Trim()),
                        DepDemandTemp = dr["sDepDemandTemp"].ToString(),
                        SInDepCode = dr["sInDepCode"].ToString(),
                        SInPersoncode = dr["sInPersoncode"].ToString(),
                        SMPeople = dr["sInName"].ToString(),
                        SOuDepCode = dr["sOuDepCode"].ToString(),
                        SOuPersonCode = dr["sOuPersonCode"].ToString(),
                        SOuPeople = dr["sOuPeople"].ToString(),
                        LFcode = dr["lFCode"].ToString().Equals("") ? 0 : Convert.ToInt32(dr["lFCode"].ToString())
                    };
                    list.Add(entity);
                }
            }
        }
        #endregion

        #region 把从数据库中获得的任务反馈存入列表
        /// <summary>
        /// 把从数据库中获得的任务反馈存入列表
        /// </summary>
        /// <param name="dt">数据库表</param>
        /// <param name="list">要分装的数据列表</param>
        /// <returns></returns>
        public void putFeedBacks(DataTable dt, List<EnPeopleFeedback> list)
        {
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    string dFTime = dr["dFTime"].ToString().Trim();
                    EnPeopleFeedback entity = new EnPeopleFeedback
                    {
                        Lcode = Convert.ToInt32(dr["lcode"]),
                        SMemo = dr["sMemo"].ToString(),
                        DFdate = Convert.ToDateTime(dr["dFdate"].ToString().Trim()),
                        DFTime = string.IsNullOrEmpty(dFTime) ? null : (DateTime?)Convert.ToDateTime(dFTime)
                    };
                    list.Add(entity);
                }
            }
        }
        #endregion


        #region 下单方-->编辑订单
        /// <summary>
        /// 下单方-->编辑订单
        /// </summary>
        /// <param name="orderCode">订单编号</param>
        /// <param name="editTitle">是否编辑标题</param>
        /// <param name="title"></param>
        /// <param name="editMessage">是否编辑消息</param>
        /// <param name="message"></param>
        /// <param name="editFinishDate">是否编辑完成日期</param>
        /// <param name="finish"></param>
        /// <param name="editOuPeople">是否编辑接单人</param>
        /// <param name="peopleCode"></param>
        /// <returns></returns>
        public string editOrder(int orderCode, string userID, bool editTitle, string title, bool editMessage, string message, bool editFinishDate, DateTime? finish, bool editOuPeople, string peopleCode)
        {
            if (false == editOuPeople && false == editTitle && false == editFinishDate && false == editMessage)
            {
                return "什么都没修改";
            }

            List<SqlParameter> param = new List<SqlParameter>();
            param.Add(new SqlParameter("@lTcode", SqlDbType.Int) { Value = orderCode });
            param.Add(new SqlParameter("@sUserID", SqlDbType.NVarChar, 20) { Value = userID });

            if (editOuPeople == true)
            {
                param.Add(new SqlParameter("@sOuPersonCode", SqlDbType.NVarChar, 20) { Value = peopleCode });
            }

            if (editTitle == true)
            {
                param.Add(new SqlParameter("@sXmName", SqlDbType.NVarChar, 100) { Value = title });
            }

            if (editMessage == true)
            {
                param.Add(new SqlParameter("@sDepDemandModify", SqlDbType.Text) { Value = message });
            }

            if (editFinishDate == true)
            {
                param.Add(new SqlParameter("@dDemDate", SqlDbType.DateTime) { Value = finish });
            }

            param.Add(new SqlParameter("@sReturnStr", SqlDbType.NVarChar, 500) { Value = "", Direction = ParameterDirection.Output });
            param.Add(new SqlParameter("@proceReturn", SqlDbType.Int) { Value = -1, Direction = ParameterDirection.ReturnValue });

            SqlParameter[] paramArr = param.ToArray();

            string spName = "p_Task_ModifyTask";
            try
            {
                SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.StoredProcedure, spName, paramArr);
            }
            catch (Exception ex)
            {
                return paramArr[paramArr.Length - 2].Value.ToString();
            }
            return paramArr[paramArr.Length - 1].Value.ToString() + "," + paramArr[paramArr.Length - 2].Value.ToString();
        }
        #endregion
    }
}
