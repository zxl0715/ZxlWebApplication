﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using ToDoService.Entity;
using ND.Lib.Data.SqlHelper;
using System.Data;

namespace ToDoService.DataAccess
{
    public class DaFeedback
    {
        private static string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;

        public bool AddFeedback(List<EnFeedback> feedbacks)
        {
            bool result = false;
            String sql = "";
            foreach (EnFeedback item in feedbacks)
            {
                String sUserID = item.SUserID;
                String dDate = item.DDate.ToString();
                String sVersion = item.SVersion;
                String Memo = item.Memo;
                sql += " INSERT INTO dbo.TM_Feedback (sUserID ,dDate , sVersion , Memo ) ";
                sql += " VALUES ( '" + sUserID + "','" + dDate + "','" + sVersion + "','" + Memo + "') ";
            }
            if (sql.Trim() != "")
            {
                int i = 0;
                try
                {
                    i = SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.Text, sql);
                    if (i == feedbacks.Count)
                    {
                        result = true;
                    }
                }
                catch (Exception)
                {
                    result = false;
                    throw;
                }

            }
            return result;
        }
    }
}
