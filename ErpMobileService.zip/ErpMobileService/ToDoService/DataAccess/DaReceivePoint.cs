﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Base;
using ToDoService.Entity;
using System.Data.SqlClient;
using System.Data;
using ND.Lib.Data.SqlHelper;

namespace ToDoService.DataAccess
{
    /// <summary>
    /// 积分领取系统
    /// </summary>
    public class DaReceivePoint
    {
        #region 获取积分领取列表
        /// <summary>
        /// 获取积分领取列表
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public List<EnReceivePoint> getReceivePointList(string userID)
        {
            string strSql = "select AutoCode, sContent, lPoint, bAdd from X3_tPoints where sPersonCode=@userID and (isnull(bAdd,0)=0 or (bAdd=1 and Convert(char(10),dAddTime,120)=@date)) order by AutoCode desc; ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@date", DateTime.Today.ToString("yyyy-MM-dd"))
            };

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, arPara);
                IList<EnReceivePoint> list = DynamicBuilder<EnReceivePoint>.ConvertToList(dr);

                if (list != null && list.Count > 0)
                    return new List<EnReceivePoint>(list);
                else
                    return null;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

        #region 积分领取
        /// <summary>
        /// 积分领取
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="auto">编号</param>
        /// <returns>1：成功 0：失败</returns>
        public EnSign receivePoint(string userID, int auto)
        {
            //返回结果实体
            EnSign result = new EnSign();

            //存储过程参数
            int signInState = -1;

            //执行签到存储过程
            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID),
                new SqlParameter("@auto", auto),
                new SqlParameter("@signInState", SqlDbType.Int),
                new SqlParameter("@lotNum", SqlDbType.Int)

            };

            arPara[2].Direction = ParameterDirection.Output;
            arPara[3].Direction = ParameterDirection.Output;
            string spName = "Grow_ReceivePoint";

            try
            {
                SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.StoredProcedure, spName, arPara);

                //执行成功
                if (arPara[2].Value != null)
                {
                    signInState = Convert.ToInt32(arPara[2].Value);

                    result.Gifts = 0;
                    result.code = signInState.ToString();

                    if (arPara[3].Value.ToString() != "")
                        result.Lot = Convert.ToInt32(arPara[3].Value);
                    else
                        result.Lot = 0;

                    //调整积分系统
                    StringBuilder strSql = new StringBuilder("Execute X3_updatePoint @userID;");

                    arPara = new SqlParameter[] {
                        new SqlParameter("@userID", userID)
                    };

                    SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql.ToString(), arPara);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }

            return result;
        }
        #endregion
    }
}
