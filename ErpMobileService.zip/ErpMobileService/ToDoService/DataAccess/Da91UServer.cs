﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Net;
using System.Text;
using System.Net.Http;
using ToDoService.Entity._91U;
using Nd.Erp.Mobile.Base;
using SysCommonLibrary.Entity;

namespace ToDoService.DataAccess
{
    public class Da91UServer
    {
        /// <summary>
        /// 礼物接口
        /// </summary>
        private string Gifts_Url = "http://nd.dwb.apps.91.com/api.php";
        private string Gifts_AppKey = "1d1b58dee2b978ffb2e6d4b3d6956fe7";
        private string Gifts_AppSecret = "f0c7eb10e854b3c8ef940f3a4d6ab9a1";

        /// <summary>
        /// 91U服务端
        /// </summary>
        private string U_Url = "http://oapnd.91.com/";
        private string U_Url_Test = "http://192.168.94.21/oap21/";
        private string U_AppID = "15";
        private string U_APPKey = "IjklOPE2WV8ucEJCibXH0uZ3TdV7eOtFfYFnwb1w";

        /// <summary>
        /// 艺术展服务端
        /// </summary>
        private string Art_Url = "http://121.207.250.157:8006";
        private string Art_Url_Test = "http://192.168.19.185:8006";

        public static string Art_Detail_Url = "http://121.207.250.157:8006/static/html/mobi_main.html?sid=@sid&category=@category";
        public static string Art_Detail_Url_Test = "http://192.168.19.185:8006/static/html/mobi_main.html?sid=@sid&category=@category";


        #region 获取别人送给用户的鲜花数
        /// <summary>
        /// 获取别人送给用户的鲜花数
        /// </summary>
        /// <param name="sid">sid</param>
        /// <param name="uid">uid</param>
        public int getGiftNum(string sid, string uid)
        {
            EnGetGiftNum response = null;
            HttpClient client = new HttpClient();

            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("mod", "alumnus_info"));
            postData.Add(new KeyValuePair<string, string>("code", "secondinfo"));
            postData.Add(new KeyValuePair<string, string>("client_interf_json", "{}"));
            postData.Add(new KeyValuePair<string, string>("client_interf_sid", sid));
            postData.Add(new KeyValuePair<string, string>("client_interf_uid", uid));
            postData.Add(new KeyValuePair<string, string>("client_interf_app_key", Gifts_AppKey));
            postData.Add(new KeyValuePair<string, string>("client_interf_app_secret", Gifts_AppSecret));
            postData.Add(new KeyValuePair<string, string>("client_interf_output", "json"));

            HttpContent content = new FormUrlEncodedContent(postData);
            client.PostAsync(Gifts_Url, content).ContinueWith(
            runResult =>
            {
                if (runResult.Result.StatusCode == HttpStatusCode.OK)
                {
                    response = runResult.Result.Content.ReadAsStringAsync().Result.DeserializeJSON<EnGetGiftNum>();
                }
            }).Wait();

            if (response != null)
            {
                string count = response.result.f_flower_count;
                count = (count == "" ? "0" : count);
                return Convert.ToInt32(count);
            }
            else
                return 0;
        }
        #endregion

        #region 添加礼物
        /// <summary>
        /// 添加礼物
        /// </summary>
        /// <param name="sid">sid</param>
        /// <param name="uid">uid</param>
        /// <returns></returns>
        public bool addGift(string sid, string uid)
        {
            EnAddGift response = null;
            HttpClient client = new HttpClient();

            var postData = new List<KeyValuePair<string, string>>();
            postData.Add(new KeyValuePair<string, string>("mod", "alumnus_money"));
            postData.Add(new KeyValuePair<string, string>("code", "sign"));
            postData.Add(new KeyValuePair<string, string>("client_interf_json", "{}"));
            postData.Add(new KeyValuePair<string, string>("client_interf_sid", sid));
            postData.Add(new KeyValuePair<string, string>("client_interf_uid", uid));
            postData.Add(new KeyValuePair<string, string>("client_interf_app_key", Gifts_AppKey));
            postData.Add(new KeyValuePair<string, string>("client_interf_app_secret", Gifts_AppSecret));
            postData.Add(new KeyValuePair<string, string>("client_interf_output", "json"));

            HttpContent content = new FormUrlEncodedContent(postData);
            client.PostAsync(Gifts_Url, content).ContinueWith(
            runResult =>
            {
                if (runResult.Result.StatusCode == HttpStatusCode.OK)
                {
                    response = runResult.Result.Content.ReadAsStringAsync().Result.DeserializeJSON<EnAddGift>();
                }
            }).Wait();

            if (response != null)
            {
                string count = response.result.addcoin;
                count = (count == "" ? "0" : count);
                return (Convert.ToInt32(count) > 0 ? true : false);
            }
            else
                return false;
        }
        #endregion

        #region 添加抽奖次数
        /// <summary>
        /// 添加抽奖次数
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="num">次数</param>
        /// <returns></returns>
        public bool addLot(string userID, string num)
        {
            bool result = false;
            EnAddLot response = null;
            HttpClient client = new HttpClient();
            client.DefaultRequestHeaders.Add("APPINFO", "id=" + U_AppID + ",key=" + U_APPKey);

            client.PostAsJsonAsync(U_Url + "lottery/addcount", new { uid = userID, count = num }).ContinueWith(
            runResult =>
            {
                if (runResult.Result.StatusCode == HttpStatusCode.OK)
                {
                    result = true;
                    response = runResult.Result.Content.ReadAsStringAsync().Result.DeserializeJSON<EnAddLot>();
                }
            }).Wait();

            return result;
        }
        #endregion

        #region 获取网龙币和抽奖次数
        /// <summary>
        /// 获取网龙币和抽奖次数
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public int getLotNum(string userID)
        {
            EnGetLotNum response = null;
            HttpClient client = new HttpClient();

            client.GetAsync(U_Url + "lottery/userinfo?uid=" + userID).ContinueWith(
            runResult =>
            {
                if (runResult.Result.StatusCode == HttpStatusCode.OK)
                {
                    response = runResult.Result.Content.ReadAsStringAsync().Result.DeserializeJSON<EnGetLotNum>();
                }
            }).Wait();

            if (response != null)
                return response.free_count;
            else
                return 0;
        }
        #endregion

        #region 是否已经91狂欢签到
        /// <summary>
        /// 是否已经91狂欢签到
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns></returns>
        public int is91Checkin(string userID)
        {
            EnIs91Checkin response = null;
            HttpClient client = new HttpClient();

            client.GetAsync(U_Url + "user/ischeckin?uid=" + userID).ContinueWith(
            runResult =>
            {
                if (runResult.Result.StatusCode == HttpStatusCode.OK)
                {
                    response = runResult.Result.Content.ReadAsStringAsync().Result.DeserializeJSON<EnIs91Checkin>();
                }
            }).Wait();

            if (response != null)
                return response.ischeckin;
            else
                return 0;
        }
        #endregion

        #region 获取艺术展任务列表
        /// <summary>
        /// 获取艺术展任务列表
        /// </summary>
        /// <param name="sid">sid</param>
        public EnGetArtTaskList getArtTaskList(string sid)
        {
            EnGetArtTaskList response = null;
            HttpClient client = new HttpClient();

            client.GetAsync(Art_Url + "/internal/exhibits/tasks?sid=" + sid).ContinueWith(
            runResult =>
            {
                if (runResult.Result.StatusCode == HttpStatusCode.OK)
                {
                    response = runResult.Result.Content.ReadAsStringAsync().Result.DeserializeJSON<EnGetArtTaskList>();
                }
            }).Wait();

            return response;
        }
        #endregion
    }
}
