﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 增加抽奖次数
    /// </summary>
    public class EnAddLot : EnResponse
    {
        public string msg { get; set; }
    }
}
