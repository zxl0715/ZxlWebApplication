﻿using System;

namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 获取礼物数
    /// </summary>
    public class EnGetGiftNum : EnResponse
    {
        public EnGetGiftNum_Result result { get; set; }
    }

    public class EnGetGiftNum_Result
    {
        public string f_flower_count { get; set; }

        public string issign { get; set; }

        public string fans_count { get; set; }

        public string follow_count { get; set; }

        public string following { get; set; }

        public string follow_by { get; set; }

        public string sinauid { get; set; }

        public string nickname { get; set; }

        public string t_flower_count { get; set; }
    }
}
