﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 获取网龙币和抽奖次数
    /// </summary>
    public class EnGetLotNum : EnResponse
    {
        public int nd_money { get; set; }

        public int free_count { get; set; }
    }
}
