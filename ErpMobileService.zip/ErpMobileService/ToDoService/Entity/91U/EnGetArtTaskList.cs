﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 艺术展任务列表
    /// </summary>
    public class EnGetArtTaskList : EnResponse
    {
        public List<EnGetArtTask> rows { get; set; }
    }
}
