﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 获取是否已经91狂欢签到
    /// </summary>
    public class EnIs91Checkin : EnResponse
    {
        public int ischeckin { get; set; }
    }
}
