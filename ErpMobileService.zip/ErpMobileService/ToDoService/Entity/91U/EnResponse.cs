﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 91U服务端接口实体
    /// </summary>
    public class EnResponse
    {
        /// <summary>
        /// 响应代码
        /// </summary>
        public string code { get; set; }

        /// <summary>
        /// 响应内容字符串
        /// </summary>
        public string resultStr { get; set; }
    }
}
