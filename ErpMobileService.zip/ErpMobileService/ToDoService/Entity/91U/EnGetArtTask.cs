﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 艺术展任务
    /// </summary>
    public class EnGetArtTask
    {
        public int categoryId { get; set; }

        public string category { get; set; }

        public int points { get; set; }

        public string percent { get; set; }

        public string dueDate { get; set; }
    }
}
