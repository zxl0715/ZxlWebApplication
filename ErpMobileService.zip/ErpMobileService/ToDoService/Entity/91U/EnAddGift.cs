﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoService.Entity._91U
{
    /// <summary>
    /// 得到礼物
    /// </summary>
    public class EnAddGift : EnResponse
    {
        public EnAddGift_Result result { get; set; }
    }

    public class EnAddGift_Result
    {
        public string alumnus_coin { get; set; }

        public string addcoin { get; set; }
    }
}
