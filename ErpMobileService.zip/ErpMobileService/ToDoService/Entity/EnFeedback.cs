﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    /// <summary>
    /// 用户意见及问题反馈表
    /// </summary>
    [DataContract]
    public class EnFeedback
    {
        private long m_AutoCode;
        private string m_sUserID;
        private DateTime? m_dDate;
        private string m_sVersion;
        private string m_Memo;

        /// <summary>
        /// 自动编号
        /// </summary>
        public long AutoCode
        {
            get { return m_AutoCode; }
            set { m_AutoCode = value; }
        }

        /// <summary>
        /// 用户ID
        /// </summary>
        [DataMember]
        public string SUserID
        {
            get { return m_sUserID; }
            set { m_sUserID = value; }
        }

        /// <summary>
        /// 反馈时间
        /// </summary>
        [DataMember]
        public DateTime? DDate
        {
            get { return m_dDate; }
            set { m_dDate = value; }
        }

        /// <summary>
        /// 版本号
        /// </summary>
        [DataMember]
        public string SVersion
        {
            get { return m_sVersion; }
            set { m_sVersion = value; }
        }

        /// <summary>
        /// 内容描述
        /// </summary>
        [DataMember]
        public string Memo
        {
            get { return m_Memo; }
            set { m_Memo = value; }
        }
    }
}
