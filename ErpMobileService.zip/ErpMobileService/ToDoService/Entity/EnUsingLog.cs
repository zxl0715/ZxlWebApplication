﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    /// <summary>
    /// 用户使用记录
    /// </summary>
    [DataContract]
    public class EnUsingLog
    {
        private int m_AutoCode;
        private string m_sUserID;
        private DateTime? m_dDate;
        private int m_lType;
        private string m_sVersion;
        private string m_sSDK;
        private string m_Memo;

        /// <summary>
        /// 自动编号
        /// </summary>
        public int AutoCode
        {
            get { return m_AutoCode; }
            set { m_AutoCode = value; }
        }

        /// <summary>
        /// 用户ID
        /// </summary>
        [DataMember]
        public string SUserID
        {
            get { return m_sUserID; }
            set { m_sUserID = value; }
        }

        /// <summary>
        /// 时间
        /// </summary>
        [DataMember]
        public DateTime? DDate
        {
            get { return m_dDate; }
            set { m_dDate = value; }
        }

        /// <summary>
        /// 类型  1：登录  2：更新
        /// </summary>
        [DataMember]
        public int LType
        {
            get { return m_lType; }
            set { m_lType = value; }
        }

        /// <summary>
        /// 版本号
        /// </summary>
        [DataMember]
        public string SVersion
        {
            get { return m_sVersion; }
            set { m_sVersion = value; }
        }
      
        /// <summary>
        /// 手机固件版本
        /// </summary>
        [DataMember]
        public string SSDK
        {
            get { return m_sSDK; }
            set {m_sSDK = value;}
        }


        /// <summary>
        /// 备注
        /// </summary>
        [DataMember]
        public string Memo
        {
            get { return m_Memo; }
            set { m_Memo = value; }
        }
    }
}
