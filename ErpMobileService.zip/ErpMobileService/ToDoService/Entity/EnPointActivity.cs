﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ToDoService.Entity
{
    /// <summary>
    /// 积分活动
    /// </summary>
    public class EnPointActivity
    {
        /// <summary>
        /// 活动编号
        /// </summary>
        public int Auto { get; set; }

        /// <summary>
        /// 默认排序
        /// </summary>
        public int Order { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        public string Title { get; set; }

        /// <summary>
        /// 类型
        /// 1：普通跳转 2：嵌Web的跳转
        /// </summary>
        public int Type { get; set; }

        /// <summary>
        /// Web链接
        /// </summary>
        public string Link { get; set; }

        /// <summary>
        /// 补充内容
        /// </summary>
        public string Content { get; set; }

        /// <summary>
        /// 状态
        /// 0：未完成（领取）   1：待开放   2：已完成（领取）   3：截止
        /// </summary>
        public int State { get; set; }

        /// <summary>
        /// 是否新活动
        /// 0：否 1：是
        /// </summary>
        public int IsNew { get; set; }

        /// <summary>
        /// 完成（领取）时间
        /// </summary>
        public DateTime? FinishTime { get; set; }
    }
}
