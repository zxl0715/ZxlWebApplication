﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    #region 数据类型
    public enum ToDoListType
    {
        /// <summary>任务 </summary>
        Order = 1,
        /// <summary>SOP </summary>
        SOP = 2,
        /// <summary>会议 </summary>
        Meeting = 3,
    }
    #endregion



    [DataContract]
    public class EnToDoListItem
    {
        /// <summary>
        /// 编号
        /// </summary>
        [DataMember]
        public string Code { get; set; }

        /// <summary>
        /// 发送者
        /// </summary>
        [DataMember]
        public string UserID { get; set; }

        /// <summary>
        /// 类型
        /// </summary>
        [DataMember]
        public int Type { get; set; }

        /// <summary>
        /// 名称
        /// </summary>
        [DataMember]
        public string Title { get; set; }

        /// <summary>
        /// 状态
        /// </summary>
        [DataMember]
        public string Mark { get; set; }

        /// <summary>
        /// 任务类型
        /// </summary>
        [DataMember]
        public string OrderType { get; set; }

        /// <summary>
        /// 接单人工号
        /// </summary>
        [DataMember]
        public string OuPersonCode { get; set; }

        /// <summary>
        /// 转单/下单人工号
        /// </summary>
        [DataMember]
        public string InPersonCode { get; set; }

        /// <summary>
        /// 开始时间
        /// </summary>
        [DataMember]
        public DateTime? BeginTime { get; set; }

        /// <summary>
        /// 结束时间
        /// </summary>
        [DataMember]
        public DateTime? EndTime { get; set; }
    }
}
