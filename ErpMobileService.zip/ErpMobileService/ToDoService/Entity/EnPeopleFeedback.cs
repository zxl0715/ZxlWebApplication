﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    [DataContract]
    public class EnPeopleFeedback
    {
        public EnPeopleFeedback() { }

        private String m_sCode;
        [DataMember]
        public String SCode
        {
            get { return m_sCode; }
            set { m_sCode = value; }
        }

        private int m_AutoCode;
        [DataMember]
        public int AutoCode
        {
            get { return m_AutoCode; }
            set { m_AutoCode = value; }
        }

        private int m_lcode;
        [DataMember]
        public int Lcode
        {
            get { return m_lcode; }
            set { m_lcode = value; }
        }

        private String m_sOrderCode;
        [DataMember]
        public String SOrderCode
        {
            get { return m_sOrderCode; }
            set { m_sOrderCode = value; }
        }

        private DateTime? m_dSTime;
        [DataMember]
        public DateTime? DSTime
        {
            get { return m_dSTime; }
            set { m_dSTime = value; }
        }

        private DateTime? m_dFTime;
        [DataMember]
        public DateTime? DFTime
        {
            get { return m_dFTime; }
            set { m_dFTime = value; }
        }

        private double m_lXMPercent;
        [DataMember]
        public double LXMPercent
        {
            get { return m_lXMPercent; }
            set { m_lXMPercent = value; }
        }

        private String m_sMemo;
        [DataMember]
        public String SMemo
        {
            get { return m_sMemo; }
            set { m_sMemo = value; }
        }

        private String m_sMpeople;
        [DataMember]
        public String SMpeople
        {
            get { return m_sMpeople; }
            set { m_sMpeople = value; }
        }

        private String m_sPersoncode;
        [DataMember]
        public String SPersoncode
        {
            get { return m_sPersoncode; }
            set { m_sPersoncode = value; }
        }

        private int m_lType;
        [DataMember]
        public int LType
        {
            get { return m_lType; }
            set { m_lType = value; }
        }

        private DateTime? m_dFdate;
        [DataMember]
        public DateTime? DFdate
        {
            get { return m_dFdate; }
            set { m_dFdate = value; }
        }

        private DateTime? m_dgDate;
        [DataMember]
        public DateTime? DgDate
        {
            get { return m_dgDate; }
            set { m_dgDate = value; }
        }

        private double m_lTaskPoint;
        [DataMember]
        public double LTaskPoint
        {
            get { return m_lTaskPoint; }
            set { m_lTaskPoint = value; }
        }

        private double m_lsubjoinPoint;
        public double LsubjoinPoint
        {
            get { return m_lsubjoinPoint; }
            set { m_lsubjoinPoint = value; }
        }

        private String m_sFettle;
        [DataMember]
        public String SFettle
        {
            get { return m_sFettle; }
            set { m_sFettle = value; }
        }

        private String m_sState;
        [DataMember]
        public String SState
        {
            get { return m_sState; }
            set { m_sState = value; }
        }

        private String m_sHfettle;
        [DataMember]
        public String SHfettle
        {
            get { return m_sHfettle; }
            set { m_sHfettle = value; }
        }

        private int m_lCheckType;
        [DataMember]
        public int LCheckType
        {
            get { return m_lCheckType; }
            set { m_lCheckType = value; }
        }

        private int m_lLast;
        [DataMember]
        public int LLast
        {
            get { return m_lLast; }
            set { m_lLast = value; }
        }

        private String m_sUrl;
        [DataMember]
        public String SUrl
        {
            get { return m_sUrl; }
            set { m_sUrl = value; }
        }

        private String m_sUrlTemp;
        [DataMember]
        public String SUrlTemp
        {
            get { return m_sUrlTemp; }
            set { m_sUrlTemp = value; }
        }

        private double m_lSubjoinHours;
        [DataMember]
        public double LSubjoinHours
        {
            get { return m_lSubjoinHours; }
            set { m_lSubjoinHours = value; }
        }

        private int m_bAffirm;
        [DataMember]
        public int BAffirm
        {
            get { return m_bAffirm; }
            set { m_bAffirm = value; }
        }

    }
}
