﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    /// <summary>
    /// 任务单实体类
    /// </summary>
    [DataContract]
    public class EnPeopleOrder
    {
        private int m_Code;
        private String m_XmName;
        private String m_XmCode;
        private int m_lType;
        private String m_Mark;
        private String m_State;
        private double m_lXMPercent;
        private DateTime m_DemDate;
        private DateTime m_DDate;
        private String m_DepDemandTemp = "";

        private String m_sInDepCode;// 下单人部门
        private String m_sInPersoncode;// 下单人工号
        private String m_sMPeople;// 下单人姓名
        private String m_sOuDepCode;// 接单人部门号
        private String m_sOuPersonCode;// 接单人工号
        private String m_sOuPeople;// 接单人姓名
        private int m_lFcode;

        [DataMember]
        public int LFcode
        {
            get { return m_lFcode; }
            set { m_lFcode = value; }
        }

        [DataMember]
        public String SInDepCode
        {
            get { return m_sInDepCode; }
            set { m_sInDepCode = value; }
        }

        [DataMember]
        public String SInPersoncode
        {
            get { return m_sInPersoncode; }
            set { m_sInPersoncode = value; }
        }

        [DataMember]
        public String SMPeople
        {
            get { return m_sMPeople; }
            set { m_sMPeople = value; }
        }

        [DataMember]
        public String SOuDepCode
        {
            get { return m_sOuDepCode; }
            set { m_sOuDepCode = value; }
        }

        [DataMember]
        public String SOuPersonCode
        {
            get { return m_sOuPersonCode; }
            set { m_sOuPersonCode = value; }
        }

        [DataMember]
        public String SOuPeople
        {
            get { return m_sOuPeople; }
            set { m_sOuPeople = value; }
        }

        [DataMember]
        public String DepDemandTemp
        {
            get { return m_DepDemandTemp; }
            set { m_DepDemandTemp = value; }
        }

        [DataMember]
        public int Code
        {
            get { return m_Code; }
            set { m_Code = value; }
        }

        [DataMember]
        public String XmName
        {
            get { return m_XmName; }
            set { m_XmName = value; }
        }

        [DataMember]
        public String XmCode
        {
            get { return m_XmCode; }
            set { m_XmCode = value; }
        }

        [DataMember]
        public int LType
        {
            get { return m_lType; }
            set { m_lType = value; }
        }

        [DataMember]
        public String Mark
        {
            get { return m_Mark; }
            set { m_Mark = value; }
        }

        [DataMember]
        public String State
        {
            get { return m_State; }
            set { m_State = value; }
        }

        [DataMember]
        public double lXMPercent
        {
            get { return m_lXMPercent; }
            set { m_lXMPercent = value; }
        }

        [DataMember]
        public DateTime DemDate
        {
            get { return m_DemDate; }
            set { m_DemDate = value; }
        }

        [DataMember]
        public DateTime DDate
        {
            get { return m_DDate; }
            set { m_DDate = value; }
        }
    }
}
