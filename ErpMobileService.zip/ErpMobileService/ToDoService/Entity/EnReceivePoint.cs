﻿using System;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    /// <summary>
    /// 积分领取项
    /// </summary>
    [DataContract]
    public class EnReceivePoint
    {
        /// <summary>
        /// 编号
        /// </summary>
        [DataMember]
        public int AutoCode { get; set; }

        /// <summary>
        /// 标题
        /// </summary>
        [DataMember]
        public string sContent { get; set; }

        /// <summary>
        /// 积分数
        /// </summary>
        [DataMember]
        public int lPoint { get; set; }

        /// <summary>
        /// 是否已领取
        /// </summary>
        [DataMember]
        public int bAdd { get; set; }
    }
}
