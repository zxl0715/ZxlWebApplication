﻿using System;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    /// <summary>
    /// 成长数据
    /// </summary>
    [DataContract]
    public class EnGrowUp
    {
        /// <summary>
        /// 工号
        /// </summary>
        [DataMember]
        public string UserID { get; set; }

        /// <summary>
        /// 姓别
        /// F:女 M:男
        /// </summary>
        [DataMember]
        public string Sex { get; set; }

        /// <summary>
        /// 入司日期
        /// </summary>
        [DataMember]
        public string JoinDay { get; set; }

        /// <summary>
        /// 生日
        /// </summary>
        [DataMember]
        public string Birthday { get; set; }

        /// <summary>
        /// 游戏星级
        /// </summary>
        [DataMember]
        public int GameStar { get; set; }

        /// <summary>
        /// 等级
        /// </summary>
        [DataMember]
        public int Grade { get; set; }

        /// <summary>
        /// 荣誉积分
        /// </summary>
        [DataMember]
        public int JiFen { get; set; }

        /// <summary>
        /// 签到积分
        /// </summary>
        [DataMember]
        public int SignJiFen { get; set; }

        /// <summary>
        /// 未领取积分
        /// </summary>
        [DataMember]
        public int ReceiveJiFen { get; set; }

        /// <summary>
        /// 达到这一等级的积分
        /// </summary>
        [DataMember]
        public int ThisGradeJF { get; set; }

        /// <summary>
        /// 达到下一等级的积分
        /// </summary>
        [DataMember]
        public int NextGradeJF { get; set; }

        /// <summary>
        /// 网龙币
        /// </summary>
        [DataMember]
        public int Coin { get; set; }

        /// <summary>
        /// 当月签到次数
        /// </summary>
        [DataMember]
        public int SignNum { get; set; }

        /// <summary>
        /// 当天是否签到
        /// </summary>
        [DataMember]
        public int IsSigned { get; set; }

        /// <summary>
        /// 当天是否日清
        /// </summary>
        [DataMember]
        public int IsSignOuted { get; set; }

        /// <summary>
        /// 可抽奖次数
        /// </summary>
        [DataMember]
        public int LotteryDraw { get; set; }

        /// <summary>
        /// 礼物数
        /// </summary>
        [DataMember]
        public int Gifts { get; set; }

        /// <summary>
        /// 是否有新活动
        /// 0：无 1：有
        /// </summary>
        [DataMember]
        public int HasNew { get; set; }
    }
}
