﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;


namespace ToDoService.Entity
{
    /// <summary>
    /// 包含TODO任务同步的分类数据和更新时间的实体
    /// </summary>
    [DataContract]
    public class EnPeopleOrders
    {
        /// <summary>
        /// 新增的任务
        /// </summary>
        [DataMember]
        public List<EnPeopleOrder> AddOrders { get; set; }

        /// <summary>
        /// 被确认的任务
        /// </summary>
        [DataMember]
        public List<EnPeopleOrder> ComOrders { get; set; }

        /// <summary>
        /// 修改过的任务
        /// </summary>
        [DataMember]
        public List<EnPeopleOrder> UpdateOrders { get; set; }

        /// <summary>
        /// 要删除的任务
        /// </summary>
        [DataMember]
        public List<EnPeopleOrder> DeleteOrders { get; set; }

        /// <summary>
        /// 要更新的任务反馈
        /// </summary>
        [DataMember]
        public List<EnPeopleFeedback> FeedBacks { get; set; }

        /// <summary>
        /// 接受到客户端同步操作的任务号，用于判断客户端最后的插入任务
        /// </summary>
        [DataMember]
        public String LastSyncCode { get; set; }

        /// <summary>
        /// 最后更新的反馈任务自加ID
        /// </summary>
        [DataMember]
        public String LastSyncFeedbackCode { get; set; }

        /// <summary>
        /// 最后更新的任务确认表的自动编号
        /// </summary>
        [DataMember]
        public string LastSyncConfirmCode { get; set; }

        /// <summary>
        /// 接受到客户端同步操作时的时间，用于判断客户端最后的更新时间
        /// </summary>
        [DataMember]
        public DateTime? LastSyncDate { get; set; }
    }
}
