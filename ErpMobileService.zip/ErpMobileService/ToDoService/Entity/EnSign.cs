﻿using System;
using System.Runtime.Serialization;

namespace ToDoService.Entity
{
    /// <summary>
    /// 签到返回信息
    /// </summary>
    [DataContract]
    public class EnSign
    {
        /// <summary>
        /// 返回状态
        /// </summary>
        [DataMember]
        public string code { get; set; }

        /// <summary>
        /// 提示信息
        /// </summary>
        [DataMember]
        public string msg { get; set; }

        /// <summary>
        /// 签到积分
        /// </summary>
        [DataMember]
        public int SignJiFen { get; set; }

        /// <summary>
        /// 网龙币
        /// </summary>
        [DataMember]
        public int Coin { get; set; }

        /// <summary>
        /// 礼物数
        /// </summary>
        [DataMember]
        public int Gifts { get; set; }

        /// <summary>
        /// 抽奖次数
        /// </summary>
        [DataMember]
        public int Lot { get; set; }
    }
}
