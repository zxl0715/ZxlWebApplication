﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Web.Http;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

using ToDoService.Entity;
using ToDoService.Business;
using ToDoService.DataAccess;

namespace ToDoService
{
    /// <summary>
    /// 91养成系统
    /// </summary>
    public class ToDoListController : ApiController
    {
        #region 获取日事日清的任务数据
        /// <summary>
        /// 获取日事日清的任务数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList_Task(string userID, string pageIndex = null)
        {
            if (pageIndex != null)
                return BzToDoList.getToDoList_Task(userID, pageIndex);
            else
                return BzToDoList.getToDoList_Task(userID);
        }
        #endregion

        #region 获取日事日清的SOP数据
        /// <summary>
        /// 获取日事日清的SOP数据
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList_SOP(string userID)
        {
            return BzToDoList.getToDoList_SOP(userID);
        }
        #endregion

        #region 获取日事日清的会议数据
        /// <summary>
        /// 获取日事日清的会议数据
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList_Meeting(string userID)
        {
            return BzToDoList.getToDoList_Meeting(userID);
        }
        #endregion

        #region 获取日事日清的全部数据
        /// <summary>
        /// 获取日事日清的全部数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="pageIndex">页码</param>
        /// <returns></returns>
        public List<EnToDoListItem> getToDoList(string userID, string pageIndex = null)
        {
            if (pageIndex != null)
                return BzToDoList.getToDoList(userID, pageIndex);
            else
                return BzToDoList.getToDoList(userID);
        }
        #endregion
        
        #region 获取日事日清数据（签退）
        /// <summary>
        /// 获取日事日清数据（签退）
        /// </summary>
        /// <param name="userID"></param>
        public List<EnToDoListItem> getToDoList_SignOut(string userID)
        {
            return BzToDoList.getToDoList_SignOut(userID);
        }
        #endregion 


        
        #region 获取成长数据
        /// <summary>
        /// 获取成长数据
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="sid">sid</param>
        /// <returns></returns>
        public EnGrowUp getGrowUpInfo(string userID, string sid = null)
        {
            if (sid != null)
                return BzToDoList.getGrowUpInfo(userID, sid);
            else
                return BzToDoList.getGrowUpInfo(userID);
        }
        #endregion

        #region 获取某个月的签到统计情况
        /// <summary>
        /// 获取某个月的签到统计情况
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="year">年份</param>
        /// <param name="month">月份</param>
        public string getSignInList(string userID, string year, string month)
        {
            int lYear = Convert.ToInt32(year);
            int lMonth = Convert.ToInt32(month);

            return BzToDoList.getSignInList(userID, lYear, lMonth);
        }
        #endregion



        #region 旧版签到签退接口

        #region 签到操作
        /// <summary>
        /// 签到操作
        /// </summary>
        /// <param name="userID">工号</param>
        [HttpGet]
        [HttpPost]
        public string signIn(string userID)
        {
            DateTime today = DateTime.Now;
            return BzToDoList.signIn(userID, today);
        }
        #endregion

        #region 签退操作
        /// <summary>
        /// 签退操作
        /// </summary>
        /// <param name="userID">工号</param>
        [HttpGet]
        [HttpPost]
        public string signOut(string userID)
        {
            DateTime today = DateTime.Now;
            return BzToDoList.signOut(userID, today);
        }
        #endregion

        #endregion

        #region 新版签到签退接口

        #region 签到操作
        /// <summary>
        /// 签到操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="sid">sid</param>
        [HttpGet]
        [HttpPost]
        public EnSign signIn(string userID, string sid)
        {
            DateTime today = DateTime.Now;
            return BzToDoList.signIn(userID, today, sid);
        }
        #endregion

        #region 签退操作
        /// <summary>
        /// 签退操作
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="sid">sid</param>
        [HttpGet]
        [HttpPost]
        public EnSign signOut(string userID, string sid)
        {
            DateTime today = DateTime.Now;
            return BzToDoList.signOut(userID, today, sid);
        }
        #endregion

        #endregion


        [HttpGet]
        [HttpPost]
        public string signIn1(string userID)
        {
            DateTime today = DateTime.Now;
            return BzToDoList.signIn(userID, today, null).code;
        }

        [HttpGet]
        [HttpPost]
        public string signOut1(string userID)
        {
            DateTime today = DateTime.Now;
            return BzToDoList.signOut(userID, today, null).code;
        }

        
        #region 获取积分领取列表
        /// <summary>
        /// 获取积分领取列表
        /// </summary>
        /// <param name="userID">工号</param>
        public List<EnReceivePoint> getReceivePointList(string userID)
        {
            return BzReceivePoint.getReceivePointList(userID);
        }
        #endregion

        #region 领取积分
        /// <summary>
        /// 领取积分
        /// </summary>
        /// <param name="userID">工号</param>
        /// <param name="auto">编号</param>
        /// <param name="sid">sid</param>
        [HttpGet]
        [HttpPost]
        public EnGrowUp receivePoint(string userID, string auto, string sid)
        {
            int _auto = Convert.ToInt32(auto);
            int result = BzReceivePoint.receivePoint(userID, _auto);

            if (result == 1)
                return BzToDoList.getGrowUpInfo(userID, sid);
            else
                return new EnGrowUp();
        }
        #endregion

        #region 是否签到
        /// <summary>
        /// 是否签到
        /// </summary>
        /// <param name="userID">工号</param>
        /// <returns>1：已签到；0：未签到</returns>
        [HttpGet]
        [HttpPost]
        public string isSigned(string userID)
        {
            DateTime today = DateTime.Now;
            return BzToDoList.isSigned(userID, today).ToString();
        }
        #endregion

        #region 获取更多积分的活动数据
        /// <summary>
        /// 获取更多积分的活动数据
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="sid"></param>
        /// <returns></returns>
        public List<EnPointActivity> getPointActivityList(string userID, string sid)
        {
            return BzToDoList.getPointActivityList(userID, sid);
        }
        #endregion


        public string getLotNum(string userID)
        {
            Da91UServer dal = new Da91UServer();
            return dal.getLotNum(userID).ToString();
        }

    }
}