﻿using System;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Dispatcher;
using System.Web.Http.SelfHost;
using System.Linq;
using Nd.Erp.Mobile.Service.Common;
using Newtonsoft.Json;
using Nd.Erp.Mobile.Base;
using SysCommonLibrary.WebApiConfig;

namespace Nd.ERPMobile.WebApi.SelfHost
{
    class Program
    {
        public static HttpSelfHostServer server = null;
        static readonly Uri _baseAddress = new Uri(BaseHelper.ServiceBaseAddress);
        static readonly Uri _address = new Uri(_baseAddress, "/ServiceHost");

        static void Main(string[] args)
        {

            try
            {
                // Set up server configuration
                HttpSelfHostConfiguration config = WebApiConfig.ApplyConfig(new HttpSelfHostConfiguration("http://localhost:8732/"));
                config.Services.Replace(typeof(IAssembliesResolver), new CustomAssemblyResolver());
                // Create server
                server = new HttpSelfHostServer(config);
                var explorer = config.Services.GetApiExplorer();
                explorer.ApiDescriptions.ToList().ForEach(i => Console.WriteLine(i.RelativePath));
                // Start listening
                server.OpenAsync().Wait();
                Console.WriteLine("Listening on " + _baseAddress);

                // Call the web API and display the result
                HttpClient client = new HttpClient();
                client.PostAsJsonAsync("http://192.168.211.51:8732/ServiceHost/LoginCheck/json/CheckPowerWithPersonInfo", new { spersoncode = 840513, spassword = "4c5ee20a16c8112b742f236397816509" }).ContinueWith(
                    getTask =>
                    {
                        if (getTask.IsCanceled)
                        {
                            Console.WriteLine("Request was canceled");
                        }
                        else if (getTask.IsFaulted)
                        {
                            Console.WriteLine("Request failed: {0}", getTask.Exception);
                        }
                        else
                        {
                            Console.WriteLine("Client received: {0}", getTask.Result);
                        }
                    });
                Console.ReadLine();
            }
            catch (Exception e)
            {
                Console.WriteLine("Could not start server: {0}", e.GetBaseException().Message);
                Console.WriteLine("Hit ENTER to exit...");
                Console.ReadLine();
            }
            finally
            {
                if (server != null)
                {
                    // Stop listening
                    server.CloseAsync().Wait();
                }
            }
        }
    }

}
