﻿using System;
using System.Data;
using System.Windows.Forms;

namespace Nd.Erp.Mobile.MgrClient
{
    public class ComboBoxHelper
    {
        private DataTable _dt = new DataTable();

        public ComboBoxHelper()
        {
            this._dt.Columns.Add(new DataColumn("Text", Type.GetType("System.String")));
            this._dt.Columns.Add(new DataColumn("Value", Type.GetType("System.Object")));
        }

        public void AddRow(string text, object value)
        {
            DataRow row = this._dt.NewRow();
            row["Text"] = text;
            row["Value"] = value;
            this._dt.Rows.Add(row);
        }

        public void AddRow(DataTable dt, string textBinding, string valueBinding)
        {
            this.AddRow(dt, textBinding, valueBinding, false);
        }

        public void AddRow(DataTable dt, string textBinding, string valueBinding, bool isBlank)
        {
            if (isBlank)
            {
                this.AddRow("---请选择---", "");
            }
            foreach (DataRow row in dt.Rows)
            {
                this.AddRow(row[textBinding].ToString().Trim(), row[valueBinding].ToString().Trim());
            }
        }

        public void AddRowAndBindToComboBox(ComboBox objCombo, DataTable dt, string textBinding, string valueBinding)
        {
            this.AddRowAndBindToComboBox(objCombo, dt, textBinding, valueBinding, false);
        }

        public void AddRowAndBindToComboBox(ComboBox objCombo, DataTable dt, string textBinding, string valueBinding, bool isBlank)
        {
            this.AddRow(dt, textBinding, valueBinding, isBlank);
            this.BindToComboBox(objCombo);
        }

        public void BindToComboBox(ComboBox objCombo)
        {
            if (this._dt != null)
            {
                objCombo.DisplayMember = "Text";
                objCombo.ValueMember = "Value";
                objCombo.DataSource = this._dt;
                if (this._dt.Rows.Count > 0)
                {
                    objCombo.SelectedIndex = 0;
                }
            }
        }

        public static void FindItemByValue(ComboBox objCombo, string value, bool isByDisplayMember=false)
        {
            if ((objCombo.Items.Count != 0) && (objCombo.DataSource.GetType().ToString() == "System.Data.DataTable"))
            {


                string columnName = isByDisplayMember ? objCombo.DisplayMember : objCombo.ValueMember;
                DataTable dataSource = (DataTable)objCombo.DataSource;
                int num = 0;
                foreach (DataRow row in dataSource.Rows)
                {
                    if (row[columnName].ToString().Equals(value))
                    {
                        objCombo.SelectedIndex = num;
                        break;
                    }
                    num++;
                }
            }
        }
    }
}

