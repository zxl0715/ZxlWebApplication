﻿namespace Nd.Erp.Mobile.MgrClient
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMain));
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle5 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle6 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle7 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle8 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle9 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle10 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle11 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle12 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle13 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle14 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle15 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle16 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle17 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle18 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle19 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle20 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle21 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle22 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle23 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle24 = new System.Windows.Forms.DataGridViewCellStyle();
            this.notifyIcon1 = new System.Windows.Forms.NotifyIcon(this.components);
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuShow = new System.Windows.Forms.ToolStripMenuItem();
            this.numHide = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.treeView1 = new System.Windows.Forms.TreeView();
            this.cmTreeView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuRefBaseCode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelBaseCode = new System.Windows.Forms.ToolStripMenuItem();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tpGeneral = new System.Windows.Forms.TabPage();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.btnSearchLog = new System.Windows.Forms.Button();
            this.dgvLogInfo = new System.Windows.Forms.DataGridView();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.btnRefreshService = new System.Windows.Forms.Button();
            this.btnStopService = new System.Windows.Forms.Button();
            this.btnResumeService = new System.Windows.Forms.Button();
            this.btnPauseService = new System.Windows.Forms.Button();
            this.btnStartService = new System.Windows.Forms.Button();
            this.picServiceStatus = new System.Windows.Forms.PictureBox();
            this.tpBaseCode = new System.Windows.Forms.TabPage();
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.label4 = new System.Windows.Forms.Label();
            this.btnUpdBaseCode = new System.Windows.Forms.Button();
            this.btnAddBaseCode = new System.Windows.Forms.Button();
            this.txtBaseName = new System.Windows.Forms.TextBox();
            this.txtBaseCode = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbParent = new System.Windows.Forms.ComboBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.tvBaseCode = new System.Windows.Forms.TreeView();
            this.tpSysArg = new System.Windows.Forms.TabPage();
            this.groupBox6 = new System.Windows.Forms.GroupBox();
            this.dgSysArg = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.RowID = new System.Windows.Forms.DataGridViewButtonColumn();
            this.dataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cmSysArg = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox5 = new System.Windows.Forms.GroupBox();
            this.radioButtonDisabled = new System.Windows.Forms.RadioButton();
            this.radioButtonEnabled = new System.Windows.Forms.RadioButton();
            this.buttonEditSysArg = new System.Windows.Forms.Button();
            this.buttonAddSysArg = new System.Windows.Forms.Button();
            this.textBoxArgDesc = new System.Windows.Forms.TextBox();
            this.textBoxArgValue = new System.Windows.Forms.TextBox();
            this.textBoxArgKey = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBoxArgTypes = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.tpSvcRegArg = new System.Windows.Forms.TabPage();
            this.groupBox8 = new System.Windows.Forms.GroupBox();
            this.tabControl2 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.btnSvcArgEdit = new System.Windows.Forms.Button();
            this.btnSvcArgAdd = new System.Windows.Forms.Button();
            this.groupBox7 = new System.Windows.Forms.GroupBox();
            this.dgSvcRegArg = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column4 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.OwnerType = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column6 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cmSvcBizArg = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem3 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem4 = new System.Windows.Forms.ToolStripMenuItem();
            this.button3 = new System.Windows.Forms.Button();
            this.rbtSvcDisable = new System.Windows.Forms.RadioButton();
            this.rbtSvcEnable = new System.Windows.Forms.RadioButton();
            this.txtSvcAddressPath = new System.Windows.Forms.TextBox();
            this.txtServiceName = new System.Windows.Forms.TextBox();
            this.txtServiceCode = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.cmbSvcOwnerType = new System.Windows.Forms.ComboBox();
            this.label11 = new System.Windows.Forms.Label();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.cmbBaseSvcArg = new System.Windows.Forms.ComboBox();
            this.label27 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox13 = new System.Windows.Forms.GroupBox();
            this.dgSvcRegArgDetail = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn14 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn13 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn15 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.BaseAddress = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ServiceID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Memo = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn2 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.cmSvcClassArg = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem7 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem8 = new System.Windows.Forms.ToolStripMenuItem();
            this.cmbBindType = new System.Windows.Forms.ComboBox();
            this.rbtSvcClassDisable = new System.Windows.Forms.RadioButton();
            this.rbtSvcClassEnable = new System.Windows.Forms.RadioButton();
            this.button4 = new System.Windows.Forms.Button();
            this.label15 = new System.Windows.Forms.Label();
            this.txtSvcArgMemo = new System.Windows.Forms.TextBox();
            this.txtSvcArgBaseAddress = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.txtSvcArgNameSpace = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.txtSvcArgClassName = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.cmbSvcClassArg = new System.Windows.Forms.ComboBox();
            this.label28 = new System.Windows.Forms.Label();
            this.button9 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.groupBox14 = new System.Windows.Forms.GroupBox();
            this.dgSvcInterface = new System.Windows.Forms.DataGridView();
            this.rbtSvcInterfaceDisable = new System.Windows.Forms.RadioButton();
            this.rbtSvcInterfaceEnable = new System.Windows.Forms.RadioButton();
            this.txtSvcInterfaceMemo = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.cmbDataType = new System.Windows.Forms.ComboBox();
            this.label20 = new System.Windows.Forms.Label();
            this.txtSvcInterfaceName = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.button5 = new System.Windows.Forms.Button();
            this.tpSvcBizArg = new System.Windows.Forms.TabPage();
            this.groupBox9 = new System.Windows.Forms.GroupBox();
            this.tabControl3 = new System.Windows.Forms.TabControl();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.groupBox10 = new System.Windows.Forms.GroupBox();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn5 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn6 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn8 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn1 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.textBox16 = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.button7 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.label25 = new System.Windows.Forms.Label();
            this.textBox15 = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.textBox14 = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.textBox13 = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.button8 = new System.Windows.Forms.Button();
            this.groupBox11 = new System.Windows.Forms.GroupBox();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmSvcClsArg = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem5 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem6 = new System.Windows.Forms.ToolStripMenuItem();
            this.textBox20 = new System.Windows.Forms.TextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.button10 = new System.Windows.Forms.Button();
            this.dgvBizLog = new System.Windows.Forms.DataGridView();
            this.dataGridViewTextBoxColumn9 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column7 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cmSvcTreeView = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.mnuRefSvcTV = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuColSvcTV = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExpSvcTV = new System.Windows.Forms.ToolStripMenuItem();
            this.cmSvcInterface = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.toolStripMenuItem9 = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripMenuItem10 = new System.Windows.Forms.ToolStripMenuItem();
            this.dataGridViewTextBoxColumn16 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn17 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewTextBoxColumn19 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column10 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column11 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column12 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridViewCheckBoxColumn3 = new System.Windows.Forms.DataGridViewCheckBoxColumn();
            this.dataGridViewTextBoxColumn18 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.contextMenuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            this.cmTreeView.SuspendLayout();
            this.tabControl1.SuspendLayout();
            this.tpGeneral.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogInfo)).BeginInit();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceStatus)).BeginInit();
            this.tpBaseCode.SuspendLayout();
            this.groupBox4.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.tpSysArg.SuspendLayout();
            this.groupBox6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSysArg)).BeginInit();
            this.cmSysArg.SuspendLayout();
            this.groupBox5.SuspendLayout();
            this.tpSvcRegArg.SuspendLayout();
            this.groupBox8.SuspendLayout();
            this.tabControl2.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.groupBox7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSvcRegArg)).BeginInit();
            this.cmSvcBizArg.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.groupBox13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSvcRegArgDetail)).BeginInit();
            this.cmSvcClassArg.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.groupBox14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgSvcInterface)).BeginInit();
            this.tpSvcBizArg.SuspendLayout();
            this.groupBox9.SuspendLayout();
            this.tabControl3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.groupBox10.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.tabPage5.SuspendLayout();
            this.groupBox11.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            this.cmSvcClsArg.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBizLog)).BeginInit();
            this.cmSvcTreeView.SuspendLayout();
            this.cmSvcInterface.SuspendLayout();
            this.SuspendLayout();
            // 
            // notifyIcon1
            // 
            this.notifyIcon1.ContextMenuStrip = this.contextMenuStrip1;
            this.notifyIcon1.Icon = ((System.Drawing.Icon)(resources.GetObject("notifyIcon1.Icon")));
            this.notifyIcon1.Text = "notifyIcon1";
            this.notifyIcon1.Visible = true;
            this.notifyIcon1.MouseDoubleClick += new System.Windows.Forms.MouseEventHandler(this.notifyIcon1_MouseDoubleClick);
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuShow,
            this.numHide,
            this.mnuExit});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(116, 70);
            // 
            // mnuShow
            // 
            this.mnuShow.Name = "mnuShow";
            this.mnuShow.Size = new System.Drawing.Size(115, 22);
            this.mnuShow.Text = "显示(&S)";
            this.mnuShow.Click += new System.EventHandler(this.mnuShow_Click);
            // 
            // numHide
            // 
            this.numHide.Name = "numHide";
            this.numHide.Size = new System.Drawing.Size(115, 22);
            this.numHide.Text = "隐藏(&H)";
            this.numHide.Click += new System.EventHandler(this.numHide_Click);
            // 
            // mnuExit
            // 
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(115, 22);
            this.mnuExit.Text = "退出(&X)";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.splitContainer1.Location = new System.Drawing.Point(0, 0);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.treeView1);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.tabControl1);
            this.splitContainer1.Size = new System.Drawing.Size(636, 518);
            this.splitContainer1.SplitterDistance = 160;
            this.splitContainer1.TabIndex = 0;
            // 
            // treeView1
            // 
            this.treeView1.ContextMenuStrip = this.cmTreeView;
            this.treeView1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.treeView1.FullRowSelect = true;
            this.treeView1.HideSelection = false;
            this.treeView1.Location = new System.Drawing.Point(0, 0);
            this.treeView1.Name = "treeView1";
            this.treeView1.Size = new System.Drawing.Size(160, 518);
            this.treeView1.TabIndex = 0;
            this.treeView1.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.treeView1_AfterSelect);
            // 
            // cmTreeView
            // 
            this.cmTreeView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuRefBaseCode,
            this.mnuDelBaseCode});
            this.cmTreeView.Name = "cmTreeView";
            this.cmTreeView.Size = new System.Drawing.Size(115, 48);
            this.cmTreeView.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmTreeView_ItemClicked);
            // 
            // mnuRefBaseCode
            // 
            this.mnuRefBaseCode.Name = "mnuRefBaseCode";
            this.mnuRefBaseCode.Size = new System.Drawing.Size(114, 22);
            this.mnuRefBaseCode.Tag = "Refresh";
            this.mnuRefBaseCode.Text = "刷新(&R)";
            // 
            // mnuDelBaseCode
            // 
            this.mnuDelBaseCode.Name = "mnuDelBaseCode";
            this.mnuDelBaseCode.Size = new System.Drawing.Size(114, 22);
            this.mnuDelBaseCode.Tag = "Delete";
            this.mnuDelBaseCode.Text = "删除(&D)";
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tpGeneral);
            this.tabControl1.Controls.Add(this.tpBaseCode);
            this.tabControl1.Controls.Add(this.tpSysArg);
            this.tabControl1.Controls.Add(this.tpSvcRegArg);
            this.tabControl1.Controls.Add(this.tpSvcBizArg);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.ItemSize = new System.Drawing.Size(30, 18);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(472, 518);
            this.tabControl1.TabIndex = 2;
            // 
            // tpGeneral
            // 
            this.tpGeneral.Controls.Add(this.groupBox2);
            this.tpGeneral.Controls.Add(this.groupBox1);
            this.tpGeneral.Location = new System.Drawing.Point(4, 22);
            this.tpGeneral.Name = "tpGeneral";
            this.tpGeneral.Padding = new System.Windows.Forms.Padding(3);
            this.tpGeneral.Size = new System.Drawing.Size(440, 479);
            this.tpGeneral.TabIndex = 0;
            this.tpGeneral.Text = "常规";
            this.tpGeneral.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            this.groupBox2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox2.Controls.Add(this.btnSearchLog);
            this.groupBox2.Controls.Add(this.dgvLogInfo);
            this.groupBox2.Location = new System.Drawing.Point(3, 142);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(434, 331);
            this.groupBox2.TabIndex = 5;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "日志";
            // 
            // btnSearchLog
            // 
            this.btnSearchLog.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSearchLog.Location = new System.Drawing.Point(314, 301);
            this.btnSearchLog.Name = "btnSearchLog";
            this.btnSearchLog.Size = new System.Drawing.Size(102, 23);
            this.btnSearchLog.TabIndex = 1;
            this.btnSearchLog.Tag = "0";
            this.btnSearchLog.Text = "查找日志(&F)";
            this.btnSearchLog.UseVisualStyleBackColor = true;
            this.btnSearchLog.Click += new System.EventHandler(this.btnSearchLog_Click);
            // 
            // dgvLogInfo
            // 
            this.dgvLogInfo.AllowUserToAddRows = false;
            this.dgvLogInfo.AllowUserToDeleteRows = false;
            this.dgvLogInfo.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvLogInfo.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLogInfo.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvLogInfo.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvLogInfo.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvLogInfo.Location = new System.Drawing.Point(9, 19);
            this.dgvLogInfo.Name = "dgvLogInfo";
            this.dgvLogInfo.ReadOnly = true;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvLogInfo.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.dgvLogInfo.Size = new System.Drawing.Size(416, 277);
            this.dgvLogInfo.TabIndex = 2;
            this.dgvLogInfo.Tag = "";
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.Controls.Add(this.btnRefreshService);
            this.groupBox1.Controls.Add(this.btnStopService);
            this.groupBox1.Controls.Add(this.btnResumeService);
            this.groupBox1.Controls.Add(this.btnPauseService);
            this.groupBox1.Controls.Add(this.btnStartService);
            this.groupBox1.Controls.Add(this.picServiceStatus);
            this.groupBox1.Location = new System.Drawing.Point(3, 6);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(431, 130);
            this.groupBox1.TabIndex = 4;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "服务状态";
            // 
            // btnRefreshService
            // 
            this.btnRefreshService.Location = new System.Drawing.Point(230, 98);
            this.btnRefreshService.Name = "btnRefreshService";
            this.btnRefreshService.Size = new System.Drawing.Size(75, 23);
            this.btnRefreshService.TabIndex = 1;
            this.btnRefreshService.Text = "刷新(&R)";
            this.btnRefreshService.UseVisualStyleBackColor = true;
            this.btnRefreshService.Click += new System.EventHandler(this.btnRefreshService_Click);
            // 
            // btnStopService
            // 
            this.btnStopService.Enabled = false;
            this.btnStopService.Location = new System.Drawing.Point(124, 98);
            this.btnStopService.Name = "btnStopService";
            this.btnStopService.Size = new System.Drawing.Size(75, 23);
            this.btnStopService.TabIndex = 1;
            this.btnStopService.Text = "停止(&O)";
            this.btnStopService.UseVisualStyleBackColor = true;
            this.btnStopService.Click += new System.EventHandler(this.btnStopService_Click);
            // 
            // btnResumeService
            // 
            this.btnResumeService.Enabled = false;
            this.btnResumeService.Location = new System.Drawing.Point(124, 69);
            this.btnResumeService.Name = "btnResumeService";
            this.btnResumeService.Size = new System.Drawing.Size(75, 23);
            this.btnResumeService.TabIndex = 1;
            this.btnResumeService.Text = "恢复(&U)";
            this.btnResumeService.UseVisualStyleBackColor = true;
            this.btnResumeService.Click += new System.EventHandler(this.btnResumeService_Click);
            // 
            // btnPauseService
            // 
            this.btnPauseService.Enabled = false;
            this.btnPauseService.Location = new System.Drawing.Point(124, 40);
            this.btnPauseService.Name = "btnPauseService";
            this.btnPauseService.Size = new System.Drawing.Size(75, 23);
            this.btnPauseService.TabIndex = 1;
            this.btnPauseService.Text = "暂停(&P)";
            this.btnPauseService.UseVisualStyleBackColor = true;
            this.btnPauseService.Click += new System.EventHandler(this.btnPauseService_Click);
            // 
            // btnStartService
            // 
            this.btnStartService.Location = new System.Drawing.Point(124, 13);
            this.btnStartService.Name = "btnStartService";
            this.btnStartService.Size = new System.Drawing.Size(75, 23);
            this.btnStartService.TabIndex = 1;
            this.btnStartService.Text = "启动(&S)";
            this.btnStartService.UseVisualStyleBackColor = true;
            this.btnStartService.Click += new System.EventHandler(this.btnStartService_Click);
            // 
            // picServiceStatus
            // 
            this.picServiceStatus.Image = global::Nd.Erp.Mobile.MgrClient.Properties.Resources.SvrStart;
            this.picServiceStatus.Location = new System.Drawing.Point(29, 37);
            this.picServiceStatus.Name = "picServiceStatus";
            this.picServiceStatus.Size = new System.Drawing.Size(53, 64);
            this.picServiceStatus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.picServiceStatus.TabIndex = 0;
            this.picServiceStatus.TabStop = false;
            // 
            // tpBaseCode
            // 
            this.tpBaseCode.Controls.Add(this.groupBox4);
            this.tpBaseCode.Controls.Add(this.groupBox3);
            this.tpBaseCode.Location = new System.Drawing.Point(4, 22);
            this.tpBaseCode.Name = "tpBaseCode";
            this.tpBaseCode.Padding = new System.Windows.Forms.Padding(3);
            this.tpBaseCode.Size = new System.Drawing.Size(440, 479);
            this.tpBaseCode.TabIndex = 1;
            this.tpBaseCode.Text = "基础代码";
            this.tpBaseCode.UseVisualStyleBackColor = true;
            // 
            // groupBox4
            // 
            this.groupBox4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox4.Controls.Add(this.label4);
            this.groupBox4.Controls.Add(this.btnUpdBaseCode);
            this.groupBox4.Controls.Add(this.btnAddBaseCode);
            this.groupBox4.Controls.Add(this.txtBaseName);
            this.groupBox4.Controls.Add(this.txtBaseCode);
            this.groupBox4.Controls.Add(this.label1);
            this.groupBox4.Controls.Add(this.label2);
            this.groupBox4.Controls.Add(this.cmbParent);
            this.groupBox4.Controls.Add(this.label3);
            this.groupBox4.Location = new System.Drawing.Point(176, 6);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(258, 465);
            this.groupBox4.TabIndex = 4;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "代码编辑";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(11, 175);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(229, 78);
            this.label4.TabIndex = 7;
            this.label4.Text = "注：\r\n1、选择左边树的具体节点，点击右键可操\r\n      作删除该节点。\r\n\r\n2、点击左边树的具体节点，在右边可对该\r\n      节点进行修改操作。";
            // 
            // btnUpdBaseCode
            // 
            this.btnUpdBaseCode.Location = new System.Drawing.Point(141, 118);
            this.btnUpdBaseCode.Name = "btnUpdBaseCode";
            this.btnUpdBaseCode.Size = new System.Drawing.Size(75, 23);
            this.btnUpdBaseCode.TabIndex = 6;
            this.btnUpdBaseCode.Text = "修改(&U)";
            this.btnUpdBaseCode.UseVisualStyleBackColor = true;
            this.btnUpdBaseCode.Click += new System.EventHandler(this.btnUpdBaseCode_Click);
            // 
            // btnAddBaseCode
            // 
            this.btnAddBaseCode.Location = new System.Drawing.Point(25, 118);
            this.btnAddBaseCode.Name = "btnAddBaseCode";
            this.btnAddBaseCode.Size = new System.Drawing.Size(75, 23);
            this.btnAddBaseCode.TabIndex = 6;
            this.btnAddBaseCode.Text = "增加(&A)";
            this.btnAddBaseCode.UseVisualStyleBackColor = true;
            this.btnAddBaseCode.Click += new System.EventHandler(this.btnAddBaseCode_Click);
            // 
            // txtBaseName
            // 
            this.txtBaseName.Location = new System.Drawing.Point(82, 78);
            this.txtBaseName.Name = "txtBaseName";
            this.txtBaseName.Size = new System.Drawing.Size(147, 20);
            this.txtBaseName.TabIndex = 5;
            // 
            // txtBaseCode
            // 
            this.txtBaseCode.Location = new System.Drawing.Point(82, 50);
            this.txtBaseCode.Name = "txtBaseCode";
            this.txtBaseCode.Size = new System.Drawing.Size(147, 20);
            this.txtBaseCode.TabIndex = 5;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 13);
            this.label1.TabIndex = 2;
            this.label1.Text = "所属父级：";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(8, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(67, 13);
            this.label2.TabIndex = 2;
            this.label2.Text = "代码编号：";
            // 
            // cmbParent
            // 
            this.cmbParent.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbParent.FormattingEnabled = true;
            this.cmbParent.Location = new System.Drawing.Point(81, 20);
            this.cmbParent.Name = "cmbParent";
            this.cmbParent.Size = new System.Drawing.Size(148, 21);
            this.cmbParent.TabIndex = 3;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(8, 81);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "代码名称：";
            // 
            // groupBox3
            // 
            this.groupBox3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.groupBox3.Controls.Add(this.tvBaseCode);
            this.groupBox3.Location = new System.Drawing.Point(8, 6);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(156, 465);
            this.groupBox3.TabIndex = 1;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "基础代码树";
            // 
            // tvBaseCode
            // 
            this.tvBaseCode.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tvBaseCode.ContextMenuStrip = this.cmTreeView;
            this.tvBaseCode.Location = new System.Drawing.Point(6, 19);
            this.tvBaseCode.Name = "tvBaseCode";
            this.tvBaseCode.Size = new System.Drawing.Size(141, 440);
            this.tvBaseCode.TabIndex = 0;
            this.tvBaseCode.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.tvBaseCode_AfterSelect);
            this.tvBaseCode.NodeMouseClick += new System.Windows.Forms.TreeNodeMouseClickEventHandler(this.tvBaseCode_NodeMouseClick);
            // 
            // tpSysArg
            // 
            this.tpSysArg.Controls.Add(this.groupBox6);
            this.tpSysArg.Controls.Add(this.groupBox5);
            this.tpSysArg.Location = new System.Drawing.Point(4, 22);
            this.tpSysArg.Name = "tpSysArg";
            this.tpSysArg.Padding = new System.Windows.Forms.Padding(3);
            this.tpSysArg.Size = new System.Drawing.Size(440, 479);
            this.tpSysArg.TabIndex = 2;
            this.tpSysArg.Text = "系统参数";
            this.tpSysArg.UseVisualStyleBackColor = true;
            // 
            // groupBox6
            // 
            this.groupBox6.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox6.Controls.Add(this.dgSysArg);
            this.groupBox6.Location = new System.Drawing.Point(6, 208);
            this.groupBox6.Name = "groupBox6";
            this.groupBox6.Size = new System.Drawing.Size(432, 265);
            this.groupBox6.TabIndex = 1;
            this.groupBox6.TabStop = false;
            this.groupBox6.Text = "参数列表";
            // 
            // dgSysArg
            // 
            this.dgSysArg.AllowUserToDeleteRows = false;
            this.dgSysArg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgSysArg.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle4.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle4.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle4.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle4.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle4.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSysArg.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle4;
            this.dgSysArg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSysArg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn1,
            this.RowID,
            this.dataGridViewTextBoxColumn2,
            this.Column1,
            this.Column2,
            this.Column3});
            this.dgSysArg.ContextMenuStrip = this.cmSysArg;
            dataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle5.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle5.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle5.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle5.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle5.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgSysArg.DefaultCellStyle = dataGridViewCellStyle5;
            this.dgSysArg.Location = new System.Drawing.Point(6, 19);
            this.dgSysArg.Name = "dgSysArg";
            this.dgSysArg.ReadOnly = true;
            dataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle6.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle6.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle6.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle6.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle6.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSysArg.RowHeadersDefaultCellStyle = dataGridViewCellStyle6;
            this.dgSysArg.Size = new System.Drawing.Size(420, 240);
            this.dgSysArg.TabIndex = 3;
            this.dgSysArg.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSysArg_CellClick);
            this.dgSysArg.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSysArg_CellMouseEnter);
            // 
            // dataGridViewTextBoxColumn1
            // 
            this.dataGridViewTextBoxColumn1.DataPropertyName = "ArgKey";
            this.dataGridViewTextBoxColumn1.HeaderText = "参数键名";
            this.dataGridViewTextBoxColumn1.Name = "dataGridViewTextBoxColumn1";
            this.dataGridViewTextBoxColumn1.ReadOnly = true;
            this.dataGridViewTextBoxColumn1.Width = 150;
            // 
            // RowID
            // 
            this.RowID.DataPropertyName = "RowID";
            this.RowID.HeaderText = "RowID";
            this.RowID.Name = "RowID";
            this.RowID.ReadOnly = true;
            this.RowID.Visible = false;
            // 
            // dataGridViewTextBoxColumn2
            // 
            this.dataGridViewTextBoxColumn2.DataPropertyName = "ArgValue";
            this.dataGridViewTextBoxColumn2.HeaderText = "参数键值";
            this.dataGridViewTextBoxColumn2.Name = "dataGridViewTextBoxColumn2";
            this.dataGridViewTextBoxColumn2.ReadOnly = true;
            this.dataGridViewTextBoxColumn2.Width = 500;
            // 
            // Column1
            // 
            this.Column1.DataPropertyName = "ArgType";
            this.Column1.HeaderText = "所属类型";
            this.Column1.Name = "Column1";
            this.Column1.ReadOnly = true;
            // 
            // Column2
            // 
            this.Column2.DataPropertyName = "ArgDesc";
            this.Column2.HeaderText = "相关说明";
            this.Column2.Name = "Column2";
            this.Column2.ReadOnly = true;
            // 
            // Column3
            // 
            this.Column3.DataPropertyName = "Enabled";
            this.Column3.HeaderText = "启用";
            this.Column3.Name = "Column3";
            this.Column3.ReadOnly = true;
            // 
            // cmSysArg
            // 
            this.cmSysArg.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem1,
            this.toolStripMenuItem2});
            this.cmSysArg.Name = "cmTreeView";
            this.cmSysArg.Size = new System.Drawing.Size(115, 48);
            this.cmSysArg.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmSysArg_ItemClicked);
            // 
            // toolStripMenuItem1
            // 
            this.toolStripMenuItem1.Name = "toolStripMenuItem1";
            this.toolStripMenuItem1.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem1.Tag = "Refresh";
            this.toolStripMenuItem1.Text = "刷新(&R)";
            // 
            // toolStripMenuItem2
            // 
            this.toolStripMenuItem2.Name = "toolStripMenuItem2";
            this.toolStripMenuItem2.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem2.Tag = "Delete";
            this.toolStripMenuItem2.Text = "删除(&D)";
            // 
            // groupBox5
            // 
            this.groupBox5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox5.Controls.Add(this.radioButtonDisabled);
            this.groupBox5.Controls.Add(this.radioButtonEnabled);
            this.groupBox5.Controls.Add(this.buttonEditSysArg);
            this.groupBox5.Controls.Add(this.buttonAddSysArg);
            this.groupBox5.Controls.Add(this.textBoxArgDesc);
            this.groupBox5.Controls.Add(this.textBoxArgValue);
            this.groupBox5.Controls.Add(this.textBoxArgKey);
            this.groupBox5.Controls.Add(this.label5);
            this.groupBox5.Controls.Add(this.label6);
            this.groupBox5.Controls.Add(this.comboBoxArgTypes);
            this.groupBox5.Controls.Add(this.label8);
            this.groupBox5.Controls.Add(this.label7);
            this.groupBox5.Location = new System.Drawing.Point(6, 6);
            this.groupBox5.Name = "groupBox5";
            this.groupBox5.Size = new System.Drawing.Size(432, 196);
            this.groupBox5.TabIndex = 0;
            this.groupBox5.TabStop = false;
            this.groupBox5.Text = "参数配置";
            // 
            // radioButtonDisabled
            // 
            this.radioButtonDisabled.AutoSize = true;
            this.radioButtonDisabled.Location = new System.Drawing.Point(123, 164);
            this.radioButtonDisabled.Name = "radioButtonDisabled";
            this.radioButtonDisabled.Size = new System.Drawing.Size(63, 17);
            this.radioButtonDisabled.TabIndex = 14;
            this.radioButtonDisabled.TabStop = true;
            this.radioButtonDisabled.Text = "禁用(&D)";
            this.radioButtonDisabled.UseVisualStyleBackColor = true;
            // 
            // radioButtonEnabled
            // 
            this.radioButtonEnabled.AutoSize = true;
            this.radioButtonEnabled.Location = new System.Drawing.Point(41, 164);
            this.radioButtonEnabled.Name = "radioButtonEnabled";
            this.radioButtonEnabled.Size = new System.Drawing.Size(62, 17);
            this.radioButtonEnabled.TabIndex = 14;
            this.radioButtonEnabled.TabStop = true;
            this.radioButtonEnabled.Text = "启用(&E)";
            this.radioButtonEnabled.UseVisualStyleBackColor = true;
            // 
            // buttonEditSysArg
            // 
            this.buttonEditSysArg.Location = new System.Drawing.Point(320, 161);
            this.buttonEditSysArg.Name = "buttonEditSysArg";
            this.buttonEditSysArg.Size = new System.Drawing.Size(75, 23);
            this.buttonEditSysArg.TabIndex = 13;
            this.buttonEditSysArg.Text = "修改(&U)";
            this.buttonEditSysArg.UseVisualStyleBackColor = true;
            this.buttonEditSysArg.Click += new System.EventHandler(this.buttonEditSysArg_Click);
            // 
            // buttonAddSysArg
            // 
            this.buttonAddSysArg.Location = new System.Drawing.Point(204, 161);
            this.buttonAddSysArg.Name = "buttonAddSysArg";
            this.buttonAddSysArg.Size = new System.Drawing.Size(75, 23);
            this.buttonAddSysArg.TabIndex = 12;
            this.buttonAddSysArg.Text = "增加(&A)";
            this.buttonAddSysArg.UseVisualStyleBackColor = true;
            this.buttonAddSysArg.Click += new System.EventHandler(this.buttonAddSysArg_Click);
            // 
            // textBoxArgDesc
            // 
            this.textBoxArgDesc.Location = new System.Drawing.Point(95, 110);
            this.textBoxArgDesc.Multiline = true;
            this.textBoxArgDesc.Name = "textBoxArgDesc";
            this.textBoxArgDesc.Size = new System.Drawing.Size(300, 40);
            this.textBoxArgDesc.TabIndex = 10;
            // 
            // textBoxArgValue
            // 
            this.textBoxArgValue.Location = new System.Drawing.Point(96, 83);
            this.textBoxArgValue.Name = "textBoxArgValue";
            this.textBoxArgValue.Size = new System.Drawing.Size(299, 20);
            this.textBoxArgValue.TabIndex = 10;
            // 
            // textBoxArgKey
            // 
            this.textBoxArgKey.Location = new System.Drawing.Point(96, 55);
            this.textBoxArgKey.Name = "textBoxArgKey";
            this.textBoxArgKey.Size = new System.Drawing.Size(299, 20);
            this.textBoxArgKey.TabIndex = 11;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(22, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(67, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "所属类型：";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(22, 59);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(67, 13);
            this.label6.TabIndex = 7;
            this.label6.Text = "参数键名：";
            // 
            // comboBoxArgTypes
            // 
            this.comboBoxArgTypes.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxArgTypes.FormattingEnabled = true;
            this.comboBoxArgTypes.Location = new System.Drawing.Point(95, 25);
            this.comboBoxArgTypes.Name = "comboBoxArgTypes";
            this.comboBoxArgTypes.Size = new System.Drawing.Size(300, 21);
            this.comboBoxArgTypes.TabIndex = 9;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(22, 110);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(67, 13);
            this.label8.TabIndex = 6;
            this.label8.Text = "相关说明：";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(22, 86);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(67, 13);
            this.label7.TabIndex = 6;
            this.label7.Text = "参数键值：";
            // 
            // tpSvcRegArg
            // 
            this.tpSvcRegArg.Controls.Add(this.groupBox8);
            this.tpSvcRegArg.Location = new System.Drawing.Point(4, 22);
            this.tpSvcRegArg.Name = "tpSvcRegArg";
            this.tpSvcRegArg.Padding = new System.Windows.Forms.Padding(3);
            this.tpSvcRegArg.Size = new System.Drawing.Size(464, 492);
            this.tpSvcRegArg.TabIndex = 3;
            this.tpSvcRegArg.Text = "服务注册";
            this.tpSvcRegArg.UseVisualStyleBackColor = true;
            // 
            // groupBox8
            // 
            this.groupBox8.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox8.Controls.Add(this.tabControl2);
            this.groupBox8.Location = new System.Drawing.Point(8, 6);
            this.groupBox8.Name = "groupBox8";
            this.groupBox8.Size = new System.Drawing.Size(456, 483);
            this.groupBox8.TabIndex = 2;
            this.groupBox8.TabStop = false;
            this.groupBox8.Text = "参数配置";
            // 
            // tabControl2
            // 
            this.tabControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl2.Controls.Add(this.tabPage1);
            this.tabControl2.Controls.Add(this.tabPage2);
            this.tabControl2.Controls.Add(this.tabPage3);
            this.tabControl2.Location = new System.Drawing.Point(7, 19);
            this.tabControl2.Name = "tabControl2";
            this.tabControl2.SelectedIndex = 0;
            this.tabControl2.Size = new System.Drawing.Size(443, 457);
            this.tabControl2.TabIndex = 1;
            this.tabControl2.Selected += new System.Windows.Forms.TabControlEventHandler(this.tabControl2_Selected);
            // 
            // tabPage1
            // 
            this.tabPage1.Controls.Add(this.btnSvcArgEdit);
            this.tabPage1.Controls.Add(this.btnSvcArgAdd);
            this.tabPage1.Controls.Add(this.groupBox7);
            this.tabPage1.Controls.Add(this.button3);
            this.tabPage1.Controls.Add(this.rbtSvcDisable);
            this.tabPage1.Controls.Add(this.rbtSvcEnable);
            this.tabPage1.Controls.Add(this.txtSvcAddressPath);
            this.tabPage1.Controls.Add(this.txtServiceName);
            this.tabPage1.Controls.Add(this.txtServiceCode);
            this.tabPage1.Controls.Add(this.label9);
            this.tabPage1.Controls.Add(this.label10);
            this.tabPage1.Controls.Add(this.label12);
            this.tabPage1.Controls.Add(this.cmbSvcOwnerType);
            this.tabPage1.Controls.Add(this.label11);
            this.tabPage1.Location = new System.Drawing.Point(4, 22);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(435, 431);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "基本信息";
            this.tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnSvcArgEdit
            // 
            this.btnSvcArgEdit.Location = new System.Drawing.Point(217, 156);
            this.btnSvcArgEdit.Name = "btnSvcArgEdit";
            this.btnSvcArgEdit.Size = new System.Drawing.Size(75, 23);
            this.btnSvcArgEdit.TabIndex = 20;
            this.btnSvcArgEdit.Text = "修改(&U)";
            this.btnSvcArgEdit.UseVisualStyleBackColor = true;
            this.btnSvcArgEdit.Click += new System.EventHandler(this.buttonEditSvcRegArg_Click);
            // 
            // btnSvcArgAdd
            // 
            this.btnSvcArgAdd.Location = new System.Drawing.Point(126, 156);
            this.btnSvcArgAdd.Name = "btnSvcArgAdd";
            this.btnSvcArgAdd.Size = new System.Drawing.Size(75, 23);
            this.btnSvcArgAdd.TabIndex = 19;
            this.btnSvcArgAdd.Text = "增加(&A)";
            this.btnSvcArgAdd.UseVisualStyleBackColor = true;
            this.btnSvcArgAdd.Click += new System.EventHandler(this.buttonAddSvcRegArg_Click);
            // 
            // groupBox7
            // 
            this.groupBox7.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox7.Controls.Add(this.dgSvcRegArg);
            this.groupBox7.Location = new System.Drawing.Point(6, 196);
            this.groupBox7.Name = "groupBox7";
            this.groupBox7.Size = new System.Drawing.Size(423, 229);
            this.groupBox7.TabIndex = 18;
            this.groupBox7.TabStop = false;
            this.groupBox7.Text = "参数列表";
            // 
            // dgSvcRegArg
            // 
            this.dgSvcRegArg.AllowUserToAddRows = false;
            this.dgSvcRegArg.AllowUserToDeleteRows = false;
            this.dgSvcRegArg.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgSvcRegArg.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle7.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle7.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle7.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle7.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle7.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSvcRegArg.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle7;
            this.dgSvcRegArg.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSvcRegArg.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn3,
            this.ID,
            this.dataGridViewTextBoxColumn4,
            this.Column4,
            this.OwnerType,
            this.Column5,
            this.Column6});
            this.dgSvcRegArg.ContextMenuStrip = this.cmSvcBizArg;
            dataGridViewCellStyle8.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle8.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle8.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle8.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle8.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle8.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgSvcRegArg.DefaultCellStyle = dataGridViewCellStyle8;
            this.dgSvcRegArg.Location = new System.Drawing.Point(6, 23);
            this.dgSvcRegArg.Name = "dgSvcRegArg";
            this.dgSvcRegArg.ReadOnly = true;
            dataGridViewCellStyle9.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle9.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle9.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle9.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle9.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle9.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSvcRegArg.RowHeadersDefaultCellStyle = dataGridViewCellStyle9;
            this.dgSvcRegArg.Size = new System.Drawing.Size(411, 200);
            this.dgSvcRegArg.TabIndex = 3;
            this.dgSvcRegArg.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSvcRegArg_CellClick);
            this.dgSvcRegArg.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSvcRegArg_CellMouseEnter);
            // 
            // dataGridViewTextBoxColumn3
            // 
            this.dataGridViewTextBoxColumn3.DataPropertyName = "ServiceCode";
            this.dataGridViewTextBoxColumn3.HeaderText = "服务程序名";
            this.dataGridViewTextBoxColumn3.Name = "dataGridViewTextBoxColumn3";
            this.dataGridViewTextBoxColumn3.ReadOnly = true;
            this.dataGridViewTextBoxColumn3.Width = 120;
            // 
            // ID
            // 
            this.ID.DataPropertyName = "ID";
            this.ID.HeaderText = "ID";
            this.ID.Name = "ID";
            this.ID.ReadOnly = true;
            this.ID.Visible = false;
            // 
            // dataGridViewTextBoxColumn4
            // 
            this.dataGridViewTextBoxColumn4.DataPropertyName = "ServiceName";
            this.dataGridViewTextBoxColumn4.HeaderText = "服务中文名";
            this.dataGridViewTextBoxColumn4.Name = "dataGridViewTextBoxColumn4";
            this.dataGridViewTextBoxColumn4.ReadOnly = true;
            this.dataGridViewTextBoxColumn4.Width = 150;
            // 
            // Column4
            // 
            this.Column4.DataPropertyName = "OwnerTypeName";
            this.Column4.HeaderText = "所属类型";
            this.Column4.Name = "Column4";
            this.Column4.ReadOnly = true;
            this.Column4.Width = 120;
            // 
            // OwnerType
            // 
            this.OwnerType.DataPropertyName = "OwnerType";
            this.OwnerType.HeaderText = "OwnerType";
            this.OwnerType.Name = "OwnerType";
            this.OwnerType.ReadOnly = true;
            this.OwnerType.Visible = false;
            // 
            // Column5
            // 
            this.Column5.DataPropertyName = "AddressPath";
            this.Column5.HeaderText = "程序集路径";
            this.Column5.Name = "Column5";
            this.Column5.ReadOnly = true;
            this.Column5.Width = 200;
            // 
            // Column6
            // 
            this.Column6.DataPropertyName = "Enabled";
            this.Column6.HeaderText = "启用";
            this.Column6.Name = "Column6";
            this.Column6.ReadOnly = true;
            this.Column6.Width = 70;
            // 
            // cmSvcBizArg
            // 
            this.cmSvcBizArg.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem3,
            this.toolStripMenuItem4});
            this.cmSvcBizArg.Name = "cmTreeView";
            this.cmSvcBizArg.Size = new System.Drawing.Size(115, 48);
            this.cmSvcBizArg.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmSvcRegArg_ItemClicked);
            // 
            // toolStripMenuItem3
            // 
            this.toolStripMenuItem3.Name = "toolStripMenuItem3";
            this.toolStripMenuItem3.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem3.Tag = "Refresh";
            this.toolStripMenuItem3.Text = "刷新(&R)";
            // 
            // toolStripMenuItem4
            // 
            this.toolStripMenuItem4.Name = "toolStripMenuItem4";
            this.toolStripMenuItem4.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem4.Tag = "Delete";
            this.toolStripMenuItem4.Text = "删除(&D)";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(307, 156);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 17;
            this.button3.Text = "下一歩(&N)";
            this.button3.UseVisualStyleBackColor = true;
            // 
            // rbtSvcDisable
            // 
            this.rbtSvcDisable.AutoSize = true;
            this.rbtSvcDisable.Location = new System.Drawing.Point(126, 126);
            this.rbtSvcDisable.Name = "rbtSvcDisable";
            this.rbtSvcDisable.Size = new System.Drawing.Size(63, 17);
            this.rbtSvcDisable.TabIndex = 16;
            this.rbtSvcDisable.TabStop = true;
            this.rbtSvcDisable.Text = "禁用(&D)";
            this.rbtSvcDisable.UseVisualStyleBackColor = true;
            // 
            // rbtSvcEnable
            // 
            this.rbtSvcEnable.AutoSize = true;
            this.rbtSvcEnable.Location = new System.Drawing.Point(44, 126);
            this.rbtSvcEnable.Name = "rbtSvcEnable";
            this.rbtSvcEnable.Size = new System.Drawing.Size(62, 17);
            this.rbtSvcEnable.TabIndex = 15;
            this.rbtSvcEnable.TabStop = true;
            this.rbtSvcEnable.Text = "启用(&E)";
            this.rbtSvcEnable.UseVisualStyleBackColor = true;
            // 
            // txtSvcAddressPath
            // 
            this.txtSvcAddressPath.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSvcAddressPath.Location = new System.Drawing.Point(92, 91);
            this.txtSvcAddressPath.Name = "txtSvcAddressPath";
            this.txtSvcAddressPath.Size = new System.Drawing.Size(322, 20);
            this.txtSvcAddressPath.TabIndex = 10;
            // 
            // txtServiceName
            // 
            this.txtServiceName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServiceName.Location = new System.Drawing.Point(92, 38);
            this.txtServiceName.Name = "txtServiceName";
            this.txtServiceName.Size = new System.Drawing.Size(322, 20);
            this.txtServiceName.TabIndex = 10;
            // 
            // txtServiceCode
            // 
            this.txtServiceCode.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtServiceCode.Location = new System.Drawing.Point(92, 10);
            this.txtServiceCode.Name = "txtServiceCode";
            this.txtServiceCode.Size = new System.Drawing.Size(322, 20);
            this.txtServiceCode.TabIndex = 11;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(19, 68);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(67, 13);
            this.label9.TabIndex = 8;
            this.label9.Text = "所属类型：";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(18, 14);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(79, 13);
            this.label10.TabIndex = 7;
            this.label10.Text = "服务程序名：";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(18, 94);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(79, 13);
            this.label12.TabIndex = 6;
            this.label12.Text = "程序集路径：";
            // 
            // cmbSvcOwnerType
            // 
            this.cmbSvcOwnerType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSvcOwnerType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSvcOwnerType.FormattingEnabled = true;
            this.cmbSvcOwnerType.Location = new System.Drawing.Point(92, 64);
            this.cmbSvcOwnerType.Name = "cmbSvcOwnerType";
            this.cmbSvcOwnerType.Size = new System.Drawing.Size(322, 21);
            this.cmbSvcOwnerType.TabIndex = 9;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(18, 41);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(79, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "服务中文名：";
            // 
            // tabPage2
            // 
            this.tabPage2.Controls.Add(this.cmbBaseSvcArg);
            this.tabPage2.Controls.Add(this.label27);
            this.tabPage2.Controls.Add(this.button2);
            this.tabPage2.Controls.Add(this.button1);
            this.tabPage2.Controls.Add(this.groupBox13);
            this.tabPage2.Controls.Add(this.cmbBindType);
            this.tabPage2.Controls.Add(this.rbtSvcClassDisable);
            this.tabPage2.Controls.Add(this.rbtSvcClassEnable);
            this.tabPage2.Controls.Add(this.button4);
            this.tabPage2.Controls.Add(this.label15);
            this.tabPage2.Controls.Add(this.txtSvcArgMemo);
            this.tabPage2.Controls.Add(this.txtSvcArgBaseAddress);
            this.tabPage2.Controls.Add(this.label18);
            this.tabPage2.Controls.Add(this.label17);
            this.tabPage2.Controls.Add(this.label16);
            this.tabPage2.Controls.Add(this.txtSvcArgNameSpace);
            this.tabPage2.Controls.Add(this.label14);
            this.tabPage2.Controls.Add(this.txtSvcArgClassName);
            this.tabPage2.Controls.Add(this.label13);
            this.tabPage2.Location = new System.Drawing.Point(4, 22);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(435, 431);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "服务类参数";
            this.tabPage2.UseVisualStyleBackColor = true;
            // 
            // cmbBaseSvcArg
            // 
            this.cmbBaseSvcArg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbBaseSvcArg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBaseSvcArg.FormattingEnabled = true;
            this.cmbBaseSvcArg.Location = new System.Drawing.Point(94, 7);
            this.cmbBaseSvcArg.Name = "cmbBaseSvcArg";
            this.cmbBaseSvcArg.Size = new System.Drawing.Size(305, 21);
            this.cmbBaseSvcArg.TabIndex = 25;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(17, 11);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(67, 13);
            this.label27.TabIndex = 24;
            this.label27.Text = "服务名称：";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(241, 169);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 23;
            this.button2.Text = "修改(&U)";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.buttonEditSvcRegArgDetail_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(156, 169);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 22;
            this.button1.Text = "增加(&A)";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.buttonAddSvcRegArgDetail_Click);
            // 
            // groupBox13
            // 
            this.groupBox13.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox13.Controls.Add(this.dgSvcRegArgDetail);
            this.groupBox13.Location = new System.Drawing.Point(6, 196);
            this.groupBox13.Name = "groupBox13";
            this.groupBox13.Size = new System.Drawing.Size(423, 229);
            this.groupBox13.TabIndex = 21;
            this.groupBox13.TabStop = false;
            this.groupBox13.Text = "参数列表";
            // 
            // dgSvcRegArgDetail
            // 
            this.dgSvcRegArgDetail.AllowUserToAddRows = false;
            this.dgSvcRegArgDetail.AllowUserToDeleteRows = false;
            this.dgSvcRegArgDetail.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgSvcRegArgDetail.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle10.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle10.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle10.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle10.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle10.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle10.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSvcRegArgDetail.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle10;
            this.dgSvcRegArgDetail.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSvcRegArgDetail.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn11,
            this.Column9,
            this.dataGridViewTextBoxColumn14,
            this.dataGridViewTextBoxColumn13,
            this.dataGridViewTextBoxColumn15,
            this.Column8,
            this.BaseAddress,
            this.ServiceID,
            this.Memo,
            this.dataGridViewCheckBoxColumn2});
            this.dgSvcRegArgDetail.ContextMenuStrip = this.cmSvcClassArg;
            dataGridViewCellStyle11.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle11.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle11.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle11.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle11.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle11.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgSvcRegArgDetail.DefaultCellStyle = dataGridViewCellStyle11;
            this.dgSvcRegArgDetail.Location = new System.Drawing.Point(6, 23);
            this.dgSvcRegArgDetail.Name = "dgSvcRegArgDetail";
            this.dgSvcRegArgDetail.ReadOnly = true;
            dataGridViewCellStyle12.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle12.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle12.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle12.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle12.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle12.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSvcRegArgDetail.RowHeadersDefaultCellStyle = dataGridViewCellStyle12;
            this.dgSvcRegArgDetail.Size = new System.Drawing.Size(411, 200);
            this.dgSvcRegArgDetail.TabIndex = 3;
            this.dgSvcRegArgDetail.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSvcRegArgDetail_CellClick);
            this.dgSvcRegArgDetail.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSvcRegArgDetail_CellMouseEnter);
            // 
            // dataGridViewTextBoxColumn11
            // 
            this.dataGridViewTextBoxColumn11.DataPropertyName = "ServiceName";
            this.dataGridViewTextBoxColumn11.HeaderText = "服务器名称";
            this.dataGridViewTextBoxColumn11.Name = "dataGridViewTextBoxColumn11";
            this.dataGridViewTextBoxColumn11.ReadOnly = true;
            this.dataGridViewTextBoxColumn11.Width = 120;
            // 
            // Column9
            // 
            this.Column9.DataPropertyName = "EndPointBinding";
            this.Column9.HeaderText = "EndPointBinding";
            this.Column9.Name = "Column9";
            this.Column9.ReadOnly = true;
            this.Column9.Visible = false;
            // 
            // dataGridViewTextBoxColumn14
            // 
            this.dataGridViewTextBoxColumn14.DataPropertyName = "NameSpace";
            this.dataGridViewTextBoxColumn14.HeaderText = "命名空间";
            this.dataGridViewTextBoxColumn14.Name = "dataGridViewTextBoxColumn14";
            this.dataGridViewTextBoxColumn14.ReadOnly = true;
            this.dataGridViewTextBoxColumn14.Width = 120;
            // 
            // dataGridViewTextBoxColumn13
            // 
            this.dataGridViewTextBoxColumn13.DataPropertyName = "ClassName";
            this.dataGridViewTextBoxColumn13.HeaderText = "服务类名称";
            this.dataGridViewTextBoxColumn13.Name = "dataGridViewTextBoxColumn13";
            this.dataGridViewTextBoxColumn13.ReadOnly = true;
            this.dataGridViewTextBoxColumn13.Width = 150;
            // 
            // dataGridViewTextBoxColumn15
            // 
            this.dataGridViewTextBoxColumn15.DataPropertyName = "EndPointBindingName";
            this.dataGridViewTextBoxColumn15.HeaderText = "服务绑定方式";
            this.dataGridViewTextBoxColumn15.Name = "dataGridViewTextBoxColumn15";
            this.dataGridViewTextBoxColumn15.ReadOnly = true;
            this.dataGridViewTextBoxColumn15.Width = 200;
            // 
            // Column8
            // 
            this.Column8.DataPropertyName = "ID";
            this.Column8.HeaderText = "ID";
            this.Column8.Name = "Column8";
            this.Column8.ReadOnly = true;
            this.Column8.Visible = false;
            // 
            // BaseAddress
            // 
            this.BaseAddress.DataPropertyName = "BaseAddress";
            this.BaseAddress.HeaderText = "相对地址";
            this.BaseAddress.Name = "BaseAddress";
            this.BaseAddress.ReadOnly = true;
            // 
            // ServiceID
            // 
            this.ServiceID.DataPropertyName = "ServiceID";
            this.ServiceID.HeaderText = "ServiceID";
            this.ServiceID.Name = "ServiceID";
            this.ServiceID.ReadOnly = true;
            this.ServiceID.Visible = false;
            // 
            // Memo
            // 
            this.Memo.DataPropertyName = "Memo";
            this.Memo.HeaderText = "备注";
            this.Memo.Name = "Memo";
            this.Memo.ReadOnly = true;
            // 
            // dataGridViewCheckBoxColumn2
            // 
            this.dataGridViewCheckBoxColumn2.DataPropertyName = "Enabled";
            this.dataGridViewCheckBoxColumn2.HeaderText = "启用";
            this.dataGridViewCheckBoxColumn2.Name = "dataGridViewCheckBoxColumn2";
            this.dataGridViewCheckBoxColumn2.ReadOnly = true;
            this.dataGridViewCheckBoxColumn2.Width = 70;
            // 
            // cmSvcClassArg
            // 
            this.cmSvcClassArg.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem7,
            this.toolStripMenuItem8});
            this.cmSvcClassArg.Name = "cmTreeView";
            this.cmSvcClassArg.Size = new System.Drawing.Size(115, 48);
            this.cmSvcClassArg.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmSvcRegArgDetail_ItemClicked);
            // 
            // toolStripMenuItem7
            // 
            this.toolStripMenuItem7.Name = "toolStripMenuItem7";
            this.toolStripMenuItem7.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem7.Tag = "Refresh";
            this.toolStripMenuItem7.Text = "刷新(&R)";
            // 
            // toolStripMenuItem8
            // 
            this.toolStripMenuItem8.Name = "toolStripMenuItem8";
            this.toolStripMenuItem8.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem8.Tag = "Delete";
            this.toolStripMenuItem8.Text = "删除(&D)";
            // 
            // cmbBindType
            // 
            this.cmbBindType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbBindType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbBindType.FormattingEnabled = true;
            this.cmbBindType.Location = new System.Drawing.Point(103, 81);
            this.cmbBindType.Name = "cmbBindType";
            this.cmbBindType.Size = new System.Drawing.Size(296, 21);
            this.cmbBindType.TabIndex = 15;
            // 
            // rbtSvcClassDisable
            // 
            this.rbtSvcClassDisable.AutoSize = true;
            this.rbtSvcClassDisable.Location = new System.Drawing.Point(86, 168);
            this.rbtSvcClassDisable.Name = "rbtSvcClassDisable";
            this.rbtSvcClassDisable.Size = new System.Drawing.Size(63, 17);
            this.rbtSvcClassDisable.TabIndex = 20;
            this.rbtSvcClassDisable.TabStop = true;
            this.rbtSvcClassDisable.Text = "禁用(&D)";
            this.rbtSvcClassDisable.UseVisualStyleBackColor = true;
            // 
            // rbtSvcClassEnable
            // 
            this.rbtSvcClassEnable.AutoSize = true;
            this.rbtSvcClassEnable.Location = new System.Drawing.Point(18, 167);
            this.rbtSvcClassEnable.Name = "rbtSvcClassEnable";
            this.rbtSvcClassEnable.Size = new System.Drawing.Size(62, 17);
            this.rbtSvcClassEnable.TabIndex = 19;
            this.rbtSvcClassEnable.TabStop = true;
            this.rbtSvcClassEnable.Text = "启用(&E)";
            this.rbtSvcClassEnable.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            this.button4.Location = new System.Drawing.Point(324, 170);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(75, 23);
            this.button4.TabIndex = 18;
            this.button4.Text = "下一歩(&N)";
            this.button4.UseVisualStyleBackColor = true;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(14, 86);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(91, 13);
            this.label15.TabIndex = 14;
            this.label15.Text = "服务绑定方式：";
            // 
            // txtSvcArgMemo
            // 
            this.txtSvcArgMemo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSvcArgMemo.Location = new System.Drawing.Point(88, 132);
            this.txtSvcArgMemo.Multiline = true;
            this.txtSvcArgMemo.Name = "txtSvcArgMemo";
            this.txtSvcArgMemo.Size = new System.Drawing.Size(311, 30);
            this.txtSvcArgMemo.TabIndex = 13;
            // 
            // txtSvcArgBaseAddress
            // 
            this.txtSvcArgBaseAddress.Location = new System.Drawing.Point(88, 108);
            this.txtSvcArgBaseAddress.Name = "txtSvcArgBaseAddress";
            this.txtSvcArgBaseAddress.Size = new System.Drawing.Size(133, 20);
            this.txtSvcArgBaseAddress.TabIndex = 13;
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(13, 135);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(67, 13);
            this.label18.TabIndex = 12;
            this.label18.Text = "说明备注：";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(228, 111);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(157, 13);
            this.label17.TabIndex = 12;
            this.label17.Text = "(如果为空，则默认为类名称)";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(13, 110);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(67, 13);
            this.label16.TabIndex = 12;
            this.label16.Text = "相对地址：";
            // 
            // txtSvcArgNameSpace
            // 
            this.txtSvcArgNameSpace.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSvcArgNameSpace.Location = new System.Drawing.Point(93, 55);
            this.txtSvcArgNameSpace.Name = "txtSvcArgNameSpace";
            this.txtSvcArgNameSpace.Size = new System.Drawing.Size(306, 20);
            this.txtSvcArgNameSpace.TabIndex = 13;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(14, 59);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(79, 13);
            this.label14.TabIndex = 12;
            this.label14.Text = "类命名空间：";
            // 
            // txtSvcArgClassName
            // 
            this.txtSvcArgClassName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSvcArgClassName.Location = new System.Drawing.Point(92, 32);
            this.txtSvcArgClassName.Name = "txtSvcArgClassName";
            this.txtSvcArgClassName.Size = new System.Drawing.Size(307, 20);
            this.txtSvcArgClassName.TabIndex = 13;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(14, 36);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 13);
            this.label13.TabIndex = 12;
            this.label13.Text = "服务类名称：";
            // 
            // tabPage3
            // 
            this.tabPage3.Controls.Add(this.cmbSvcClassArg);
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Controls.Add(this.button9);
            this.tabPage3.Controls.Add(this.button11);
            this.tabPage3.Controls.Add(this.groupBox14);
            this.tabPage3.Controls.Add(this.rbtSvcInterfaceDisable);
            this.tabPage3.Controls.Add(this.rbtSvcInterfaceEnable);
            this.tabPage3.Controls.Add(this.txtSvcInterfaceMemo);
            this.tabPage3.Controls.Add(this.label21);
            this.tabPage3.Controls.Add(this.cmbDataType);
            this.tabPage3.Controls.Add(this.label20);
            this.tabPage3.Controls.Add(this.txtSvcInterfaceName);
            this.tabPage3.Controls.Add(this.label19);
            this.tabPage3.Controls.Add(this.button5);
            this.tabPage3.Location = new System.Drawing.Point(4, 22);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(435, 431);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "服务接口参数";
            this.tabPage3.UseVisualStyleBackColor = true;
            // 
            // cmbSvcClassArg
            // 
            this.cmbSvcClassArg.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbSvcClassArg.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbSvcClassArg.FormattingEnabled = true;
            this.cmbSvcClassArg.Location = new System.Drawing.Point(99, 6);
            this.cmbSvcClassArg.Name = "cmbSvcClassArg";
            this.cmbSvcClassArg.Size = new System.Drawing.Size(311, 21);
            this.cmbSvcClassArg.TabIndex = 31;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(24, 10);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(67, 13);
            this.label28.TabIndex = 30;
            this.label28.Text = "服务名称：";
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(223, 167);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 29;
            this.button9.Text = "修改(&U)";
            this.button9.UseVisualStyleBackColor = true;
            this.button9.Click += new System.EventHandler(this.buttonEditSvcInterface_Click);
            // 
            // button11
            // 
            this.button11.Location = new System.Drawing.Point(136, 167);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(75, 23);
            this.button11.TabIndex = 28;
            this.button11.Text = "增加(&A)";
            this.button11.UseVisualStyleBackColor = true;
            this.button11.Click += new System.EventHandler(this.buttonAddSvcInterface_Click);
            // 
            // groupBox14
            // 
            this.groupBox14.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox14.Controls.Add(this.dgSvcInterface);
            this.groupBox14.Location = new System.Drawing.Point(6, 196);
            this.groupBox14.Name = "groupBox14";
            this.groupBox14.Size = new System.Drawing.Size(423, 229);
            this.groupBox14.TabIndex = 27;
            this.groupBox14.TabStop = false;
            this.groupBox14.Text = "参数列表";
            // 
            // dgSvcInterface
            // 
            this.dgSvcInterface.AllowUserToAddRows = false;
            this.dgSvcInterface.AllowUserToDeleteRows = false;
            this.dgSvcInterface.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgSvcInterface.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle13.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle13.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle13.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle13.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle13.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle13.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSvcInterface.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle13;
            this.dgSvcInterface.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgSvcInterface.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn16,
            this.dataGridViewTextBoxColumn17,
            this.dataGridViewTextBoxColumn19,
            this.Column10,
            this.Column11,
            this.Column12,
            this.dataGridViewCheckBoxColumn3,
            this.dataGridViewTextBoxColumn18});
            this.dgSvcInterface.ContextMenuStrip = this.cmSvcInterface;
            dataGridViewCellStyle14.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle14.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle14.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle14.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle14.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle14.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgSvcInterface.DefaultCellStyle = dataGridViewCellStyle14;
            this.dgSvcInterface.Location = new System.Drawing.Point(6, 23);
            this.dgSvcInterface.Name = "dgSvcInterface";
            this.dgSvcInterface.ReadOnly = true;
            dataGridViewCellStyle15.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle15.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle15.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle15.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle15.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle15.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgSvcInterface.RowHeadersDefaultCellStyle = dataGridViewCellStyle15;
            this.dgSvcInterface.Size = new System.Drawing.Size(411, 200);
            this.dgSvcInterface.TabIndex = 3;
            this.dgSvcInterface.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSvcInterface_CellClick);
            this.dgSvcInterface.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgSvcInterface_CellMouseEnter);
            // 
            // rbtSvcInterfaceDisable
            // 
            this.rbtSvcInterfaceDisable.AutoSize = true;
            this.rbtSvcInterfaceDisable.Location = new System.Drawing.Point(175, 142);
            this.rbtSvcInterfaceDisable.Name = "rbtSvcInterfaceDisable";
            this.rbtSvcInterfaceDisable.Size = new System.Drawing.Size(63, 17);
            this.rbtSvcInterfaceDisable.TabIndex = 26;
            this.rbtSvcInterfaceDisable.TabStop = true;
            this.rbtSvcInterfaceDisable.Text = "禁用(&D)";
            this.rbtSvcInterfaceDisable.UseVisualStyleBackColor = true;
            // 
            // rbtSvcInterfaceEnable
            // 
            this.rbtSvcInterfaceEnable.AutoSize = true;
            this.rbtSvcInterfaceEnable.Location = new System.Drawing.Point(99, 142);
            this.rbtSvcInterfaceEnable.Name = "rbtSvcInterfaceEnable";
            this.rbtSvcInterfaceEnable.Size = new System.Drawing.Size(62, 17);
            this.rbtSvcInterfaceEnable.TabIndex = 25;
            this.rbtSvcInterfaceEnable.TabStop = true;
            this.rbtSvcInterfaceEnable.Text = "启用(&E)";
            this.rbtSvcInterfaceEnable.UseVisualStyleBackColor = true;
            // 
            // txtSvcInterfaceMemo
            // 
            this.txtSvcInterfaceMemo.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSvcInterfaceMemo.Location = new System.Drawing.Point(99, 88);
            this.txtSvcInterfaceMemo.Multiline = true;
            this.txtSvcInterfaceMemo.Name = "txtSvcInterfaceMemo";
            this.txtSvcInterfaceMemo.Size = new System.Drawing.Size(311, 46);
            this.txtSvcInterfaceMemo.TabIndex = 24;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(13, 94);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(67, 13);
            this.label21.TabIndex = 23;
            this.label21.Text = "说明备注：";
            // 
            // cmbDataType
            // 
            this.cmbDataType.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.cmbDataType.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbDataType.FormattingEnabled = true;
            this.cmbDataType.Location = new System.Drawing.Point(99, 61);
            this.cmbDataType.Name = "cmbDataType";
            this.cmbDataType.Size = new System.Drawing.Size(311, 21);
            this.cmbDataType.TabIndex = 22;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(13, 62);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(91, 13);
            this.label20.TabIndex = 20;
            this.label20.Text = "返回数据格式：";
            // 
            // txtSvcInterfaceName
            // 
            this.txtSvcInterfaceName.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.txtSvcInterfaceName.Location = new System.Drawing.Point(99, 35);
            this.txtSvcInterfaceName.Name = "txtSvcInterfaceName";
            this.txtSvcInterfaceName.Size = new System.Drawing.Size(311, 20);
            this.txtSvcInterfaceName.TabIndex = 21;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(13, 37);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(91, 13);
            this.label19.TabIndex = 20;
            this.label19.Text = "服务接口名称：";
            // 
            // button5
            // 
            this.button5.Location = new System.Drawing.Point(307, 167);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(75, 23);
            this.button5.TabIndex = 19;
            this.button5.Text = "设置(&S)";
            this.button5.UseVisualStyleBackColor = true;
            // 
            // tpSvcBizArg
            // 
            this.tpSvcBizArg.Controls.Add(this.groupBox9);
            this.tpSvcBizArg.Location = new System.Drawing.Point(4, 22);
            this.tpSvcBizArg.Name = "tpSvcBizArg";
            this.tpSvcBizArg.Padding = new System.Windows.Forms.Padding(3);
            this.tpSvcBizArg.Size = new System.Drawing.Size(464, 492);
            this.tpSvcBizArg.TabIndex = 4;
            this.tpSvcBizArg.Text = "服务业务参数";
            this.tpSvcBizArg.UseVisualStyleBackColor = true;
            // 
            // groupBox9
            // 
            this.groupBox9.Controls.Add(this.tabControl3);
            this.groupBox9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupBox9.Location = new System.Drawing.Point(3, 3);
            this.groupBox9.Name = "groupBox9";
            this.groupBox9.Size = new System.Drawing.Size(458, 486);
            this.groupBox9.TabIndex = 0;
            this.groupBox9.TabStop = false;
            // 
            // tabControl3
            // 
            this.tabControl3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.tabControl3.Controls.Add(this.tabPage4);
            this.tabControl3.Controls.Add(this.tabPage5);
            this.tabControl3.Controls.Add(this.tabPage6);
            this.tabControl3.Location = new System.Drawing.Point(6, 12);
            this.tabControl3.Name = "tabControl3";
            this.tabControl3.SelectedIndex = 0;
            this.tabControl3.Size = new System.Drawing.Size(449, 468);
            this.tabControl3.TabIndex = 0;
            // 
            // tabPage4
            // 
            this.tabPage4.Controls.Add(this.comboBox5);
            this.tabPage4.Controls.Add(this.groupBox10);
            this.tabPage4.Controls.Add(this.textBox16);
            this.tabPage4.Controls.Add(this.label26);
            this.tabPage4.Controls.Add(this.button7);
            this.tabPage4.Controls.Add(this.button6);
            this.tabPage4.Controls.Add(this.label25);
            this.tabPage4.Controls.Add(this.textBox15);
            this.tabPage4.Controls.Add(this.label24);
            this.tabPage4.Controls.Add(this.textBox14);
            this.tabPage4.Controls.Add(this.label23);
            this.tabPage4.Controls.Add(this.textBox13);
            this.tabPage4.Controls.Add(this.label22);
            this.tabPage4.Location = new System.Drawing.Point(4, 22);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(441, 442);
            this.tabPage4.TabIndex = 0;
            this.tabPage4.Text = "业务参数管理";
            this.tabPage4.UseVisualStyleBackColor = true;
            // 
            // comboBox5
            // 
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Location = new System.Drawing.Point(75, 93);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(211, 21);
            this.comboBox5.TabIndex = 17;
            // 
            // groupBox10
            // 
            this.groupBox10.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox10.Controls.Add(this.dataGridView2);
            this.groupBox10.Location = new System.Drawing.Point(5, 169);
            this.groupBox10.Name = "groupBox10";
            this.groupBox10.Size = new System.Drawing.Size(429, 266);
            this.groupBox10.TabIndex = 21;
            this.groupBox10.TabStop = false;
            this.groupBox10.Text = "参数列表";
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView2.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle16.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle16.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle16.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle16.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle16.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle16.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle16;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn5,
            this.dataGridViewTextBoxColumn6,
            this.dataGridViewTextBoxColumn7,
            this.dataGridViewTextBoxColumn8,
            this.dataGridViewCheckBoxColumn1});
            this.dataGridView2.ContextMenuStrip = this.cmSvcBizArg;
            dataGridViewCellStyle17.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle17.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle17.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle17.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle17.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle17.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle17.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView2.DefaultCellStyle = dataGridViewCellStyle17;
            this.dataGridView2.Location = new System.Drawing.Point(6, 19);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            dataGridViewCellStyle18.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle18.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle18.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle18.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle18.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle18.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView2.RowHeadersDefaultCellStyle = dataGridViewCellStyle18;
            this.dataGridView2.Size = new System.Drawing.Size(417, 241);
            this.dataGridView2.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn5
            // 
            this.dataGridViewTextBoxColumn5.HeaderText = "服务程序名";
            this.dataGridViewTextBoxColumn5.Name = "dataGridViewTextBoxColumn5";
            this.dataGridViewTextBoxColumn5.ReadOnly = true;
            this.dataGridViewTextBoxColumn5.Width = 120;
            // 
            // dataGridViewTextBoxColumn6
            // 
            this.dataGridViewTextBoxColumn6.HeaderText = "服务中文名";
            this.dataGridViewTextBoxColumn6.Name = "dataGridViewTextBoxColumn6";
            this.dataGridViewTextBoxColumn6.ReadOnly = true;
            this.dataGridViewTextBoxColumn6.Width = 150;
            // 
            // dataGridViewTextBoxColumn7
            // 
            this.dataGridViewTextBoxColumn7.HeaderText = "所属类型";
            this.dataGridViewTextBoxColumn7.Name = "dataGridViewTextBoxColumn7";
            this.dataGridViewTextBoxColumn7.ReadOnly = true;
            this.dataGridViewTextBoxColumn7.Width = 120;
            // 
            // dataGridViewTextBoxColumn8
            // 
            this.dataGridViewTextBoxColumn8.HeaderText = "程序集路径";
            this.dataGridViewTextBoxColumn8.Name = "dataGridViewTextBoxColumn8";
            this.dataGridViewTextBoxColumn8.ReadOnly = true;
            this.dataGridViewTextBoxColumn8.Width = 200;
            // 
            // dataGridViewCheckBoxColumn1
            // 
            this.dataGridViewCheckBoxColumn1.HeaderText = "启用";
            this.dataGridViewCheckBoxColumn1.Name = "dataGridViewCheckBoxColumn1";
            this.dataGridViewCheckBoxColumn1.ReadOnly = true;
            this.dataGridViewCheckBoxColumn1.Width = 70;
            // 
            // textBox16
            // 
            this.textBox16.Location = new System.Drawing.Point(75, 120);
            this.textBox16.Multiline = true;
            this.textBox16.Name = "textBox16";
            this.textBox16.Size = new System.Drawing.Size(211, 44);
            this.textBox16.TabIndex = 20;
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(10, 123);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(67, 13);
            this.label26.TabIndex = 19;
            this.label26.Text = "说明备注：";
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(314, 141);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 18;
            this.button7.Text = "保存(&S)";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            this.button6.Location = new System.Drawing.Point(295, 91);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(100, 23);
            this.button6.TabIndex = 18;
            this.button6.Text = "管理分类(&M)";
            this.button6.UseVisualStyleBackColor = true;
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(10, 96);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(67, 13);
            this.label25.TabIndex = 16;
            this.label25.Text = "所属分类：";
            // 
            // textBox15
            // 
            this.textBox15.Location = new System.Drawing.Point(75, 67);
            this.textBox15.Name = "textBox15";
            this.textBox15.Size = new System.Drawing.Size(323, 20);
            this.textBox15.TabIndex = 13;
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(10, 69);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(67, 13);
            this.label24.TabIndex = 12;
            this.label24.Text = "参数键值：";
            // 
            // textBox14
            // 
            this.textBox14.Location = new System.Drawing.Point(75, 41);
            this.textBox14.Name = "textBox14";
            this.textBox14.Size = new System.Drawing.Size(323, 20);
            this.textBox14.TabIndex = 13;
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(10, 43);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(67, 13);
            this.label23.TabIndex = 12;
            this.label23.Text = "参数键名：";
            // 
            // textBox13
            // 
            this.textBox13.Location = new System.Drawing.Point(75, 15);
            this.textBox13.Name = "textBox13";
            this.textBox13.Size = new System.Drawing.Size(323, 20);
            this.textBox13.TabIndex = 13;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(10, 17);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(67, 13);
            this.label22.TabIndex = 12;
            this.label22.Text = "中文名称：";
            // 
            // tabPage5
            // 
            this.tabPage5.Controls.Add(this.button8);
            this.tabPage5.Controls.Add(this.groupBox11);
            this.tabPage5.Controls.Add(this.textBox20);
            this.tabPage5.Controls.Add(this.label31);
            this.tabPage5.Location = new System.Drawing.Point(4, 22);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(441, 442);
            this.tabPage5.TabIndex = 1;
            this.tabPage5.Text = "参数分类管理";
            this.tabPage5.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(317, 37);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(83, 23);
            this.button8.TabIndex = 34;
            this.button8.Text = "保存(&S)";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // groupBox11
            // 
            this.groupBox11.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox11.Controls.Add(this.dataGridView3);
            this.groupBox11.Location = new System.Drawing.Point(6, 66);
            this.groupBox11.Name = "groupBox11";
            this.groupBox11.Size = new System.Drawing.Size(430, 366);
            this.groupBox11.TabIndex = 33;
            this.groupBox11.TabStop = false;
            this.groupBox11.Text = "参数列表";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView3.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle19.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle19.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle19.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle19.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle19.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle19.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle19;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn12});
            this.dataGridView3.ContextMenuStrip = this.cmSvcClsArg;
            dataGridViewCellStyle20.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle20.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle20.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle20.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle20.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle20.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle20.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridView3.DefaultCellStyle = dataGridViewCellStyle20;
            this.dataGridView3.Location = new System.Drawing.Point(6, 19);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            dataGridViewCellStyle21.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle21.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle21.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle21.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle21.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle21.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle21.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView3.RowHeadersDefaultCellStyle = dataGridViewCellStyle21;
            this.dataGridView3.Size = new System.Drawing.Size(418, 341);
            this.dataGridView3.TabIndex = 4;
            // 
            // dataGridViewTextBoxColumn12
            // 
            this.dataGridViewTextBoxColumn12.HeaderText = "参数分类名称";
            this.dataGridViewTextBoxColumn12.Name = "dataGridViewTextBoxColumn12";
            this.dataGridViewTextBoxColumn12.ReadOnly = true;
            this.dataGridViewTextBoxColumn12.Width = 300;
            // 
            // cmSvcClsArg
            // 
            this.cmSvcClsArg.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem5,
            this.toolStripMenuItem6});
            this.cmSvcClsArg.Name = "cmTreeView";
            this.cmSvcClsArg.Size = new System.Drawing.Size(115, 48);
            // 
            // toolStripMenuItem5
            // 
            this.toolStripMenuItem5.Name = "toolStripMenuItem5";
            this.toolStripMenuItem5.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem5.Text = "刷新(&R)";
            // 
            // toolStripMenuItem6
            // 
            this.toolStripMenuItem6.Name = "toolStripMenuItem6";
            this.toolStripMenuItem6.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem6.Text = "删除(&D)";
            // 
            // textBox20
            // 
            this.textBox20.Location = new System.Drawing.Point(79, 11);
            this.textBox20.Name = "textBox20";
            this.textBox20.Size = new System.Drawing.Size(321, 20);
            this.textBox20.TabIndex = 26;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(14, 13);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(67, 13);
            this.label31.TabIndex = 24;
            this.label31.Text = "分类名称：";
            // 
            // tabPage6
            // 
            this.tabPage6.Controls.Add(this.groupBox12);
            this.tabPage6.Location = new System.Drawing.Point(4, 22);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(441, 442);
            this.tabPage6.TabIndex = 2;
            this.tabPage6.Text = "日志查询";
            this.tabPage6.UseVisualStyleBackColor = true;
            // 
            // groupBox12
            // 
            this.groupBox12.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox12.Controls.Add(this.button10);
            this.groupBox12.Controls.Add(this.dgvBizLog);
            this.groupBox12.Location = new System.Drawing.Point(6, 6);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(429, 430);
            this.groupBox12.TabIndex = 6;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "日志";
            // 
            // button10
            // 
            this.button10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button10.Location = new System.Drawing.Point(321, 401);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(102, 23);
            this.button10.TabIndex = 1;
            this.button10.Tag = "1";
            this.button10.Text = "查找日志(&F)";
            this.button10.UseVisualStyleBackColor = true;
            this.button10.Click += new System.EventHandler(this.btnSearchLog_Click);
            // 
            // dgvBizLog
            // 
            this.dgvBizLog.AllowUserToAddRows = false;
            this.dgvBizLog.AllowUserToDeleteRows = false;
            this.dgvBizLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dgvBizLog.BackgroundColor = System.Drawing.Color.White;
            dataGridViewCellStyle22.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle22.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle22.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle22.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle22.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle22.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBizLog.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle22;
            this.dgvBizLog.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvBizLog.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dataGridViewTextBoxColumn9,
            this.dataGridViewTextBoxColumn10,
            this.Column7});
            dataGridViewCellStyle23.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle23.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle23.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle23.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle23.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle23.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dgvBizLog.DefaultCellStyle = dataGridViewCellStyle23;
            this.dgvBizLog.Location = new System.Drawing.Point(10, 19);
            this.dgvBizLog.Name = "dgvBizLog";
            this.dgvBizLog.ReadOnly = true;
            dataGridViewCellStyle24.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle24.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            dataGridViewCellStyle24.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle24.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle24.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle24.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvBizLog.RowHeadersDefaultCellStyle = dataGridViewCellStyle24;
            this.dgvBizLog.Size = new System.Drawing.Size(410, 376);
            this.dgvBizLog.TabIndex = 2;
            // 
            // dataGridViewTextBoxColumn9
            // 
            this.dataGridViewTextBoxColumn9.DataPropertyName = "LogTime";
            this.dataGridViewTextBoxColumn9.HeaderText = "发生时间";
            this.dataGridViewTextBoxColumn9.Name = "dataGridViewTextBoxColumn9";
            this.dataGridViewTextBoxColumn9.ReadOnly = true;
            this.dataGridViewTextBoxColumn9.Width = 80;
            // 
            // dataGridViewTextBoxColumn10
            // 
            this.dataGridViewTextBoxColumn10.DataPropertyName = "LogInfo";
            this.dataGridViewTextBoxColumn10.HeaderText = "日志信息";
            this.dataGridViewTextBoxColumn10.Name = "dataGridViewTextBoxColumn10";
            this.dataGridViewTextBoxColumn10.ReadOnly = true;
            this.dataGridViewTextBoxColumn10.Width = 500;
            // 
            // Column7
            // 
            this.Column7.DataPropertyName = "LogType";
            this.Column7.HeaderText = "日志类型";
            this.Column7.Name = "Column7";
            this.Column7.ReadOnly = true;
            // 
            // cmSvcTreeView
            // 
            this.cmSvcTreeView.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuRefSvcTV,
            this.mnuColSvcTV,
            this.mnuExpSvcTV});
            this.cmSvcTreeView.Name = "cmTreeView";
            this.cmSvcTreeView.Size = new System.Drawing.Size(115, 70);
            // 
            // mnuRefSvcTV
            // 
            this.mnuRefSvcTV.Name = "mnuRefSvcTV";
            this.mnuRefSvcTV.Size = new System.Drawing.Size(114, 22);
            this.mnuRefSvcTV.Text = "刷新(&R)";
            // 
            // mnuColSvcTV
            // 
            this.mnuColSvcTV.Name = "mnuColSvcTV";
            this.mnuColSvcTV.Size = new System.Drawing.Size(114, 22);
            this.mnuColSvcTV.Text = "收缩(&C)";
            // 
            // mnuExpSvcTV
            // 
            this.mnuExpSvcTV.Name = "mnuExpSvcTV";
            this.mnuExpSvcTV.Size = new System.Drawing.Size(114, 22);
            this.mnuExpSvcTV.Text = "展开(&E)";
            // 
            // cmSvcInterface
            // 
            this.cmSvcInterface.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.toolStripMenuItem9,
            this.toolStripMenuItem10});
            this.cmSvcInterface.Name = "cmTreeView";
            this.cmSvcInterface.Size = new System.Drawing.Size(115, 48);
            this.cmSvcInterface.ItemClicked += new System.Windows.Forms.ToolStripItemClickedEventHandler(this.cmSvcInterface_ItemClicked);
            // 
            // toolStripMenuItem9
            // 
            this.toolStripMenuItem9.Name = "toolStripMenuItem9";
            this.toolStripMenuItem9.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem9.Tag = "Refresh";
            this.toolStripMenuItem9.Text = "刷新(&R)";
            // 
            // toolStripMenuItem10
            // 
            this.toolStripMenuItem10.Name = "toolStripMenuItem10";
            this.toolStripMenuItem10.Size = new System.Drawing.Size(114, 22);
            this.toolStripMenuItem10.Tag = "Delete";
            this.toolStripMenuItem10.Text = "删除(&D)";
            // 
            // dataGridViewTextBoxColumn16
            // 
            this.dataGridViewTextBoxColumn16.DataPropertyName = "InterfaceName";
            this.dataGridViewTextBoxColumn16.HeaderText = "接口名称";
            this.dataGridViewTextBoxColumn16.Name = "dataGridViewTextBoxColumn16";
            this.dataGridViewTextBoxColumn16.ReadOnly = true;
            this.dataGridViewTextBoxColumn16.Width = 120;
            // 
            // dataGridViewTextBoxColumn17
            // 
            this.dataGridViewTextBoxColumn17.DataPropertyName = "EndPointAddress";
            this.dataGridViewTextBoxColumn17.HeaderText = "返回数据格式";
            this.dataGridViewTextBoxColumn17.Name = "dataGridViewTextBoxColumn17";
            this.dataGridViewTextBoxColumn17.ReadOnly = true;
            this.dataGridViewTextBoxColumn17.Width = 150;
            // 
            // dataGridViewTextBoxColumn19
            // 
            this.dataGridViewTextBoxColumn19.DataPropertyName = "NameSpace";
            this.dataGridViewTextBoxColumn19.HeaderText = "命名空间";
            this.dataGridViewTextBoxColumn19.Name = "dataGridViewTextBoxColumn19";
            this.dataGridViewTextBoxColumn19.ReadOnly = true;
            this.dataGridViewTextBoxColumn19.Width = 200;
            // 
            // Column10
            // 
            this.Column10.DataPropertyName = "ClassName";
            this.Column10.HeaderText = "服务类名称";
            this.Column10.Name = "Column10";
            this.Column10.ReadOnly = true;
            // 
            // Column11
            // 
            this.Column11.DataPropertyName = "ID";
            this.Column11.HeaderText = "ID";
            this.Column11.Name = "Column11";
            this.Column11.ReadOnly = true;
            this.Column11.Visible = false;
            // 
            // Column12
            // 
            this.Column12.DataPropertyName = "ServiceClassID";
            this.Column12.HeaderText = "ServiceClassID";
            this.Column12.Name = "Column12";
            this.Column12.ReadOnly = true;
            this.Column12.Visible = false;
            // 
            // dataGridViewCheckBoxColumn3
            // 
            this.dataGridViewCheckBoxColumn3.DataPropertyName = "Enabled";
            this.dataGridViewCheckBoxColumn3.HeaderText = "启用";
            this.dataGridViewCheckBoxColumn3.Name = "dataGridViewCheckBoxColumn3";
            this.dataGridViewCheckBoxColumn3.ReadOnly = true;
            this.dataGridViewCheckBoxColumn3.Width = 70;
            // 
            // dataGridViewTextBoxColumn18
            // 
            this.dataGridViewTextBoxColumn18.DataPropertyName = "Memo";
            this.dataGridViewTextBoxColumn18.HeaderText = "备注";
            this.dataGridViewTextBoxColumn18.Name = "dataGridViewTextBoxColumn18";
            this.dataGridViewTextBoxColumn18.ReadOnly = true;
            this.dataGridViewTextBoxColumn18.Width = 120;
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(636, 518);
            this.Controls.Add(this.splitContainer1);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmMain";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "手机后台服务控制台";
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.contextMenuStrip1.ResumeLayout(false);
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            this.cmTreeView.ResumeLayout(false);
            this.tabControl1.ResumeLayout(false);
            this.tpGeneral.ResumeLayout(false);
            this.groupBox2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvLogInfo)).EndInit();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picServiceStatus)).EndInit();
            this.tpBaseCode.ResumeLayout(false);
            this.groupBox4.ResumeLayout(false);
            this.groupBox4.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.tpSysArg.ResumeLayout(false);
            this.groupBox6.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgSysArg)).EndInit();
            this.cmSysArg.ResumeLayout(false);
            this.groupBox5.ResumeLayout(false);
            this.groupBox5.PerformLayout();
            this.tpSvcRegArg.ResumeLayout(false);
            this.groupBox8.ResumeLayout(false);
            this.tabControl2.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.groupBox7.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgSvcRegArg)).EndInit();
            this.cmSvcBizArg.ResumeLayout(false);
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.groupBox13.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgSvcRegArgDetail)).EndInit();
            this.cmSvcClassArg.ResumeLayout(false);
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.groupBox14.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgSvcInterface)).EndInit();
            this.tpSvcBizArg.ResumeLayout(false);
            this.groupBox9.ResumeLayout(false);
            this.tabControl3.ResumeLayout(false);
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.groupBox10.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.groupBox11.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            this.cmSvcClsArg.ResumeLayout(false);
            this.tabPage6.ResumeLayout(false);
            this.groupBox12.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dgvBizLog)).EndInit();
            this.cmSvcTreeView.ResumeLayout(false);
            this.cmSvcInterface.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.NotifyIcon notifyIcon1;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private System.Windows.Forms.TreeView treeView1;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem mnuShow;
        private System.Windows.Forms.ToolStripMenuItem numHide;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tpGeneral;
        private System.Windows.Forms.TabPage tpBaseCode;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.DataGridView dgvLogInfo;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button btnRefreshService;
        private System.Windows.Forms.Button btnStopService;
        private System.Windows.Forms.Button btnResumeService;
        private System.Windows.Forms.Button btnPauseService;
        private System.Windows.Forms.Button btnStartService;
        private System.Windows.Forms.PictureBox picServiceStatus;
        private System.Windows.Forms.TabPage tpSysArg;
        private System.Windows.Forms.TabPage tpSvcRegArg;
        private System.Windows.Forms.TabPage tpSvcBizArg;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.TreeView tvBaseCode;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btnUpdBaseCode;
        private System.Windows.Forms.Button btnAddBaseCode;
        private System.Windows.Forms.TextBox txtBaseName;
        private System.Windows.Forms.TextBox txtBaseCode;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbParent;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.GroupBox groupBox5;
        private System.Windows.Forms.TextBox textBoxArgValue;
        private System.Windows.Forms.TextBox textBoxArgKey;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBoxArgTypes;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.RadioButton radioButtonDisabled;
        private System.Windows.Forms.RadioButton radioButtonEnabled;
        private System.Windows.Forms.Button buttonEditSysArg;
        private System.Windows.Forms.Button buttonAddSysArg;
        private System.Windows.Forms.TextBox textBoxArgDesc;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.GroupBox groupBox6;
        private System.Windows.Forms.DataGridView dgSysArg;
        private System.Windows.Forms.GroupBox groupBox8;
        private System.Windows.Forms.TabControl tabControl2;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TextBox txtServiceName;
        private System.Windows.Forms.TextBox txtServiceCode;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox cmbSvcOwnerType;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.RadioButton rbtSvcDisable;
        private System.Windows.Forms.RadioButton rbtSvcEnable;
        private System.Windows.Forms.TextBox txtSvcAddressPath;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtSvcArgClassName;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtSvcArgNameSpace;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.RadioButton rbtSvcClassDisable;
        private System.Windows.Forms.RadioButton rbtSvcClassEnable;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.ComboBox cmbBindType;
        private System.Windows.Forms.TextBox txtSvcArgBaseAddress;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtSvcArgMemo;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtSvcInterfaceName;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.RadioButton rbtSvcInterfaceDisable;
        private System.Windows.Forms.RadioButton rbtSvcInterfaceEnable;
        private System.Windows.Forms.TextBox txtSvcInterfaceMemo;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ComboBox cmbDataType;
        private System.Windows.Forms.GroupBox groupBox9;
        private System.Windows.Forms.TabControl tabControl3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TextBox textBox13;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.TextBox textBox15;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox textBox14;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox textBox16;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.GroupBox groupBox10;
        private System.Windows.Forms.DataGridView dataGridView2;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn5;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn6;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn8;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn1;
        private System.Windows.Forms.GroupBox groupBox11;
        private System.Windows.Forms.DataGridView dataGridView3;
        private System.Windows.Forms.TextBox textBox20;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn12;
        private System.Windows.Forms.ContextMenuStrip cmTreeView;
        private System.Windows.Forms.ToolStripMenuItem mnuRefBaseCode;
        private System.Windows.Forms.ToolStripMenuItem mnuDelBaseCode;
        private System.Windows.Forms.ContextMenuStrip cmSysArg;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem2;
        private System.Windows.Forms.ContextMenuStrip cmSvcBizArg;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem3;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem4;
        private System.Windows.Forms.ContextMenuStrip cmSvcClsArg;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem5;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem6;
        private System.Windows.Forms.ContextMenuStrip cmSvcTreeView;
        private System.Windows.Forms.ToolStripMenuItem mnuColSvcTV;
        private System.Windows.Forms.ToolStripMenuItem mnuExpSvcTV;
        private System.Windows.Forms.ToolStripMenuItem mnuRefSvcTV;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.Button btnSearchLog;
        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.DataGridView dgvBizLog;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column7;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewButtonColumn RowID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column3;
        private System.Windows.Forms.GroupBox groupBox7;
        private System.Windows.Forms.DataGridView dgSvcRegArg;
        private System.Windows.Forms.GroupBox groupBox13;
        private System.Windows.Forms.DataGridView dgSvcRegArgDetail;
        private System.Windows.Forms.GroupBox groupBox14;
        private System.Windows.Forms.DataGridView dgSvcInterface;
        private System.Windows.Forms.Button btnSvcArgEdit;
        private System.Windows.Forms.Button btnSvcArgAdd;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn4;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column4;
        private System.Windows.Forms.DataGridViewTextBoxColumn OwnerType;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column5;
        private System.Windows.Forms.DataGridViewCheckBoxColumn Column6;
        private System.Windows.Forms.ComboBox cmbBaseSvcArg;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.ComboBox cmbSvcClassArg;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.ContextMenuStrip cmSvcClassArg;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem7;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem8;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column9;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn14;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn13;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn15;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column8;
        private System.Windows.Forms.DataGridViewTextBoxColumn BaseAddress;
        private System.Windows.Forms.DataGridViewTextBoxColumn ServiceID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Memo;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn2;
        private System.Windows.Forms.ContextMenuStrip cmSvcInterface;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem9;
        private System.Windows.Forms.ToolStripMenuItem toolStripMenuItem10;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn16;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn17;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn19;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column10;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column11;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column12;
        private System.Windows.Forms.DataGridViewCheckBoxColumn dataGridViewCheckBoxColumn3;
        private System.Windows.Forms.DataGridViewTextBoxColumn dataGridViewTextBoxColumn18;
    }
}

