﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.MgrClient
{
    public enum TabCtlTypeEnum
    {
        /// <summary>
        /// 常规
        /// </summary>
        General = 0,
        /// <summary>
        /// 基础代码
        /// </summary>
        BaseCode = 1,
        /// <summary>
        /// 系统参数
        /// </summary>
        SysArg = 2,
        /// <summary>
        /// 服务注册
        /// </summary>
        SvcRegArg = 3,
        /// <summary>
        /// 服务类库
        /// </summary>
        SvcBizArg = 4
    }
}
