﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Nd.Erp.Mobile.MgrClient
{
    public partial class frmMain : Form
    {


        RemoteMgrService.MgrServiceClient msc = null;

        public frmMain()
        {
            InitializeComponent();
            msc = new RemoteMgrService.MgrServiceClient();
        }


        #region 主导航初始化相关
        /// <summary>
        /// 显示标签页
        /// </summary>
        /// <param name="type"></param>
        private void ShowTabCtl(TabCtlTypeEnum type)
        {
            try
            {
                tabControl1.TabPages.Clear();
                tabControl1.ItemSize = new Size(32, 16);
                switch (type)
                {
                    case TabCtlTypeEnum.BaseCode:
                        tabControl1.TabPages.Add(tpBaseCode);
                        tpBaseCode.Parent = tabControl1;
                        Init_tpBaseCode();
                        break;
                    case TabCtlTypeEnum.SvcBizArg:
                        tabControl1.TabPages.Add(tpSvcBizArg);
                        tpSvcBizArg.Parent = tabControl1;

                        break;
                    case TabCtlTypeEnum.SvcRegArg:
                        tabControl1.TabPages.Add(tpSvcRegArg);
                        tpSvcRegArg.Parent = tabControl1;
                        Init_tpSvcRegArg();
                        break;
                    case TabCtlTypeEnum.SysArg:
                        tabControl1.TabPages.Add(tpSysArg);
                        tpSysArg.Parent = tabControl1;
                        Init_tpSvcArg();
                        break;
                    case TabCtlTypeEnum.General:
                    default:
                        tabControl1.TabPages.Add(tpGeneral);
                        tpGeneral.Parent = tabControl1;
                        Init_tpGeneral();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            this.Size = new Size(612, 532);
            this.tabControl1.Dock = DockStyle.Fill;

            InitTreeView();
            ShowTabCtl(TabCtlTypeEnum.General);
            RefreshServiceStatus();
        }

        /// <summary>
        /// 初始树相关数据
        /// </summary>
        private void InitTreeView()
        {
            treeView1.Nodes.Clear();
            TreeNode tn = treeView1.Nodes.Add("N1", "环境参数");
            tn.Nodes.Add("N1_1", "常规");
            tn.Nodes.Add("N1_3", "系统参数");
            tn.Nodes.Add("N1_4", "服务注册");
            tn.Nodes.Add("N1_2", "基础代码");

            //tn = treeView1.Nodes.Add("N2", "服务目录");
            //msc = new RemoteMgrService.MgrServiceClient();
            //DataTable dt = msc.GetAllService();
            //if (dt != null && dt.Rows.Count > 0)
            //{
            //    int i = 1;
            //    foreach (DataRow dr in dt.Rows)
            //    {
            //        tn.Nodes.Add("N2_" + i.ToString(), dr["ServiceName"].ToString());
            //        i++;
            //    }
            //}
            treeView1.ExpandAll();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            if (e.Node.Name.StartsWith("N2_"))
                ShowTabCtl(TabCtlTypeEnum.SvcBizArg);
            else
            {
                switch (e.Node.Name)
                {
                    case "N1_2":
                        ShowTabCtl(TabCtlTypeEnum.BaseCode);
                        break;
                    case "N1_3":
                        ShowTabCtl(TabCtlTypeEnum.SysArg);
                        break;
                    case "N1_4":
                        ShowTabCtl(TabCtlTypeEnum.SvcRegArg);
                        break;
                    case "N1_1":
                    default:
                        ShowTabCtl(TabCtlTypeEnum.General);
                        break;
                }
            }
        }

        #endregion

        #region 常规面板
        /// <summary>
        /// 初始化常规面板
        /// </summary>
        private void Init_tpGeneral()
        {
            try
            {
                //dgvLogInfo.DataSource = msc.FetchLogInfo("", DateTime.Now, DateTime.Now, "", "");
                //if (dgvLogInfo.DataSource != null)
                //{
                //    ResetLogDataGrid(dgvLogInfo);
                //}
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "查找日志失败：" + ex.Message, "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnSearchLog_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;
            frmSearch frm = new frmSearch();
            if (frm.ShowDialog(this) == System.Windows.Forms.DialogResult.OK)
            {
                switch (btn.Tag.ToString())
                {
                    case "1":
                        {
                            dgvBizLog.DataSource = frm.LogData;
                            if (dgvBizLog.DataSource != null)
                            {
                                ResetLogDataGrid(dgvBizLog);
                            }
                        }
                        break;
                    case "0":
                    default:
                        {
                            dgvLogInfo.DataSource = frm.LogData;
                            if (dgvLogInfo.DataSource != null)
                            {
                                ResetLogDataGrid(dgvLogInfo);
                            }
                        }
                        break;
                }

            }
        }

        private void ResetLogDataGrid(DataGridView dgv)
        {
            if (dgv.DataSource != null)
            {
                foreach (DataGridViewColumn col in dgv.Columns)
                {
                    if (col.Name == "LogTime")
                        col.HeaderText = "发生时间";
                    if (col.Name == "LogInfo")
                        col.HeaderText = "日志信息";
                    if (col.Name == "LogType")
                        col.HeaderText = "日志类型";
                    col.AutoSizeMode = DataGridViewAutoSizeColumnMode.AllCells;
                    col.ReadOnly = true;
                }
            }
        }

        #endregion

        #region 基础代码配置面板

        /// <summary>
        /// 当前选定的代码编辑ID
        /// </summary>
        private int? CurrentBaseCodeID = null;

        /// <summary>
        /// 当前要删除的代码编辑ID
        /// </summary>
        private int? CurrentDeleteBaseCodeID = null;

        /// <summary>
        /// 初始化基础配置面板
        /// </summary>
        private void Init_tpBaseCode()
        {

            msc = new RemoteMgrService.MgrServiceClient();
            DataTable dt = msc.GetBaseCodes();
            Bind_tvBaseCodeTree(dt);

            ComboBoxHelper cmbHelper = new ComboBoxHelper();
            dt.Select("parentid=0").ToList().ForEach(dr => cmbHelper.AddRow(dr["Name"].ToString(), dr["ID"].ToString()));
            cmbHelper.BindToComboBox(cmbParent);

        }

        /// <summary>
        /// 绑定基础配置树
        /// </summary>
        /// <param name="dt"></param>
        private void Bind_tvBaseCodeTree(DataTable dt)
        {

            tvBaseCode.Nodes.Clear();
            tvBaseCode.Tag = dt;
            dt.Select("parentid=0").ToList().ForEach(
                dr =>
                {
                    TreeNode childNode = tvBaseCode.Nodes.Add(dr["Code"].ToString(), dr["Name"].ToString());
                    dt.Select("parentid=" + dr["ID"].ToString()).ToList().ForEach(
                    drChild =>
                    {
                        var code = drChild["Code"].ToString();
                        var childChildNode = new TreeNode(string.Format("({0}){1}", code, drChild["Name"].ToString()));
                        childChildNode.Name = code;
                        childChildNode.Tag = drChild;
                        childNode.Nodes.Add(childChildNode);
                    }
                );
                }
                );

            tvBaseCode.ExpandAll();
        }



        /// <summary>
        /// 选中节点
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tvBaseCode_AfterSelect(object sender, TreeViewEventArgs e)
        {
            DataRow dr = e.Node.Tag as DataRow;
            if (dr == null || dr["parentID"].ToString() == "0")
                return;
            ComboBoxHelper.FindItemByValue(cmbParent, dr["parentID"].ToString());

            CurrentBaseCodeID = Convert.ToInt32(dr["ID"]);
            txtBaseCode.Text = e.Node.Name;
            txtBaseName.Text = dr["Name"].ToString();
        }

        private void tvBaseCode_NodeMouseClick(object sender, TreeNodeMouseClickEventArgs e)
        {
            DataRow dr = e.Node.Tag as DataRow;
            if (dr == null || dr["parentID"].ToString() == "0")
                CurrentDeleteBaseCodeID = null;
            else
            {
                CurrentDeleteBaseCodeID = Convert.ToInt32(dr["ID"]);
            }

        }

        private void cmTreeView_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (Convert.ToString(e.ClickedItem.Tag))
            {
                case "Delete":
                    ((ContextMenuStrip)sender).Visible = false;
                    DataTable dt = tvBaseCode.Tag as DataTable;
                    // 删除前的用户确认。
                    if (dt != null && CurrentDeleteBaseCodeID != null && MessageBox.Show("确认要删除“" + dt.Select("ID=" + CurrentDeleteBaseCodeID.ToString())[0]["Name"].ToString() + "”的配置吗？", "删除确认",
                            MessageBoxButtons.OKCancel,
                            MessageBoxIcon.Question,
                            MessageBoxDefaultButton.Button2) == DialogResult.OK)
                    {
                        msc.DeleteBaseCode((int)CurrentDeleteBaseCodeID);
                        Bind_tvBaseCodeTree(msc.GetBaseCodes());
                    }
                    break;
                case "Refresh":
                    Bind_tvBaseCodeTree(msc.GetBaseCodes());
                    break;
            }
        }


        private void btnAddBaseCode_Click(object sender, EventArgs e)
        {
            try
            {
                if (msc.AddBaseCode(txtBaseCode.Text, txtBaseName.Text, Convert.ToInt32(cmbParent.SelectedValue.ToString())))
                {
                    Bind_tvBaseCodeTree(msc.GetBaseCodes());
                    CurrentBaseCodeID = null;
                    MessageBox.Show("添加成功!");
                }
                else
                    MessageBox.Show(txtBaseCode.Text + "已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btnUpdBaseCode_Click(object sender, EventArgs e)
        {
            try
            {
                if (CurrentBaseCodeID != null && msc.UpdateBaseCode((int)CurrentBaseCodeID, txtBaseCode.Text, txtBaseName.Text, Convert.ToInt32(cmbParent.SelectedValue.ToString())))
                {
                    Bind_tvBaseCodeTree(msc.GetBaseCodes());
                    MessageBox.Show("修改成功!");
                }
                else if (CurrentBaseCodeID == null)
                    MessageBox.Show("您未选择要修改的节点");
                else
                    MessageBox.Show(txtBaseCode.Text + "已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region 系统参数配置面板
        /// <summary>
        /// 当表格选定的系统参数行ID
        /// </summary>
        private int? CurrentSysArgRowID = null;

        /// <summary>
        /// 当前要删除的系统参数行号
        /// </summary>
        private int? CurrentDeleteSysArgRowIndex = null;

        /// <summary>
        /// 初始化系统参数配置面板
        /// </summary>
        private void Init_tpSvcArg()
        {
            msc = new RemoteMgrService.MgrServiceClient();

            comboBoxArgTypes.DataSource = msc.GetArgTypes();
            comboBoxArgTypes.DisplayMember = "ArgValue";
            comboBoxArgTypes.ValueMember = "ArgKey";
            dgSysArg.DataSource = msc.GetSysArgsWithType();
        }

        /// <summary>
        /// 设置进入单元格时所在行，用于右键删除时
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSysArg_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            CurrentDeleteSysArgRowIndex = e.RowIndex;
        }

        /// <summary>
        /// 选择配置行事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSysArg_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataTable dt = dgSysArg.DataSource as DataTable;
                if (dt != null && e.RowIndex < dt.Rows.Count)
                {
                    ComboBoxHelper.FindItemByValue(comboBoxArgTypes, dt.Rows[e.RowIndex]["ArgType"].ToString(), isByDisplayMember: true);
                    textBoxArgKey.Text = dt.Rows[e.RowIndex]["ArgKey"].ToString();
                    textBoxArgValue.Text = dt.Rows[e.RowIndex]["ArgValue"].ToString();
                    textBoxArgDesc.Text = dt.Rows[e.RowIndex]["ArgDesc"].ToString();
                    radioButtonEnabled.Checked = Convert.ToBoolean(dt.Rows[e.RowIndex]["Enabled"]);
                    radioButtonDisabled.Checked = !radioButtonEnabled.Checked;
                    CurrentSysArgRowID = Convert.ToInt32(dt.Rows[e.RowIndex]["RowID"].ToString());
                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAddSysArg_Click(object sender, EventArgs e)
        {
            try
            {
                RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
                if (msc.AddSysArgs(textBoxArgKey.Text, textBoxArgValue.Text, textBoxArgDesc.Text, radioButtonEnabled.Checked, comboBoxArgTypes.SelectedValue.ToString()))
                {
                    dgSysArg.DataSource = msc.GetSysArgsWithType();
                    CurrentSysArgRowID = null;
                    MessageBox.Show("添加成功!");
                }
                else
                    MessageBox.Show(textBoxArgKey.Text + "的key已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditSysArg_Click(object sender, EventArgs e)
        {
            try
            {
                RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
                if (CurrentSysArgRowID != null && msc.UpdateSysArgs(textBoxArgKey.Text, textBoxArgValue.Text, textBoxArgDesc.Text, radioButtonEnabled.Checked, comboBoxArgTypes.SelectedValue.ToString(), (int)CurrentSysArgRowID))
                {
                    dgSysArg.DataSource = msc.GetSysArgsWithType();
                    MessageBox.Show("修改成功!");
                }
                else if (CurrentSysArgRowID == null)
                    MessageBox.Show("您未选择要修改的行");
                else
                    MessageBox.Show(textBoxArgKey.Text + "的key已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void cmSysArg_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            switch (Convert.ToString(e.ClickedItem.Tag))
            {
                case "Delete":
                    ((ContextMenuStrip)sender).Visible = false;
                    DataTable dt = dgSysArg.DataSource as DataTable;
                    // 删除前的用户确认。
                    if (dt != null && CurrentDeleteSysArgRowIndex != null && MessageBox.Show("确认要删除键值为" + dt.Rows[(int)CurrentDeleteSysArgRowIndex]["ArgKey"].ToString() + "的配置吗？", "删除确认",
                            MessageBoxButtons.OKCancel,
                            MessageBoxIcon.Question,
                            MessageBoxDefaultButton.Button2) == DialogResult.OK)
                    {
                        msc = new RemoteMgrService.MgrServiceClient();
                        msc.DeleteSysArgs(Convert.ToInt32(dt.Rows[(int)CurrentDeleteSysArgRowIndex]["RowID"].ToString()));
                        dgSysArg.DataSource = msc.GetSysArgsWithType();
                    }
                    break;
                case "Refresh":
                    dgSysArg.DataSource = msc.GetSysArgsWithType();
                    break;
            }
        }

        #endregion

        #region 服务注册面板
        /// <summary>
        /// 选择服务类型参数触发事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void tabControl2_Selected(object sender, TabControlEventArgs e)
        {
            try
            {
                switch (e.TabPageIndex)
                {
                    case 1: Init_tpSvcRegArgDetail(); 
                        break;

                    case 2: Init_tpSvcInterface();
                        break;

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        #region 基础信息
        /// <summary>
        /// 初始化服务绑定方式下拉框
        /// </summary>
        private void Init_tpSvcRegArg()
        {
            ComboBoxHelper cmbHelper = new ComboBoxHelper();
            cmbHelper.AddRow("服务返回JSON数据格式", "json");
            cmbHelper.AddRow("服务返回XML数据格式", "xml");
            cmbHelper.BindToComboBox(cmbDataType);

            cmbHelper = new ComboBoxHelper();

            msc.GetBaseCodes().Select("ParentID=5").ToList().ForEach(
                dr => cmbHelper.AddRow(dr["Name"].ToString(), dr["Code"].ToString())
                );
            cmbHelper.BindToComboBox(cmbSvcOwnerType);

            dgSvcRegArg.DataSource = msc.GetSvcRegArg();
        }
        /// <summary>
        /// 当表格选定的注册服务行ID
        /// </summary>
        private int? CurrentSvcRegArgRowID = null;

        /// <summary>
        /// 当前要删除的注册服务行号
        /// </summary>
        private int? CurrentDeleteSvcRegArgRowIndex = null;


        /// <summary>
        /// 设置进入单元格时所在行，用于右键删除时
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSvcRegArg_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            CurrentDeleteSvcRegArgRowIndex = e.RowIndex;
        }

        /// <summary>
        /// 选择配置行事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSvcRegArg_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataTable dt = dgSvcRegArg.DataSource as DataTable;
                if (dt != null && e.RowIndex < dt.Rows.Count)
                {
                    ComboBoxHelper.FindItemByValue(cmbSvcOwnerType, dt.Rows[e.RowIndex]["OwnerType"].ToString());
                    txtServiceCode.Text = dt.Rows[e.RowIndex]["ServiceCode"].ToString();
                    txtServiceName.Text = dt.Rows[e.RowIndex]["ServiceName"].ToString();
                    txtSvcAddressPath.Text = dt.Rows[e.RowIndex]["AddressPath"].ToString();
                    rbtSvcEnable.Checked = Convert.ToBoolean(dt.Rows[e.RowIndex]["Enabled"]);
                    rbtSvcDisable.Checked = !rbtSvcEnable.Checked;
                    CurrentSvcRegArgRowID = Convert.ToInt32(dt.Rows[e.RowIndex]["ID"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAddSvcRegArg_Click(object sender, EventArgs e)
        {
            try
            {
                if (msc.AddSvcRegArg(txtServiceCode.Text, txtServiceName.Text, cmbSvcOwnerType.SelectedValue.ToString(), txtSvcAddressPath.Text, rbtSvcEnable.Checked))
                {
                    dgSvcRegArg.DataSource = msc.GetSvcRegArg();
                    CurrentSvcRegArgRowID = null;
                    MessageBox.Show("添加成功!");
                }
                else
                    MessageBox.Show(txtServiceCode.Text + "的key已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditSvcRegArg_Click(object sender, EventArgs e)
        {
            try
            {
                if (CurrentSvcRegArgRowID != null && msc.UpdateSvcRegArg((int)CurrentSvcRegArgRowID, txtServiceCode.Text, txtServiceName.Text, cmbSvcOwnerType.SelectedValue.ToString(), txtSvcAddressPath.Text, rbtSvcEnable.Checked))
                {
                    dgSvcRegArg.DataSource = msc.GetSvcRegArg();
                    MessageBox.Show("修改成功!");
                }
                else if (CurrentSvcRegArgRowID == null)
                    MessageBox.Show("您未选择要修改的行");
                else
                    MessageBox.Show(txtServiceCode.Text + "的key已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void cmSvcRegArg_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
            {
                var menuStrip = sender as ContextMenuStrip;
                var sourceDataGrid = menuStrip.SourceControl as DataGridView;

                switch (Convert.ToString(e.ClickedItem.Tag))
                {
                    case "Delete":
                        menuStrip.Visible = false;
                        DataTable dt = sourceDataGrid.DataSource as DataTable;
                        // 删除前的用户确认。
                        if (dt != null && CurrentDeleteSvcRegArgRowIndex != null && MessageBox.Show("确认要删除键值为" + dt.Rows[(int)CurrentDeleteSvcRegArgRowIndex]["ServiceName"].ToString() + "的配置吗？", "删除确认",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Question,
                                MessageBoxDefaultButton.Button2) == DialogResult.OK)
                        {
                            msc.DeleteSvcRegArg(Convert.ToInt32(dt.Rows[(int)CurrentDeleteSvcRegArgRowIndex]["ID"].ToString()));
                            sourceDataGrid.DataSource = msc.GetSvcRegArg();
                        }
                        break;
                    case "Refresh":
                        sourceDataGrid.DataSource = msc.GetSvcRegArg();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region 服务类型参数


        /// <summary>
        /// 初始化服务绑定方式下拉框
        /// </summary>
        private void Init_tpSvcRegArgDetail()
        {
            ComboBoxHelper cmbHelper = new ComboBoxHelper();

            msc.GetBaseCodes().Select("ParentID=1").ToList().ForEach(
                dr => cmbHelper.AddRow(dr["Name"].ToString(), dr["Code"].ToString())
                );
            cmbHelper.BindToComboBox(cmbBindType);

            cmbBaseSvcArg.DisplayMember = "ServiceName";
            cmbBaseSvcArg.ValueMember = "ID";
            cmbBaseSvcArg.DataSource = msc.GetSvcRegArg();

            dgSvcRegArgDetail.DataSource = msc.GetSvcClassArg();
        }
        /// <summary>
        /// 当表格选定的注册服务行ID
        /// </summary>
        private int? CurrentSvcRegArgDetailRowID = null;

        /// <summary>
        /// 当前要删除的注册服务行号
        /// </summary>
        private int? CurrentDeleteSvcRegArgDetailRowIndex = null;


        /// <summary>
        /// 设置进入单元格时所在行，用于右键删除时
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSvcRegArgDetail_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            CurrentDeleteSvcRegArgDetailRowIndex = e.RowIndex;
        }

        /// <summary>
        /// 选择配置行事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSvcRegArgDetail_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataTable dt = dgSvcRegArgDetail.DataSource as DataTable;
                if (dt != null && e.RowIndex < dt.Rows.Count)
                {
                    ComboBoxHelper.FindItemByValue(cmbBaseSvcArg, dt.Rows[e.RowIndex]["ServiceID"].ToString());
                    ComboBoxHelper.FindItemByValue(cmbBindType, dt.Rows[e.RowIndex]["EndPointBinding"].ToString());

                    txtSvcArgClassName.Text = dt.Rows[e.RowIndex]["ClassName"].ToString();
                    txtSvcArgNameSpace.Text = dt.Rows[e.RowIndex]["NameSpace"].ToString();
                    txtSvcArgBaseAddress.Text = dt.Rows[e.RowIndex]["BaseAddress"].ToString();
                    rbtSvcClassEnable.Checked = Convert.ToBoolean(dt.Rows[e.RowIndex]["Enabled"]);
                    txtSvcAddressPath.Text = dt.Rows[e.RowIndex]["Memo"].ToString();
                    rbtSvcClassDisable.Checked = !rbtSvcClassEnable.Checked;
                    CurrentSvcRegArgDetailRowID = Convert.ToInt32(dt.Rows[e.RowIndex]["ID"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAddSvcRegArgDetail_Click(object sender, EventArgs e)
        {
            try
            {
                if (msc.AddSvcClassArg(
                    int.Parse(cmbBaseSvcArg.SelectedValue.ToString()),
                    txtSvcArgNameSpace.Text,
                    txtSvcArgClassName.Text,
                    cmbBindType.SelectedValue.ToString(),
                    txtSvcArgBaseAddress.Text,
                    rbtSvcClassEnable.Checked,
                    txtSvcArgMemo.Text))
                {
                    dgSvcRegArgDetail.DataSource = msc.GetSvcClassArg();
                    CurrentSvcRegArgDetailRowID = null;
                    MessageBox.Show("添加成功!");
                }
                else
                    MessageBox.Show(txtSvcArgNameSpace.Text + "的" + txtSvcArgClassName.Text + "已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditSvcRegArgDetail_Click(object sender, EventArgs e)
        {
            try
            {
                if (CurrentSvcRegArgDetailRowID != null && msc.UpdateSvcClassArg((int)CurrentSvcRegArgDetailRowID, int.Parse(cmbBaseSvcArg.SelectedValue.ToString()),
                    txtSvcArgNameSpace.Text,
                    txtSvcArgClassName.Text,
                    cmbBindType.SelectedValue.ToString(),
                    txtSvcArgBaseAddress.Text,
                    rbtSvcClassEnable.Checked,
                    txtSvcArgMemo.Text))
                {
                    dgSvcRegArgDetail.DataSource = msc.GetSvcClassArg();
                    MessageBox.Show("修改成功!");
                }
                else if (CurrentSvcRegArgDetailRowID == null)
                    MessageBox.Show("您未选择要修改的行");
                else
                    MessageBox.Show(txtSvcArgNameSpace.Text + "的" + txtSvcArgClassName.Text + "已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void cmSvcRegArgDetail_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
            {
                var menuStrip = sender as ContextMenuStrip;
                var sourceDataGrid = menuStrip.SourceControl as DataGridView;

                switch (Convert.ToString(e.ClickedItem.Tag))
                {
                    case "Delete":
                        menuStrip.Visible = false;
                        DataTable dt = sourceDataGrid.DataSource as DataTable;
                        // 删除前的用户确认。
                        if (dt != null && CurrentDeleteSvcRegArgDetailRowIndex != null && MessageBox.Show("确认要删除为" + dt.Rows[(int)CurrentDeleteSvcRegArgDetailRowIndex]["NameSpace"].ToString() + ":" + dt.Rows[(int)CurrentDeleteSvcRegArgDetailRowIndex]["ClassName"].ToString() + "的配置吗？", "删除确认",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Question,
                                MessageBoxDefaultButton.Button2) == DialogResult.OK)
                        {
                            msc.DeleteSvcClassArg(Convert.ToInt32(dt.Rows[(int)CurrentDeleteSvcRegArgDetailRowIndex]["ID"].ToString()));
                            sourceDataGrid.DataSource = msc.GetSvcClassArg();
                        }
                        break;
                    case "Refresh":
                        sourceDataGrid.DataSource = msc.GetSvcClassArg();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #region 服务接口参数


        /// <summary>
        /// 初始化服务绑定方式下拉框
        /// </summary>
        private void Init_tpSvcInterface()
        {
            ComboBoxHelper cmbHelper = new ComboBoxHelper();
            msc.GetSvcClassArg().AsEnumerable().ToList().ForEach(
                dr => cmbHelper.AddRow(dr["NameSpace"].ToString() + ":" + dr["ClassName"].ToString(), dr["ID"].ToString())
                );
            cmbHelper.BindToComboBox(cmbSvcClassArg);

            dgSvcInterface.DataSource = msc.GetSvcInterfaceArg();
        }
        /// <summary>
        /// 当表格选定的注册服务行ID
        /// </summary>
        private int? CurrentSvcInterfaceRowID = null;

        /// <summary>
        /// 当前要删除的注册服务行号
        /// </summary>
        private int? CurrentDeleteSvcInterfaceRowIndex = null;


        /// <summary>
        /// 设置进入单元格时所在行，用于右键删除时
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSvcInterface_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            CurrentDeleteSvcInterfaceRowIndex = e.RowIndex;
        }

        /// <summary>
        /// 选择配置行事件
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dgSvcInterface_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                DataTable dt = dgSvcInterface.DataSource as DataTable;
                if (dt != null && e.RowIndex < dt.Rows.Count)
                {
                    ComboBoxHelper.FindItemByValue(cmbSvcClassArg, dt.Rows[e.RowIndex]["ServiceClassID"].ToString());
                    ComboBoxHelper.FindItemByValue(cmbDataType, dt.Rows[e.RowIndex]["EndPointAddress"].ToString());

                    txtSvcInterfaceName.Text = dt.Rows[e.RowIndex]["InterfaceName"].ToString();
                    txtSvcInterfaceMemo.Text = dt.Rows[e.RowIndex]["Memo"].ToString();

                    rbtSvcInterfaceEnable.Checked = Convert.ToBoolean(dt.Rows[e.RowIndex]["Enabled"]);
                    rbtSvcInterfaceDisable.Checked = !rbtSvcInterfaceEnable.Checked;
                    CurrentSvcInterfaceRowID = Convert.ToInt32(dt.Rows[e.RowIndex]["ID"].ToString());
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonAddSvcInterface_Click(object sender, EventArgs e)
        {
            try
            {
                if (msc.AddSvcInterfaceArg(
                    int.Parse(cmbSvcClassArg.SelectedValue.ToString()),
                    txtSvcInterfaceName.Text,
                    cmbDataType.SelectedValue.ToString(),
                    rbtSvcInterfaceEnable.Checked,
                    txtSvcInterfaceMemo.Text))
                {
                    dgSvcInterface.DataSource = msc.GetSvcInterfaceArg();
                    CurrentSvcInterfaceRowID = null;
                    MessageBox.Show("添加成功!");
                }
                else
                    MessageBox.Show(txtSvcInterfaceName.Text + "的" + cmbDataType.SelectedValue.ToString() + "已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonEditSvcInterface_Click(object sender, EventArgs e)
        {
            try
            {
                if (CurrentSvcInterfaceRowID != null && msc.UpdateSvcInterfaceArg((int)CurrentSvcInterfaceRowID, int.Parse(cmbSvcClassArg.SelectedValue.ToString()),
                    txtSvcInterfaceName.Text,
                    cmbDataType.SelectedValue.ToString(),
                    rbtSvcInterfaceEnable.Checked,
                    txtSvcInterfaceMemo.Text))
                {
                    dgSvcInterface.DataSource = msc.GetSvcInterfaceArg();
                    MessageBox.Show("修改成功!");
                }
                else if (CurrentSvcInterfaceRowID == null)
                    MessageBox.Show("您未选择要修改的行");
                else
                    MessageBox.Show(txtSvcArgNameSpace.Text + "的" + txtSvcArgClassName.Text + "已经存在");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void cmSvcInterface_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {
            try
            {
                var menuStrip = sender as ContextMenuStrip;
                var sourceDataGrid = menuStrip.SourceControl as DataGridView;

                switch (Convert.ToString(e.ClickedItem.Tag))
                {
                    case "Delete":
                        menuStrip.Visible = false;
                        DataTable dt = sourceDataGrid.DataSource as DataTable;
                        // 删除前的用户确认。
                        if (dt != null && CurrentDeleteSvcInterfaceRowIndex != null && MessageBox.Show("确认要删除为" + dt.Rows[(int)CurrentDeleteSvcInterfaceRowIndex]["InterfaceName"].ToString() + ":" + dt.Rows[(int)CurrentDeleteSvcInterfaceRowIndex]["EndPointAddress"].ToString() + "的配置吗？", "删除确认",
                                MessageBoxButtons.OKCancel,
                                MessageBoxIcon.Question,
                                MessageBoxDefaultButton.Button2) == DialogResult.OK)
                        {
                            msc.DeleteSvcInterfaceArg(Convert.ToInt32(dt.Rows[(int)CurrentDeleteSvcInterfaceRowIndex]["ID"].ToString()));
                            sourceDataGrid.DataSource = msc.GetSvcInterfaceArg();
                        }
                        break;
                    case "Refresh":
                        sourceDataGrid.DataSource = msc.GetSvcInterfaceArg();
                        break;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        #endregion

        #region 最小化或正常化窗体
        protected override void WndProc(ref Message m)
        {
            const int WM_SYSCOMMAND = 0x0112;
            const int SC_CLOSE = 0xF060;
            if (m.Msg == WM_SYSCOMMAND && (int)m.WParam == SC_CLOSE)
            {
                MinWindow();
                return;
            }
            base.WndProc(ref m);
        }

        /// <summary>
        /// 最小化窗体
        /// </summary>
        private void MinWindow()
        {
            this.ShowInTaskbar = false;
            this.Visible = false;
            this.WindowState = FormWindowState.Minimized;

            ShowBalloonTip("如果重新打开控制台，请双击右下角图标哦！");
        }

        /// <summary>
        /// 正常化窗体
        /// </summary>
        private void NormalWindow()
        {
            if (this.Visible)
            {
                this.Activate();
            }
            else
            {
                this.ShowInTaskbar = true;
                this.Visible = true;
                this.WindowState = FormWindowState.Normal;
                this.Activate();
            }
        }

        /// <summary>
        /// 显示气泡
        /// </summary>
        /// <param name="tipText"></param>
        private void ShowBalloonTip(string tipText)
        {
            notifyIcon1.BalloonTipIcon = ToolTipIcon.Info;
            notifyIcon1.Text = this.Text;
            notifyIcon1.BalloonTipTitle = this.Text;
            notifyIcon1.BalloonTipText = tipText;
            notifyIcon1.ShowBalloonTip(3000);
        }

        private void notifyIcon1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            NormalWindow();
        }

        private void mnuShow_Click(object sender, EventArgs e)
        {
            NormalWindow();
        }

        private void numHide_Click(object sender, EventArgs e)
        {
            MinWindow();
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            this.Close();
            Application.Exit();
        }
        #endregion

        #region 服务状态信息获取和控制
        private void btnStartService_Click(object sender, EventArgs e)
        {
            RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
            if (!msc.CheckServiceIsExist())
            {
                MessageBox.Show("启动服务失败，因服务不存在。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!msc.StartService())
            {
                MessageBox.Show("启动服务失败，请稍后再试。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrStart;
            SetServiceButton(1);
        }

        private void btnPauseService_Click(object sender, EventArgs e)
        {
            RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
            if (!msc.CheckServiceIsExist())
            {
                MessageBox.Show("暂停服务失败，因服务不存在。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!msc.PauseService())
            {
                MessageBox.Show("暂停服务失败，请稍后再试。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrPause;
            SetServiceButton(2);
        }

        private void btnResumeService_Click(object sender, EventArgs e)
        {
            RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
            if (!msc.CheckServiceIsExist())
            {
                MessageBox.Show("恢复服务失败，因服务不存在。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!msc.ResumeService())
            {
                MessageBox.Show("恢复服务失败，请稍后再试。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrStart;
            SetServiceButton(1);
        }

        private void btnStopService_Click(object sender, EventArgs e)
        {
            RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
            if (!msc.CheckServiceIsExist())
            {
                MessageBox.Show("停止服务失败，因服务不存在。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            if (!msc.StopService())
            {
                MessageBox.Show("停止服务失败，请稍后再试。", "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrStop;
            SetServiceButton(3);
        }

        private void btnRefreshService_Click(object sender, EventArgs e)
        {
            RefreshServiceStatus();
        }

        /// <summary>
        /// 获取服务状态
        /// </summary>
        private void RefreshServiceStatus()
        {
            return;
            RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
            int status = msc.GetServiceStatus();
            switch (status)
            {
                case 1:     //StartPending
                case 2:     //Running
                case 5:     //ContinuePending
                    SetServiceButton(1);
                    picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrStart;
                    break;
                case 3:     //PausePending
                case 4:     //Paused
                    SetServiceButton(2);
                    picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrPause;
                    break;
                case 6:     //StopPending
                case 7:     //Stopped
                    SetServiceButton(3); ;
                    picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrStop;
                    break;
                case 0:     //None
                default:
                    SetServiceButton(0);
                    picServiceStatus.Image = Erp.Mobile.MgrClient.Properties.Resources.SvrNone;
                    break;
            }
        }

        /// <summary>
        /// 设置服务控制按钮状态
        /// </summary>
        /// <param name="type"></param>
        private void SetServiceButton(int type)
        {
            switch (type)
            {
                case 1:     //StartPending
                    btnStartService.Enabled = false;
                    btnResumeService.Enabled = false;
                    btnStopService.Enabled = true;
                    btnPauseService.Enabled = false;
                    break;
                case 2:     //Paused
                    btnStartService.Enabled = false;
                    btnResumeService.Enabled = true;
                    btnStopService.Enabled = false;
                    btnPauseService.Enabled = false;
                    break;
                case 3:     //Stopped
                    btnStartService.Enabled = true;
                    btnResumeService.Enabled = false;
                    btnStopService.Enabled = false;
                    btnPauseService.Enabled = false;
                    break;
                case 0:     //None
                default:
                    btnStartService.Enabled = false;
                    btnResumeService.Enabled = false;
                    btnStopService.Enabled = false;
                    btnPauseService.Enabled = false;
                    break;
            }
        }
        #endregion



    }


}
