﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Nd.Erp.Mobile.MgrClient
{
    public partial class frmSearch : Form
    {
        public frmSearch()
        {
            InitializeComponent();
        }

        private DataTable _logData;
        public DataTable LogData
        {
            get
            {
                return _logData;
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            try
            {
                RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
                _logData = msc.FetchLogInfo(cmbServerCode.SelectedValue.ToString(), dtpStartDate.Value, dtpEndDate.Value, cmbLogType.SelectedValue.ToString(), txtKeyWord.Text.Trim());
                this.DialogResult = System.Windows.Forms.DialogResult.OK;
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "查找日志失败：" + ex.Message, "系统提示", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void frmSearch_Load(object sender, EventArgs e)
        {
            this.Icon = Erp.Mobile.MgrClient.Properties.Resources.search16;
            this.DialogResult = System.Windows.Forms.DialogResult.None;
            InitServerCtrl();
            InitLogTypeCtrl();
        }


        private void InitServerCtrl()
        {
            cmbServerCode.DataSource = null;
            ComboBoxHelper cmbHelper = new ComboBoxHelper();
            cmbHelper.AddRow("所有服务", "");
            cmbHelper.AddRow("WCF接入服务", "ErpMobileService");
            RemoteMgrService.MgrServiceClient msc = new RemoteMgrService.MgrServiceClient();
            DataTable dt = msc.GetAllService();
            if (dt != null && dt.Rows.Count > 0)
            {
                foreach (DataRow dr in dt.Rows)
                {
                    cmbHelper.AddRow(dr["ServiceName"].ToString(), dr["ServiceCode"].ToString());
                }
            }
            cmbHelper.BindToComboBox(cmbServerCode);
        }

        private void InitLogTypeCtrl()
        {
            cmbLogType.DataSource = null;
            ComboBoxHelper cmbHelper = new ComboBoxHelper();
            cmbHelper.AddRow("所有日志", "");
            cmbHelper.AddRow("正常日志", "03");
            cmbHelper.AddRow("异常日志", "04");
            cmbHelper.BindToComboBox(cmbLogType);
        }
    }
}
