﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Data;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;
using System.Diagnostics;
using System.Data.SqlClient;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Reflector;

namespace Nd.Erp.Mobile.Service.Common.Extensions
{
    public static class SyncHelper
    {

        private static LogMgr<BzMobileSyncServer> _logMgr = new LogMgr<BzMobileSyncServer>();
        #region 常用变量
        private static Dictionary<int, List<EnSyncTableDetail>> _syncTableDetailDic;

        public static Dictionary<int, List<EnSyncTableDetail>> SyncTableDetailDic
        {
            get
            {
                if (_syncTableDetailDic == null)
                {
                    IDataReader dr = null;
                    try
                    {
                        string sql = " SELECT AutoCode, ColumnName, IsPrimaryKey, lTableNameCode, sForeignTableCode, sForeignColumnName, IsIdentity FROM TM_SyncTableDetail ";
                        dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, sql);
                        _syncTableDetailDic = DynamicBuilder<EnSyncTableDetail>
                            .ConvertToList(dr)
                            .GroupBy(tableDetail => tableDetail.lTableNameCode)
                            .ToDictionary(key => key.Key, value => value.ToList());

                    }
                    catch (Exception ex)
                    {
                        return null;
                    }
                    finally
                    {
                        if (dr != null)
                        {
                            dr.Dispose();
                        }
                    }

                }
                return _syncTableDetailDic;
            }
        }

        private static Dictionary<int, Type> _syncTableMapTypeDic;

        public static Dictionary<int, Type> SyncTableMapTypeDic
        {
            get
            {
                if (_syncTableMapTypeDic == null)
                {
                    _syncTableMapTypeDic = new Dictionary<int, Type>();
                    _syncTableMapTypeDic.Add(0, typeof(EnAffair));
                    _syncTableMapTypeDic.Add(1, typeof(EnAffairAssistant));
                    _syncTableMapTypeDic.Add(2, typeof(EnAlarmClock));
                    _syncTableMapTypeDic.Add(3, typeof(EnAffairAssistantWithAlarmClock));
                    _syncTableMapTypeDic.Add(4, typeof(EnAffairBespeak));
                    _syncTableMapTypeDic.Add(5, typeof(EnAffairMeetingBespeak));
                    _syncTableMapTypeDic.Add(6, typeof(EnAffairMeetingDecision));
                    _syncTableMapTypeDic.Add(7, typeof(EnAffairRepeat));
                    _syncTableMapTypeDic.Add(8, typeof(EnAffairType));
                    _syncTableMapTypeDic.Add(9, typeof(EnCalendar));
                    _syncTableMapTypeDic.Add(10, typeof(EnCalendarAttention));
                    _syncTableMapTypeDic.Add(11, typeof(EnRepeatModel));
                    //_syncTableMapTypeDic.Add(12, typeof(EnUserAttentionList));
                    //_syncTableMapTypeDic.Add(13, typeof(EnUserConfig));  
                }
                return _syncTableMapTypeDic;
            }

        }

        private static Dictionary<int, string> _syncTableNameDic;

        public static Dictionary<int, string> SyncTableNameDic
        {
            get
            {

                if (_syncTableNameDic == null)
                {
                    IDataReader dr = null;
                    try
                    {
                        string sql = " SELECT AutoCode, lTableNameCode, TableName FROM dbo.TM_SyncTableName ";
                        dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, sql);
                        _syncTableNameDic = DynamicBuilder<EnSyncTableName>
                            .ConvertToList(dr)
                            .Select(s => new { s.lTableNameCode, s.TableName })
                            .ToDictionary(s => s.lTableNameCode, s => s.TableName);

                    }
                    catch (Exception ex)
                    {
                        return null;
                    }
                    finally
                    {
                        if (dr != null)
                        {
                            dr.Dispose();
                        }
                    }

                }
                return _syncTableNameDic;
            }
        }
        #endregion

        #region EnSyncTableDetail 表结构实体扩展方法


        public static bool GetIsIdentity(this EnSyncTableDetail enSyncTableDetail)
        {
            return enSyncTableDetail.IsIdentity == 1;
        }

        /// <summary>
        /// 根据列名合并字符串
        /// </summary>
        /// <param name="enSyncTableDetailList"></param>
        /// <param name="separator"></param>
        /// <param name="hasGenIdentityColumn"></param>
        /// <returns></returns>
        public static string ToStringJoin(this List<EnSyncTableDetail> enSyncTableDetailList, bool hasGenIdentityColumn = false, string separator = ",")
        {
            return string.Join(separator, enSyncTableDetailList
                .Where(s => hasGenIdentityColumn ? true : !s.GetIsIdentity())
                .Select(s => s.ColumnName).ToArray());
        }

        ///// <summary>
        ///// 把实体的值和表列名比对，生成insert语句值
        ///// </summary>
        ///// <typeparam name="T"></typeparam>
        ///// <param name="entity"></param>
        ///// <returns></returns>
        //private static string ToStringJoinEntityValue<T>(this List<EnSyncTableDetail> enSyncTableDetailList, T entity,bool hasGenIdentityColumn = false, string separator="," )
        //{
        //    Type t = typeof(T);
        //    var tableColumns = enSyncTableDetailList
        //        .Where(s => hasGenIdentityColumn ? true : !s.GetIsIdentity())
        //        .Select(s =>t.GetProperty(s.ColumnName).FastGetValue(entity));
        //    return string.Join(separator,tableColumns);
        //}

        /// <summary>
        /// 根据服务端同步表从表生成插入客户端数据库的语句，并生成插入对应MapCode映射服务端ID和客户端ID语句
        /// </summary>
        /// <param name="slave"></param>
        /// <param name="hasGenIdentityColumn"></param>
        /// <param name="hasReplace"></param>
        /// <param name="isInsertWhenNotExists"></param>
        /// <returns></returns>
        public static string[] ToInsertSqliteSql(this EnMobileSyncServerSlave slave, bool hasGenIdentityColumn = false, bool hasReplace = true, bool isInsertWhenNotExists = true)
        {
            List<EnSyncTableDetail> enSyncTableDetailList = slave.GetTableDetailInfo();
            string lServerCode = slave.sTableCode;
            if (enSyncTableDetailList == null || enSyncTableDetailList.Count == 0)
                return null;
            int lTableNameCode = enSyncTableDetailList.First().lTableNameCode;
            string tableName = SyncTableNameDic[lTableNameCode];
            tableName = tableName.Length > 30 ? tableName.Substring(0, 30) : tableName;
            var identityColumn = enSyncTableDetailList.Find(td => td.GetIsIdentity());
            string sql = "";
            if (isInsertWhenNotExists)
            {
                sql = "insert " + (hasReplace ? "or replace" : "") + " into " + tableName + "(" + enSyncTableDetailList.ToStringJoin(hasGenIdentityColumn) + ") select "
                  + slave.ToStringJoinColumnValue(hasGenIdentityColumn, null, "'{0}' ") + " where not exists ( select * from " + tableName + " where 1=1 " + slave.ToWhereCondition() + " )";
            }
            else
            {
                sql = "insert " + (hasReplace ? "or replace" : "") + " into " + tableName + "(" + enSyncTableDetailList.ToStringJoin(hasGenIdentityColumn) + ") values ( "
                  + slave.ToStringJoinColumnValue(hasGenIdentityColumn) + ");";
            }
            string mapCodeSql = " insert into TM_MapCode(lServerCode,lClientCode,lTableNameCode,sPersonCode,ColumnName) select '" + lServerCode + "','#@" + lTableNameCode + "_" + identityColumn.ColumnName + ":" + lServerCode + "@#'," + lTableNameCode + ",'','" + identityColumn.ColumnName + "' where not exists(select * from tm_mapcode where lservercode='" + lServerCode + "' and lTableNameCode=" + lTableNameCode + " and columnName collate nocase='" + identityColumn.ColumnName + "' );";

            string selectMapCode = " select lServerCode from tm_mapcode where lservercode='" + lServerCode + "' and lTableNameCode=" + lTableNameCode + " and columnName collate nocase='" + identityColumn.ColumnName + "' ;";

            return new string[] { sql, mapCodeSql, selectMapCode };
        }
        /// <summary>
        /// 服务器生成自增ID后，生成插入Sqlite客户端MapCode映射表语句
        /// </summary>
        /// <param name="slave">同步从表实体</param>
        /// <param name="dbGuid">数据库唯一标识</param>
        /// <returns></returns>
        public static string ToInsertMapCodeSqliteSql(this EnMobileSyncServerSlave slave, string dbGuid)
        {
            List<EnSyncTableDetail> enSyncTableDetailList = slave.GetTableDetailInfo();
            string lServerCode = slave.sTableCode;
            int lTableNameCode = enSyncTableDetailList.First().lTableNameCode;
            var identityColumn = enSyncTableDetailList.Find(td => td.GetIsIdentity());
            if (string.IsNullOrEmpty(slave.sTableCode3)|| !new Guid(dbGuid).Equals(new Guid(slave.sTableCode3)))
                return "";
            string mapCodeSql = " insert into TM_MapCode(lServerCode,lClientCode,lTableNameCode,sPersonCode,ColumnName)  select '" + slave.sTableCode + "','" + slave.sTableCode2 + "'," + lTableNameCode + ",'','" + identityColumn.ColumnName + "'  where not exists(select * from tm_mapcode where lservercode='" + lServerCode + "' and lTableNameCode=" + lTableNameCode + " and columnName collate nocase='" + identityColumn.ColumnName + "' );";
            return mapCodeSql;
        }


        ///// <summary>
        ///// 根据表字段生成插入语句
        ///// </summary>
        ///// <param name="enSyncTableDetailList">表列实体列表</param>
        ///// <param name="hasGenIdentityColumn"></param>
        ///// <param name="hasReplace"></param>
        ///// <returns></returns>
        //public static string[] ToInsertSqliteSql<T>(this List<EnSyncTableDetail> enSyncTableDetailList, T entity, bool hasGenIdentityColumn = false, bool hasReplace = true)
        //{
        //    return enSyncTableDetailList.ToInsertSqliteSql(enSyncTableDetailList.ToStringJoinEntityValue(entity), hasGenIdentityColumn, hasReplace);
        //}

        public static IEnumerable<EnSyncTableDetail> FindPrimaryKeyColumns(this List<EnSyncTableDetail> enSyncTableDetailList)
        {
            return enSyncTableDetailList.Where(s => (s.IsPrimaryKey == 1));
        }

        #endregion


        #region EnMobileSyncServerSlave 同步从表实体扩展方法
        /// <summary>
        /// 把实体的值和表列名比对，生成insert语句值
        /// </summary>
        ///<param name="format">格式{0}传入列值，{1}传入列名</param>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        private static string ToStringJoinColumnValue(this EnMobileSyncServerSlave slave, bool hasGenIdentityColumn = false, DataTable dt = null, string format = "'{0}'", string separator = ",")
        {
            if (format == null) format = "{0}";

            DataTable tempdt = dt ?? DaMobileSyncServer.Instance.GetDataTable(slave);
            if (tempdt == null || tempdt.Rows.Count == 0)
            {
                Debug.WriteLine("tempdt is null or Rows.Count=0");
                return null;

            }

            Func<EnSyncTableDetail, string> formatColumnValue = s => string.Format(string.IsNullOrWhiteSpace(s.sForeignColumnName) ? "{0}" : "#@" + s.sForeignTableCode + "_" + s.sForeignColumnName + ":{0}@#", tempdt.Rows[0][s.ColumnName].GetType() == typeof(DateTime) ? Convert.ToDateTime(tempdt.Rows[0][s.ColumnName]).ToString("yyyy-MM-dd HH:mm:ss").Replace("/", "-") : tempdt.Rows[0][s.ColumnName].ToString());
            var tableColumns = slave.GetTableDetailInfo()
                .Where(s => hasGenIdentityColumn ? true : !s.GetIsIdentity())//筛选出自增列
                .Select(s => string.Format(format, formatColumnValue(s), s.ColumnName));
            dt = tempdt;
            return string.Join(separator, tableColumns);
        }




        // /// <summary>
        ///// 根据表字段生成插入语句
        ///// </summary>
        ///// <param name="enSyncTableDetailList">表列</param>
        ///// <param name="hasGenIdentityColumn"></param>
        ///// <param name="hasReplace"></param>
        ///// <returns></returns>
        //public static string[] ToInsertSqliteSql(this EnMobileSyncServerSlave slave, bool hasGenIdentityColumn = false, bool hasReplace = false,bool isInsertWhenNotExists=true)
        //{
        //    return slave.GetTableDetailInfo().ToInsertSqliteSql(slave.ToStringJoinColumnValue(hasGenIdentityColumn,null,"'{0} as {1}"),slave.sTableCode,hasGenIdentityColumn, hasReplace,isInsertWhenNotExists);
        //}

        public static string ToUpdateSqliteSql(this EnMobileSyncServerSlave slave)
        {
            List<EnSyncTableDetail> tableDetailList = slave.GetTableDetailInfo();
            if (tableDetailList == null || tableDetailList.Count == 0)
                return null;
            DataTable dt = DaMobileSyncServer.Instance.GetDataTable(slave);
            string tableName = SyncTableNameDic[tableDetailList.First().lTableNameCode];
            tableName = (tableName.Length > 30 ? tableName.Substring(0, 30) : tableName);

            string columnSetString = slave.ToStringJoinColumnValue(hasGenIdentityColumn: false, dt: dt, format: "{1}='{0}'");

            string sql = "update " + tableName + " set " + columnSetString + " where 1=1 " + slave.ToWhereCondition() + "; ";
            return sql;
        }

        public static string ToSelectSqliteSql(this EnMobileSyncServerSlave slave, DataTable dt, string selectColumnName = "*")
        {
            List<EnSyncTableDetail> tableDetailList = slave.GetTableDetailInfo();
            string tableName = SyncTableNameDic[tableDetailList.First().lTableNameCode];
            tableName = (tableName.Length > 30 ? tableName.Substring(0, 30) : tableName);
            string joinString = "";
            string conditionString = "";
            var primaryKeyColumns = tableDetailList.FindPrimaryKeyColumns().ToList();
            for (int i = 0; i < primaryKeyColumns.Count; i++)
            {
                {
                    var t = primaryKeyColumns[i];
                    joinString += string.Format(" join TM_MapCode {0} on {0}.columnName collate nocase='{1}' and a.{1}={0}.lClientCode and {0}.lTableNameCode={2} ", "m_" + t.ColumnName, t.ColumnName, t.lTableNameCode);
                    string tableCode = null;
                    switch (i + 1)
                    {
                        case 1:
                            tableCode = slave.sTableCode;
                            break;
                        case 2:
                            tableCode = slave.sTableCode2;
                            break;
                        case 3:
                            tableCode = slave.sTableCode3;
                            break;

                        default:
                            break;
                    }
                    conditionString += string.Format(" {0}.lservercode='{1}'", "m_" + t.ColumnName, tableCode);
                }
            }
            return "select " + (selectColumnName ?? "*") + " from  " + tableName + " a " + joinString + " where " + conditionString + " ";


        }

        private static string ToWhereCondition(this EnMobileSyncServerSlave slave)
        {
            List<EnSyncTableDetail> tableDetailList = slave.GetTableDetailInfo();
            DataTable dt = DaMobileSyncServer.Instance.GetDataTable(slave);
            string condition = "";
            var primaryColumns = tableDetailList.Where(td => td.GetIsIdentity()).ToList();
            if (primaryColumns.Count == 0)
                condition = " and 1=2 ";
            else
            {
                primaryColumns.ForEach(td =>
                {
                    condition += " and " + td.ColumnName + "=(" + slave.ToSelectSqliteSql(dt, "a." + td.ColumnName) + " limit 0,1)";
                });
            }
            return condition;
        }
        /// <summary>
        /// 通过服务端同步表生成删除客户端数据的语句，并删除对应MapCode
        /// </summary>
        /// <param name="slave"></param>
        /// <returns></returns>
        public static string[] ToDeleteSqliteSql(this EnMobileSyncServerSlave slave)
        {
            string sql = "";
            List<EnSyncTableDetail> tableDetailList = slave.GetTableDetailInfo();
            string tableName = SyncTableNameDic[tableDetailList.First().lTableNameCode];
            tableName = (tableName.Length > 30 ? tableName.Substring(0, 30) : tableName);
            DataTable dt = DaMobileSyncServer.Instance.GetDataTable(slave);
            string lServerCode = slave.sTableCode;
            int lTableNameCode = tableDetailList.First().lTableNameCode;
            var identityColumn = tableDetailList.Find(td => td.GetIsIdentity());

            sql= "delete from " + tableName + " where 1=1 " + slave.ToWhereCondition() + ";";
            string deleteMapCodeSql = " delete from TM_MapCode where lServerCode='" + lServerCode + "' and lTableNameCode="+lTableNameCode+";";
            return new string[] {sql, deleteMapCodeSql};

        }

        /// <summary>
        /// 根据列名合并主键
        /// </summary>
        /// <param name="enSyncTableDetailList"></param>
        /// <param name="separator"></param>
        /// <param name="hasGenIdentityColumn"></param>
        /// <returns></returns>
        public static string ToStringJoinPrimaryKeyCondition(this EnMobileSyncServerSlave enMobileSyncServerSlave, string format = " and {0}='{1}'")
        {
            if (format == null) format = " and {0}='{1}'";
            var primaryKeyColumns = enMobileSyncServerSlave.GetTableDetailInfo()
                .Where(s => (s.IsPrimaryKey == 1))
                .Select(s => s.ColumnName).ToList();
            string condition = " 1=1 ";
            if (primaryKeyColumns.Count <= 3)
            {
                if (!string.IsNullOrWhiteSpace(enMobileSyncServerSlave.sTableCode))
                    condition += string.Format(format, primaryKeyColumns[0], enMobileSyncServerSlave.sTableCode);
                if (!string.IsNullOrWhiteSpace(enMobileSyncServerSlave.sTableCode2) && enMobileSyncServerSlave.lType != 4)
                    condition += string.Format(format, primaryKeyColumns[1], enMobileSyncServerSlave.sTableCode2);
                if (!string.IsNullOrWhiteSpace(enMobileSyncServerSlave.sTableCode3) && enMobileSyncServerSlave.lType != 4)
                    condition += string.Format(format, primaryKeyColumns[2], enMobileSyncServerSlave.sTableCode3);
            }
            else
            {
                condition = " 1=2 ";
            }
            return condition;
        }

        public static List<EnSyncTableDetail> GetTableDetailInfo(this EnMobileSyncServerSlave slave)
        {
            return SyncHelper.SyncTableDetailDic[slave.lTableNameCode];
        }


        #endregion


        #region EnMobileSyncClientSlave 客户端同步主表实体方法
        public static Dictionary<string, string> ToInsertMSSql(this EnMobileSyncClientSlave slave, SqlTransaction trans, string sPersonCode, string dbGuid, int lSyncMainCode, Dictionary<string, string> mapCodeDic)
        {
            List<EnSyncTableDetail> enSyncTableDetailList = slave.GetTableDetailInfo();
            int lTableNameCode = enSyncTableDetailList.First().lTableNameCode;
            string lClientCode = slave.sTableCode;
            if (enSyncTableDetailList == null || enSyncTableDetailList.Count == 0)
                return null;
            string tableName = SyncTableNameDic[lTableNameCode];
            var identityColumn = enSyncTableDetailList.Find(td => td.GetIsIdentity());

            string sql = @" declare @lservercode int 
                insert into " + tableName + "(" + enSyncTableDetailList.ToStringJoin(false) + ") values (" + slave.ToStringJoinEntityValue(mapCodeDic) + @") 
                set @lservercode= SCOPE_IDENTITY() ";
            sql += @" INSERT INTO dbo.TM_MobileSyncServerSlave ( lSyncMainCode, lTableNameCode, sTableCode, dAddTime, lType, lSyncState, sTableCode2, sTableCode3 )
                      Values(" + lSyncMainCode + "," + slave.lTableNameCode + ", cast (@lservercode as nvarchar(30)),getdate()," + slave.lType + ",0,null,null)   ";
            if (identityColumn != null)//返回自增ID映射
            {
                sql += @" INSERT INTO dbo.TM_MobileSyncServer ( dAddTime, lSyncState, sPersonCode, lSyncType ) VALUES  ( GETDATE(), 0, '" + sPersonCode + "',  0  ) ";
                sql += @" INSERT INTO dbo.TM_MobileSyncServerSlave ( lSyncMainCode, lTableNameCode, sTableCode, dAddTime, lType, lSyncState, sTableCode2, sTableCode3 )
            VALUES  ( SCOPE_IDENTITY(), " + lTableNameCode + ",cast (@lservercode as nvarchar(30)), GETDATE(), 4, 0, " + (string.IsNullOrWhiteSpace(lClientCode) ? "NULL" : lClientCode) + ", " + (string.IsNullOrWhiteSpace(dbGuid) ? "NULL" : "'" + dbGuid + "'") + " ) ";
                sql += @" select @lservercode ";
                
            }
 

            _logMgr.WriteInfoFormat("语句:{0};", sql);
            DataTable dt = SqlHelper.ExecuteDataset(trans, CommandType.Text, sql).Tables[0];
            string lServerCode = dt.Rows[0][0].ToString();
            string key = "#@" + lTableNameCode + "_" + identityColumn.ColumnName + ":" + lClientCode + "@#";
            mapCodeDic.Add(key, lServerCode);
            return mapCodeDic;
        }



        public static string ToUpdateOrDeleteMSSqlString(this EnMobileSyncClientSlave slave, string sPersonCode, int lSyncMainCode, Dictionary<string, string> mapCodeDic, bool isUpdate)
        {
            List<EnSyncTableDetail> enSyncTableDetailList = slave.GetTableDetailInfo();
            int lTableNameCode = enSyncTableDetailList.First().lTableNameCode;
            // string lClientCode = slave.sTableCode;
            if (enSyncTableDetailList == null || enSyncTableDetailList.Count == 0)
                return null;
            var primaryColumns = enSyncTableDetailList.Where(td => td.GetIsIdentity()).ToList();
            Type tableType = SyncHelper.SyncTableMapTypeDic[lTableNameCode];
            object entity = JSONHelper.DeserializeJSON(slave.JSONEntityString, tableType);
            string condition = null;
            if (primaryColumns.Count == 0)
                condition = " and 1=2 ";
            else
            {
                //primaryColumns.ForEach(td =>
                //{
                //    string value = tableType.GetProperty(td.ColumnName).FastGetValue(entity).ToString();
                //    condition += " and " + td.ColumnName + "='" + RepalceByMapCode(mapCodeDic, td.lTableNameCode.ToString(), td.ColumnName, value) + "' ";
                //});
                for (int i = 0; i < primaryColumns.Count; i++)
                {
                    {
                        var td = primaryColumns[i];
                        string value = tableType.GetProperty(td.ColumnName).FastGetValue(entity).ToString();
                        value = RepalceByMapCode(mapCodeDic, td.lTableNameCode.ToString(), td.ColumnName, value);
                        if (slave.lType == 3 || slave.lType == 2)
                        {
                            switch (i + 1)
                            {
                                case 1:

                                    slave.sTableCode = value = RepalceByMapCode(mapCodeDic, td.lTableNameCode.ToString(), td.ColumnName, slave.sTableCode);
                                    break;
                                case 2:
                                    slave.sTableCode2 = value = slave.sTableCode2 = RepalceByMapCode(mapCodeDic, td.lTableNameCode.ToString(), td.ColumnName, slave.sTableCode2);
                                    break;
                                case 3:
                                    slave.sTableCode3 = value = slave.sTableCode3 = RepalceByMapCode(mapCodeDic, td.lTableNameCode.ToString(), td.ColumnName, slave.sTableCode3);
                                    break;

                                default:
                                    break;
                            }
                        }
                        condition += " and " + td.ColumnName + "='" + value + "' ";

                    }
                }
            }
            string tableName = SyncTableNameDic[lTableNameCode];
            string updateOrDelete = @" update  " + tableName + " set " + slave.ToStringJoinEntityValue(mapCodeDic, false, "{1}= '{0}'", "{1}= NULL");
            if (!isUpdate)
                updateOrDelete = "delete " + tableName;
            string sql = updateOrDelete + "  where 1=1 " + condition;
            Func<string, string> isNullValueString = s => string.IsNullOrWhiteSpace(s) ? "NULL" : "'" + s + "'";
            sql += @" INSERT INTO dbo.TM_MobileSyncServerSlave ( lSyncMainCode, lTableNameCode, sTableCode, dAddTime, lType, lSyncState, sTableCode2, sTableCode3 )
                      Values(" + lSyncMainCode + "," + slave.lTableNameCode + ", " + isNullValueString(slave.sTableCode) + ",getdate()," + slave.lType + ",0," + isNullValueString(slave.sTableCode2) + "," + isNullValueString(slave.sTableCode3) + ")   ";
            
            return sql;

        }

        private static string RepalceByMapCode(Dictionary<string, string> mapCodeDic, string foreignTableNameCode, string foreignColumnName, string value)
        {
            string foreignKey = "#@" + foreignTableNameCode + "_" + foreignColumnName + ":" + value + "@#";
            if (mapCodeDic != null && mapCodeDic.ContainsKey(foreignKey))
                return mapCodeDic[foreignKey];
            return value;

        }

        /// <summary>
        /// 把实体的值和表列名比对，生成insert语句值
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="entity"></param>
        /// <returns></returns>
        private static string ToStringJoinEntityValue(this EnMobileSyncClientSlave slave, Dictionary<string, string> mapCodeDic, bool hasGenIdentityColumn = false, string format = "'{0}'", string nullFormat = "NULL", string separator = ",")
        {
            List<EnSyncTableDetail> enSyncTableDetailList = slave.GetTableDetailInfo();
            int lTableNameCode = enSyncTableDetailList.First().lTableNameCode;
            Type tableType = SyncHelper.SyncTableMapTypeDic[lTableNameCode];
            object entity = JSONHelper.DeserializeJSON(slave.JSONEntityString, tableType);
            var tableColumns = enSyncTableDetailList
                .Where(s => hasGenIdentityColumn ? true : !s.GetIsIdentity())
                .Select(s =>
                {
                    try
                    {
                        object obj = tableType.GetProperty(s.ColumnName).FastGetValue(entity);
                        string value = null;
                        if (obj != null)
                            value = obj.ToString();
                        bool isNullFormat = false;
                        if (value ==null|| value.Replace("-","/") == "0001/1/1 0:00:00" )
                            isNullFormat = true;
                        return string.Format(isNullFormat ? nullFormat : format, RepalceByMapCode(mapCodeDic, s.sForeignTableCode.ToString(), s.sForeignColumnName, value), s.ColumnName);
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine(ex.Message);
                        return null;
                    }

                });
            return string.Join(separator, tableColumns);
        }




        public static List<EnSyncTableDetail> GetTableDetailInfo(this EnMobileSyncClientSlave slave)
        {
            return SyncHelper.SyncTableDetailDic[slave.lTableNameCode];
        }

        #endregion





    }
}
