﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;

using SysCommonLibrary.Entity;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Service.Common;
using Nd.Erp.Mobile.Service.Common.Entity;
using Nd.Erp.Mobile.Log;

namespace SysCommonLibrary.Business
{
    public partial class BzLoginCheck
    {
        private static LogMgr<BzLoginCheck> _logMgr = new LogMgr<BzLoginCheck>();

        /// <summary>
        /// 到91U服务器验证登录
        /// </summary>
        /// <param name="sid"></param>
        /// <returns></returns>
        public static ResultStatusWithPersonInfo CheckPower(string sid)
        {
            string serverUrl = SQLiteAccess.GetSysArgValue("91Check");

            HttpClient client = new HttpClient();
            En91Check checker = null;
            var result = new ResultStatusWithPersonInfo() { IsSuccess = false, ErrorInfo = "验证失败" };

            client.PostAsJsonAsync(serverUrl, new { uap_sid = sid, insidepassport = "1" }).ContinueWith(
            checkResult =>
            {
                if (checkResult.Result.StatusCode == HttpStatusCode.OK)
                {
                    checker = checkResult.Result.Content.ReadAsStringAsync().Result.DeserializeJSON<En91Check>();
                    result.PersonInfo = BzPersonAndDept.GetPersonInfoInCache(checker.uid);
                    result.PersonInfo.sPassword = BzPersonAndDept.GetLoginUserInCache(checker.uid).Password; 

                    ResultStatus tmp = CheckPower(checker.uid, result.PersonInfo.sPassword)[0];
                    result.IsSuccess = tmp.IsSuccess;
                    result.ErrorInfo = tmp.ErrorInfo;
                    result.IsProxy = tmp.IsProxy;
                    result.UserGUID = tmp.UserGUID;                                 
                }
            }).Wait();

            return result;
        }

        #region 验证用户（不返回用户信息）
        /// <summary>验证用户（不返回用户信息）</summary>
        /// <param name="osType">设备类型</param>
        /// <param name="sPersonCode">用户工号</param>
        /// <param name="sPassword">用户密码</param>      
        /// <param name="deviceName">设备名称</param>
        /// <param name="deviceUUIDHash">设备唯一标识散列</param>
        /// <returns>验证结果</returns>
        public static List<ResultStatus> CheckPower(string sPersonCode, string sPassword, string osType = null, string deviceName = null, string deviceUUIDHash = null, string sdkVersion = null)
        {
            var list = new List<ResultStatus>();
            try
            {
                var loginUser = BzPersonAndDept.GetLoginUserInCache(sPersonCode);
                if (loginUser == null || loginUser.Password != sPassword)
                {
                    list.Add(new ResultStatus { IsSuccess = false, ErrorInfo = "用户名或密码不正确。" });
                }
                else
                {
                    string userGUID = Guid.NewGuid().ToString();
                    UserData ud = UserCache.Get(sPersonCode, userGUID);
                    if (ud == null)
                        ud = new UserData { UserID = sPersonCode, UserGUID = userGUID, FirstTime = DateTime.Now, OSType = osType, LifeTime = DateTime.MaxValue };
                    else
                        ud.LifeTime = DateTime.Now;
                    UserCache.Add(ud);
                    list.Add(new ResultStatus { IsSuccess = true, UserGUID = userGUID });

                    Action asycAddPersonDeviceInfo = () => DaLoginUser.AddPersonDeviceInfo(new EnLoginMobileDevice() { sPersonCode = sPersonCode, sDeviceName = deviceName, sDeviceUUIDHashed = deviceUUIDHash, sSDKVersion = sdkVersion });
                    if (!string.IsNullOrWhiteSpace(deviceUUIDHash))
                        asycAddPersonDeviceInfo.BeginInvoke(null, asycAddPersonDeviceInfo);
                }
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("登录权限验证失败:{0}", ex.ToString());
                list.Add(new ResultStatus { IsSuccess = false, ErrorInfo = "登录权限验证失败:" + ex.Message });
            }
            _logMgr.WriteInfo("调用CheckPower 完毕");
            return list;
        }
        #endregion
    }
}
