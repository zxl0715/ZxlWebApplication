﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Nd.Erp.Mobile.Service.Common.Extensions;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;
using System.Diagnostics;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace Nd.Erp.Mobile.Service.Common
{
    /// <summary>
    /// 获取人员和部门相关方法
    /// </summary>
    public partial class BzPersonAndDept
    {
        private static ICacheClient _cache = CacheManager.CacheClient;
        private static readonly object deptlocker = new object();
        private static readonly object loginUserlocker = new object();
        private static readonly object personInfolocker = new object();
        private static readonly object personAndDepInfolocker = new object();
        private static readonly object personLoginDeviceInfolocker = new object();
        public const string deptAllKey = "BzPersonAndDept_Dept";
        public const string loginUserAllKey = "BzPersonAndDept_LoginUser";
        public const string personInfoAllKey = "BzPersonAndDept_PersonInfo";
        public const string personAndDepInfoAllKey = "BzPersonAndDept_PersonAndDepInfo";
        public const string personLoginDeviceInfoAllKey = "BzPersonAndDept_PersonLoginDeviceInfo";

        /// <summary>
        /// 从缓存中获取部门信息
        /// </summary>
        /// <param name="depCode"></param>
        /// <returns></returns>
        public static DepInfo GetDepByDepCodeInCache(string depCode) {
            return CacheHelper.GetEntityInCache<DepInfo, string, DaDepInfo>(deptlocker, depCode, deptAllKey, new TimeSpan(24, 0, 0));
        }

        /// <summary>
        /// 从缓存中获取登陆用户
        /// </summary>
        /// <param name="personCode"></param>
        /// <returns></returns>
        public static LoginUser GetLoginUserInCache(string personCode) {
            return CacheHelper.GetEntityInCache<LoginUser, string, DaLoginUser>(loginUserlocker, personCode, loginUserAllKey, new TimeSpan(24, 0, 0));
        }


        public static ICollection<PersonEntity> GetAllPersonInfoListInCache() {
            return CacheHelper.GetEntityListInCache<PersonEntity, string, DaPersonInfo>(personInfolocker, personInfoAllKey, new TimeSpan(24, 0, 0), () =>
            {
                //未加载部门缓存则不加载所有人员信息
                var deptDict = _cache.Get<ConcurrentDictionary<string, DepInfo>>(deptAllKey);
                if (deptDict == null)
                {
                    GetAllDepInfoListInCache();
                    return true;
                }
                return true;
            },
            dict =>
            {
                foreach (var d in dict.Values)
                {
               
                    d.sDepName = (GetDepByDepCodeInCache(d.sDepCode) ?? new DepInfo()).DepName;
                 
                }
            }
            ).Values;
        }

         public static ICollection<EnPersonAndDep> GetAllPersonAndDepInfoListInCache() {
             return CacheHelper.GetEntityListInCache<EnPersonAndDep, string, DaPersonAndDepInfo>(personAndDepInfolocker, personAndDepInfoAllKey, new TimeSpan(24, 0, 0), () =>
            {
                //未加载部门缓存则不加载所有人员信息
                var deptDict = _cache.Get<ConcurrentDictionary<string, DepInfo>>(deptAllKey);
                if (deptDict == null)
                {
                    GetAllDepInfoListInCache();
                    return true;
                }
                return true;
            },
            dict =>
            {
                foreach (var d in dict.Values)
                {
                    DepInfo depInfo = new DepInfo();
                    depInfo = GetDepByDepCodeInCache(d.sDepCode);
                    if (depInfo != null)
                    {
                        d.sDepName = depInfo.DepName;
                        d.sFDepCode = depInfo.FDepCode;
                        d.lDepGrade = depInfo.DepGrade;
                    }
                }
            }
            ).Values;
        }

        public static ICollection<DepInfo> GetAllDepInfoListInCache() {
            return CacheHelper.GetEntityListInCache<DepInfo, string,DaDepInfo>(deptlocker, deptAllKey, new TimeSpan(24, 0, 0)).Values;
        
        }


 
        /// <summary>
        /// 获取用户设备信息
        /// </summary>
        /// <param name="deviceUUIDHashed"></param>
        /// <returns></returns>
        public static EnLoginMobileDevice GetDeviceInfoInCache(string deviceUUIDHashed,string userID)
        {
            return CacheHelper.GetEntityGroupInCache<EnLoginMobileDevice, string>(personLoginDeviceInfolocker, userID+"_"+deviceUUIDHashed, personLoginDeviceInfoAllKey, new TimeSpan(1, 0, 0),
                null, null,
                customGetDict: GetDeviceInfoDictForDeviceUUIDHashed,
                customGetEntity: u => DaDeviceInfo.GetDaInstance<DaDeviceInfo>().GetEntityListByDeviceUUIDAndUserID(u));
        }

        public static int CurrentMaxDeviceAutoCode = 0;

        /// <summary>
        /// 获取根据用户为key的字典，用于加载缓存（调用后会更新当前最新时间）
        /// </summary>
        /// <returns></returns>
        private static ConcurrentDictionary<string, EnLoginMobileDevice> GetDeviceInfoDictForDeviceUUIDHashed()
        {
            var deviceInfoList = DaDeviceInfo
                .GetDaInstance<DaDeviceInfo>()
                .GetEntityListToDict();
            if (deviceInfoList.Any())
            {
                var maxDeviceAutoCode = deviceInfoList.Max(d=>d.AutoCode);
                if (maxDeviceAutoCode >= CurrentMaxDeviceAutoCode)
                    CurrentMaxDeviceAutoCode = maxDeviceAutoCode;
            }

            return new ConcurrentDictionary<string, EnLoginMobileDevice>(
                deviceInfoList.GroupBy(s => s.sPersonCode+"_"+s.sDeviceUUIDHashed).ToDictionary(g => g.Key, g => g.FirstOrDefault())
            );
        }


        /// <summary>
        /// 从缓存中获用户信息
        /// </summary>
        /// <param name="personCode"></param>
        /// <returns></returns>
        public static PersonEntity GetPersonInfoInCache(string personCode)
        {
            var person = CacheHelper.GetEntityInCache<PersonEntity, string, DaPersonInfo>(personInfolocker, personCode, personInfoAllKey, new TimeSpan(24, 0, 0), () =>
            {
                //未加载部门缓存则不加载所有人员信息
                var deptDict = _cache.Get<ConcurrentDictionary<string, DepInfo>>(deptAllKey);
                if (deptDict == null)
                {
                    GetAllDepInfoListInCache();
                    return false;
                }
                return true;
            },
            dict =>
            {
                foreach (var d in dict.Values)
                {
                    d.sDepName = (GetDepByDepCodeInCache(d.sDepCode) ?? new DepInfo()).DepName;
                }
            }
            );

            if (person.sDepName == null)
                person.sDepName = (GetDepByDepCodeInCache(person.sDepCode) ?? new DepInfo()).DepName;
            return person;
        }
         #region 缓存监控线程
        public static int fobbidenCount = -1;
        public static DateTime lastCheckTime = DateTime.MinValue;
        /// <summary>
        /// 异步监控同步表是否有变化，如果有变化，则更新对应员工的缓存
        /// </summary>
        public static void AsyncCheckSyncChange(bool isAsync = true)
        {
                Action asyncCheckSyncChangeAction = () =>
                {
                    lock (personLoginDeviceInfolocker)
                    {
                        if (DateTime.Now > lastCheckTime.AddSeconds(10))
                        {
                            if (DaDeviceInfo.GetFobbidenCount() != fobbidenCount)
                            {
                                _cache.GetAllKeys().ToList().ForEach(key => {
                                    if (key.StartsWith(personLoginDeviceInfoAllKey))
                                        _cache.Remove(key);
                                });
                                
                            }
                            lastCheckTime = DateTime.Now;
                        }
                    }
                };
                if (isAsync)
                    new Task(asyncCheckSyncChangeAction).Start();
                else
                    asyncCheckSyncChangeAction();

        }


        /// <summary>
        /// 部门人员开始
        /// </summary>
        static BzPersonAndDept()
        {
            System.Timers.Timer t = new System.Timers.Timer();
            t.Interval = 10000;
            t.Elapsed += (o, e) => AsyncCheckSyncChange();
            t.AutoReset = true;//设置是执行一次（false）还是一直执行(true)；   
            t.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；
        }

        #endregion
      
	}
}
