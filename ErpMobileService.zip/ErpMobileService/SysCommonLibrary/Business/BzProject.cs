﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Nd.Erp.Mobile.Service.Common.Extensions;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;
using System.Diagnostics;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;
using System.Threading.Tasks;

namespace Nd.Erp.Mobile.Service.Common
{
    /// <summary>
    /// 获取人员和部门相关方法
    /// </summary>
    public partial class BzProject
    {
        private static ICacheClient _cache = CacheManager.CacheClient;
        private static readonly object locker = new object();

        public const string projectInfoAllKey = "BzProject_ProjectInfo";

        /// <summary>
        /// 从缓存中获取部门信息
        /// </summary>
        /// <param name="depCode"></param>
        /// <returns></returns>
        public static EnProject GetProjectInCache(string xmCode)
        {
            return CacheHelper.GetEntityInCache<EnProject, string, DaTop2GradeProject>(locker, xmCode, projectInfoAllKey, new TimeSpan(24, 0, 0));
        }


        public static ICollection<EnProject> GetAllProjectListInCache()
        {
            return CacheHelper.GetEntityListInCache<EnProject, string,DaProject>(locker, projectInfoAllKey, new TimeSpan(24, 0, 0)).Values;
        }       

	}
}
