﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Nd.Erp.Mobile.Service.Common.Extensions;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;
using System.Diagnostics;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;
using System.Threading.Tasks;
using System.Threading;
using Nd.Erp.Mobile.Log;

namespace Nd.Erp.Mobile.Service.Common
{
    /// <summary>
    /// 手机同步主数据实体
    /// </summary>
    public partial class BzMobileSyncServer
    {
        private static ICacheClient _cache = CacheManager.CacheClient;
        public const string MobileSyncServerAllKey = "BzMobileSyncServer_MobileSyncServer";
        public const string MobileSyncServerSlaveAllKey = "BzMobileSyncServer_MobileSyncServerSlave";
        private static readonly object lasteastOneMonthMobileSyncLocker = new object();
        private static readonly object syncLocker = new object();
        private static readonly object syncSlaveLocker = new object();
        protected static LogMgr<BzMobileSyncServer> _logMgr = new LogMgr<BzMobileSyncServer>();

        private static int lastestSyncMobileCode = 0;
        private static DateTime minDate = DateTime.MaxValue;
        private static DateTime maxDate = DateTime.MinValue;

        /// <summary>
        /// 从缓存同步表取最近一个月的信息
        /// </summary>
        /// <param name="userCode">员工工号</param>
        /// <returns></returns>
        public static List<EnMobileSyncServer> GetLasteastOneMonthMobileSyncServerListInCacheByUserCode(string userCode)
        {
            return CacheHelper.GetEntityGroupInCache<List<EnMobileSyncServer>, string>(lasteastOneMonthMobileSyncLocker, userCode, MobileSyncServerAllKey, new TimeSpan(24, 0, 0),
                null, null,
                customGetDict: GetLasteastOneMonthMobileSyncServerDictForUserCode,
                customGetEntity: u => DaMobileSyncLasteastOneMonth.GetDaInstance<DaMobileSyncLasteastOneMonth>().GetEntityList(u));
        }
        class SyncTemp:IComparable<SyncTemp> {
            public int lSyncMainCode { get; set; }
            public DateTime dAddTime { get; set; }

            public int CompareTo(SyncTemp obj)
            {
                return  this.lSyncMainCode-obj.lSyncMainCode;
            }
        }
        /// <summary>
        /// 获取根据用户为key的字典，用于加载缓存（调用后会更新当前最新时间）
        /// </summary>
        /// <returns></returns>
        private static ConcurrentDictionary<string, List<EnMobileSyncServer>> GetLasteastOneMonthMobileSyncServerDictForUserCode()
        {
            var lasteastOneMonthMobileSyncList = DaMobileSyncLasteastOneMonth
                .GetDaInstance<DaMobileSyncLasteastOneMonth>()
                .GetEntityListToDict();
            if (lasteastOneMonthMobileSyncList.Any())
            {
                var maxSyncEntity = lasteastOneMonthMobileSyncList.Max(l => new SyncTemp { lSyncMainCode=l.lSyncMainCode,dAddTime= l.dAddTime });
                lastestSyncMobileCode = maxSyncEntity.lSyncMainCode;
                maxDate = maxSyncEntity.dAddTime;
                minDate = lasteastOneMonthMobileSyncList.Min(l => l.dAddTime);
            }

            return new ConcurrentDictionary<string, List<EnMobileSyncServer>>(
                lasteastOneMonthMobileSyncList.GroupBy(s => s.sPersonCode).ToDictionary(g => g.Key, g => g.ToList())
                );
        }

        /// <summary>
        /// 获取服务器端修改的数据同步信息
        /// </summary>
        /// <param name="sPersonCode"></param>
        /// <param name="dbGuid"></param>
        /// <param name="dAddTime"></param>
        /// <returns></returns>
        public static List<EnMobileSyncServer> GetSyncInfoByAddTime(string sPersonCode, string dbGuid, string dAddTime)
        {
            return DaMobileSyncServer.Instance.GetSyncInfoByAddTime(sPersonCode, dbGuid, dAddTime, false);
        }
        /// <summary>
        /// 获取服务器端修改的数据同步信息
        /// </summary>
        /// <param name="sPersonCode"></param>
        /// <param name="dbGuid"></param>
        /// <param name="dAddTime"></param>
        /// <returns></returns>
        public static List<EnMobileSyncServer> GetSyncInfoByAddTimeInCache(string sPersonCode, string dbGuid, string dAddTime)
        {
            DateTime addTime = Convert.ToDateTime(dAddTime);
            var lastestSync = BzMobileSyncServer.GetLasteastOneMonthMobileSyncServerListInCacheByUserCode(sPersonCode).FindAll(l=>l!=null).OrderByDescending(l=>l.dAddTime).ToList();
            if (addTime < minDate || (lastestSync != null && lastestSync.Exists(s => s.dAddTime > addTime.AddSeconds(1))))
                return DaMobileSyncServer.Instance.GetSyncInfoByAddTime(sPersonCode, dbGuid, dAddTime, false);
            return new List<EnMobileSyncServer>();
        }
        public static EnPostSyncBackInfo PostSyncInfo(string sPersonCode, string dbGuid, string dAddTime, List<EnMobileSyncClient> syncClientList)
        {
            var failClientCodeList = DaMobileSyncServer.Instance.PostSyncInfo(sPersonCode, dbGuid, dAddTime, syncClientList);
            EnPostSyncBackInfo enPostSyncBackInfo = new EnPostSyncBackInfo();
            enPostSyncBackInfo.FailList = failClientCodeList;
            try
            {
                enPostSyncBackInfo.EnMobileSyncServerList = DaMobileSyncServer.Instance.GetSyncInfoByAddTime(sPersonCode, dbGuid, dAddTime, true);
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("获取Mapcode失败:{0}", ex.Message);
            }

            //有修改操作，更新缓存
            AsyncCheckSyncChange(isAsync: false);
            return enPostSyncBackInfo;
        }


        #region 缓存监控线程
        public static DateTime lastCheckTime = DateTime.MinValue;

        /// <summary>
        /// 异步监控同步表是否有变化，如果有变化，则更新对应员工的缓存
        /// </summary>
        public static void AsyncCheckSyncChange(bool isAsync = true)
        {
            var syncCache = _cache.Get<ConcurrentDictionary<string, List<EnMobileSyncServer>>>(MobileSyncServerAllKey);
            if (syncCache != null)
            {
                Action asyncCheckSyncChangeAction = () =>
                {
                    lock (syncSlaveLocker)
                    {
                        if (DateTime.Now > lastCheckTime.AddSeconds(1))
                        {
                            var result = DaMobileSyncLasteastOneMonth.GetDaInstance<DaMobileSyncLasteastOneMonth>().GetEntityList(maxDate);

                            if (result.Any())
                            {
                                result.GroupBy(r => r.sPersonCode).ToList().ForEach(g =>
                                {
                                    if (!syncCache.ContainsKey(g.Key))
                                    {
                                        syncCache[g.Key] = g.ToList();
                                    }
                                    else
                                    {
                                        syncCache[g.Key].AddRange(g.ToList());
                                    }
                                    _cache.Remove(MobileSyncServerAllKey + "_" + g.Key);
                                });

                                var descResutl=result.OrderByDescending(l=>l.lSyncMainCode);
                                var maxSyncEntity = descResutl.FirstOrDefault();
                                lastestSyncMobileCode = maxSyncEntity.lSyncMainCode;
                                maxDate = maxSyncEntity.dAddTime;
                                minDate = result.LastOrDefault().dAddTime;
                            }
                            lastCheckTime = DateTime.Now;
                        }
                    }
                };
                if (isAsync)
                    new Task(asyncCheckSyncChangeAction).Start();
                else
                    asyncCheckSyncChangeAction();
            }

        }

        /// <summary>
        /// 程序启动后自动定时执行
        /// </summary>
        static BzMobileSyncServer()
        {
            System.Timers.Timer t = new System.Timers.Timer();
            t.Interval = 1000;
            t.Elapsed += (o, e) => AsyncCheckSyncChange();
            t.AutoReset = true;//设置是执行一次（false）还是一直执行(true)；   
            t.Enabled = true;//是否执行System.Timers.Timer.Elapsed事件；
        }

        #endregion

    }
}
