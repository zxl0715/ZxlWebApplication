﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;
using System.Diagnostics;
using System.Threading.Tasks;

namespace Nd.Erp.Mobile.Service.Common
{
    public class CacheHelper
    {
        private static ICacheClient _cache = CacheManager.CacheClient;

        /// <summary>
        /// 从缓存获取实体
        /// </summary>
        /// <typeparam name="T">缓存类型</typeparam>
        /// <typeparam name="CacheKeyType">缓存键类型</typeparam>
        /// <typeparam name="DaType">数据访问类型</typeparam>
        /// <param name="locker">缓存锁，并发操作需要就加一个锁，防止重复加载</param>
        /// <param name="code">缓存键值</param>
        /// <param name="allKey">缓存键常量</param>
        /// <param name="timespan">缓存时间</param>
        /// <param name="isToLoadAllFunc">是否异步加载所有</param>
        /// <param name="action">对返回字典进行特殊操作</param>
        /// <param name="customGetDict">自定义字典方法</param>
        /// <param name="customGetEntity">自定义缓存实体方法</param>
        /// <returns></returns>
        public static T GetEntityInCache<T, CacheKeyType, DaType>(object locker, CacheKeyType code, string allKey, TimeSpan timespan,
            Func<bool> isToLoadAllFunc = null, Action<ConcurrentDictionary<CacheKeyType, T>> action = null
            , Func<ConcurrentDictionary<CacheKeyType, T>> customGetDict = null, Func<CacheKeyType, T> customGetEntity = null) where DaType : DaTemplate<T, CacheKeyType>
        { 
            if(customGetDict==null)
              customGetDict=()=>DaTemplate<T, CacheKeyType>.GetDaInstance<DaType>().GetDict();//获取默认以主键为KEY的字典
            if(customGetEntity==null)
                customGetEntity=c=>DaTemplate<T, CacheKeyType>.GetDaInstance<DaType>().GetEntity(c);
            return GetEntityInCache<T, CacheKeyType>(locker, code, allKey, timespan, isToLoadAllFunc, action, customGetDict, customGetEntity);
        }
        /// <summary>
        /// 从缓存获取实体列表
        /// </summary>
        /// <typeparam name="T">缓存类型</typeparam>
        /// <typeparam name="CacheKeyType">缓存键类型</typeparam>
        /// <typeparam name="DaType">数据访问类型</typeparam>
        /// <param name="locker">缓存锁，并发操作需要就加一个锁，防止重复加载</param>
        /// <param name="code">缓存键值</param>
        /// <param name="allKey">缓存键常量</param>
        /// <param name="timespan">缓存时间</param>
        /// <param name="isToLoadAllFunc">是否异步加载所有</param>
        /// <param name="action">对返回字典进行特殊操作</param>
        /// <param name="customGetDict">自定义字典方法</param>
        /// <param name="customGetEntity">自定义缓存实体方法</param>
        /// <returns></returns>
        public static ConcurrentDictionary<CacheKeyType,T> GetEntityListInCache<T, CacheKeyType, DaType>(object locker,string allKey, TimeSpan timespan,
            Func<bool> isToLoadAllFunc = null, Action<ConcurrentDictionary<CacheKeyType, T>> action = null
            , Func<ConcurrentDictionary<CacheKeyType, T>> customGetDict = null, Func<CacheKeyType, T> customGetEntity = null) where DaType : DaTemplate<T, CacheKeyType>
        {
            if (customGetDict == null)
                customGetDict = () => DaTemplate<T, CacheKeyType>.GetDaInstance<DaType>().GetDict();//获取默认以主键为KEY的字典
            return GetEntityListInCache<T, CacheKeyType>(locker, allKey, timespan, isToLoadAllFunc, action, customGetDict);
        }
        /// <summary>
        /// 从缓存中获取信息
        /// </summary>
        /// <param name="allKey">键值key前缀（加载所有的key）</param>
        /// <param name="code">主键值</param>
        /// <param name="isToLoadAll">是异步否加载所有，true是，如果未加载所有，则异步加载所有T类型对象</param>
        /// <remarks>采用异步加载，如果缓存未加载好，则先从数据库读取，避免第一次访问速度由于加载数据量大而变慢</remarks>
        /// <returns></returns>
        public static T GetEntityInCache<T, CacheKeyType>(object locker, CacheKeyType code, string allKey, TimeSpan timespan,
            Func<bool> isToLoadAllFunc = null, Action<ConcurrentDictionary<CacheKeyType, T>> action = null
            , Func<ConcurrentDictionary<CacheKeyType, T>> customGetDict = null, Func<CacheKeyType,T> customGetEntity = null)
        {
            var key = allKey + "_" + code.ToString();

            var dict = _cache.Get<ConcurrentDictionary<CacheKeyType, T>>(allKey);
            if (dict == null||dict.Count==0)
            {
                //异步加载缓存
                Action loadAllCache = () =>
                {
                    lock (locker)//避免第一次未加载缓存，重复访问多请求访问数据库读取所有数据
                    {
                        dict = _cache.Get<ConcurrentDictionary<CacheKeyType, T>>(allKey);
                        if (dict != null)
                            return;
                        if (isToLoadAllFunc != null && !isToLoadAllFunc())//如果特殊条件，例如需要其他缓存加载后才能加载此缓存的则跳过
                            return;
                        if (customGetDict != null)
                            dict = customGetDict();
                        if (action != null)
                            action(dict);
                        Debug.WriteLine(string.Format("add cache {0}", allKey));
                        _cache.Add(allKey, dict, timespan);
                    }
                };

                new Task(loadAllCache).Start();
               
                Debug.WriteLine(string.Format("get by code {0}", allKey));
                if(customGetEntity!=null)
                    return customGetEntity(code);
            }
            if (dict.ContainsKey(code))
                return dict[code];
            return default(T);
        }

        /// <summary>
        /// 从缓存中获取信息集合
        /// </summary>
        /// <param name="allKey">键值key前缀（加载所有的key）</param>
        /// <param name="isToLoadAll">是异步否加载所有，true是，如果未加载所有，则异步加载所有T类型对象</param>
        /// <remarks>采用异步加载，如果缓存未加载好，则先从数据库读取，避免第一次访问速度由于加载数据量大而变慢</remarks>
        /// <returns></returns>
        public static ConcurrentDictionary<CacheKeyType, T> GetEntityListInCache<T, CacheKeyType>(object locker, string allKey, TimeSpan timespan,
            Func<bool> isToLoadAllFunc = null, Action<ConcurrentDictionary<CacheKeyType, T>> action = null
            , Func<ConcurrentDictionary<CacheKeyType, T>> customGetDict = null)
        {
            var dict = _cache.Get<ConcurrentDictionary<CacheKeyType, T>>(allKey);
            if (dict == null)
            {
                //异步加载缓存
                Action loadAllCache = () =>
                {
                    lock (locker)//避免第一次未加载缓存，重复访问多请求访问数据库读取所有数据
                    {
                        dict = _cache.Get<ConcurrentDictionary<CacheKeyType, T>>(allKey);
                        if (dict != null)
                            return;
                        if (isToLoadAllFunc != null && !isToLoadAllFunc())//如果特殊条件，例如需要其他缓存加载后才能加载此缓存的则跳过
                            return;
                        if (customGetDict != null)
                            dict = customGetDict();
                        if (action != null)
                            action(dict);
                        _cache.Add(allKey, dict, timespan);
                    }
                };

                loadAllCache();
            }
            return dict;
        }
        /// <summary>
        /// 从缓存中获取信息
        /// </summary>
        /// <param name="allKey">键值key前缀（加载所有的key）</param>
        /// <param name="code">主键值</param>
        /// <param name="isToLoadAll">是异步否加载所有，true是，如果未加载所有，则异步加载所有T类型对象</param>
        /// <remarks>采用异步加载，如果缓存未加载好，则先从数据库读取，避免第一次访问速度由于加载数据量大而变慢</remarks>
        /// <returns></returns>
        public static T GetEntityGroupInCache<T, CacheKeyType>(object locker, CacheKeyType code, string allKey, TimeSpan timespan,
            Func<bool> isToLoadAllFunc = null, Action<ConcurrentDictionary<CacheKeyType, T>> action = null
            , Func<ConcurrentDictionary<CacheKeyType, T>> customGetDict = null, Func<CacheKeyType, T> customGetEntity = null)
        {
            var key = allKey + "_" + code.ToString();
            T entity = _cache.Get<T>(key);
            if (entity != null)
                return entity;
           
            var dict = _cache.Get<ConcurrentDictionary<CacheKeyType, T>>(allKey);
            if (dict == null)
            {
                //异步加载缓存
                Action loadAllGroupAsync = () =>
                {
                    lock (locker)//避免第一次未加载缓存，重复访问多请求访问数据库读取所有数据
                    {
                        dict = _cache.Get<ConcurrentDictionary<CacheKeyType, T>>(allKey);
                        if (dict != null)
                            return;
                        if (isToLoadAllFunc != null && !isToLoadAllFunc())//如果特殊条件，例如需要其他缓存加载后才能加载此缓存的则跳过
                            return;
                        if (customGetDict != null)
                            dict = customGetDict();
                        if (action != null)
                            action(dict);
                        Debug.WriteLine(string.Format("add cache {0}", allKey));
                        _cache.Add(allKey, dict, timespan);
                        dict.ToList().ForEach(en =>
                            {
                                _cache.Add(allKey+"_"+en.Key, en.Value, timespan);
                            }
                            );
                    }
                };
                new Task(loadAllGroupAsync).Start();
                Debug.WriteLine(string.Format("get by code {0}", allKey));
                if (customGetEntity != null)
                    return customGetEntity(code);
            }
            if(dict.ContainsKey(code)&&entity==null)//说明此用户由于有更新数据，缓存被清空
            {
                entity = customGetEntity(code);
                _cache.Add(key, entity, timespan);
            }

            return entity;
        }
    }
}
