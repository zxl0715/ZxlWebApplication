﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;
using Nd.Erp.Mobile.Service.Common.Extensions;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DaMobileSyncSlave : DaTemplate<EnMobileSyncServerSlave, int>
    {
        protected override Func<EnMobileSyncServerSlave, int> funcKey
        {
            get { return s => s.AutoCode; }
        }

        protected override string SelectSql
        {
            get { return "SELECT  AutoCode, lSyncMainCode, lTableNameCode, sTableCode, dAddTime, lType, lSyncState, sTableCode2, sTableCode3 FROM dbo.TM_MobileSyncServerSlave "; }
        }

        public override EnMobileSyncServerSlave GetEntity(int code)
        {
            return GetEntityList("AutoCode=@AutoCode  ", new List<EnMobileSyncServerSlave>(), new SqlParameter[] { new SqlParameter("@AutoCode", code) }).FirstOrDefault();
        }

        /// <summary>
        /// 获取同步从表实体集合
        /// </summary>
        /// <param name="lSyncMainCode"></param>
        /// <returns></returns>
        public List<EnMobileSyncServerSlave> GetEntityListBySyncMainCode(int lSyncMainCode)
        {
            return GetEntityList("lSyncMainCode=@lSyncMainCode  ", new List<EnMobileSyncServerSlave>(), new SqlParameter[] { new SqlParameter("@lSyncMainCode", lSyncMainCode) });
        }

        /// <summary>
        /// 获取同步从表实体集合
        /// </summary>
        /// <param name="lSyncMainCode"></param>
        /// <returns></returns>
        public List<EnMobileSyncServerSlave> GetEntityListBySyncMainCode(List<int> lSyncMainCodes)
        {
            if (lSyncMainCodes == null || lSyncMainCodes.Count() == 0)
                return new List<EnMobileSyncServerSlave>();
            return GetEntityList(string.Format("lSyncMainCode in ({0})  ", string.Join(",", lSyncMainCodes.ToArray())), new List<EnMobileSyncServerSlave>());
        }


        public EnPostSyncBackInfo PostSyncInfo(string sPersonCode, string dbGuid, string dAddTime, List<EnMobileSyncClient> syncClientList)
        {

            var list = syncClientList;
            var failClientCodeList = new List<int>();
            foreach (var client in list)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(BaseHelper.ErpDataBaseAccess))
                    {
                        conn.Open();
                        SqlTransaction trans = conn.BeginTransaction("ClientSyncToServer");
                        try
                        {
                            string insertSyncMainSql = " INSERT INTO dbo.TM_MobileSyncServer ( dAddTime, lSyncState, sPersonCode, lSyncType ) values (getdate(),0,'" + sPersonCode + "',0) Select SCOPE_IDENTITY()";
                            int lSyncMainCode = int.Parse(SqlHelper.ExecuteDataset(trans, CommandType.Text, insertSyncMainSql).Tables[0].Rows[0][0].ToString());
                            Dictionary<string, string> mapCodeDic = client.EnMapCodeList.GroupBy(e => "#@" + e.lTableNameCode + "_" + e.ColumnName + ":" + e.lClientCode + "@#").ToDictionary(g => g.Key, g => g.First().lServerCode);
                            foreach (var slave in client.EnMobileSyncClientSlaveList)
                            {
                                switch (slave.lType)
                                {
                                    case 1://增加 
                                        mapCodeDic = slave.ToInsertMSSql(trans, sPersonCode, dbGuid, lSyncMainCode, mapCodeDic);
                                        break;
                                    case 2:
                                    case 3:
                                        string sql = slave.ToUpdateOrDeleteMSSqlString(sPersonCode, lSyncMainCode, mapCodeDic, slave.lType == 2);
                                        SqlHelper.ExecuteNonQuery(trans, CommandType.Text, sql);
                                        break;
                                }
                            }
                            trans.Commit();
                        }
                        catch (Exception ex2)
                        {
                            try
                            {
                                _logMgr.WriteErrorFormat("同步事务失败:{0},message:{1}", ex2.StackTrace, ex2.Message);
                                trans.Rollback();
                                failClientCodeList.Add(client.lSyncMainCode);
                            }
                            catch (Exception ex)
                            {
                                _logMgr.WriteErrorFormat("同步事务回滚失败:{0}", ex.StackTrace);
                                failClientCodeList.Add(client.lSyncMainCode);
                            }


                        }
                    }

                }
                catch (Exception ex)
                {
                    failClientCodeList.Add(client.lSyncMainCode);
                }

            }

            EnPostSyncBackInfo enPostSyncBackInfo = new EnPostSyncBackInfo();
            enPostSyncBackInfo.FailList = failClientCodeList;
            try
            {
                enPostSyncBackInfo.EnMobileSyncServerList = GetSyncInfoByAddTime(sPersonCode, dbGuid, dAddTime, true);
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("获取Mapcode失败:{0}", ex.Message);
            }


            return enPostSyncBackInfo;
        }

        /// <summary>
        /// 获取服务器端修改的数据同步信息
        /// </summary>
        /// <param name="sPersonCode"></param>
        /// <param name="dbGuid"></param>
        /// <param name="dAddTime"></param>
        /// <returns></returns>
        public List<EnMobileSyncServer> GetSyncInfoByAddTime(string sPersonCode, string dbGuid, string dAddTime)
        {
            return GetSyncInfoByAddTime(sPersonCode, dbGuid, dAddTime, false);
        }
        private List<EnMobileSyncServer> GetSyncInfoByAddTimeWithoutSql(string sPersonCode, string dAddTime, bool isPostBackInfo)
        {
            var syncEntityList = new List<EnMobileSyncServer>();
            string lTypeString = isPostBackInfo ? " and lType=4 " : " ";
            string sqlStr = @"SELECT a.lSyncMainCode, a.dAddTime, a.lSyncState, sPersonCode, AutoCode, lTableNameCode, sTableCode,lSyncType,sTableCode2,sTableCode3,
                            b.dAddTime as dAddTimeChild, lType, b.lSyncState as lSyncStateChild FROM dbo.TM_MobileSyncServer a JOIN dbo.TM_MobileSyncServerSlave  b ON 
                            a.lSyncMainCode=b.lSyncMainCode WHERE a.dAddTime>@dAddTime " + lTypeString + " AND  (sPersonCode = @sPersonCode OR sPersonCode ='' OR sPersonCode is NULL OR @sPersonCode in (select spersoncode from TM_MobileSyncServerPerson mssp where mssp.lSyncMainCode=a.lSyncMainCode) ) ORDER BY ltype/4 desc,a.lSyncMainCode,b.AutoCode --and a.lSyncState=0";
            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, new SqlParameter[] {
                new SqlParameter("@sPersonCode",sPersonCode),
                new SqlParameter("@dAddTime",Convert.ToDateTime(string.IsNullOrWhiteSpace(dAddTime)?"1950-1-1":dAddTime).AddSeconds(1))
                    }).Tables[0];

                string updateMainStateSql = "update TM_MobileSyncServer set lSyncState=1 where lSyncMainCode in (";//初始化更新状态语句
                string updateSlaveStateSql = "update TM_MobileSyncServerSlave set lSyncState=1 where AutoCode in (";
                int lSyncMainLastCode = -1;
                EnMobileSyncServer syncMainEntity = null;
                foreach (DataRow dr in dt.Rows)
                {
                    //添加主表实体
                    int lSyncMainCode = Convert.ToInt32(dr["lSyncMainCode"].ToString());
                    if (lSyncMainCode != lSyncMainLastCode)
                    {
                        lSyncMainLastCode = lSyncMainCode;
                        updateMainStateSql += lSyncMainCode + ",";
                        syncMainEntity = new EnMobileSyncServer()
                        {
                            lSyncMainCode = lSyncMainCode,
                            sPersonCode = dr["sPersonCode"].ToString(),
                            lSyncState = 0,
                            lSyncType = Convert.ToInt32(dr["lSyncType"].ToString()),
                            dAddTime = Convert.ToDateTime(dr["dAddTime"].ToString())
                        };
                        syncMainEntity.SlaveList = new List<EnMobileSyncServerSlave>();
                        syncEntityList.Add(syncMainEntity);
                    }
                    //添加从表实体
                    syncMainEntity.SlaveList.Add(new EnMobileSyncServerSlave()
                    {
                        AutoCode = Convert.ToInt32(dr["AutoCode"].ToString()),
                        lSyncMainCode = Convert.ToInt32(dr["lSyncMainCode"].ToString()),
                        lTableNameCode = Convert.ToInt32(dr["lTableNameCode"].ToString()),
                        sTableCode = dr["sTableCode"].ToString(),
                        dAddTime = Convert.ToDateTime(dr["dAddTimeChild"].ToString()),
                        lType = Convert.ToInt32(dr["lType"].ToString()),
                        lSyncState = Convert.ToInt32(dr["lSyncStateChild"].ToString()),
                        sTableCode2 = Convert.ToString(dr["sTableCode2"].ToString()),
                        sTableCode3 = Convert.ToString(dr["sTableCode3"].ToString())
                    });
                    updateSlaveStateSql += dr["AutoCode"].ToString() + ",";
                }
                string updateSql = "";
                if (updateMainStateSql.EndsWith(","))
                    updateSql += updateMainStateSql.TrimEnd(',') + ")";
                if (updateSlaveStateSql.EndsWith(","))
                    updateSql += updateSlaveStateSql.TrimEnd(',') + ")";
                // SqlHelper.ExecuteNonQuery(_sqlCnnStr, CommandType.Text, updateSql);
            }
            catch (Exception ex)
            {
            }
            return syncEntityList;
        }

        /// <summary>
        /// 获取服务器端修改的数据同步信息或映射MAPCODE
        /// </summary>
        /// <param name="sPersonCode"></param>
        /// <param name="dbGuid"></param>
        /// <param name="dAddTime"></param>
        /// <returns></returns>
        public List<EnMobileSyncServer> GetSyncInfoByAddTime(string sPersonCode, string dbGuid, string dAddTime, bool isPostBackInfo)
        {
            bool hasDeadLine = true;
            var syncServerList = GetSyncInfoByAddTimeWithoutSql(sPersonCode, dAddTime, isPostBackInfo);
            var result = new List<EnMobileSyncServer>();
            foreach (var server in syncServerList)
            {
                bool isError = false;
                foreach (var slave in server.SlaveList)
                {
                    var dt = DaMobileSyncServer.Instance.GetDataTable(slave);
                    if ((dt == null || dt.Rows.Count == 0) && slave.lType != 3/*不是删除操作*/)
                    {
                        isError = true;
                        break;
                    }
                }
                if (!isError)
                    result.Add(server);
            }
            return GenerateClientSql(result, dbGuid);
        }

        /// <summary>
        /// 根据同步实体生成所有语句
        /// </summary>
        /// <param name="syncList"></param>
        /// <returns></returns>
        private List<EnMobileSyncServer> GenerateClientSql(List<EnMobileSyncServer> syncList, string dbGuid)
        {
            syncList.ForEach(syncEntity =>
            {
                List<string> sqlList = new List<string>();
                syncEntity.SlaveList.ForEach(slave =>
                {
                    switch (slave.lType)
                    {
                        case 1:
                            slave.Sqls = slave.ToInsertSqliteSql();
                            break;
                        case 2:
                            slave.Sqls = new string[] { slave.ToUpdateSqliteSql() };
                            break;
                        case 3:
                            slave.Sqls = slave.ToDeleteSqliteSql();
                            break;
                        case 4:
                            slave.Sqls = new string[] { slave.ToInsertMapCodeSqliteSql(dbGuid) };
                            break;
                    }
                });
            });
            return syncList
                .FindAll(s => !(s.SlaveList.Count == 1 && s.SlaveList[0].Sqls.Length == 1 && s.SlaveList[0].Sqls[0] == ""));//语句不为空的
        }
    }
}
