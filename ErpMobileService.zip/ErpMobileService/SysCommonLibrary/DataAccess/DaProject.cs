﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DaProject:DaTemplate<EnProject,string>
    {
        protected override string SelectSql
        {
            get { return "SELECT sXmCode, sXmName, sXmFCode, lXmGrade FROM A5_wXmCls "; }
        }

        protected override Func<EnProject, string> funcKey
        {
            get { return p=>p.sXmCode; }
        }

        public override EnProject GetEntity(string code)
        {
            return GetEntityList(" ISNULL(bdel,0)=0 AND ISNULL(bisfinish,0)=0 And  sXmCode=@sXmCode", new List<EnProject>(), new SqlParameter[] { new SqlParameter("sXmCode", code) }).FirstOrDefault();
        }
    }
}
