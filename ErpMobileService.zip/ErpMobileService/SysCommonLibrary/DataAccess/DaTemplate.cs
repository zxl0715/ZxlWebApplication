﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;
using System.Diagnostics;

namespace Nd.Erp.Mobile.Service.Common
{
    public abstract class DaTemplate<T,PKType>
    {

        protected static LogMgr<DaTemplate<T, PKType>> _logMgr = new LogMgr<DaTemplate<T, PKType>>();

        private static ConcurrentDictionary<Type, DaTemplate<T, PKType>> DaTemplateDict = new ConcurrentDictionary<Type, DaTemplate<T, PKType>>();

        protected abstract Func<T, PKType> funcKey { get; }

        protected abstract string SelectSql { get; }

        public abstract T GetEntity(PKType code);

        public List<T> GetEntityList(string strWhere, List<T> defaultResult = null, SqlParameter[] param = null)
        {
            if (!string.IsNullOrWhiteSpace(strWhere))
                strWhere = " and " + strWhere;
            var list = new List<T>();
            try
            {
                string sqlStr = SelectSql + " where 1=1 " + strWhere;
                var dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, param);
                list = DynamicBuilder<T>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                _logMgr.WriteError(ex.Message);
                throw ex;

            }
        }

        public virtual List<T> GetEntityAll()
        {
            return GetEntityList(null);
        }
        /// <summary>
        /// 需要添加到缓存的内容，如果不全部缓存，可以重写此方法
        /// </summary>
        /// <returns></returns>
        public virtual List<T> GetEntityListToDict() {
            var result= GetEntityAll();
            if (result == null)
                return new List<T>();
            return result;
        }

        /// <summary>
        /// 返回部门字典
        /// </summary>
        /// <returns></returns>
        public virtual ConcurrentDictionary<PKType, T> GetDict()
        {
            return new ConcurrentDictionary<PKType, T>(GetEntityListToDict().Where(en => funcKey(en) != null&&en!=null).ToDictionary(funcKey, d => d));
        }
        /// <summary>
        /// 获取当前类型实例
        /// </summary>
        /// <typeparam name="DaT">Da数据访问类型</typeparam>
        /// <returns></returns>
        public static DaT GetDaInstance<DaT>() where DaT:DaTemplate<T,PKType>
        {
            Type type = typeof(DaT);
            if (!DaTemplateDict.ContainsKey(type))
                DaTemplateDict[type] = (DaT)Activator.CreateInstance(type);
            return (DaT)DaTemplateDict[type];
        }

    }
}
