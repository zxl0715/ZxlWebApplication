﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;

namespace Nd.Erp.Mobile.Service.Common
{

    public class DaPersonInfo : DaTemplate<PersonEntity,string> {

        protected override string SelectSql
        {
            get { return "SELECT a.sPersonCode ,a.sPersonName ,a.sDepCode,b.sClassCode FROM dbo.A5_CWPerson a left join dbo.A5_wZzzl b ON a.sPersonCode=b.sPersonCode "; }
        }

        protected override Func<PersonEntity, string> funcKey
        {
            get { return p=>p.sPersonCode; }
        }

        public override PersonEntity GetEntity(string code)
        {
            return GetEntityList(" a.spersoncode=@spersoncode ", new List<PersonEntity>(), new SqlParameter[] { new SqlParameter("@spersoncode", code) }).FirstOrDefault();
        }
    }

}
