﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DaMobileSyncLasteastOneMonth : DaTemplate<EnMobileSyncServer, int>
    {
        protected override string SelectSql
        {
            get { return " SELECT a.lSyncMainCode, a.dAddTime, lSyncState, ISNULL(b.sPersonCode,a.sPersonCode) AS sPersonCode, lSyncType, AutoCode, b.lSyncMainCode, b.sPersonCode, b.dAddTime FROM dbo.TM_MobileSyncServer a left JOIN dbo.TM_MobileSyncServerPerson b ON a.lSyncMainCode=b.lSyncMainCode "; }
        }

        protected override Func<EnMobileSyncServer, int> funcKey
        {
            get { return s => s.lSyncMainCode; }
        }

        public override EnMobileSyncServer GetEntity(int code)
        {
            return GetEntityList(" a.lSyncMainCode=@lSyncMainCode ", new List<EnMobileSyncServer>(), new SqlParameter[] { new SqlParameter("@lSyncMainCode", code) }).FirstOrDefault();
        }

        public override List<EnMobileSyncServer> GetEntityListToDict()
        {
            DateTime startDate = DateTime.Now.AddMonths(-1);
            return GetEntityList(" a.dAddTime>=@dAddTime ", new List<EnMobileSyncServer>(), new SqlParameter[] { new SqlParameter("@dAddTime", startDate) });
        }


        public List<EnMobileSyncServer> GetEntityList(string userCode)
        {
            return GetEntityList(userCode, DateTime.Now.AddMonths(-1));
        }

        public List<EnMobileSyncServer> GetEntityList(string userCode, DateTime startDate)
        {
            startDate = startDate < new DateTime(1900, 1, 1) ? new DateTime(1900, 1, 1) : startDate;
            return GetEntityList(" a.dAddTime>@dAddTime AND  (ISNULL(b.sPersonCode,a.sPersonCode) = @sPersonCode OR a.sPersonCode ='' ) ",
                new List<EnMobileSyncServer>(),
                new SqlParameter[] { new SqlParameter("@dAddTime", startDate), new SqlParameter("@sPersonCode", userCode) });
        }

        public List<EnMobileSyncServer> GetEntityList(DateTime startDate)
        {
            startDate = startDate < new DateTime(1900, 1, 1) ? new DateTime(1900, 1, 1) : startDate;
            return GetEntityList(" a.dAddTime>@dAddTime ",
                           new List<EnMobileSyncServer>(),
                           new SqlParameter[] { new SqlParameter("@dAddTime", startDate) });
        }
    }
}
