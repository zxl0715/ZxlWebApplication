﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DaDeviceInfo : DaTemplate<EnLoginMobileDevice, string>
    {
        protected override string SelectSql
        {
            get { return "SELECT * FROM  dbo.A5_wlandMobileDevice  "; }
        }

        protected override Func<EnLoginMobileDevice, string> funcKey
        {
            get { return d => d.AutoCode.ToString(); }
        }

        public override EnLoginMobileDevice GetEntity(string code)
        {
            return GetEntityList("AutoCode=@AutoCode ", new List<EnLoginMobileDevice>(), new SqlParameter[] { new SqlParameter("@AutoCode", code) }).FirstOrDefault();
        }

        public List<EnLoginMobileDevice> GetEntityListByUserCode(string userCode) {
            return GetEntityList("spersoncode=@userCode ", new List<EnLoginMobileDevice>(), new SqlParameter[] { new SqlParameter("@userCode", userCode) });
        }

        public EnLoginMobileDevice GetEntityListByDeviceUUIDAndUserID(string userIDAndDeviceUUIDHashed)
        {
            var userIDAndDeviceUUIDHashedArray = userIDAndDeviceUUIDHashed.Split('_');
            return GetEntityList("sDeviceUUIDHashed=@deviceUUIDHashed and sPersonCode=@sPersonCode", new List<EnLoginMobileDevice>(), 
                new SqlParameter[] { 
                new SqlParameter("@deviceUUIDHashed", userIDAndDeviceUUIDHashedArray[1]), 
                new SqlParameter("@sPersonCode", userIDAndDeviceUUIDHashedArray[0]) }).FirstOrDefault();
        }


        public static int GetFobbidenCount() {
            
            try
            {
                string sqlStr = "SELECT COUNT(1) FROM A5_wlandMobileDevice WHERE IsFobidden=1";
                var ds = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, null);
                if(ds!=null&&ds.Tables[0].Rows.Count>0)
                    return Convert.ToInt32(ds.Tables[0].Rows[0][0]);
            }
            catch (Exception ex)
            {
                _logMgr.WriteError(ex.Message);
            }
            return 0;
        }

    }
}
