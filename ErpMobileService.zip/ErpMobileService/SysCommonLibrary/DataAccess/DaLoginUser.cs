﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DaLoginUser : DaTemplate<LoginUser, string>
    {

        protected override string SelectSql
        {
            get { return "SELECT l.spersoncode as PersonCode,sPassword as Password FROM A5_wland l join a5_wzzzl w on l.sPersoncode=w.sPersoncode "; }
        }

        protected override Func<LoginUser, string> funcKey
        {
            get { return u => u.PersonCode; }
        }

        public override LoginUser GetEntity(string code)
        {
            return GetEntityList(" (w.sClassCode <'04' or w.sClassCode='99') and l.spersoncode=@spersoncode  ", new List<LoginUser>(), new SqlParameter[] { new SqlParameter("@spersoncode", code) }).FirstOrDefault();

        }

        public override List<LoginUser> GetEntityAll()
        {
            return GetEntityList(" (w.sClassCode <'04' or w.sClassCode='99') ");
        }

        public static void AddPersonDeviceInfo(EnLoginMobileDevice deviceInfo)
        {

            string sql = @"
IF not Exists (select * from A5_wlandMobileDevice where sPersonCode=@sPersonCode and sDeviceUUIDHashed=@sDeviceUUIDHashed )    
begin            
INSERT INTO dbo.A5_wlandMobileDevice ( sPersonCode, sDeviceName, sCustomDeviceName, sDeviceUUIDHashed, dLastLoginDate,sSDKVersion, IsFobidden )
VALUES  ( @sPersonCode, -- sPersonCode - nvarchar(20)
          @sDeviceName, -- sDeviceName - nvarchar(50)
          @sCustomDeviceName, -- sCustomDeviceName - nvarchar(50)
          @sDeviceUUIDHashed, -- sDeviceUUIDHashed - nvarchar(256)
          getdate(), -- dLastLoginDate - datetime
          @sSDKVersion,
          0  -- IsFobidden - tinyint
          )
end
else
begin
  update A5_wlandMobileDevice set dLastLoginDate=getdate() where sPersonCode=@sPersonCode and sDeviceUUIDHashed=@sDeviceUUIDHashed
end
if not Exists(SELECT * FROM TM_MobileSyncUser WHERE sPersonCode=@sPersonCode)
begin
insert into TM_MobileSyncUser ( sPersonCode )
VALUES  ( @sPersonCode  -- sPersonCode - nvarchar(20)
          )
end

";
            SqlParameter[] param = {
		        new SqlParameter("@sPersonCode", deviceInfo.sPersonCode),
		        new SqlParameter("@sDeviceName", deviceInfo.sDeviceName),
		        new SqlParameter("@sCustomDeviceName", deviceInfo.sCustomDeviceName),
		        new SqlParameter("@sDeviceUUIDHashed", deviceInfo.sDeviceUUIDHashed),
                new SqlParameter("@sSDKVersion", deviceInfo.sSDKVersion)
		    };

            SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, sql, param);
        }
    }

}
