﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;
using Nd.Erp.Mobile.Service.Common.Extensions;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DaMobileSyncServer
    {

        public static readonly DaMobileSyncServer Instance = new DaMobileSyncServer();

        protected static LogMgr<DaMobileSyncServer> _logMgr = new LogMgr<DaMobileSyncServer>();

        private DaMobileSyncServer() { }


        public List<int> PostSyncInfo(string sPersonCode, string dbGuid, string dAddTime, List<EnMobileSyncClient> syncClientList)
        {

            var list = syncClientList;
            var failClientCodeList = new List<int>();
            foreach (var client in list)
            {
                try
                {
                    using (SqlConnection conn = new SqlConnection(BaseHelper.ErpDataBaseAccess))
                    {
                        conn.Open();
                        SqlTransaction trans = conn.BeginTransaction("ClientSyncToServer");
                        try
                        {
                            string insertSyncMainSql = " INSERT INTO dbo.TM_MobileSyncServer ( dAddTime, lSyncState, sPersonCode, lSyncType ) values (getdate(),0,'" + sPersonCode + "',0) Select SCOPE_IDENTITY()";
                            int lSyncMainCode = int.Parse(SqlHelper.ExecuteDataset(trans, CommandType.Text, insertSyncMainSql).Tables[0].Rows[0][0].ToString());
                            Dictionary<string, string> mapCodeDic = client.EnMapCodeList.GroupBy(e => "#@" + e.lTableNameCode + "_" + e.ColumnName + ":" + e.lClientCode + "@#").ToDictionary(g => g.Key, g => g.First().lServerCode);
                            foreach (var slave in client.EnMobileSyncClientSlaveList)
                            {
                                switch (slave.lType)
                                {
                                    case 1://增加 
                                        mapCodeDic = slave.ToInsertMSSql(trans, sPersonCode, dbGuid, lSyncMainCode, mapCodeDic);
                                        break;
                                    case 2:
                                    case 3:
                                        string sql = slave.ToUpdateOrDeleteMSSqlString(sPersonCode, lSyncMainCode, mapCodeDic, slave.lType == 2);
                                        SqlHelper.ExecuteNonQuery(trans, CommandType.Text, sql);
                                        break;
                                }

                               
                            }
                            if (client.SyncPersonCodeList != null && client.SyncPersonCodeList.Count>0)
                            {
                                string sql = "";
                                foreach (var p in client.SyncPersonCodeList)
                                {
                                    sql += @"  INSERT INTO dbo.TM_MobileSyncServerPerson( lSyncMainCode ,sPersonCode ,dAddTime)VALUES  ( " + lSyncMainCode + " , N'" + p.sPersonCode + "' ,GETDATE())";
                                }

                                SqlHelper.ExecuteNonQuery(trans, CommandType.Text, sql);
                            }

                            trans.Commit();
                        }
                        catch (Exception ex2)
                        {
                            try
                            {
                                _logMgr.WriteErrorFormat("同步事务失败:{0},message:{1}", ex2.StackTrace.ToString(), ex2.Message);
                                trans.Rollback();
                                failClientCodeList.Add(client.lSyncMainCode);
                            }
                            catch (Exception ex)
                            {
                                _logMgr.WriteErrorFormat("同步事务回滚失败:{0}", ex.StackTrace.ToString());
                                failClientCodeList.Add(client.lSyncMainCode);
                            }


                        }
                    }

                }
                catch (Exception ex)
                {
                    failClientCodeList.Add(client.lSyncMainCode);
                }

            }
            return failClientCodeList;
        }


        private List<EnMobileSyncServer> GetSyncInfoByAddTimeWithoutSqliteSql(string sPersonCode, string dAddTime, bool isPostBackInfo)
        {
            var syncEntityList = new List<EnMobileSyncServer>();
            string lTypeString = isPostBackInfo ? " and lType=4 " : " ";
            string sqlStr = @"SELECT a.lSyncMainCode, a.dAddTime, a.lSyncState, sPersonCode, AutoCode, lTableNameCode, sTableCode,lSyncType,sTableCode2,sTableCode3,
                            b.dAddTime as dAddTimeChild, lType, b.lSyncState as lSyncStateChild FROM dbo.TM_MobileSyncServer a JOIN dbo.TM_MobileSyncServerSlave  b ON 
                            a.lSyncMainCode=b.lSyncMainCode WHERE a.dAddTime>@dAddTime " + lTypeString + " AND  (sPersonCode = @sPersonCode OR sPersonCode ='' OR sPersonCode is NULL OR @sPersonCode in (select spersoncode from TM_MobileSyncServerPerson mssp where mssp.lSyncMainCode=a.lSyncMainCode) ) ORDER BY ltype/4 desc,a.lSyncMainCode,b.AutoCode ";
            try
            {
                DataTable dt = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, sqlStr, new SqlParameter[] {
                new SqlParameter("@sPersonCode",sPersonCode),
                new SqlParameter("@dAddTime",Convert.ToDateTime(string.IsNullOrWhiteSpace(dAddTime)?"1950-1-1":dAddTime).AddSeconds(1))
                    }).Tables[0];

                int lSyncMainLastCode = -1;
                EnMobileSyncServer syncMainEntity = null;
                foreach (DataRow dr in dt.Rows)
                {
                    //添加主表实体
                    int lSyncMainCode = Convert.ToInt32(dr["lSyncMainCode"].ToString());
                    if (lSyncMainCode != lSyncMainLastCode)
                    {
                        lSyncMainLastCode = lSyncMainCode;
                        syncMainEntity = new EnMobileSyncServer()
                        {
                            lSyncMainCode = lSyncMainCode,
                            sPersonCode = dr["sPersonCode"].ToString(),
                            lSyncState = 0,
                            lSyncType = Convert.ToInt32(dr["lSyncType"].ToString()),
                            dAddTime = Convert.ToDateTime(dr["dAddTime"].ToString())
                        };
                        syncMainEntity.SlaveList = new List<EnMobileSyncServerSlave>();
                        syncEntityList.Add(syncMainEntity);
                    }
                    //添加从表实体
                    syncMainEntity.SlaveList.Add(new EnMobileSyncServerSlave()
                    {
                        AutoCode = Convert.ToInt32(dr["AutoCode"].ToString()),
                        lSyncMainCode = Convert.ToInt32(dr["lSyncMainCode"].ToString()),
                        lTableNameCode = Convert.ToInt32(dr["lTableNameCode"].ToString()),
                        sTableCode = dr["sTableCode"].ToString(),
                        dAddTime = Convert.ToDateTime(dr["dAddTimeChild"].ToString()),
                        lType = Convert.ToInt32(dr["lType"].ToString()),
                        lSyncState = Convert.ToInt32(dr["lSyncStateChild"].ToString()),
                        sTableCode2 = Convert.ToString(dr["sTableCode2"].ToString()),
                        sTableCode3 = Convert.ToString(dr["sTableCode3"].ToString())
                    });
                }
            }
            catch (Exception ex)
            {
                _logMgr.WriteLogToLocal(true, ex.Message + ex.StackTrace);
            }
            return syncEntityList;
        }

        /// <summary>
        /// 获取服务器端修改的数据同步信息或映射MAPCODE
        /// </summary>
        /// <param name="sPersonCode"></param>
        /// <param name="dbGuid"></param>
        /// <param name="dAddTime"></param>
        /// <returns></returns>
        public List<EnMobileSyncServer> GetSyncInfoByAddTime(string sPersonCode, string dbGuid, string dAddTime, bool isPostBackInfo)
        {
            bool hasDeadLine = true;
            var syncServerList = GetSyncInfoByAddTimeWithoutSqliteSql(sPersonCode, dAddTime, isPostBackInfo);
            var result = new List<EnMobileSyncServer>();
            foreach (var server in syncServerList)
            {
                bool isError = false;
                foreach (var slave in server.SlaveList)
                {
                    var dt = GetDataTable(slave);
                    if ((dt == null || dt.Rows.Count == 0) && slave.lType != 3/*不是删除操作*/&&slave.lTableNameCode!=(int)EnumSyncTableName.TM_AffairAssistant)
                    {
                        isError = true;
                        break;
                    }
                }
                if (!isError)
                    result.Add(server);
            }
            return GenerateSqliteSql(result, dbGuid);
        }

        /// <summary>
        /// 根据同步实体生成所有语句
        /// </summary>
        /// <param name="syncList"></param>
        /// <returns></returns>
        private List<EnMobileSyncServer> GenerateSqliteSql(List<EnMobileSyncServer> syncList, string dbGuid)
        {
            syncList.ForEach(syncEntity =>
            {
                List<string> sqlList = new List<string>();
                syncEntity.SlaveList.ForEach(slave =>
                {
                    switch (slave.lType)
                    {
                        case 1:
                            slave.Sqls = slave.ToInsertSqliteSql();
                            break;
                        case 2:
                            slave.Sqls = new string[] { slave.ToUpdateSqliteSql() };
                            break;
                        case 3:
                            slave.Sqls = slave.ToDeleteSqliteSql();
                            break;
                        case 4:
                            slave.Sqls = new string[] { slave.ToInsertMapCodeSqliteSql(dbGuid) };
                            break;
                    }
                });
            });
            return syncList
                .FindAll(s => !(s.SlaveList.Count == 1 && s.SlaveList[0].Sqls.Length == 1 && s.SlaveList[0].Sqls[0] == ""));//语句不为空的
        }

        public DataTable GetDataTable(EnMobileSyncServerSlave syncInfo)
        {
            DataTable dt = null;
            try
            {
                int ltableNameCode = syncInfo.lTableNameCode;
                var tableDetail = SyncHelper.SyncTableDetailDic[ltableNameCode];
                string sql = " SELECT " + tableDetail.ToStringJoin(hasGenIdentityColumn: true) + " FROM " + SyncHelper.SyncTableNameDic[ltableNameCode] + " where " + syncInfo.ToStringJoinPrimaryKeyCondition();
                dt = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, sql).Tables[0];
            }
            catch (Exception ex)
            {
                _logMgr.WriteLogFormatToLocal(true, ex.Message + ex.StackTrace);
            }

            return dt;
        }
    }


}
