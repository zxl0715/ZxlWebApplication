﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.Collections.Concurrent;

namespace Nd.Erp.Mobile.Service.Common
{
    public class DaDepInfo:DaTemplate<DepInfo,string>
    {
        protected override string SelectSql
        {
            get { return "SELECT sDepCode as DepCode,sDepName as DepName,sFDepCode as FDepCode,lDepGrade as DepGrade FROM dbo.A5_Wdepartmentcls "; }
        }

        protected override Func<DepInfo, string> funcKey
        {
            get { return d => d.DepCode; }
        }

        public override DepInfo GetEntity(string code)
        {
            return GetEntityList("sDepCode=@sDepCode ", new List<DepInfo>(), new SqlParameter[] { new SqlParameter("@sDepCode", code) }).FirstOrDefault();
        }
    }
}
