﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Http;
using System.Web.Http.Dispatcher;
using System.Web.Http.SelfHost;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile.Service.Common;
using System.Net.Http.Headers;
using System.Net.Http.Formatting;
using Nd.Erp.Mobile;
using Newtonsoft.Json.Converters;

namespace SysCommonLibrary.WebApiConfig
{
    public static class WebApiConfig
    {
        public  static HttpSelfHostConfiguration ApplyConfig(HttpSelfHostConfiguration config)
        {
            config.MaxReceivedMessageSize = 100L * 1024 * 1024;//最大上传文件为2G
            return (HttpSelfHostConfiguration)WebApiConfig.ApplyConfig<HttpConfiguration>(config);
        }

        public static T ApplyConfig<T>(T config) where T : HttpConfiguration 
        {
            
            //config.Filters.Add(new ERPAuthorizeAttribute());
            config.Filters.Add(new CorsExceptionFilterAttribute());
            config.Filters.Add(new LogExceptionFilterAttribute());

            
            //config.Services.Replace(typeof(IAssembliesResolver), new CustomAssemblyResolver());
            //var xml = config.Formatters.XmlFormatter;
            //config.Formatters.Remove(config.Formatters.XmlFormatter);
            //config.MessageHandlers.Insert(0, new ERPAuthMessageHandler(new ERPAuthPrincipalProvider()));
            //config.MessageHandlers.Insert(0, new BaseAuthMessageHandler(new ERPAuthPrincipalProvider()));
            config.MessageHandlers.Insert(0, new CorsMessageHandler());
            config.MessageHandlers.Insert(0, new CompressionHandler());
            var json = config.Formatters.JsonFormatter;
            //json.SerializerSettings.NullValueHandling=NullValueHandling.Ignore;
            json.MediaTypeMappings.Clear();
            json.MediaTypeMappings.Add(new WithoutQueryStringMapping("CustomContentType", "application/json"));// set default media type to json
            json.AddQueryStringMapping("CustomContentType", "json", "application/json");
            json.AddRequestHeaderMapping("CustomContentType", "json",StringComparison.InvariantCultureIgnoreCase,false,"application/json");
            json.SerializerSettings.DateFormatHandling = Newtonsoft.Json.DateFormatHandling.MicrosoftDateFormat;
            var json_LowerCase = new JsonMediaTypeFormatter();
            json_LowerCase.MediaTypeMappings.Clear();
            json_LowerCase.SerializerSettings.ContractResolver = new LowerCasePropertyNamesContractResolver();
            json_LowerCase.AddQueryStringMapping("CustomContentType", "jsonMicrosoftDateFormat-LowerCase", "application/json");
            json_LowerCase.AddRequestHeaderMapping("CustomContentType", "jsonMicrosoftDateFormat-LowerCase", StringComparison.InvariantCultureIgnoreCase, false, "application/json");
            json_LowerCase.SerializerSettings.DateFormatHandling = Newtonsoft.Json.DateFormatHandling.MicrosoftDateFormat;
            config.Formatters.Add(json_LowerCase);
            var jsonJavascriptDateFormat = new JsonMediaTypeFormatter();
            jsonJavascriptDateFormat.MediaTypeMappings.Clear();
            jsonJavascriptDateFormat.SerializerSettings.Converters.Add(new JavaScriptDateTimeConverter());
            jsonJavascriptDateFormat.AddQueryStringMapping("CustomContentType", "jsonJavascriptDateFormat", "application/json");
            json.AddRequestHeaderMapping("CustomContentType", "jsonJavascriptDateFormat", StringComparison.InvariantCultureIgnoreCase, false, "application/json");
            config.Formatters.Add(jsonJavascriptDateFormat);

            var jsonJavascriptDateFormat_LowerCase = new JsonMediaTypeFormatter();
            jsonJavascriptDateFormat_LowerCase.MediaTypeMappings.Clear();
            jsonJavascriptDateFormat_LowerCase.SerializerSettings.Converters.Add(new JavaScriptDateTimeConverter());
            jsonJavascriptDateFormat_LowerCase.SerializerSettings.ContractResolver = new LowerCasePropertyNamesContractResolver();
            jsonJavascriptDateFormat_LowerCase.AddQueryStringMapping("CustomContentType", "jsonJavascriptDateFormat-LowerCase", "application/json");
            json.AddRequestHeaderMapping("CustomContentType", "jsonJavascriptDateFormat-LowerCase", StringComparison.InvariantCultureIgnoreCase, false, "application/json");
            config.Formatters.Add(jsonJavascriptDateFormat_LowerCase);

            config.Routes.MapHttpRoute(
                name: "DefaultApi",
                routeTemplate: "ServiceHost/{controller}/json/{action}"
            );
            return config;
        }
    }
}
