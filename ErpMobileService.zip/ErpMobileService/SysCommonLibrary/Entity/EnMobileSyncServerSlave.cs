﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 手机同步从数据实体
    /// </summary>
    public partial class EnMobileSyncServerSlave
    {
        /// <summary>
        /// 生成对应的语句
        /// </summary>
        [DataMember]
        public string[] Sqls { get; set; }

    }
}
