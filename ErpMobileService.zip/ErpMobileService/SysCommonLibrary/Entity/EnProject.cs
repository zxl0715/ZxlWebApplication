﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Text;

namespace Nd.Erp.Mobile.Service.Common
{
    [DataContract]
    public class EnProject
    {
        [DataMember]
        public string sXmCode { get; set; }
        [DataMember]
        public string sXmName { get; set; }
        [DataMember]
        public string sXmFCode { get; set; }
        [DataMember]
        public int lXmGrade { get; set; }
    }
}
