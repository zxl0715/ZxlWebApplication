﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 客户端手机同步从数据实体
    /// </summary>
    public partial class EnMobileSyncClientSlave
    {

        /// <summary>
        /// 同步的实体的JSON字符串
        /// </summary>
        [DataMember]
        public String JSONEntityString { get; set; }

    }
}
