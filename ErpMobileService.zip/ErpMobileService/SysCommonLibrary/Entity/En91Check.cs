﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace SysCommonLibrary.Entity
{
    [DataContract]
    public class En91Check
    {
        /// <summary>
        /// uid
        /// </summary>
        [DataMember]
        public string uid { get; set; }

        /// <summary>
        /// unitid
        /// </summary>
        [DataMember]
        public string unitid { get; set; }

        /// <summary>
        /// sid
        /// </summary>
        [DataMember]
        public string sid { get; set; }
    }
}
