﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 服务端客户端映射实体
    /// </summary>
    public partial class EnMapCode
    {

        public int AutoCode { get; set; }

        public String lServerCode { get; set; }

        public String lClientCode { get; set; }

        public int lTableNameCode { get; set; }

        public String ColumnName { get; set; }
    }
}
