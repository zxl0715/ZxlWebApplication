﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    [DataContract]
    public class EnOftenPerson
    {
        private string m_userID;

        private string m_personCode;

        private string m_personName;


        #region 所属用户ID
        [DataMember]
        public string sUserID
        {
            get { return m_userID; }
            set { m_userID = value; }
        }
        #endregion

        #region 接单人工号
        [DataMember]
        public string sPersonCode
        {
            get { return m_personCode; }
            set { m_personCode = value; }
        }
        #endregion

        #region 接单人姓名
        [DataMember]
        public string sPersonName
        {
            get { return m_personName; }
            set { m_personName = value; }
        }
        #endregion
    }
}
