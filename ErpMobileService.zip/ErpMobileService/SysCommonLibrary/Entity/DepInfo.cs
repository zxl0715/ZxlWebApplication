﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    [DataContract]
    public class DepInfo
    {
        [DataMember]
        public string DepName { get; set; }

        [DataMember]
        public string DepCode { get; set; }

        [DataMember]
        public string FDepCode { get; set; }

        [DataMember]
        public int DepGrade { get; set; }
    }
}
