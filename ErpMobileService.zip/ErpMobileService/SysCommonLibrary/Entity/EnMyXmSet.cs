using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common
{
    [DataContract]
    public class EnMyXmSet
    {
        /// <summary>
        /// ��˾����
        /// </summary>
        [DataMember]
        public int lCompanyCode { get; set; }

        /// <summary>
        /// Ա������
        /// </summary>
        [DataMember]
        public string sPersonCode { get; set; }

        /// <summary>
        /// ��Ŀ���
        /// </summary>
        [DataMember]
        public string sXmCode { get; set; }

        /// <summary>
        /// ʹ�ô���
        /// </summary>
        [DataMember]
        public int lNum { get; set; }


    }
}