using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common
{
    [DataContract]
    public class ResultStatusWithPersonInfo:ResultStatus
    {
        [DataMember]
        public PersonEntity PersonInfo { get; set; }
    }
}