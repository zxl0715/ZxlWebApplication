﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    [DataContract]
    public class EnOftenProject
    {
        private string m_userID;

        private string m_xmCode;


        #region 所属用户ID
        [DataMember]
        public string sUserID
        {
            get { return m_userID; }
            set { m_userID = value; }
        }
        #endregion


        #region 项目编号
        [DataMember]
        public string sXmCode
        {
            get { return m_xmCode; }
            set { m_xmCode = value; }
        }
        #endregion
    }
}
