﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.Service.Common
{
    public class VersionInfo
    {
        public string VersionName { get; set; }

        public int VersionCode { get; set; }

    }
}
