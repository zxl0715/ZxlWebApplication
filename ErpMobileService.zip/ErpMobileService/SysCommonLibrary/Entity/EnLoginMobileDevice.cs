﻿
using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public partial class EnLoginMobileDevice
    {
        
		/// <summary>
		/// 自动编号
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 工号
		/// </summary>
        [DataMember]
		public string sPersonCode{ get; set; }
			
        
		/// <summary>
		/// 设备名称
		/// </summary>
        [DataMember]
		public string sDeviceName{ get; set; }
			
        
		/// <summary>
		/// 自定义设备名称
		/// </summary>
        [DataMember]
		public string sCustomDeviceName{ get; set; }
			
        
		/// <summary>
		/// 设备唯一标识散列
		/// </summary>
        [DataMember]
		public string sDeviceUUIDHashed{ get; set; }
			
        
		/// <summary>
		/// 最后登陆时间
		/// </summary>
        [DataMember]
		public DateTime dLastLoginDate{ get; set; }
			
        
		/// <summary>
		/// 是否禁止
		/// </summary>
        [DataMember]
		public Int16 IsFobidden{ get; set; }


        /// <summary>
        /// SDK版本
        /// </summary>
        public string sSDKVersion { get; set; }
    }
}
