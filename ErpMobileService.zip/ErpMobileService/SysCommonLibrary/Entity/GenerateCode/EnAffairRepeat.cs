﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 事件重复周期数据实体
    /// </summary>
    [DataContract]
    public partial class EnAffairRepeat
    {
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int RepeatCode{ get; set; }
			
        
		/// <summary>
		/// 事件号 (索引)
		/// </summary>
        [DataMember]
		public int AffairCode{ get; set; }
			
        
		/// <summary>
		/// 索引
		/// </summary>
        [DataMember]
		public string UserID{ get; set; }
			
        
		/// <summary>
		/// 1：天模式 2周模式 3月模式
		/// </summary>
        [DataMember]
		public Int16 RepeatMode{ get; set; }
			
        
		/// <summary>
		/// 天模式下 0：每天 1：每个工作日 周模式下1，2，3 月模式下类型分为两种 第一种有，标示第几周星期几，无逗号表示该月份的日期
		/// </summary>
        [DataMember]
		public string RepeatValue{ get; set; }
			
        
		/// <summary>
		/// 重复间隔
		/// </summary>
        [DataMember]
		public int RepeatSpace{ get; set; }
			
        
		/// <summary>
		/// 重复开始日期
		/// </summary>
        [DataMember]
		public DateTime BeginDate{ get; set; }
			
        
		/// <summary>
		/// 重复结束日期
		/// </summary>
        [DataMember]
		public DateTime EndDate{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
		
	}
}
