﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 日历数据实体
    /// </summary>
    [DataContract]
    public partial class EnCalendarAttention
    {
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 日历编号
		/// </summary>
        [DataMember]
		public int CalendarCode{ get; set; }
			
        
		/// <summary>
		/// 关注人工号
		/// </summary>
        [DataMember]
		public string AttentionUserID{ get; set; }
			
        
		/// <summary>
		/// 关注该日历人工号
		/// </summary>
        [DataMember]
		public string BeAttentionUserID{ get; set; }
			
        
		/// <summary>
		/// 颜色类型
		/// </summary>
        [DataMember]
		public int ColorType{ get; set; }
			
        
		/// <summary>
		/// 1：显示 0：不显示
		/// </summary>
        [DataMember]
		public Int16 IsShow{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
		
	}
}
