﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 事件详情数据实体
    /// </summary>
    [DataContract]
    public partial class EnAffairAssistant
    {
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int AffairAssistantCode{ get; set; }
			
        
		/// <summary>
		/// 事件主题Code[索引]
		/// </summary>
        [DataMember]
		public int AffairCode{ get; set; }
			
        
		/// <summary>
		/// 所属者工号 索引
		/// </summary>
        [DataMember]
		public string UserID{ get; set; }
			
        
		/// <summary>
		/// 开始时间[索引]
		/// </summary>
        [DataMember]
		public DateTime BeginTime{ get; set; }
			
        
		/// <summary>
		/// 结束时间[索引]
		/// </summary>
        [DataMember]
		public DateTime EndTime{ get; set; }
			
        
		/// <summary>
		/// 所属日历  索引
		/// </summary>
        [DataMember]
		public int CalendarCode{ get; set; }
			
        
		/// <summary>
		/// 0：自己，1：任何人，2：部门
		/// </summary>
        [DataMember]
		public Int16 ShareType{ get; set; }
			
        
		/// <summary>
		/// 1：一定要我才能做好，2：可以让人代我做，3：没有效益却又不得不做
		/// </summary>
        [DataMember]
		public Int16 DruckerType{ get; set; }
			
        
		/// <summary>
		/// 1：不紧急不重要，2：紧急不重要，3：正常，3：重要不紧急，4：重要紧急
		/// </summary>
        [DataMember]
		public Int16 LevelType{ get; set; }
			
        
		/// <summary>
		/// 0：无表示 1：有表示
		/// </summary>
        [DataMember]
		public Int16 IsAffairType{ get; set; }
			
        
		/// <summary>
		/// 0：未设置 1：已设置
		/// </summary>
        [DataMember]
		public Int16 IsRemind{ get; set; }
			
        
		/// <summary>
		/// 0：未设置 1：已设置
		/// </summary>
        [DataMember]
		public Int16 IsUsingKpi{ get; set; }
			
        
		/// <summary>
		/// 0：无效 1：有效
		/// </summary>
        [DataMember]
		public Int16 IsAvailability{ get; set; }
			
        
		/// <summary>
		/// 1：完全修改，0：部分修改
		/// </summary>
        [DataMember]
		public Int16 IsCanEdit{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public Int16 EventCodeSign{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public Int16 EventCodeEditSign{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public DateTime EventEditTime{ get; set; }
			
		
	}
}
