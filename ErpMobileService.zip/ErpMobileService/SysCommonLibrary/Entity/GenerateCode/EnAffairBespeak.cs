﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 事件预约关系数据实体
    /// </summary>
    [DataContract]
    public partial class EnAffairBespeak
    {
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 事件Code
		/// </summary>
        [DataMember]
		public int AffairCode{ get; set; }
			
        
		/// <summary>
		/// 预约发起者
		/// </summary>
        [DataMember]
		public string InitiateUserID{ get; set; }
			
        
		/// <summary>
		/// 预约接收者
		/// </summary>
        [DataMember]
		public string InceptUserID{ get; set; }
			
        
		/// <summary>
		/// 0：未确定，1：已确定，2：已拒绝
		/// </summary>
        [DataMember]
		public Int16 BespeakState{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
		
	}
}
