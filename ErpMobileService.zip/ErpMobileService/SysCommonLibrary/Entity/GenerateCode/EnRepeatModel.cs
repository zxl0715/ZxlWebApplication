﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 重复周期实体数据实体
    /// </summary>
    [DataContract]
    public partial class EnRepeatModel
    {
        
		/// <summary>
		/// AutoCode
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 实体事件编号
		/// </summary>
        [DataMember]
		public int ModelAffairCode{ get; set; }
			
        
		/// <summary>
		/// 重复周期编号
		/// </summary>
        [DataMember]
		public int RepeatCode{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string UserId{ get; set; }
			
        
		/// <summary>
		/// 实体日期
		/// </summary>
        [DataMember]
		public DateTime ModelDate{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
        
		/// <summary>
		/// 是否为有效的预约特例 1:有效 0:无效
		/// </summary>
        [DataMember]
		public Int16 ModelState{ get; set; }
			
		
	}
}
