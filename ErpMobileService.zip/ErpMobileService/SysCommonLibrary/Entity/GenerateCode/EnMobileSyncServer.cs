﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 手机同步主数据实体
    /// </summary>
    [DataContract]
    public partial class EnMobileSyncServer
    {
        
		/// <summary>
		/// 自动编号
		/// </summary>
        [DataMember]
		public int lSyncMainCode{ get; set; }
			
        
		/// <summary>
		/// 修改时间
		/// </summary>
        [DataMember]
		public DateTime dAddTime{ get; set; }
			
        
		/// <summary>
		/// 同步状态
		/// </summary>
        [DataMember]
		public int lSyncState{ get; set; }
			
        
		/// <summary>
		/// 用户工号
		/// </summary>
        [DataMember]
		public string sPersonCode{ get; set; }
			
        
		/// <summary>
		/// 同步类型
		/// </summary>
        [DataMember]
		public int lSyncType{ get; set; }
			
		
	}
}
