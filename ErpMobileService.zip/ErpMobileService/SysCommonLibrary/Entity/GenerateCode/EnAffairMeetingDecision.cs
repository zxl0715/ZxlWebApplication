﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// TM_AffairMeetingDecision
    /// </summary>
    [DataContract]
    public partial class EnAffairMeetingDecision
    {
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public int MeetingDecisionItemCode{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public int AffairCode{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string Title{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public Int16 NeedHigherResolution{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public Int16 NeedDiscuss{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string AddUserID{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
		
	}
}
