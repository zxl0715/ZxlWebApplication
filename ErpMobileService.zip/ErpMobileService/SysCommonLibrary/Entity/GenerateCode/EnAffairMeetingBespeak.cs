﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// TM_AffairMeetingBespeak
    /// </summary>
    [DataContract]
    public partial class EnAffairMeetingBespeak
    {
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public int AffairCode{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string InitiateUserID{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string InceptUserID{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public Int16 BespeakState{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string Memo{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
		
	}
}
