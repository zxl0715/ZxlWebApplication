﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 事件主体数据实体
    /// </summary>
    [DataContract]
    public partial class EnAffair
    {
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int AffairCode{ get; set; }
			
        
		/// <summary>
		/// 主题
		/// </summary>
        [DataMember]
		public string Title{ get; set; }
			
        
		/// <summary>
		/// 地点
		/// </summary>
        [DataMember]
		public string Address{ get; set; }
			
        
		/// <summary>
		/// 描述
		/// </summary>
        [DataMember]
		public string Memo{ get; set; }
			
        
		/// <summary>
		/// 0：无
		/// </summary>
        [DataMember]
		public int ParentCode{ get; set; }
			
        
		/// <summary>
		/// 所属者工号[索引]
		/// </summary>
        [DataMember]
		public string UserID{ get; set; }
			
        
		/// <summary>
		/// 非代理时，代理人工号为0
		/// </summary>
        [DataMember]
		public string AgentUserID{ get; set; }
			
        
		/// <summary>
		/// 0：不重复，1：重复
		/// </summary>
        [DataMember]
		public Int16 IsRepeat{ get; set; }
			
        
		/// <summary>
		/// 0：未设置，1：已设置
		/// </summary>
        [DataMember]
		public Int16 IsUsingCheck{ get; set; }
			
        
		/// <summary>
		/// 0：无效 1：有效 索引
		/// </summary>
        [DataMember]
		public Int16 IsAvailability{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
        
		/// <summary>
		/// 旧时间表编号
		/// </summary>
        [DataMember]
		public int oldSchemeCode{ get; set; }
			
        
		/// <summary>
		/// 所属项目编号
		/// </summary>
        [DataMember]
		public string XMCode{ get; set; }
			
        
		/// <summary>
		/// 所属项目父编号
		/// </summary>
        [DataMember]
		public string XMFCode{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string MeetingPurpose{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public Int16 IsUsingMeetingDecision{ get; set; }
			
		
	}
}
