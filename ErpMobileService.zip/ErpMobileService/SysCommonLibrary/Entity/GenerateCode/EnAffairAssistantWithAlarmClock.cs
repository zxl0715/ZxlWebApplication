﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 事件详情与闹铃关系数据实体
    /// </summary>
    [DataContract]
    public partial class EnAffairAssistantWithAlarmClock
    {
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int AffairAssistantCode{ get; set; }
			
        
		/// <summary>
		/// 索引
		/// </summary>
        [DataMember]
		public int AlarmClockCode{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string UserID{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
		
	}
}
