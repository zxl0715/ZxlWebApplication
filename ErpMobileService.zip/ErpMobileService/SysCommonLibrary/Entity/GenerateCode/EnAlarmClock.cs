﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 闹铃数据实体
    /// </summary>
    [DataContract]
    public partial class EnAlarmClock
    {
        
		/// <summary>
		/// 自增主键
		/// </summary>
        [DataMember]
		public int ClockCode{ get; set; }
			
        
		/// <summary>
		/// 主题
		/// </summary>
        [DataMember]
		public string Title{ get; set; }
			
        
		/// <summary>
		/// 索引
		/// </summary>
        [DataMember]
		public string UserID{ get; set; }
			
        
		/// <summary>
		/// 0：书桌，1：短信，2：email
		/// </summary>
        [DataMember]
		public Int16 ClockType{ get; set; }
			
        
		/// <summary>
		/// 闹铃时间
		/// </summary>
        [DataMember]
		public DateTime ClockTime{ get; set; }
			
        
		/// <summary>
		/// 0:自身；1：事件；2：todo
		/// </summary>
        [DataMember]
		public int ClockSource{ get; set; }
			
        
		/// <summary>
		/// 0：无重复 1：按天，2：按周，3按月
		/// </summary>
        [DataMember]
		public int RepeatMode{ get; set; }
			
        
		/// <summary>
		/// 天模式下 0：每天 1：每个工作日 周模式下1，2，3 月模式下类型分为两种 第一种有，标示第几周星期几，无逗号表示该月份的日期 按小时 小时数
		/// </summary>
        [DataMember]
		public string RepeatValue{ get; set; }
			
        
		/// <summary>
		/// 重复开始日期
		/// </summary>
        [DataMember]
		public DateTime RepeatBeginDate{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public DateTime RepeatEndDate{ get; set; }
			
        
		/// <summary>
		/// 每隔？分钟提醒一次
		/// </summary>
        [DataMember]
		public int SpaceMinute{ get; set; }
			
        
		/// <summary>
		/// 间隔开始时间
		/// </summary>
        [DataMember]
		public DateTime SpaceBtime{ get; set; }
			
        
		/// <summary>
		/// 间隔结束时间
		/// </summary>
        [DataMember]
		public DateTime SpaceEtime{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
        [DataMember]
		public DateTime AddTime{ get; set; }
			
        
		/// <summary>
		/// 
		/// </summary>
        [DataMember]
		public string SourceCode{ get; set; }
			
		
	}
}
