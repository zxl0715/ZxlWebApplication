﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 
    /// </summary>
    [DataContract]
    public class EnSyncTableDetail
    {
        
		/// <summary>
		/// 自动编码
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 列名
		/// </summary>
        [DataMember]
		public string ColumnName{ get; set; }
			
        
		/// <summary>
		/// 是否主键
		/// </summary>
        [DataMember]
		public int IsPrimaryKey{ get; set; }
			
        
		/// <summary>
		/// 表对应编码
		/// </summary>
        [DataMember]
		public int lTableNameCode{ get; set; }
			
        
		/// <summary>
		/// 外键表编码
		/// </summary>
        [DataMember]
		public string sForeignTableCode{ get; set; }
			
        
		/// <summary>
		/// 外建关联列名
		/// </summary>
        [DataMember]
		public string sForeignColumnName{ get; set; }
			
        
		/// <summary>
		/// 是否自增
		/// </summary>
        [DataMember]
		public int IsIdentity{ get; set; }
			
		
	}
}
