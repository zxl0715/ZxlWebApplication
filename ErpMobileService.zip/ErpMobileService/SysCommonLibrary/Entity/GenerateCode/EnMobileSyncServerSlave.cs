﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 手机同步从数据实体
    /// </summary>
    [DataContract]
    public partial class EnMobileSyncServerSlave
    {
        
		/// <summary>
		/// 自动编号
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 同步主表编号
		/// </summary>
        [DataMember]
		public int lSyncMainCode{ get; set; }
			
        
		/// <summary>
		/// 同步表名
		/// </summary>
        [DataMember]
		public int lTableNameCode{ get; set; }
			
        
		/// <summary>
		/// 要同步表的主键Code
		/// </summary>
        [DataMember]
		public string sTableCode{ get; set; }
			
        
		/// <summary>
		/// 修改时间
		/// </summary>
        [DataMember]
		public DateTime dAddTime{ get; set; }
			
        
		/// <summary>
		/// 修改类型(1.新增,2.修改,3.删除)
		/// </summary>
        [DataMember]
		public int lType{ get; set; }
			
        
		/// <summary>
		/// 同步状态
		/// </summary>
        [DataMember]
		public int lSyncState{ get; set; }
			
        
		/// <summary>
		/// 要同步表的主键Code2，当有两个主键时候用
		/// </summary>
        [DataMember]
		public string sTableCode2{ get; set; }
			
        
		/// <summary>
		/// 要同步表的主键Code2，当有3个主键时候用
		/// </summary>
        [DataMember]
		public string sTableCode3{ get; set; }
			
		
	}
}
