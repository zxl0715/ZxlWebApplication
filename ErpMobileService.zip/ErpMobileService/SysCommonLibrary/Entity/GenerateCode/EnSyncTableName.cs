﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 同步数据实体基础数据实体
    /// </summary>
    [DataContract]
    public class EnSyncTableName
    {
        
		/// <summary>
		/// 自动编码
		/// </summary>
        [DataMember]
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 表ID
		/// </summary>
        [DataMember]
		public int lTableNameCode{ get; set; }
			
        
		/// <summary>
		/// 表名
		/// </summary>
        [DataMember]
		public string TableName{ get; set; }
			
		
	}
}
