﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 手机同步主数据实体
    /// </summary>
    public partial class EnMobileSyncServer
    {

        /// <summary>
        /// 从表实体集合
        /// </summary>
        [DataMember]
        public List<EnMobileSyncServerSlave> SlaveList { get; set; }

   
	}
}
