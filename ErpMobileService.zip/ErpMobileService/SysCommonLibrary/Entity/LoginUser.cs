﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    [DataContract]
    public class LoginUser
    {
        [DataMember]
        public string PersonCode { get; set; }

        [DataMember]
        public string Password { get; set; }
    }
}
