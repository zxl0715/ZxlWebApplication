﻿using System;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 同步单条事务关联表人员
    /// </summary>
    public partial class EnMobileSyncServerPerson
    {
        
		/// <summary>
		/// 自动编号
		/// </summary>
		public int AutoCode{ get; set; }
			
        
		/// <summary>
		/// 同步事务关联Code
		/// </summary>
		public int lSyncMainCode{ get; set; }
			
        
		/// <summary>
		/// 工号
		/// </summary>
		public string sPersonCode{ get; set; }
			
        
		/// <summary>
		/// 添加时间
		/// </summary>
		public DateTime dAddTime{ get; set; }
			
		
	}
}
