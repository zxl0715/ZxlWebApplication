using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common
{
    [DataContract]
    public class ResultStatus
    {
        [DataMember]
        public bool IsSuccess { get; set; }
        [DataMember]
        public bool IsProxy { get; set; }
        [DataMember]
        public string UserGUID { get; set; }
        [DataMember]
        public string ErrorInfo { get; set; }
    }
}