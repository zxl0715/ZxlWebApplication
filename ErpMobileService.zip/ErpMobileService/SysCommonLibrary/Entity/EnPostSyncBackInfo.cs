﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    public class EnPostSyncBackInfo
    {
        public List<int> FailList { get; set; }

        public List<EnMobileSyncServer> EnMobileSyncServerList { get; set; }
    }
}
