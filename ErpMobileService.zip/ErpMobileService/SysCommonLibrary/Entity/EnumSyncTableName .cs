﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 同步表枚举
    /// </summary>
    public enum EnumSyncTableName
    {
        TM_Affair = 0,
        TM_AffairAssistant = 1,
        TM_AlarmClock = 2,
        TM_AffairAssistantWithAlarmClo = 3,
        TM_AffairBespeak = 4,
        TM_AffairMeetingBespeak = 5,
        TM_AffairMeetingDecision = 6,
        TM_AffairRepeat = 7,
        TM_AffairType = 8,
        TM_Calendar = 9,
        TM_CalendarAttention = 10,
        TM_RepeatModel = 11,
        TM_UserAttentionList = 12,
        TM_UserConfig = 13
    }
}
