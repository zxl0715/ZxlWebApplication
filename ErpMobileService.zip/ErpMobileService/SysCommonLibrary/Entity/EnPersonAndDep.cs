using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.Common
{
    [DataContract]
    public class EnPersonAndDep
    {
        [DataMember]
        public string sPersonCode { get; set; }
        [DataMember]
        public string sPersonName { get; set; }
        [DataMember]
        public string sDepCode { get; set; }
        [DataMember]
        public string sDepName { get; set; }
        [DataMember]
        public string sFDepCode { get; set; }
        [DataMember]
        public int    lDepGrade { get; set; }
        [DataMember]
        public string sClassCode { get; set; }
     
    }
}