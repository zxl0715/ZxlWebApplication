﻿using System;
using System.Runtime.Serialization;
using System.Collections.Generic;

namespace Nd.Erp.Mobile.Service.Common.Entity
{
    /// <summary>
    /// 客户端手机同步主数据实体
    /// </summary>
    public partial class EnMobileSyncClient
    {
        
        [DataMember]
        public List<EnMapCode> EnMapCodeList{get;set;}

		/// <summary>
		/// 客户端从表内容集合
		/// </summary>
        [DataMember]
        public List<EnMobileSyncClientSlave> EnMobileSyncClientSlaveList { get; set; }

        /// <summary>
        /// 客户端从表人员工号
        /// </summary>
        [DataMember]
        public List<EnMobileSyncServerPerson> SyncPersonCodeList { get; set; }
		
	}
}
