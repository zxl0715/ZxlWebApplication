﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Principal;
using System.Text;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile.ERPAuthorize;

namespace Nd.Erp.Mobile.Service.Common
{
    public class ERPAuthPrincipalProvider : IERPProvidePrincipal, IProvidePrincipal
    {
        public IPrincipal CreatePrincipal(string username, string password, string userguid)
        {
            var identity = new GenericIdentity(username);
            IPrincipal principal = new GenericPrincipal(identity, new[] { "User" });
            return principal;

        }

        public IPrincipal CreatePrincipal(string username, string password)
        {
            throw new NotImplementedException();
        }
    }
}
