using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http;
using System.Web.Http.Controllers;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;

namespace Nd.Erp.Mobile.Service.Common
{

    public class ERPAuthorizeAttribute : AuthorizeAttribute
    {
        private static LogMgr<ERPAuthorizeAttribute> _logMgr = new LogMgr<ERPAuthorizeAttribute>();
        private const string ERPAuthResponseHeader = "WWW-Authenticate";
        private const string ERPAuthResponseHeaderValue = "ERPAuth";
        protected override void HandleUnauthorizedRequest(HttpActionContext actionContext)
        {
            //_logMgr.WriteLogToLocal(false, "HandleUnauthorizedRequest ");
            if (actionContext == null)
                throw new ArgumentNullException("actionContext");
            actionContext.Response = CreateUnauthorizedResponse(actionContext
                .ControllerContext.Request);
        }
        private HttpResponseMessage CreateUnauthorizedResponse(HttpRequestMessage request)
        {
            //_logMgr.WriteLogToLocal(false, "CreateUnauthorizedResponse ");
            var result = new HttpResponseMessage()
            {
                StatusCode = HttpStatusCode.MethodNotAllowed, //HttpStatusCode.Unauthorized,��ʱ���ھɰ�ʹ��405���ȶ����������°���޸�Ϊ401
                RequestMessage = request
            };

            //result.Headers.Add(ERPAuthResponseHeader, ERPAuthResponseHeaderValue);
            return result;
        }

        public override void OnAuthorization(System.Web.Http.Controllers.HttpActionContext actionContext)
        {
            //_logMgr.WriteLogToLocal(false, "OnAuthorization ");
            if (actionContext == null)
                throw new ArgumentNullException("actionContext");
            if (AuthorizationDisabled(actionContext)
                || AuthorizeRequest(actionContext.ControllerContext.Request))
                return;
            this.HandleUnauthorizedRequest(actionContext);
        }
        private bool AuthorizeRequest(HttpRequestMessage request)
        {
            //_logMgr.WriteLogToLocal(false, "AuthorizeRequest IsOpenAuthorize:" + SQLiteAccess.GetSysArgValue("IsAuthorize"));
            if (SQLiteAccess.GetSysArgValue("IsAuthorize")!="true")
                return true;
            IEnumerable<string> osType = null;
            IEnumerable<string> userID = null;
            IEnumerable<string> userGUID = null;
            IEnumerable<string> deviceUUIDHashed = null;
            //ios��ȫ������
            if (request.Headers.TryGetValues("OSTYPE", out osType) && osType.FirstOrDefault().ToLower() == "ios")
                return true;
            
            request.Headers.TryGetValues("USERID", out userID);
            if (request.Headers.TryGetValues("USERGUID", out userGUID) && !string.IsNullOrWhiteSpace(userGUID.FirstOrDefault()))
            {
                
                string newGUID = string.Format("{0}_{1}", userID.FirstOrDefault(), userGUID.FirstOrDefault());
                var usr = UserCache.Get(newGUID);
                if (usr == null)        //���������û�д��ڵ�¼,��ܾ�����
                {
                    return false;
                }
                else
                {
                    if (usr.LifeTime != DateTime.MaxValue && usr.LifeTime <= DateTime.Now)
                    {
                        return false;
                    }
                }
                if (request.Headers.TryGetValues("DEVICEUUID", out deviceUUIDHashed) && request.Headers.TryGetValues("USERID", out userID))
                {
                    var deviceInfo = BzPersonAndDept.GetDeviceInfoInCache(deviceUUIDHashed.FirstOrDefault(),userID.FirstOrDefault());
                    if (deviceInfo != null && deviceInfo.IsFobidden == 0)
                        return true;
                    else
                        return false;
                }
            }
            return false;
        }
        private static bool AuthorizationDisabled(HttpActionContext actionContext)
        {
            //_logMgr.WriteLogToLocal(false, "AuthorizationDisabled ");
            //support new AllowAnonymousAttribute
            if (!actionContext.ActionDescriptor.GetCustomAttributes<AllowAnonymousAttribute>().Any())
                return actionContext.ControllerContext
                    .ControllerDescriptor
                    .GetCustomAttributes<AllowAnonymousAttribute>().Any();
            else
                return true;
        }
    }
}