using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Security.Principal;
using System.Threading;
using System.Threading.Tasks;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile.ERPAuthorize;

namespace Nd.Erp.Mobile.Service.Common
{
    
    public class ERPAuthMessageHandler : DelegatingHandler
    {

        public IERPProvidePrincipal PrincipalProvider { get; set; }
        public ERPAuthMessageHandler() {
        }
        public ERPAuthMessageHandler(IERPProvidePrincipal PrincipalProvider)
        {
            this.PrincipalProvider = PrincipalProvider;
        }
        protected override System.Threading.Tasks.Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request,
            CancellationToken cancellationToken)
        {
            IEnumerable<string> userguids = new List<string>();
            if (request.Headers.TryGetValues("USERGUID", out userguids))
            {
                string userGuid = userguids.FirstOrDefault();
                if (userGuid != null)
                {
                    Thread.CurrentPrincipal = PrincipalProvider
                        .CreatePrincipal(null, null, userGuid);
                }
                return base.SendAsync(request, cancellationToken);
            }
            return base.SendAsync(request, cancellationToken);
        }
       
      
    }
}