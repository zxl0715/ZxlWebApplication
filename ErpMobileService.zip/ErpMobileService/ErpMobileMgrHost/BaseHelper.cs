﻿using System;
using System.Data.SqlClient;
using System.Reflection;
using ND.Lib.Data.SqlHelper;
using ND.Lib.PDec;
using System.Data;
using System.Configuration;

namespace Nd.Erp.Mobile.Base
{
    public class BaseHelper
    {
        /// <summary>
        /// 日志是否写入数据库
        /// </summary>
        public readonly static bool IsWriteLogToDataBase = false;
        /// <summary>
        /// ERP数据库访问连接字符串
        /// </summary>
        public readonly static string ErpDataBaseAccess = "";
        /// <summary>
        /// 本地SQLite数据库访问
        /// </summary>
        public readonly static string SQLiteDBAccess = "";
        /// <summary>
        /// 服务的启动目录
        /// </summary>
        public readonly static string StartPath = "";
        /// <summary>
        /// 服务对外发布的基础地址
        /// </summary>
        public readonly static string ServiceBaseAddress = "";
        /// <summary>
        /// 手机接入服务名称
        /// </summary>
        public readonly static string MobileServiceName = "ErpMobileService";
        /// <summary>
        /// 日志
        /// </summary>
        private static SysEventLog<BaseHelper> _logMgr = new SysEventLog<BaseHelper>();
        static BaseHelper()
        {
            try
            {
                StartPath = Assembly.GetExecutingAssembly().Location.Substring(0, Assembly.GetExecutingAssembly().Location.LastIndexOf("\\"));
                ServiceBaseAddress = ConfigurationManager.AppSettings["baseAddress"];
                SQLiteDBAccess = GetSQLiteDBAccess();
                IsWriteLogToDataBase = IsWriteLogToDB();
                ErpDataBaseAccess = GetErpDataAccess();
            }
            catch(Exception ex)
            {
                _logMgr.WriteErrorFormat("初始化基础参数失败:{0}",ex.ToString());
                throw;
            }
        }

        /// <summary>
        /// ERP数据库访问连接字符串
        /// </summary>
        /// <returns></returns>
        private static string GetErpDataAccess()
        {
            string sqlCnnStr = ConfigurationManager.AppSettings["sqlCnnStr"]; //SQLiteAccess.GetSysArgValue("ErpSqlCnnStr");
            return PDesc.Decrypt(sqlCnnStr);
        }

        /// <summary>
        /// 日志是否写入数据库
        /// </summary>
        /// <returns></returns>
        private static bool IsWriteLogToDB()
        {
            string isWriteLogToDB = SQLiteAccess.GetSysArgValue("IsWriteLogToDB");
            return (isWriteLogToDB.ToLower() == "true" ? true : false);
        }

        /// <summary>
        /// 本地SQLite数据库访问连接字符串
        /// </summary>
        /// <returns></returns>
        private static string GetSQLiteDBAccess()
        {
            string sqliteCnnStr = PDesc.Decrypt(ConfigurationManager.AppSettings["sqliteCnnStr"]);
            if (sqliteCnnStr != "")
            {
                string sqliteCnnStrNew = "";
                foreach (string para in sqliteCnnStr.Split(';'))
                {
                    if (para.Trim().Length > 0)
                    {
                        string[] arPara = para.Split('=');
                        if (arPara[0].Trim().ToLower().Replace(" ", "").Equals("datasource"))
                        {
                            sqliteCnnStrNew += string.Format("Data Source={0};", StartPath + @"\" + arPara[1]);
                        }
                        else
                        {
                            sqliteCnnStrNew += para + ";";
                        }
                    }
                }
                sqliteCnnStr = sqliteCnnStrNew;
            }
            else
                throw new ApplicationException("未配置SQLite数据库连接串。");
            return sqliteCnnStr;
        }
    }
}
