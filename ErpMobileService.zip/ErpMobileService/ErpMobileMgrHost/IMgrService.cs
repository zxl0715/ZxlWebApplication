﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Data;
using ND.Lib.WinService.Manager;

namespace Nd.Erp.Mobile.Service
{
    [ServiceContract]
    public interface IMgrService
    {
        /// <summary>
        /// 获取所服务类库信息
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        DataTable GetAllService();

        /// <summary>
        /// 启动服务
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool StartService();

        /// <summary>
        /// 停止服务
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool StopService();

        /// <summary>
        /// 暂停服务
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool PauseService();

        /// <summary>
        /// 恢复服务
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool ResumeService();

        /// <summary>
        /// 检查服务是否存在
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        bool CheckServiceIsExist();

        /// <summary>
        /// 取得服务状态
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        int GetServiceStatus();

        /// <summary>
        /// 读取服务日志
        /// </summary>
        /// <param name="serviceCode">服务名称，空代表取所有服务日志</param>
        /// <param name="startDate">日志开始日期</param>
        /// <param name="endDate">日志结束日期</param>
        /// <param name="logType">日志类型</param>
        /// <param name="keyWord">关键字</param>
        /// <returns>日志信息</returns>
        [OperationContract]
        DataTable FetchLogInfo(string serviceCode,DateTime startDate,DateTime endDate,string logType,string keyWord);

        #region 系统参数相关

              /// <summary>
        /// 获取系统参数信息
        /// </summary>
        [OperationContract]
        DataTable GetSysArg();

        [OperationContract]
        bool AddSysArgs(string argKey, string argValue, string argDesc, bool? enable, string ParentArg);

        [OperationContract]
        DataTable GetArgTypes();

                /// <summary>
        /// 根据参数所属类型查找参数
        /// </summary>
        /// <param name="ArgType"></param>
        /// <returns></returns>
        [OperationContract]
        DataTable GetSysArgsWithType();

        [OperationContract]
        DataTable GetSysArgByType(string ArgType);

        [OperationContract]
        bool UpdateSysArgs(string argKey, string argValue, string argDesc, bool? enable, string ParentArg, int rowID);

        [OperationContract]
        bool DeleteSysArgs(int rowID);

        #endregion

        #region 基础代码相关
         /// <summary>
        /// 获取基础代码配置
        /// </summary>
        /// <returns></returns>
        [OperationContract]
        DataTable GetBaseCodes();

        [OperationContract]
        bool AddBaseCode(string code, string name, int parentID);

        [OperationContract]
        bool UpdateBaseCode(int id, string code, string name, int parentID);

        [OperationContract]
        bool DeleteBaseCode(int id);

        #endregion

        #region 服务注册相关

        [OperationContract]
        DataTable GetSvcRegArg();

        [OperationContract]
        bool AddSvcRegArg(string serviceCode, string serviceName, string ownerType, string addressPath, bool enabled);

        [OperationContract]
        bool UpdateSvcRegArg(int id, string serviceCode, string serviceName, string ownerType, string addressPath, bool enabled);

        [OperationContract]
        bool DeleteSvcRegArg(int id);
        
        #region 服务注册类别
        [OperationContract]
        DataTable GetSvcClassArg();

        [OperationContract]
        bool AddSvcClassArg(int serviceID, string nameSpace, string className, string EndPointBinding,string baseAddress, bool enabled,string memo);

        [OperationContract]
        bool UpdateSvcClassArg(int id, int serviceID, string nameSpace, string className, string EndPointBinding, string baseAddress, bool enabled, string memo);

        [OperationContract]
        bool DeleteSvcClassArg(int id);

        #endregion

        #region 服务接口参数

        [OperationContract]
        DataTable GetSvcInterfaceArg();

        [OperationContract]
        bool AddSvcInterfaceArg(int serviceClassID, string interfaceName, string endPointAddress, bool enabled, string memo);

        [OperationContract]
        bool UpdateSvcInterfaceArg(int id, int serviceClassID, string interfaceName, string endPointAddress, bool enabled, string memo);

        [OperationContract]
        bool DeleteSvcInterfaceArg(int id);

        #endregion

        #endregion



    }


}
