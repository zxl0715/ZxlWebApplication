﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.Configuration;
using Nd.Erp.Mobile.Base;

namespace Nd.Erp.Mobile.Service
{
    public class Host
    {
        private readonly string _baseAddress = ConfigurationManager.AppSettings["baseAddress"];
        private readonly string _metaHttpUrl = ConfigurationManager.AppSettings["metaHttpUrl"];
        private SysEventLog<Host> _logMgr = new SysEventLog<Host>();
        private ServiceHost _host;

        public void Start()
        {
            try
            {
                //服务地址
                Uri baseAddress = new Uri(_baseAddress);
                _host = new ServiceHost(typeof(MgrService), new Uri[] { baseAddress });

                //服务绑定
                NetTcpBinding bind = new NetTcpBinding();
                bind.Security.Mode = SecurityMode.None;
                bind.Security.Transport.ClientCredentialType = TcpClientCredentialType.None;
                _host.AddServiceEndpoint(typeof(IMgrService), bind, "");

                if (_host.Description.Behaviors.Find<System.ServiceModel.Description.ServiceMetadataBehavior>() == null)
                {
                    System.ServiceModel.Description.ServiceMetadataBehavior svcMetaBehavior = new System.ServiceModel.Description.ServiceMetadataBehavior();
                    svcMetaBehavior.HttpGetEnabled = true;
                    svcMetaBehavior.HttpGetUrl = new Uri(_metaHttpUrl);
                    _host.Description.Behaviors.Add(svcMetaBehavior);
                }
                _host.Opened += new EventHandler(delegate(object obj, EventArgs e)
                {
                    _logMgr.WriteInfo("服务启动成功！");
                });

                _host.Faulted += new EventHandler(Host_Faulted);
                _logMgr.WriteInfo("开始启动手机服务平台管理服务...");
                _host.Open();
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("启动手机服务平台管理服务失败：{0}", ex.Message);
            }
        }

        public void Stop()
        {
            if (_host != null)
            {
                _host.Close();
            }
        }

        private void Host_Faulted(object sender, EventArgs e)
        {
            _logMgr.WriteInfo("服务发生了内部异常！");
        }
    }
}
