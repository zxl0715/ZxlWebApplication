﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using Nd.Erp.Data.SQLite;
using Nd.Erp.Mobile.Base;
using ND.Lib.WinService.Manager;
using ND.Lib.Data.SqlHelper;
using System.Data.SQLite;

namespace Nd.Erp.Mobile.Service
{
    public class MgrService : IMgrService
    {
        private SysEventLog<MgrService> _logMgr = new SysEventLog<MgrService>();
        /// <summary>
        /// 获取所服务类库信息
        /// </summary>
        /// <returns></returns>
        public DataTable GetAllService()
        {
            string cmdTxt = "select * from ServiceArg order by ID";
            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }

        /// <summary>
        /// 启动服务
        /// </summary>
        /// <returns></returns>
        public bool StartService()
        {
            WinServiceManager sm = new WinServiceManager();
            return sm.StartService(BaseHelper.MobileServiceName);
        }

        /// <summary>
        /// 停止服务
        /// </summary>
        /// <returns></returns>
        public bool StopService()
        {
            WinServiceManager sm = new WinServiceManager();
            return sm.StopService(BaseHelper.MobileServiceName);
        }

        /// <summary>
        /// 暂停服务
        /// </summary>
        /// <returns></returns>
        public bool PauseService()
        {
            WinServiceManager sm = new WinServiceManager();
            return sm.PauseService(BaseHelper.MobileServiceName);
        }

        /// <summary>
        /// 恢复服务
        /// </summary>
        /// <returns></returns>
        public bool ResumeService()
        {
            WinServiceManager sm = new WinServiceManager();
            return sm.ResumeService(BaseHelper.MobileServiceName);
        }

        /// <summary>
        /// 检查服务是否存在
        /// </summary>
        /// <returns></returns>
        public bool CheckServiceIsExist()
        {
            WinServiceManager sm = new WinServiceManager();
            return sm.RemoteConnectValidate();
        }

        /// <summary>
        /// 取得服务状态
        /// </summary>
        /// <returns></returns>
        public int GetServiceStatus()
        {
            try
            {
                int serviceStatus = (int)WinServiceManager.ServiceStatusEnum.None;
                WinServiceManager sm = new WinServiceManager();
                if (sm.RemoteConnectValidate())
                {
                    serviceStatus = (int)sm.GetServiceStatus(BaseHelper.MobileServiceName);
                }
                return serviceStatus;
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("获取服务状态失败：{0}", ex.ToString());
                return 0;
            }
        }

        /// <summary>
        /// 读取服务日志
        /// </summary>
        /// <param name="serviceCode">服务名称，空代表取所有服务日志</param>
        /// <param name="startDate">日志开始日期</param>
        /// <param name="endDate">日志结束日期</param>
        /// <param name="logType">日志类型</param>
        /// <param name="keyWord">关键字</param>
        /// <returns>日志信息</returns>
        public DataTable FetchLogInfo(string serviceCode, DateTime startDate, DateTime endDate, string logType, string keyWord)
        {
            try
            {
                string cmdTxt = string.Format("SELECT CONVERT(VARCHAR,LogTime,121) LogTime,LogInfo,(case when LogType='03' then '正常日志' when LogType='04' then '异常日志' else '未知类型' end) LogType FROM M7_ServiceLogInfo WHERE CONVERT(NVARCHAR(10),LogTime,120) BETWEEN '{0}' AND '{1}' ", startDate.ToString("yyyy-MM-dd"), endDate.ToString("yyyy-MM-dd"));
                if (serviceCode.Length > 0)
                    cmdTxt += string.Format(" AND  ServiceCode = '{0}' ", serviceCode.Replace("'", "''"));
                if (logType.Length > 0)
                    cmdTxt += string.Format(" AND  LogType = '{0}' ", logType.Replace("'", "''"));
                if (keyWord.Length > 0)
                    cmdTxt += string.Format(" AND  LogInfo like '%{0}%' ", keyWord.Replace("'", "''"));

                return SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, cmdTxt).Tables[0];
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("读取服务日志失败：{0}", ex.ToString());
                return null;
            }
        }

        /// <summary>
        /// 获取系统参数信息
        /// </summary>
        /// <returns></returns>
        public DataTable GetSysArg()
        {
            string cmdTxt = "select * from SysArg order by RowID";
            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }
        /// <summary>
        /// 获取参数所属类型
        /// </summary>
        /// <returns></returns>
        public DataTable GetArgTypes()
        {
            string cmdTxt = "select * from SysArg where parentArg is null order by RowID";
            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }

        /// <summary>
        /// 根据参数所属类型查找参数
        /// </summary>
        /// <param name="ArgType"></param>
        /// <returns></returns>
        public DataTable GetSysArgByType(string ArgType)
        {
            string cmdTxt = "select * from SysArg where parentArg COLLATE NOCASE  =@parentArg order by RowID";

            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt, new SQLiteParameter("@parentArg", ArgType)).Tables[0];
        }



        /// <summary>
        /// 根据参数所属类型查找参数
        /// </summary>
        /// <param name="ArgType"></param>
        /// <returns></returns>
        public DataTable GetSysArgsWithType()
        {
            string cmdTxt = @"SELECT        b.RowID, b.ArgKey, b.ArgValue, a.ArgValue AS ArgType, b.ArgDesc, b.Enabled
                            FROM            SysArg a JOIN
                                                     SysArg b ON b.ParentArg = a.ArgKey
                            WHERE        (a.ParentArg IS NULL)
                            ORDER BY a.RowID";

            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }

        /// <summary>
        /// 添加系统参数
        /// </summary>
        /// <param name="argKey">系统参数KEY值</param>
        /// <param name="argValue">系统参数值</param>
        /// <param name="argDesc">系统参数描述</param>
        /// <param name="enabled">系统参数是否启用</param>
        /// <returns></returns>
        public bool AddSysArgs(string argKey, string argValue, string argDesc, bool? enabled, string ParentArg)
        {
            string cmdText = " insert into SysArg (ArgKey,ArgValue,ArgDesc,Enabled,ParentArg) select @ArgKey,@ArgValue,@ArgDesc,@Enabled,@ParentArg where not exists(select * from SysArg where argKey=@ArgKey ) ";


            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@ArgKey", argKey),
                new SQLiteParameter("@ArgValue", argValue),
                new SQLiteParameter("@ArgDesc", argDesc),
                new SQLiteParameter("@Enabled", enabled),
                new SQLiteParameter("@ParentArg", ParentArg)) > 0;
        }

        /// <summary>
        /// 更新系统参数
        /// </summary>
        /// <param name="argKey">系统参数KEY值</param>
        /// <param name="argValue">系统参数值</param>
        /// <param name="argDesc">系统参数描述</param>
        /// <param name="enabled">系统参数是否启用</param>
        /// <param name="rowID">系统参数ID</param>
        /// <returns></returns>
        public bool UpdateSysArgs(string argKey, string argValue, string argDesc, bool? enabled, string ParentArg, int rowID)
        {
            string cmdText = "update SysArg set ArgKey=@ArgKey,ArgValue=@ArgValue,ArgDesc=@ArgDesc,Enabled=@Enabled,ParentArg=@ParentArg where RowId=@RowID";
            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                 new SQLiteParameter("@ArgKey", argKey),
                 new SQLiteParameter("@ArgValue", argValue),
                 new SQLiteParameter("@ArgDesc", argDesc),
                 new SQLiteParameter("@Enabled", enabled),
                 new SQLiteParameter("@RowID", rowID),
                 new SQLiteParameter("@ParentArg", ParentArg)
                 ) > 0;
        }
        /// <summary>
        /// 删除系统参数
        /// </summary>
        /// <param name="RowID"></param>
        /// <returns></returns>
        public bool DeleteSysArgs(int rowID)
        {
            string cmdText = " delete from SysArg where RowID=@RowID ";
            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                 new SQLiteParameter("@RowID", rowID)
                 ) > 0;
        }

        /// <summary>
        /// 获取基础配置
        /// </summary>
        /// <returns></returns>
        public DataTable GetBaseCodes() {
            string cmdTxt = "select * from BaseCode";

            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }

        /// <summary>
        /// 添加基础配置
        /// </summary>
        /// <param name="code"></param>
        /// <param name="name"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool AddBaseCode(string code, string name, int parentID)
        {
            string cmdText = " insert into BaseCode (Code,Name,ParentID) select @Code,@Name,@ParentID where not exists(select * from BaseCode where ParentID=@ParentID and Code=@Code ) ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@Code", code),
                new SQLiteParameter("@Name", name),
                new SQLiteParameter("@ParentID", parentID)) > 0;
        }

        /// <summary>
        /// 修改基础配置
        /// </summary>
        /// <param name="id"></param>
        /// <param name="code"></param>
        /// <param name="name"></param>
        /// <param name="parentID"></param>
        /// <returns></returns>
        public bool UpdateBaseCode(int id, string code, string name, int parentID)
        {
            string cmdText = " update BaseCode set Code=@Code,Name=@Name,ParentID=@ParentID where ID=@ID  ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@Code", code),
                new SQLiteParameter("@Name", name),
                new SQLiteParameter("@ParentID", parentID),
                new SQLiteParameter("@ID", id)) > 0;
        }


        public bool DeleteBaseCode(int id)
        {
            string cmdText = " delete from BaseCode where ID=@ID ";
            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                 new SQLiteParameter("@ID", id)
                 ) > 0;
        }


        public DataTable GetSvcRegArg()
        {
            string cmdTxt = @"SELECT       s.ID, s.ServiceCode, s.ServiceName, s.OwnerType, s.AddressPath, s.Enabled, b.Name AS OwnerTypeName
                            FROM            ServiceArg s INNER JOIN
                         BaseCode b ON s.OwnerType = b.Code AND b.ParentID = 5";

            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }


        public bool AddSvcRegArg(string serviceCode,string serviceName,string ownerType,string addressPath,bool enabled)
        {
            string cmdText = " insert into ServiceArg (ServiceCode,ServiceName,OwnerType,AddressPath,Enabled) select @ServiceCode,@ServiceName,@OwnerType,@AddressPath,@Enabled where not exists(select * from ServiceArg where ServiceCode=@ServiceCode ) ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@ServiceCode", serviceCode),
                new SQLiteParameter("@ServiceName", serviceName),
                new SQLiteParameter("@OwnerType", ownerType),
                new SQLiteParameter("@AddressPath", addressPath),
                new SQLiteParameter("@Enabled", enabled)) > 0;
        }

        public bool UpdateSvcRegArg(int id, string serviceCode, string serviceName, string ownerType, string addressPath, bool enabled)
        {
            string cmdText = " update ServiceArg set ServiceCode=@ServiceCode,ServiceName=@ServiceName,OwnerType=@OwnerType,AddressPath=@AddressPath,Enabled=@Enabled where ID=@ID  ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@ID", id),
                new SQLiteParameter("@ServiceCode", serviceCode),
                new SQLiteParameter("@ServiceName", serviceName),
                new SQLiteParameter("@OwnerType", ownerType),
                new SQLiteParameter("@AddressPath", addressPath),
                new SQLiteParameter("@Enabled", enabled)) > 0;
        }

        public bool DeleteSvcRegArg(int id)
        {
            string cmdText = " delete from ServiceArg where ID=@ID ";
            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                 new SQLiteParameter("@ID", id)
                 ) > 0;
        }


        public DataTable GetSvcClassArg()
        {
            string cmdTxt = @"SELECT        sca.ID, sca.ServiceID, sca.NameSpace, sca.ClassName, sca.EndPointBinding, sca.BaseAddress, sca.Enabled, sca.Memo, sa.ServiceName, 
                         b.Name AS EndPointBindingName
                        FROM            ServiceClassArg sca INNER JOIN
                         ServiceArg sa ON sca.ServiceID = sa.ID INNER JOIN
                         BaseCode b ON sca.EndPointBinding = b.Code AND b.ParentID = 1";

            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }

        public bool AddSvcClassArg(int serviceID, string nameSpace, string className, string EndPointBinding, string baseAddress, bool enabled, string memo)
        {
            string cmdText = " insert into ServiceClassArg (ServiceID,NameSpace,ClassName,EndPointBinding,BaseAddress,Enabled,Memo) select @ServiceID,@NameSpace,@ClassName,@EndPointBinding,@BaseAddress,@Enabled,@Memo where not exists(select * from ServiceClassArg where NameSpace=@NameSpace and ClassName=@ClassName ) ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@ServiceID", serviceID),
                new SQLiteParameter("@NameSpace", nameSpace),
                new SQLiteParameter("@ClassName", className),
                new SQLiteParameter("@EndPointBinding", EndPointBinding),
                new SQLiteParameter("@BaseAddress", baseAddress),
                new SQLiteParameter("@Enabled", enabled),
                new SQLiteParameter("@Memo", memo)) > 0;
        }

        public bool UpdateSvcClassArg(int id, int serviceID, string nameSpace, string className, string EndPointBinding, string baseAddress, bool enabled, string memo)
        {
            string cmdText = " update ServiceClassArg set ServiceID=@ServiceID,NameSpace=@NameSpace,ClassName=@ClassName,EndPointBinding=@EndPointBinding,BaseAddress=@BaseAddress,Enabled=@Enabled,Memo=@Memo where ID=@ID  ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@ID", id),
                new SQLiteParameter("@ServiceID", serviceID),
                new SQLiteParameter("@NameSpace", nameSpace),
                new SQLiteParameter("@ClassName", className),
                new SQLiteParameter("@EndPointBinding", EndPointBinding),
                new SQLiteParameter("@BaseAddress", baseAddress),
                new SQLiteParameter("@Enabled", enabled),
                new SQLiteParameter("@Memo", memo)) > 0;
        }

        public bool DeleteSvcClassArg(int id)
        {
            string cmdText = " delete from ServiceClassArg where ID=@ID ";
            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                 new SQLiteParameter("@ID", id)
                 ) > 0;
        }


        public DataTable GetSvcInterfaceArg()
        {
            string cmdTxt = @"SELECT        si.ID, si.ServiceClassID, si.InterfaceName, si.EndPointAddress, si.Enabled, si.Memo, sca.NameSpace, sca.ClassName
                        FROM            ServiceInterfaceArg si INNER JOIN
                         ServiceClassArg sca ON si.ServiceClassID = sca.ID";

            return SQLiteHelper.GetDataSet(BaseHelper.SQLiteDBAccess, cmdTxt).Tables[0];
        }

        public bool AddSvcInterfaceArg(int serviceClassID, string interfaceName, string endPointAddress, bool enabled, string memo)
        {
            string cmdText = " insert into ServiceInterfaceArg (  ServiceClassID, InterfaceName, EndPointAddress, Enabled, Memo) select @ServiceClassID,@InterfaceName,@EndPointAddress,@Enabled,@Memo where not exists(select * from ServiceInterfaceArg where ServiceClassID=@ServiceClassID and InterfaceName=@InterfaceName ) ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@ServiceClassID", serviceClassID),
                new SQLiteParameter("@InterfaceName", interfaceName),
                new SQLiteParameter("@EndPointAddress", endPointAddress),
                new SQLiteParameter("@Enabled", enabled),
                new SQLiteParameter("@Memo", memo)) > 0;
        }

        public bool UpdateSvcInterfaceArg(int id, int serviceClassID, string interfaceName, string endPointAddress, bool enabled, string memo)
        {
            string cmdText = " update ServiceInterfaceArg set ServiceClassID=@ServiceClassID,InterfaceName=@InterfaceName,EndPointAddress=@EndPointAddress,Enabled=@Enabled,Memo=@Memo where ID=@ID  ";

            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                new SQLiteParameter("@ID", id),
                new SQLiteParameter("@ServiceClassID", serviceClassID),
                new SQLiteParameter("@InterfaceName", interfaceName),
                new SQLiteParameter("@EndPointAddress", endPointAddress),
                new SQLiteParameter("@Enabled", enabled),
                new SQLiteParameter("@Memo", memo)) > 0;
        }

        public bool DeleteSvcInterfaceArg(int id)
        {
            string cmdText = " delete from ServiceInterfaceArg where ID=@ID ";
            return SQLiteHelper.ExecuteNonQuery(BaseHelper.SQLiteDBAccess, cmdText,
                 new SQLiteParameter("@ID", id)
                 ) > 0;
        }
    }
}
