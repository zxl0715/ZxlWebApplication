﻿using System;
using System.Data.SQLite;
using Nd.Erp.Data.SQLite;
using ND.Lib.PDec;
using System.Data;
using System.Collections.Generic;
using System.Reflection;

namespace Nd.Erp.Mobile.Base
{
    public class SQLiteAccess
    {
        /// <summary>
        /// 访问SQLite数据库连接串
        /// </summary>
        private static string _sqliteCnnStr = "";

        /// <summary>
        /// 构造函数
        /// </summary>
        static SQLiteAccess()
        {
            _sqliteCnnStr = BaseHelper.SQLiteDBAccess;
        }
        
        /// <summary>
        /// 取得系统参数键值
        /// </summary>
        /// <param name="argKey">参数键</param>
        /// <returns>参数键值</returns>
        public static string GetSysArgValue(string argKey)
        {
            string cmdTxt = "select ArgValue from SysArg where ArgKey=@ArgKey and Enabled=1";
            object obj = SQLiteHelper.ExecuteScalar(_sqliteCnnStr, cmdTxt,new SQLiteParameter("@ArgKey",argKey));
            return (obj != null ? obj.ToString() : "");
        }
   
    }
}
