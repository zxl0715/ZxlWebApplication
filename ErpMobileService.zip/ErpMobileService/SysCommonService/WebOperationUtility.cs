﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel.Web;
using System.Net;

namespace Nd.Erp.Mobile.Service.Common
{
    public class WebOperationUtility
    {

        public static WebHeaderCollection GetRequestHeaders()
        {
            return WebOperationContext.Current.IncomingRequest.Headers;
        }

        public static int GetCurrentUserVersionCode()
        {

            try
            {
                var headers = GetRequestHeaders();
                return int.Parse(headers["VersionCode"]);
            }
            catch
            {
            }
            return -1;
        }



    }
}
