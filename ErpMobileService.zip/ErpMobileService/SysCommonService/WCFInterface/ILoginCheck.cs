﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;

namespace Nd.Erp.Mobile.Service.Common
{
    [ServiceContract]
    public interface ILoginCheckJson
    {
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "CheckPower?osType={osType}&sPersonCode={sPersonCode}&sPassword={sPassword}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<ResultStatus> CheckPower(string sPersonCode, string sPassword, string osType);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "CheckPowerWithPersonInfo?osType={osType}&sPersonCode={sPersonCode}&sPassword={sPassword}", BodyStyle = WebMessageBodyStyle.Bare)]
        ResultStatusWithPersonInfo CheckPowerWithPersonInfo(string sPersonCode, string sPassword, string osType);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetPersonInfo?sPersonCode={sPersonCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<PersonEntity> GetPersonInfo(string sPersonCode);

    }

}
