﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using Nd.Erp.Mobile.Service.Common.Entity;

namespace Nd.Erp.Mobile.Service.Common
{
    [ServiceContract]
    interface IAsyncTaskJson
    {
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "AsyncPerson", BodyStyle = WebMessageBodyStyle.Bare)]
        string AsyncPerson();

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "AsyncProject", BodyStyle = WebMessageBodyStyle.Bare)]
        string AsyncProject();
        
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "AsyncDepartment", BodyStyle = WebMessageBodyStyle.Bare)]
        string AsyncDepartment();
        
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetSyncInfoByAddTime?sPersonCode={sPersonCode}&dAddTime={dAddTime}&dbGuid={dbGuid}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnMobileSyncServer> GetSyncInfoByAddTime(string sPersonCode,string dbGuid, string dAddTime);
        
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "PostSyncInfo?sPersonCode={sPersonCode}&dAddTime={dAddTime}&dbGuid={dbGuid}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnPostSyncBackInfo PostSyncInfo(string sPersonCode, string dbGuid, string dAddTime, List<EnMobileSyncClient> syncClientList);
    
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "findPersonInSameDept?sPersonCode={sPersonCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        String findPersonInSameDept(string sPersonCode);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "selectPersonByStr?selectStr={selectStr}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnPersonAndDep> selectPersonByStr(string selectStr);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "selectProjectByStr?selectStr={selectStr}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnProject> selectProjectByStr(string selectStr);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "selectProjectByXmCode?sXmCode={sXmCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnProject selectProjectByXmCode(string sXmCode);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "selectProjectByXmFCode?sXmFCode={sXmFCode}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnProject> selectProjectByXmFCode(string sXmFCode);
    }

}
