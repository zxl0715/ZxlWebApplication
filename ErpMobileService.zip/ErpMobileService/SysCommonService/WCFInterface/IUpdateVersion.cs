﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.IO;

namespace Nd.Erp.Mobile.Service.Common
{
    [ServiceContract]
    interface IUpdateVersionJson
    {
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, UriTemplate = "GetLastestAPK?sha1={sha1}&startPosition={startPosition}", BodyStyle = WebMessageBodyStyle.Bare)]
        Stream GetLastestAPK(string sha1, long startPosition);

        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, UriTemplate = "ERPMobile.apk?sha1={sha1}&startPosition={startPosition}", BodyStyle = WebMessageBodyStyle.Bare)]
        Stream GetLastestERPMobile(string sha1, long startPosition);
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetVersionInfo?osType={osType}", BodyStyle = WebMessageBodyStyle.Bare)]
        VersionInfo GetVersionInfo(string osType = "");
    }

}
