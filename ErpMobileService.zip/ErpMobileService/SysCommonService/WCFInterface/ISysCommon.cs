﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.IO;

namespace Nd.Erp.Mobile.Service.Common
{
    [ServiceContract]
    public interface ISysCommonJson
    {
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "RefreshConfigInfomation", BodyStyle = WebMessageBodyStyle.Bare)]
        void RefreshConfigInfomation();

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "ShowLogInfomation", BodyStyle = WebMessageBodyStyle.Bare)]
        string ShowLogInfomation();

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getOftenOuPersonCode?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnOftenPerson> getOftenOuPersonCode(string userID);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getOftenProject?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnOftenProject> getOftenProject(string userID);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getOftenData?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<String> getOftenData(string userID);

        //[OperationContract]
        //[WebInvoke(Method = "POST", UriTemplate = "uploadFile?fileName={fileName}", ResponseFormat = WebMessageFormat.Json)]
        //long uploadFile(Stream stream,string fileName);
    }

    [ServiceContract]
    public interface ISysCommonXml
    {
        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Xml, ResponseFormat = WebMessageFormat.Xml, UriTemplate = "RefreshConfigInfomation", BodyStyle = WebMessageBodyStyle.Bare)]
        void RefreshConfigInfomation();

        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Xml, ResponseFormat = WebMessageFormat.Xml, UriTemplate = "ShowLogInfomation", BodyStyle = WebMessageBodyStyle.Bare)]
        string ShowLogInfomation();

        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Xml, ResponseFormat = WebMessageFormat.Xml, UriTemplate = "getOftenOuPersonCode?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnOftenPerson> getOftenOuPersonCode(string userID);

        [OperationContract]
        [WebInvoke(Method = "*", RequestFormat = WebMessageFormat.Xml, ResponseFormat = WebMessageFormat.Xml, UriTemplate = "getOftenData?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<String> getOftenData(string userID);
    }
}
