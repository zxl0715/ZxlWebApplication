﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Web.Http;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Service.Common.Entity;
using System.ServiceModel.Activation;

namespace Nd.Erp.Mobile.Service.Common
{
    /// <summary>
    /// 旧接口
    /// </summary>
    public class SysCommon : SysCommonController
    {
         
    }

    /// <summary>
    /// API新接口
    /// </summary>
    public class SysCommonController :ApiController, ISysCommonJson
    {
        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;

        [HttpGet]
        public void RefreshConfigInfomation()
        {
            BaseHelper.RefreshConfig();
        }

        [HttpGet]
        public string ShowLogInfomation()
        {

            string logFile = BaseHelper.StartPath + @"\Log\Log.txt";
            try
            {
                if (File.Exists(logFile))
                {
                    Stream stream = File.Open(logFile, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
                    StreamReader reader = new StreamReader(stream, Encoding.GetEncoding("GB2312"));
                    return reader.ReadToEnd();
                }
                return "could not file the file of " + logFile;
            }
            catch (Exception ex)
            {

                return "an exception:" + ex.Message;
            }

        }

        #region 获取常用接单人
        /// <summary>
        /// 获取常用接单人
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public List<EnOftenPerson> getOftenOuPersonCode(string userID)
        {
            var list = new List<EnOftenPerson>();
            string sqlStr = "select top 10 a.sLinkPeo as sPersonCode, b.sPersonName from A0_MyJdSet a, A5_CWPerson b, A5_wZzzl c where a.sLinkPeo=b.sPersonCode and b.sPersonCode=c.sPersonCode and (c.sClassCode<='03' or c.sClassCode='99') and a.sPersonCode=@userID order by lNum desc ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara).Tables[0];
            foreach (DataRow row in dt.Rows)
            {
                EnOftenPerson en = new EnOftenPerson
                {
                    sUserID = userID,
                    sPersonCode = row["sPersonCode"].ToString(),
                    sPersonName = row["sPersonName"].ToString()
                };

                list.Add(en);
            }

            return list;
        }
        #endregion

        #region 获取常用项目
        /// <summary>
        /// 获取常用项目
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public List<EnOftenProject> getOftenProject(string userID)
        {
            var list = new List<EnOftenProject>();
            string sqlStr = "select top 10 sXmCode from A0_MyXmSet where sPersonCode=@userID order by lNum desc ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara).Tables[0];
            foreach (DataRow row in dt.Rows)
            {
                EnOftenProject en = new EnOftenProject
                {
                    sUserID = userID,
                    sXmCode = row["sXmCode"].ToString()
                };

                list.Add(en);
            }

            return list;
        }
        #endregion

        #region 获取常用接单人和项目的编号
        /// <summary>
        /// 获取常用接单人和项目的编号
        /// </summary>
        /// <param name="userID">用户ID</param>
        /// <returns></returns>
        public List<String> getOftenData(string userID)
        {
            List<String> result = new List<string>();
            
            string sqlStr = "";
            sqlStr += " select top 10 sLinkPeo, ISNULL(lNum,0) as lNum from A0_MyJdSet where sPersonCode=@userID order by lNum desc ";
            sqlStr += " select top 10 sXmCode, ISNULL(lNum,0) as lNum from A0_MyXmSet where sPersonCode=@userID order by lNum desc ";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            DataSet ds = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara);
            foreach (DataTable dt in ds.Tables)
            {
                string data = "";
                foreach (DataRow row in dt.Rows)
                {
                    data += row[0].ToString() + "&" + row[1].ToString() + ",";
                }

                if (dt.Rows.Count > 0)
                    data = data.Substring(0, data.Length - 1);

                result.Add(data);
            }

            return result;
        }
        #endregion

        #region 导入人员基础数据
        /// <summary>
        /// 导入人员基础数据
        /// </summary>
        /// <returns></returns>
        public List<String> getImportPersonData()
        {
            List<string> result = new List<string>();
            string sqlStr = "SELECT a.spersoncode, a.spersonname, a.sdepcode, b.sClassCode FROM A5_CWPerson a, A5_wZZzl b WHERE a.sPersoncode=b.sPersoncode";

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr).Tables[0];

            string data = "";
            foreach (DataRow row in dt.Rows)
            {
                data = row[0].ToString() + "δ" + row[1].ToString() + "δ" + row[2].ToString() + "δ" + row[3].ToString();
                result.Add(data);
            }

            return result;
        }
        #endregion

        #region 导入项目基础数据
        /// <summary>
        /// 导入项目基础数据
        /// </summary>
        /// <returns></returns>
        public List<String> getImportProjectData()
        {
            List<string> result = new List<string>();
            string sqlStr = "SELECT sXMCode, sXMName, sXMFCode, lXMGrade, isnull(bIsFinish,0) as bIsFinish, isnull(bdel,0) as bdel FROM A5_WXMcls";

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr).Tables[0];

            string data = "";
            foreach (DataRow row in dt.Rows)
            {
                data = row[0].ToString() + "δ" + row[1].ToString() + "δ" + row[2].ToString() + "δ" + row[3].ToString() + "δ" + row[4].ToString() + "δ" + row[5].ToString();
                result.Add(data);
            }

            return result;
        }
        #endregion

        #region 导入部门基础数据
        /// <summary>
        /// 导入部门基础数据
        /// </summary>
        /// <returns></returns>
        public List<String> getImportDepData()
        {
            List<string> result = new List<string>();
            string sqlStr = "SELECT sDepCode, sDepName, sFDepCode, lDepGrade FROM A5_Wdepartmentcls";

            DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr).Tables[0];

            string data = "";
            foreach (DataRow row in dt.Rows)
            {
                data = row[0].ToString() + "δ" + row[1].ToString() + "δ" + row[2].ToString() + "δ" + row[3].ToString();
                result.Add(data);
            }

            return result;
        }
        #endregion

        #region 获取是否需要必填项目
        /// <summary>
        /// 获取是否需要必填项目
        /// </summary>
        /// <returns></returns>
        public string getERPRuleSettings(string userID)
        {
            string sqlStr = "select bNeedXm from A5_wOrderRule where sDepCode='' ";
            sqlStr += "select a.bNeedXm from A5_wOrderRule a, A5_CWPerson b where a.sDepCode=b.sDepCode and b.sPersonCode=@userID";

            SqlParameter[] arPara = new SqlParameter[] {
                new SqlParameter("@userID", userID)
            };

            string result = "1";
            DataSet ds = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, arPara);

            if (ds != null && ds.Tables[1].Rows.Count > 0)
                result = ds.Tables[1].Rows[0]["bNeedXm"].ToString();
            else if (ds != null && ds.Tables[0].Rows.Count > 0)
                result = ds.Tables[0].Rows[0]["bNeedXm"].ToString();

            return result;
        }
        #endregion
    }
}
