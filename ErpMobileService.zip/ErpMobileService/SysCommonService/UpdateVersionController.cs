﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Security.Cryptography;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using System.IO;
using System.Web.Http;
using Nd.Erp.Mobile.Base;
using System.ServiceModel.Activation;
using Nd.Erp.Mobile.Service.Common.Filters;
using System.Net.Http;
using System.Net;
using System.Net.Http.Headers;

namespace Nd.Erp.Mobile.Service.Common
{
    public class UpdateVersion : UpdateVersionController
    {
    }
    [AllowAnonymous]
    [AspNetCompatibilityRequirements(RequirementsMode = AspNetCompatibilityRequirementsMode.Allowed)]
    [ServiceBehavior(InstanceContextMode = InstanceContextMode.PerCall, Namespace = "")]
    public class UpdateVersionController : ApiController//, IUpdateVersionJson
    {
        private struct CurrentFileVersion
        {
            public long Length;
            public string SHA1;
            public int VersionCode;
        }


        private SysEventLog<UpdateVersionController> _logMgr = new SysEventLog<UpdateVersionController>();
        protected static string LastVersionAPKFileName = SQLiteAccess.GetSysArgValue("LastVersionAPKFileName");
        protected static string LastVersionIPAFileName = SQLiteAccess.GetSysArgValue("LastVersionIPAFileName");
        protected static string HostName = SQLiteAccess.GetSysArgValue("HostName");
        protected static string IpaIcon = "mainicon.png";
        protected static string IpaFullIcon = "mainicon@2x.png";
        const string versionCodeKey = "VersionCode";
        const string versionNameKey = "VersionName";
        const string versioniOSCodeKey = "iosVersionCode";
        const string versioniOSNameKey = "iosVersionName";

        /// <summary>
        /// 更新文件版本
        /// </summary>
        private static CurrentFileVersion _currentFileVersion;
        [NoZip]
        public HttpResponseMessage GetLastestAPK(string sha1 = null, long startPosition = 0)
        {
            string runDir = BaseHelper.StartPath;
            string filePath = Path.Combine(runDir, LastVersionAPKFileName);
            return DownloadFile(filePath, sha1, startPosition);
        }
        [NoZip]
        public HttpResponseMessage GetLastestIPA(string sha1 = null, long startPosition = 0)
        {
            string runDir = BaseHelper.StartPath;
            string filePath = Path.Combine(runDir, LastVersionIPAFileName);
            return DownloadFile(filePath, sha1, startPosition);
        }
        [NoZip]
        [ActionName("mainicon.png")]
        public HttpResponseMessage GetIPAIcon(string sha1 = null, long startPosition = 0)
        {
            string runDir = BaseHelper.StartPath;
            string filePath = Path.Combine(runDir, IpaIcon);
            return DownloadFile(filePath, sha1, startPosition);
        }
        [NoZip]
        [ActionName("mainicon2.png")]
        public HttpResponseMessage GetIPAFullIcon(string sha1 = null, long startPosition = 0)
        {
            string runDir = BaseHelper.StartPath;
            string filePath = Path.Combine(runDir, IpaFullIcon);
            return DownloadFile(filePath, sha1, startPosition);
        }
        protected HttpResponseMessage DownloadFile(string fileName, string sha1 = null, long startPosition = 0) {
           
            try
            {
                HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);

                SHA1 sha = new SHA1CryptoServiceProvider();

                FileStream fs = new FileStream(fileName, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);

                MemoryStream ms = new MemoryStream();
                int versionCode = GetVersionInfo().VersionCode;

                if (versionCode != _currentFileVersion.VersionCode || fs.Length != _currentFileVersion.Length)
                {
                    _currentFileVersion.VersionCode = versionCode;
                    _currentFileVersion.Length = fs.Length;
                    _currentFileVersion.SHA1 = CheckSumFile(fs);
                }
                if (sha1 != _currentFileVersion.SHA1)
                {
                    //不相等说明版本更新，需要从头下载
                    startPosition = 0;
                }
                ms.SetLength(fs.Length - startPosition);
                fs.Seek(startPosition, SeekOrigin.Begin);
                fs.Read(ms.GetBuffer(), 0, (int)(fs.Length - startPosition));
                System.Threading.Thread.Sleep(200);

                result.Content = new StreamContent(ms);
                result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");
                result.Content.Headers.TryAddWithoutValidation("ContentLength", fs.Length.ToString());
                result.Content.Headers.TryAddWithoutValidation("SHA1", _currentFileVersion.SHA1);

                return result;
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("文件获取失败:{0},文件路径:", ex.ToString(), fileName);
                throw;
            }
        }


        private string CheckSumFile(Stream stream)
        {
            SHA1Managed sha = new SHA1Managed();
            byte[] checksum = sha.ComputeHash(stream);
            return BitConverter.ToString(checksum).Replace("-", string.Empty);

        }

        public VersionInfo GetVersionInfo(string osType = "")
        {
            int versionCode = 0;


            if ((osType??"").ToLower() == "ios")
            {
                versionCode = int.Parse(SQLiteAccess.GetSysArgValue(versioniOSCodeKey));
            }
            try
            {
                versionCode = int.Parse(SQLiteAccess.GetSysArgValue(versionCodeKey));
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("获取版本号错误:{0}", ex.ToString());
            }

            return new VersionInfo
            {
                VersionCode = versionCode,
                VersionName = SQLiteAccess.GetSysArgValue(versionNameKey)
            };
        }
        [NoZip]
        [ActionName("ERPMobile.apk")]
        public HttpResponseMessage GetLastestERPMobile(string sha1 = null, long startPosition = 0)
        {
            return GetLastestAPK(sha1, startPosition);
        }

        [NoZip]
        [ActionName("ERPMobile.ipa")]
        public HttpResponseMessage GetLastestERPMobileIpa(string sha1 = null, long startPosition = 0)
        {
            return GetLastestIPA(sha1, startPosition);
        }
        [ActionName("ERPMobile.plist")]
        public HttpResponseMessage GetIpaPlist() {

             string versionName = SQLiteAccess.GetSysArgValue(versioniOSNameKey);
            string plist= string.Format("<?xml version=\"1.0\" encoding=\"UTF-8\"?><!DOCTYPE plist PUBLIC \"-//Apple//DTD PLIST 1.0//EN\" \"http://www.apple.com/DTDs/PropertyList-1.0.dtd\"><plist version=\"1.0\">"+ @"
<dict>
   <key>items</key>
   <array>
       <dict>
           <key>assets</key>
           <array>
               <dict>
                   <key>kind</key>
                   <string>software-package</string>
                   <key>url</key>
                   <string>{0}/ServiceHost/UpdateVersion/json/ERPMobile.ipa</string>
               </dict>
               <dict>
                   <key>kind</key>
                   <string>display-image</string>
                   <key>needs-shine</key>
                   <true/>
                   <key>url</key>
                   <string>{0}/ServiceHost/UpdateVersion/json/mainicon.png</string>
               </dict>
	       <dict>
                   <key>kind</key>
                   <string>full-size-image</string>
                   <key>needs-shine</key>
                   <true/>
                   <key>url</key>
                   <string>{0}/ServiceHost/UpdateVersion/json/mainicon2.png</string>
               </dict>
           </array><key>metadata</key>
           <dict>
               <key>bundle-identifier</key>
               <string>nd.erp.mobile.ent</string>
               <key>bundle-version</key>
               <string>{1}</string>
               <key>kind</key>
               <string>software</string>
               <key>subtitle</key>
               <string>网龙集团移动办公</string>
               <key>title</key>
               <string>网龙集团移动办公</string>
           </dict>
       </dict>
   </array>
</dict>
</plist>", HostName, "1.6.5");
            HttpResponseMessage result = new HttpResponseMessage(HttpStatusCode.OK);
            result.Content = new StringContent(plist);
            return result;
            
        }
    }

}
