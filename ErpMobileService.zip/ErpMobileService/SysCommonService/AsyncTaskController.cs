﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.Http;
using ND.Lib.Data.SqlHelper;
using System.Data.SqlClient;
using System.Data;
using System.Reflection;
using Nd.ERPMobile.WebApi.SelfHost;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using Nd.Erp.Mobile.Service.Common.Extensions;
using System.ServiceModel.Web;

namespace Nd.Erp.Mobile.Service.Common
{
    public class AsyncTask : AsyncTaskController
    {
    }
    public class AsyncTaskController : ApiController, IAsyncTaskJson
    {

        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;
        private LogMgr<AsyncTaskController> _logMgr = new LogMgr<AsyncTaskController>();

        /**
         * 同步公司人员数据
         * 
         * updateLog:
         * 2011.10.13 wqz 增加sDepCode字段
         * 2012.9.27 ccl
         **/
        [HttpGet]
        public string AsyncPerson()
        {
            return BzPersonAndDept.GetAllPersonInfoListInCache().ToJSON(isWithSinglQuote: true);
        }
        /**
        * 查询与工号相同部门的人的id 和名字和 部门id
        * 2012.9.19 zsw 
         * 2012.9.27 ccl
        **/
        [HttpGet]
        public string findPersonInSameDept(String sPersonCode)
        {
            #region //无缓存旧代码
            //StringBuilder result = new StringBuilder();
            //string sqlStr = "SELECT  a.sPersonCode ,a.sPersonName ,a.sDepCode FROM    A5_CWPerson a  LEFT JOIN A5_wZzzl b ON a.sPersonCode = b.sPersonCode WHERE   b.sClassCode <= '03' AND a.sDepCode LIKE ( SELECT TOP 1 (SELECT sFDepCode FROM A5_Wdepartmentcls WHERE sDepCode=a.sDepCode) FROM     A5_CWPerson a WHERE    a.sPersoncode =@sPersonCode) + '%' ORDER BY a.sPersonName";

            //DataTable dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr,new SqlParameter[] {
            //   new SqlParameter("@sPersonCode",sPersonCode)
            //        }).Tables[0];
            //if (dt != null && dt.Rows.Count > 0)
            //{
            //    result.Append("[");

            //    foreach (DataRow row in dt.Rows)
            //    {
            //        result.Append("{'sPersonCode':'" + row["sPersonCode"] + "','sPersonName':'" + row["sPersonName"] + "','sDepCode':'" + row["sDepCode"] + "'},");
            //    }

            //    result = result.Remove(result.Length - 1, 1);
            //    result.Append("]");
            //}
            //return result.ToString();
            #endregion

            var person = BzPersonAndDept.GetPersonInfoInCache(sPersonCode);
            var depInfo = BzPersonAndDept.GetDepByDepCodeInCache(person.sDepCode);
            return BzPersonAndDept.GetAllPersonInfoListInCache()
                .Where(p => Convert.ToInt32(p.sClassCode == "" ? "0" : p.sClassCode) <= 3 && p.sDepCode.Contains(depInfo.FDepCode))
                .Select(p => new { p.sPersonCode, p.sPersonName, p.sDepCode }/*排除部门名称，减少数据量*/)
                .ToList().ToJSON(isWithSinglQuote: true);

        }


        /**
       * 根据用户输入的查询字段获取对应的人员数据
       * 2012.10.18 zsw 
       **/
        [HttpGet]
        public List<EnPersonAndDep> selectPersonByStr(string selectStr)
        {


            return BzPersonAndDept.GetAllPersonAndDepInfoListInCache()
                .Where(p => Convert.ToInt32(p.sClassCode == "" || p.sClassCode == "99" ? "0" : p.sClassCode) <= 3 &&
                    (p.sPersonName.Contains(selectStr) || p.sPersonCode.Contains(selectStr))
                    )
                .ToList();
        }
        /**
         * 根据用户输入的查询字段获取对应的项目数据
         * 2012.10.19 zsw 
         **/
        [HttpGet]
        public List<EnProject> selectProjectByStr(string selectStr)
        {
            List<EnProject> resultList = new List<EnProject>();
            List<EnProject> resultListTemp = new List<EnProject>();
            var allProject=BzProject.GetAllProjectListInCache();
            resultList = allProject
                .Where(p => p.sXmName.Contains(selectStr))
                .ToList();
            resultList.ForEach(p => resultListTemp.AddRange(allProject.Where(pSub => pSub.sXmFCode == p.sXmCode)));
            resultListTemp.AddRange(resultList);
            return resultListTemp.Where(p => p.sXmFCode != "00")
                .Select(p=>new EnProject(){lXmGrade=p.lXmGrade,sXmCode=p.sXmCode,sXmName= BzProject.GetProjectInCache(p.sXmFCode).sXmName + "-" + p.sXmName, sXmFCode=p.sXmFCode})
                .ToList();
           
        }
        /**
        * 根据xXmCode获取项目
        * 2012.10.19 zsw 
        **/
        [HttpGet]
        public List<EnProject> selectProjectByXmFCode(string sXmFCode)
        {
            return BzProject.GetAllProjectListInCache().Where(p => p.sXmCode.StartsWith(sXmFCode) && p.sXmCode!=sXmFCode).ToList();
                
        }
        /**
       * 根据父项目编号获取子项目
       * 2012.10.19 zsw 
       **/
        [HttpGet]
        public EnProject selectProjectByXmCode(string sXmCode)
        {
            return BzProject.GetProjectInCache(sXmCode);

        }
        /// <summary>
        ///  同步公司一二级项目数据
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public string AsyncProject()
        {
            return BzProject.GetAllProjectListInCache().ToList().ToJSON(isWithSinglQuote: true);
        }

        /// <summary>
        /// 同步公司部门数据
        /// </summary>
        /// <returns></returns>
        [HttpGet]
        public string AsyncDepartment()
        {
            return BzPersonAndDept.GetAllDepInfoListInCache().ToList().ToJSON(isWithSinglQuote: true);
        }

        /// <summary>
        /// 获取服务器端修改的数据同步信息
        /// </summary>
        /// <param name="sPersonCode"></param>
        /// <param name="dbGuid"></param>
        /// <param name="dAddTime"></param>
        /// <returns></returns>
        public List<EnMobileSyncServer> GetSyncInfoByAddTime(string sPersonCode, string dbGuid=null, string dAddTime=null)
        {
            return BzMobileSyncServer.GetSyncInfoByAddTimeInCache(sPersonCode, dbGuid, dAddTime);
        }

        public EnPostSyncBackInfo PostSyncInfo(string sPersonCode, string dbGuid, string dAddTime, List<EnMobileSyncClient> syncClientList)
        {

            return BzMobileSyncServer.PostSyncInfo(sPersonCode, dbGuid, dAddTime, syncClientList);
        }
    }
}
