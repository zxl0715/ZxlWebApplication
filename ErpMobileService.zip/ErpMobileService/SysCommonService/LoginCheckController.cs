﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Net.Http;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.Web.Http;
using System.Reflection;
using Nd.Erp.Mobile;
using Nd.Erp.Mobile.Base;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Service.Common.Entity;
using SysCommonLibrary.Business;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.Common
{
    [AllowAnonymous]
    public class LoginCheckController : ApiController
    {
        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;
        private LogMgr<LoginCheckController> _logMgr = new LogMgr<LoginCheckController>();

        #region 验证用户（不返回用户信息）
        /// <summary>验证用户（不返回用户信息）</summary>
        /// <param name="osType">设备类型</param>
        /// <param name="sPersonCode">用户工号</param>
        /// <param name="sPassword">用户密码</param>      
        /// <param name="deviceName">设备名称</param>
        /// <param name="deviceUUIDHash">设备唯一标识散列</param>
        /// <returns>验证结果</returns>
        [HttpGet]
        public List<ResultStatus> CheckPower(string sPersonCode, string sPassword, string osType = null, string deviceName = null, string deviceUUIDHash = null,string sdkVersion=null)
        {
            return BzLoginCheck.CheckPower(sPersonCode, sPassword, osType, deviceName, deviceUUIDHash, sdkVersion);
        }
        #endregion

        #region 验证登陆并返回用户信息
        /// <summary>
        /// 验证登陆并返回用户信息
        /// </summary>
        /// <param name="sPersonCode">工号</param>
        /// <param name="sPassword">密码</param>
        /// <param name="osType">设备类型</param>
        /// <param name="deviceName">设备名称</param>
        /// <param name="deviceUUIDHash">设备唯一标识散列</param>
        /// <returns>验证结果与用户信息</returns>
        [HttpGet]
        [HttpPost]
        public ResultStatusWithPersonInfo CheckPowerWithPersonInfo(string sPersonCode, string sPassword, string osType = null, string deviceName = null, string deviceUUIDHash = null, string sdkVersion = null)
        {
            var resultStatusList = CheckPower(sPersonCode, sPassword, osType, deviceName, deviceUUIDHash, sdkVersion);

            
            if (resultStatusList != null && resultStatusList.Count > 0)
            {
               
                ResultStatusWithPersonInfo resultWithPersonInfo = new ResultStatusWithPersonInfo()
                {
                    ErrorInfo = resultStatusList[0].ErrorInfo,
                    IsProxy = resultStatusList[0].IsProxy,
                    IsSuccess = resultStatusList[0].IsSuccess,
                    UserGUID = resultStatusList[0].UserGUID

                }; 
                
                if (resultStatusList[0].IsSuccess)
                {
                    if (SQLiteAccess.GetSysArgValue("IsAuthorize") == "true")
                    {
                        var deviceInfo = BzPersonAndDept.GetDeviceInfoInCache(deviceUUIDHash, sPersonCode);
                        if (deviceInfo != null && deviceInfo.IsFobidden == 1)
                            return new ResultStatusWithPersonInfo() { IsSuccess = false, ErrorInfo = "您的手机被设置禁止登陆" };
                    }
                    resultWithPersonInfo.PersonInfo = GetPersonInfo(sPersonCode)[0];

                }
                return resultWithPersonInfo;
            }

            return null;
        }
        #endregion

        [HttpGet]
        [HttpPost]
        public ResultStatusWithPersonInfo CheckPower(string sid)
        {
            return BzLoginCheck.CheckPower(sid);
        }

        #region 获取用户信息
        /// <summary>
        /// 获取用户信息
        /// </summary>
        /// <param name="sPersonCode"></param>
        /// <returns></returns>
        [HttpGet]
        public List<PersonEntity> GetPersonInfo(string sPersonCode)
        {
            var list = new List<PersonEntity>();
            try
            {
                var person = BzPersonAndDept.GetPersonInfoInCache(sPersonCode);
                if (person != null)
                {
                    list.Add(person);
                    return list;
                }
                return list;
            }
            catch (Exception ex)
            {
                _logMgr.WriteErrorFormat("读取人员({1})信息失败:{0}", ex.ToString(), sPersonCode);
                return list;
            }
        }
        #endregion
    }
}
