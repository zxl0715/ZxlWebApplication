﻿IF EXISTS(SELECT * FROM dbo.sysobjects WHERE id=OBJECT_ID(N'[K5_wTQjInfoMobile]') AND OBJECTPROPERTY(id,N'IsUserTable')=1)
DROP TABLE [K5_wTQjInfoMobile]
GO

CREATE TABLE [dbo].[K5_wTQjInfoMobile]
(
	[AutoCode] [int] NOT NULL IDENTITY(1, 1),
	[lCode] [int]  NULL ,                     ----关联的表单编号
	[sPersoncode] [nvarchar] (20)  NULL,         ----申请人
	[sDepCode] [nvarchar] (12)  NULL,            ----申请人所在部门
	[sKCode] [nvarchar] (10)  NULL,              ----单据类型
	[dDate] [datetime] NULL,                     ----填单时间
	[dSDate] [datetime] NULL,                    ----开始时间
	[dEDate] [datetime] NULL,                    ----结束时间
	[lTime] [float] NULL,                        ----时数
	[lWorkTime] [float] NULL,                    ----工作时数
	[sStrName] [nvarchar] (600)  NULL,           ----备注信息
	[sInMemo] [nvarchar] (200)  NULL,            ----交接内容 
	[sInPeoCode] [nvarchar] (20)  NULL,          ----交接人
	[lState] [int]  NULL,                     ----状态,0/1/2,新增/修改/作废
	[lflag] [int]  NULL,                      ----是否已经同步到请假表
    [sTel] [nvarchar] (50)  NULL                 ----请假调休期间联系电话
	
) ON [PRIMARY]
GO

CREATE UNIQUE CLUSTERED INDEX [autocode] ON [dbo].[K5_wTQjInfoMobile] ([AutoCode]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [dDate] ON [dbo].[K5_wTQjInfoMobile] ([dDate]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [dSDate] ON [dbo].[K5_wTQjInfoMobile] ([dSDate]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [index_K5_wTQjInfo_sPersoncode] ON [dbo].[K5_wTQjInfoMobile] ([sPersoncode], [sKCode]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [sDepCode] ON [dbo].[K5_wTQjInfoMobile] ([sDepCode]) ON [PRIMARY]
GO
CREATE NONCLUSTERED INDEX [lState] ON [dbo].[K5_wTQjInfoMobile] ([lState]) ON [PRIMARY]
GO