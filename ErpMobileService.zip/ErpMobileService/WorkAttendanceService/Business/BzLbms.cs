﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.WorkAttendance.DataAccess;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Business
{
    public class BzLbms
    {
        private static readonly DaLbms dal = new DaLbms();

        public static List<EnLbms> GetKqLbms(string userID, string sdate, string edate)
        {
            return dal.GetKqLbms(userID, sdate, edate);
        }

    }
}
