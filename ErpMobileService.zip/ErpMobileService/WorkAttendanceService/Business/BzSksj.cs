﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.WorkAttendance.DataAccess;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Business
{
    public class BzSksj
    {
        private static readonly DaSksj dal = new DaSksj();


        #region 获取员工的指纹刷卡数据
        /// <summary>
        /// 获取员工指定日期的班次时间
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public static List<string> GetSksj(string userID, string p_date)
        {
            return dal.GetSksj(userID, p_date);
        }
        #endregion
    }
}
