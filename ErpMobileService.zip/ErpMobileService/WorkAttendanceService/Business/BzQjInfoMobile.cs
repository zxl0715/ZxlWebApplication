﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;


namespace Nd.Erp.Mobile.Service.WorkAttendance.Business
{
    public class BzQjInfoMobile
    {
        private static readonly DaQjInfoMobile dal = new DaQjInfoMobile();

        public static List<EnQjInfoMobile> GetQjInfoMobile(string userID, string p_sdate, string p_edate, string p_skcode)
        {
            return dal.GetQjInfoMobile(userID, p_sdate,p_edate, p_skcode);
        }


        /// <summary>
        /// 更新单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        public static int AddQjInfo(EnQjInfoMobile enQjinfoMobile)
        {
            return dal.AddQjInfo(enQjinfoMobile);

        }

         /// <summary>
        /// 更新单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        public static int UpdateQjInfo(EnQjInfoMobile enQjinfoMobile)
        {
            return dal.UpdateQjInfo(enQjinfoMobile);

        }

        /// <summary>
        /// 作废单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        public static int BlankOutQjInfo(EnQjInfoMobile enQjinfoMobile)
        {
            return dal.BlankOutQjInfo(enQjinfoMobile);

        }

        /// <summary>
        /// 获取可调休时间
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static float GetTxTime(string userID)
        {
            return dal.GetTxTime(userID);
        }

        /// <summary>
        /// 是否超过填单期限
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public static bool IsOverTime(string userID, string date)
        {
            return dal.IsOverTime(userID, date);
        }

        /// <summary>
        /// 获取员工的手机号码
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static string GetUserMobile(string userID)
        {
            return dal.GetUserMobile(userID);

        }
    }
}
