﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.WorkAttendance.DataAccess;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Business
{
    public class BzMenjin
    {
        private static readonly DaMenjin dal = new DaMenjin();


        #region 获取员工的门禁记录
        /// <summary>
        /// 获取员工指定日期的班次时间
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public static List<EnMenjin> GetMenjinList(string userID, string p_date)
        {
            return dal.GetMenjinList(userID, p_date);
        }
        #endregion
    }
}
