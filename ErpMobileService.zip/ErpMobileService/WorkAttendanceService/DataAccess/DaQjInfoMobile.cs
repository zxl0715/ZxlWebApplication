﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;
using System.Data.SqlClient;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Entity
{
    public class DaQjInfoMobile
    {
        #region 获取员工的填单记录
        /// <summary>
        /// 获取员工指定日期的班次时间
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public List<EnQjInfoMobile> GetQjInfoMobile(string userID, string p_sdate, string p_edate, string p_skcode)
        {
            string strSql = " ";
		   strSql +=" SELECT ";
           strSql +="   sPersoncode , ";
           strSql +="   sDepCode ,";
           strSql +="   sKCode ,";
           strSql +="   dDate ,";
           strSql +="   dSDate + dSTime dSDate,";
           strSql +="   dEDate +dETime dEDate ,";
           strSql +="   lTime ,";
           strSql +="   lWorkTime ,";
           strSql +="   sStrName ,";
           strSql +="   sInMemo ,";
           strSql +="   sInPeoCode ,";
           strSql +="   lState ,";
           strSql += "  autocode lCode ,";
           strSql +="   sTel";
           strSql += "  FROM K5_wTQjInfo WHERE spersoncode = '" + userID + "' AND CONVERT(NVARCHAR(10),dSDate,120) between '" + p_sdate + "' and '" + p_edate + "' AND skcode in ('" + p_skcode.Replace(",","','") + "') ";
		   strSql +=" union ";
           strSql +=" SELECT  ";
           strSql +="sPersoncode , ";
           strSql +="sDepCode , ";
           strSql +="sKCode , ";
           strSql +="dDate ,";
           strSql +="dSDate ,";
           strSql +="dEDate ,";
           strSql +="lTime ,";
           strSql +="lWorkTime ,";
           strSql +="sStrName ,";
           strSql +="sInMemo ,";
           strSql +="sInPeoCode ,";
           strSql += " (case lState when 0 then 1 when 2 then 4 else 1 end ) lState ,";
           strSql += " lCode ,";
           strSql +="sTel ";
           strSql += "FROM K5_wTQjInfoMobile WHERE isnull(lCode,0)=0 and spersoncode = '" + userID + "'  AND CONVERT(NVARCHAR(10),dSDate,120) between '" + p_sdate + "' and '" + p_edate + "' AND skcode in ('" + p_skcode.Replace(",", "','") + "') order by dDate desc";

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                List<EnQjInfoMobile> list = DynamicBuilder<EnQjInfoMobile>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

        /// <summary>
        /// 增加单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        public int AddQjInfo(EnQjInfoMobile enQjinfoMobile)
        {
            int result = 0;

            string strSql = @" INSERT INTO K5_wTQjInfoMobile( sPersoncode ,sDepCode ,sKCode , dDate ,dSDate ,dEDate , lTime , lWorkTime ,sStrName ,sInMemo , sInPeoCode , lState ,sTel )
                VALUES  ( @sPersoncode ,@sDepCode,@sKCode,@dDate,@dSDate,@dEDate,@lTime,@lWorkTime,@sStrName,@sInMemo,@sInPeoCode, @lState,@sTel) ";

            SqlParameter[] param = {
                new SqlParameter("@sPersoncode", SqlDbType.NVarChar),
                new SqlParameter("@sDepCode",SqlDbType.NVarChar) ,
                new SqlParameter("@sKCode",SqlDbType.NVarChar) ,
                new SqlParameter("@dDate",SqlDbType.DateTime) ,
                new SqlParameter("@dSDate",SqlDbType.DateTime) ,
                new SqlParameter("@dEDate",SqlDbType.DateTime) ,
                new SqlParameter("@lTime",SqlDbType.Float) ,
                new SqlParameter("@lWorkTime",SqlDbType.Float) ,
                new SqlParameter("@sStrName",SqlDbType.NVarChar) ,
                new SqlParameter("@sInMemo",SqlDbType.NVarChar) ,
                new SqlParameter("@sInPeoCode",SqlDbType.NVarChar) ,
                new SqlParameter("@lState",SqlDbType.Int) ,
                new SqlParameter("@sTel",SqlDbType.NVarChar) 
          };


            param[0].Value = enQjinfoMobile.sPersoncode;
            param[1].Value = enQjinfoMobile.sDepCode;
            param[2].Value = enQjinfoMobile.sKCode;
            param[3].Value = DateTime.Now.ToString();
            param[4].Value = enQjinfoMobile.dSDate;
            param[5].Value = enQjinfoMobile.dEDate;
            param[6].Value = enQjinfoMobile.lTime;
            param[7].Value = enQjinfoMobile.lWorkTime;
            param[8].Value = enQjinfoMobile.sStrName;
            param[9].Value = enQjinfoMobile.sInMemo;
            param[10].Value = enQjinfoMobile.sInPeoCode;
            param[11].Value = 0;
            param[12].Value = enQjinfoMobile.sTel;


            try
            {
                result = SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, param);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }


        /// <summary>
        /// 更新单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        public int UpdateQjInfo(EnQjInfoMobile enQjinfoMobile)
        {
            int result = 0;

            string strSql = @" update K5_wTQjInfoMobile set sPersoncode =@sPersoncode ,lflag=0,sDepCode =@sDepCode,sKCode=@sKCode,dDate=@dDate ,dSDate=@dSDate ,dEDate=@dEDate , lTime= @lTime, lWorkTime=@lWorkTime ,sStrName=@sStrName ,sInMemo=@sInMemo , sInPeoCode=@sInPeoCode , lState =@lState,sTel=@sTel  where autocode=@autocode ";

            SqlParameter[] param = {
                new SqlParameter("@sPersoncode", SqlDbType.NVarChar),
                new SqlParameter("@sDepCode",SqlDbType.NVarChar) ,
                new SqlParameter("@sKCode",SqlDbType.NVarChar) ,
                new SqlParameter("@dDate",SqlDbType.DateTime) ,
                new SqlParameter("@dSDate",SqlDbType.DateTime) ,
                new SqlParameter("@dEDate",SqlDbType.DateTime) ,
                new SqlParameter("@lTime",SqlDbType.Float) ,
                new SqlParameter("@lWorkTime",SqlDbType.Float) ,
                new SqlParameter("@sStrName",SqlDbType.NVarChar) ,
                new SqlParameter("@sInMemo",SqlDbType.NVarChar) ,
                new SqlParameter("@sInPeoCode",SqlDbType.NVarChar) ,
                new SqlParameter("@lState",SqlDbType.Int) ,
                new SqlParameter("@sTel",SqlDbType.NVarChar), 
                new SqlParameter("@autocode",SqlDbType.Int) 
         };


            param[0].Value = enQjinfoMobile.sPersoncode;
            param[1].Value = enQjinfoMobile.sDepCode;
            param[2].Value = enQjinfoMobile.sKCode;
            param[3].Value = DateTime.Now.ToString();
            param[4].Value = enQjinfoMobile.dSDate;
            param[5].Value = enQjinfoMobile.dEDate;
            param[6].Value = enQjinfoMobile.lTime;
            param[7].Value = enQjinfoMobile.lWorkTime;
            param[8].Value = enQjinfoMobile.sStrName;
            param[9].Value = enQjinfoMobile.sInMemo;
            param[10].Value = enQjinfoMobile.sInPeoCode;
            param[11].Value = 1;
            param[12].Value = enQjinfoMobile.sTel;
            param[13].Value = enQjinfoMobile.AutoCode;


            try
            {
                result = SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, param);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// 作废单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        public int BlankOutQjInfo(EnQjInfoMobile enQjinfoMobile)
        {
            int result = 0;

            string strSql = @" update K5_wTQjInfoMobile set lState =2,lflag=0 where autocode=@autocode ";

            SqlParameter[] param = {
                new SqlParameter("@autocode",SqlDbType.NVarChar) 
          };


            param[0].Value = enQjinfoMobile.AutoCode;
           


            try
            {
                result = SqlHelper.ExecuteNonQuery(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql, param);
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// 获取可调休时间
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public float GetTxTime(string userID)
        {

            float result = 0;

            string strSql = " declare @sPersoncode varchar(50) ";
                  strSql += "              set @sPersoncode = '"+userID+"' ";
                  strSql += @"              declare @OverTime float , @UsedTime float , @TJTime float
                                select  @OverTime = sum(isnull(lTime, 0)) , @UsedTime = sum(isnull(lUsedTime, 0))
                                from    K5_wQjInfo
                                where   ( sKCode = '10' or sKCode = '11' or sKCode = '12')  and sMCode = '01'
                                        and sPersoncode = @sPersoncode  and (   dSDate between '2007-12-21' and '2050-12-31' )
                                select  @TJTime = sum(isnull(B.lTime, 0))
                                from    K5_wTQjInfo A inner join K5_wTQjInfos B on A.Autocode = B.lcode
                                where   B.sKCode = '18' and A.lState = 1 and A.sPersoncode = @sPersoncode
                                select  isnull(( isnull(@OverTime, 0) - isnull(@UsedTime, 0) - isnull(@TJTime, 0) ), 0)  ";

       
            try
            {
                Object TxObject = SqlHelper.ExecuteScalar(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                try
                {
                    result = float.Parse(TxObject.ToString());
                }
                catch (Exception ex)
                {
                    result = 0;
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        /// <summary>
        /// 是否超过填单期限
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        public bool IsOverTime(string userID, string date)
        {
            return true;
        }

         /// <summary>
        /// 获取员工的手机号码
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public string GetUserMobile(string userID)
        {
            string result = "";

            string strSql = "  ";
            strSql += @"        select  sygmobile
                                from    A5_CWPerson
                                where   spersoncode ='" + userID + "'  ";


            try
            {
                Object TxObject = SqlHelper.ExecuteScalar(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                try
                {
                    result = TxObject.ToString();
                }
                catch (Exception ex)
                {
                    result = "";
                }
                return result;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
