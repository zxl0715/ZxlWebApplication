﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;
using System.Data;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Base;

namespace Nd.Erp.Mobile.Service.WorkAttendance.DataAccess
{
    public class DaMenjin
    {
        #region 获取员工的门禁记录
        /// <summary>
        /// 获取员工指定日期的班次时间
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public List<EnMenjin> GetMenjinList(string userID, string p_date)
        {
            if (p_date == ""||p_date ==null)
                p_date = DateTime.Now.ToString("yyyy-MM-dd");
            string strSql = @" SELECT dEventTime,(SELECT sName FROM  a5_kqmenjinset WHERE sMenjinCode = sFixNo) MenjinName,
                        (CASE WHEN lEventType =0 THEN '进门' ELSE '出门' END) EventType
                        FROM dbo.K5_YMenJin WHERE sGKcode='" + userID + "' AND CONVERT(CHAR(10),dEventTime,120) ='" + p_date + "'";

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                List<EnMenjin> list = DynamicBuilder<EnMenjin>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

    }
}
