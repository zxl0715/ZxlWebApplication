﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;
using System.Data;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.WorkAttendance.DataAccess
{
    public class DaSksj
    {

        #region 获取员工指定日期的班次时间
        /// <summary>
        /// 获取员工指定日期的班次时间
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public List<string> GetSksj(string userID, string p_date)
        {
            if (p_date == "" || p_date == null)
                p_date = DateTime.Now.ToString("yyyy-MM-dd");
            string strSql = @" 
            declare @m_Onduty datetime 
            declare @m_RestStart datetime 
            declare @m_RestEnd datetime 
            declare @m_Offduty datetime 
            SELECT  @m_Onduty=(CASE ISNULL(b.bFOnSpan,0) WHEN 0 THEN (a.ddate+b.sFOnduty) ELSE (DATEADD(DAY,-1,a.dDate)+b.sFOnduty) end),
	                                    @m_RestStart=(CASE ISNULL(b.brsfdflag,0) WHEN 0 THEN (CASE ISNULL(b.brsspan,0) WHEN 0 THEN (a.ddate+b.sreststart) ELSE (DATEADD(DAY,1,a.ddate)+b.sreststart) end) ELSE (CASE ISNULL(b.bfrsfdspan,0) WHEN 0 THEN (a.ddate+b.sfreststartfd) ELSE (DATEADD(day,1,a.ddate)+b.sfreststartfd)END ) END),
	                                   @m_Offduty=(CASE ISNULL(b.bLOffSpan,0) WHEN 0 THEN (a.ddate+b.sLOffduty) ELSE (DATEADD(DAY,1,a.dDate)+b.sLOffduty) end),
	                                    @m_RestEnd= (CASE ISNULL(b.brefdflag,0) WHEN 0 THEN (CASE ISNULL(b.brespan,0) WHEN 0 THEN (a.ddate+b.srestend) ELSE (DATEADD(DAY,1,a.ddate)+b.srestend) END )ELSE (CASE ISNULL(b.bLREFdSpan,0) WHEN 0 THEN (a.dDate+b.sLRestEndFd) ELSE (DATEADD(DAY,1,a.ddate)+b.sLRestEndFd) END )END)
                                         FROM dbo.K1_wTurnResult a,dbo.K1_wBCms b
                                        WHERE a.sTurnNo = b.sTurnNo
                                        AND a.dDate = '"+p_date+"'  and sPersoncode='" + userID + "' ";

            strSql += "     SELECT dDate+sTime AS sktime INTO  #K1_wsksj  from K1_wsksj where sgkcode ='" + userID + "' and ddate+stime between @m_Onduty and @m_Offduty                      ";
            strSql += @" SELECT  (SELECT TOP 1 sktime FROM  #K1_wsksj WHERE sktime BETWEEN @m_Onduty and  @m_RestStart ) as sksj1,
            (SELECT TOP 1 sktime FROM  #K1_wsksj WHERE sktime BETWEEN @m_RestStart and  @m_RestEnd ORDER BY sktime ASC )as sksj2,
            (SELECT TOP 1 sktime FROM  #K1_wsksj WHERE sktime BETWEEN @m_RestStart and  @m_RestEnd ORDER BY sktime desc ) as sksj3,
            (SELECT TOP 1 sktime FROM  #K1_wsksj WHERE sktime BETWEEN @m_RestEnd and  @m_Offduty ) as sksj4
            DROP TABLE #K1_wsksj

            ";
            DataTable dt = null;
            try
            {
                dt = SqlHelper.ExecuteDataset(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql).Tables[0];
                List<string> m_list=new List<string>();
               m_list.Add( dt.Rows[0][0].ToString());
                 m_list.Add( dt.Rows[0][1].ToString());
               m_list.Add( dt.Rows[0][2].ToString());
               m_list.Add( dt.Rows[0][3].ToString());
             
                return m_list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dt != null)
                {
                    dt.Dispose();
                }
            }
        }
        #endregion

    }
}
