﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;
using System.Data;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

namespace Nd.Erp.Mobile.Service.WorkAttendance.DataAccess
{
    public class DaLbms
    {

        #region 获取员工指定日期的班次时间
        /// <summary>
        /// 获取员工指定日期的班次时间
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public List<EnLbms> GetKqLbms(string userID, string sdate, string edate)
        {
            if (sdate == "" || sdate == null)
                sdate = DateTime.Now.ToString("yyyy-MM-dd");
            if (edate == "" || edate == null)
                edate = sdate;
            string strSql = @" SELECT 
	                            bFdFlag IsFd,
                                (case when a.sdatetype in ('03','04','05') then 1 else 0 end )        IsHoliday,
	                            (CASE WHEN b.bOnFdFlag=1 THEN b.sFOndutyFd ELSE b.sOnduty END) OndutyF,
	                            (CASE WHEN b.bOnFdFlag=1 THEN b.sLOndutyFd ELSE b.sOnduty END) OndutyL,
	                            (CASE WHEN b.bRSFdFlag=1 THEN b.sFRestStartFd ELSE b.sRestStart END) RestStartF,
	                            (CASE WHEN b.bRSFdFlag=1 THEN b.sLRestStartFd ELSE b.sRestStart END) RestStartL,
	                            (CASE WHEN b.bREFdFlag=1 THEN b.sFRestEndFd ELSE b.sRestEnd END) RestEndF,
	                            (CASE WHEN b.bREFdFlag=1 THEN b.sLRestEndFd ELSE b.sRestEnd END) RestEndL,
	                            (CASE WHEN b.bOffFdFlag=1 THEN b.sFOffdutyFd ELSE b.sOffduty END) OffdutyF,
	                            (CASE WHEN b.bOffFdFlag=1 THEN b.sLOffdutyFd ELSE b.sOffduty END) OffdutyL,
                                dDate,
                                lJobhour lWorkTime
                             FROM dbo.K1_wTurnResult a,dbo.K1_wBCms b
                            WHERE a.sTurnNo = b.sTurnNo
                            AND a.dDate between '" + sdate + "' and '" + edate + "' and sPersoncode='" + userID + "' ";

            IDataReader dr = null;
            try
            {
                dr = SqlHelper.ExecuteReader(BaseHelper.ErpDataBaseAccess, CommandType.Text, strSql);
                List<EnLbms> list = DynamicBuilder<EnLbms>.ConvertToList(dr);
                return list;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dr != null)
                {
                    dr.Dispose();
                }
            }
        }
        #endregion

    }
}
