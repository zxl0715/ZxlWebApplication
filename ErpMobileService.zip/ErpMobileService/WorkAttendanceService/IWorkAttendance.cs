﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.Text;
using System.ServiceModel.Web;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;


namespace Nd.Erp.Mobile.Service.WorkAttendance
{
    [ServiceContract]
    public interface IWorkAttendanceJson
    {
        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetKqLbms?userID={userID}&sdate={sdate}&edate={edate}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnLbms> GetKqLbms(string userID, string sdate, string edate);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetTxTime?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        float GetTxTime(string userID);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetQjInfoMobile?userID={userID}&sdate={sdate}&edate={edate}&skcode={skcode}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnQjInfoMobile> GetQjInfoMobile(string userID, string sdate, string edate, string skcode);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetSksj?userID={userID}&date={date}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<string> GetSksj(string userID, string date);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetMenjinList?userID={userID}&date={date}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnMenjin> GetMenjinList(string userID, string date);



        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "AddQjInfo?dsdate={dsdate}&dedate={dedate}&ltime={ltime}&lWorkTime={lWorkTime}&sDepCode={sDepCode}&sInMemo={sInMemo}&sInPeoCode={sInPeoCode}&sKCode={sKCode}&sPersoncode={sPersoncode}&sStrName={sStrName}&sTel={sTel}", BodyStyle = WebMessageBodyStyle.Bare)]
        int AddQjInfo(string dsdate, string dedate, string ltime, string lWorkTime, string sDepCode, string sInMemo, string sInPeoCode, string sKCode, string sPersoncode, string sStrName, string sTel);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "UpdateQjInfo?dsdate={dsdate}&dedate={dedate}&ltime={ltime}&lWorkTime={lWorkTime}&sDepCode={sDepCode}&sInMemo={sInMemo}&sInPeoCode={sInPeoCode}&sKCode={sKCode}&sPersoncode={sPersoncode}&sStrName={sStrName}&sTel={sTel}", BodyStyle = WebMessageBodyStyle.Bare)]
        int UpdateQjInfo(string dsdate, string dedate, string ltime, string lWorkTime, string sDepCode, string sInMemo, string sInPeoCode, string sKCode, string sPersoncode, string sStrName, string sTel);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "BlankOutQjInfo?dsdate={dsdate}&dedate={dedate}&ltime={ltime}&lWorkTime={lWorkTime}&sDepCode={sDepCode}&sInMemo={sInMemo}&sInPeoCode={sInPeoCode}&sKCode={sKCode}&sPersoncode={sPersoncode}&sStrName={sStrName}&sTel={sTel}", BodyStyle = WebMessageBodyStyle.Bare)]
        int BlankOutQjInfo(string dsdate, string dedate, string ltime, string lWorkTime, string sDepCode, string sInMemo, string sInPeoCode, string sKCode, string sPersoncode, string sStrName, string sTel);


        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "IsOverTime?userID={userID}&date={date}", BodyStyle = WebMessageBodyStyle.Bare)]
        bool IsOverTime(string userID, string date);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetUserMobile?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        string GetUserMobile(string userID);

        [GZip]
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "GetTxTimeAndTelAndKqLbms?userID={userID}&sdate={sdate}&edate={edate}", BodyStyle = WebMessageBodyStyle.Bare)]
        EnComplexKQ GetTxTimeAndTelAndKqLbms(string userID,string sdate, string edate);

    }

}
