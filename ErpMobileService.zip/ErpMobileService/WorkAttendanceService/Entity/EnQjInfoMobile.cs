﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Entity
{
    [DataContract]
    public class EnQjInfoMobile
    {
        private int m_AutoCode;
        private string m_sPersoncode;
        private string m_sDepCode;
        private DateTime m_dDate;
        private DateTime m_dSDate;
        private DateTime m_dEDate;
        private float m_lTime;
        private float m_lWorkTime;
        private string m_sKCode;
        private string m_sStrName;
        private string m_sInMemo;
        private string m_sInPeoCode;
        private int m_lState;
        private int m_lflag;
        private string m_sTel;
        private int m_lCode;

        #region 是否已同步
        [DataMember]
        public int lflag
        {
            get { return m_lflag; }
            set { m_lflag = value; }
        }
        #endregion

        #region 自动编号
        [DataMember]
        public int lCode
        {
            get { return m_lCode; }
            set { m_lCode = value; }
        }
        #endregion

        #region 自动编号
        [DataMember]
        public int AutoCode
        {
            get { return m_AutoCode; }
            set { m_AutoCode = value; }
        }
        #endregion
        
        #region 申请人
        [DataMember]
        public string sPersoncode
        {
            get { return m_sPersoncode; }
            set { m_sPersoncode = value; }
        }
        #endregion

        #region 申请人所在部门
        [DataMember]
        public string sDepCode
        {
            get { return m_sDepCode; }
            set { m_sDepCode = value; }
        }
        #endregion

        #region 填单时间
        [DataMember]
        public DateTime dDate
        {
            get { return m_dDate; }
            set { m_dDate = value; }
        }
        #endregion

        
        #region 开始时间
        [DataMember]
        public DateTime dSDate
        {
            get { return m_dSDate; }
            set { m_dSDate = value; }
        }
        #endregion

        #region 结束时间
        [DataMember]
        public DateTime dEDate
        {
            get { return m_dEDate; }
            set { m_dEDate = value; }
        }
        #endregion


        #region 时数
        [DataMember]
        public float lTime
        {
            get { return m_lTime; }
            set { m_lTime = value; }
        }
        #endregion
        
        #region 工作时数
        [DataMember]
        public float lWorkTime
        {
            get { return m_lWorkTime; }
            set { m_lWorkTime = value; }
        }
        #endregion


        #region 单据类型
        [DataMember]
        public string sKCode
        {
            get { return m_sKCode; }
            set { m_sKCode = value; }
        }
        #endregion
        
        #region 备注信息
        [DataMember]
        public string sStrName
        {
            get { return m_sStrName; }
            set { m_sStrName = value; }
        }
        #endregion
        
        #region 交接内容
        [DataMember]
        public string sInMemo
        {
            get { return m_sInMemo; }
            set { m_sInMemo = value; }
        }
        #endregion

        #region 交接人工号
        [DataMember]
        public string sInPeoCode
        {
            get { return m_sInPeoCode; }
            set { m_sInPeoCode = value; }
  
        }
        #endregion

        #region 是否已经添加到请假表,0/1/2,未添加/已添加/已删除
        [DataMember]
        public int lState
        {
            get { return m_lState; }
            set { m_lState = value; }
  
        }
        #endregion

        #region 请假调休期间联系电话
        [DataMember]
        public string sTel
        {
            get { return m_sTel; }
            set { m_sTel = value; }
  
        }
        #endregion

    }
}
