﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Entity
{
    [DataContract]
    public class EnComplexKQ
    {
        public EnComplexKQ()
        {}

        [DataMember]
        public List<EnLbms> LbmsList { get; set; }

        [DataMember]
        public string UserMobile { get; set; }

        [DataMember]
        public float TxTime { get; set; }
  

    }
}
