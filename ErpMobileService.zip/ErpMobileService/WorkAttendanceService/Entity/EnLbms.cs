﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Entity
{
    [DataContract]
    public class EnLbms
    {
        private bool m_isFd;
        private bool m_isHoliday;



        private string m_ondutyF;
        private string m_ondutyL;

        private string m_restStartF;
        private string m_restStartL;

        private string m_restEndF;
        private string m_restEndL;

        private string m_offdutyF;
        private string m_offdutyL;
       
        private float m_lWorkTime;

        private DateTime m_dDate;

        public EnLbms()
        { }

        #region 是否浮动班次
        [DataMember]
        public bool IsFd
        {
            get { return m_isFd; }
            set { m_isFd = value; }
        }
        #endregion

        #region 班次日期
        [DataMember]
        public DateTime dDate
        {
            get { return m_dDate; }
            set { m_dDate = value; }
        }
        #endregion

        #region 是否节假日
        [DataMember]
        public bool IsHoliday
        {
            get { return m_isHoliday; }
            set { m_isHoliday = value; }
        }
        #endregion

        #region 工作时数
        [DataMember]
        public float lWorkTime
        {
            get { return m_lWorkTime; }
            set { m_lWorkTime = value; }
        }
        #endregion

        #region 上班开始时间/浮动开始时间上限
        [DataMember]
        public string OndutyF
        {
            get { return m_ondutyF; }
            set { m_ondutyF = value; }
        }
        #endregion

        #region 上班开始时间/浮动开始时间下限
        [DataMember]
        public string OndutyL
        {
            get { return m_ondutyL; }
            set { m_ondutyL = value; }
        }
        #endregion


        #region 休息开始时间/浮动开始时间上限
        [DataMember]
        public string RestStartF
        {
            get { return m_restStartF; }
            set { m_restStartF = value; }
        }
        #endregion
        #region 休息开始时间/浮动开始时间下限
        [DataMember]
        public string RestStartL
        {
            get { return m_restStartL; }
            set { m_restStartL = value; }
        }
        #endregion

        #region 休息结束时间/休息结束时间上限
        [DataMember]
        public string RestEndF
        {
            get { return m_restEndF; }
            set { m_restEndF = value; }
        }
        #endregion

        #region 休息结束时间/休息结束时间下限
        [DataMember]
        public string RestEndL
        {
            get { return m_restEndL; }
            set { m_restEndL = value; }
        }
        #endregion

        #region 下班时间/下班时间上限
        [DataMember]
        public string OffdutyF
        {
            get { return m_offdutyF; }
            set { m_offdutyF = value; }
        }
        #endregion

        #region 下班时间时间/下班时间下限
        [DataMember]
        public string OffdutyL
        {
            get { return m_offdutyL; }
            set { m_offdutyL = value; }
        }
        #endregion


    }
}
