﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Entity
{
    [DataContract]
    public class EnSksj
    {
        public EnSksj()
        { }
        private DateTime? m_dDate;

        #region 上班开始时间/浮动开始时间上限
        [DataMember]
        public DateTime? dDate
        {
            get { return m_dDate; }
            set { m_dDate = value; }
        }
        #endregion
    }
}
