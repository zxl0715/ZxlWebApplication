﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace Nd.Erp.Mobile.Service.WorkAttendance.Entity
{
    [DataContract]
    public class EnMenjin
    {
        private DateTime m_dEventTime;

        private string m_MenjinName;
        private string m_EventType;


        public EnMenjin()
        { }




      

        #region 门禁时间
        [DataMember]
        public DateTime dEventTime
        {
            get { return m_dEventTime; }
            set { m_dEventTime = value; }
        }
        #endregion

        #region 门禁名称
        [DataMember]
        public string MenjinName
        {
            get { return m_MenjinName; }
            set { m_MenjinName = value; }
        }
        #endregion

        #region 进出门方向
        [DataMember]
        public string EventType
        {
            get { return m_EventType; }
            set { m_EventType = value; }
        }
        #endregion

    }
}
