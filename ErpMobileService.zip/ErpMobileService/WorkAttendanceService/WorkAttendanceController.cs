﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.ServiceModel;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Web.Http;
using Nd.Erp.Mobile.Log;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;
using Nd.Erp.Mobile.Service.Common;
using Nd.Erp.Mobile.Service.WorkAttendance.Entity;
using Nd.Erp.Mobile.Service.WorkAttendance.Business;

namespace Nd.Erp.Mobile.Service.WorkAttendance
{
    public class WorkAttendance : WorkAttendanceController
    {
    }

    public class WorkAttendanceController :ApiController, IWorkAttendanceJson
    {
        private string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;
        private LogMgr<WorkAttendanceController> _logMgr = new LogMgr<WorkAttendanceController>("WorkAttendanceService");


        /// <summary>
        /// 获取人员班次
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public List<EnLbms> GetKqLbms(string userID, string sdate, string edate)
        {
            return BzLbms.GetKqLbms(userID, sdate, edate);

        }

        /// <summary>
        /// 获取可用调休时间
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public float GetTxTime(string userID)
        {
            return BzQjInfoMobile.GetTxTime(userID);
        }

        /// <summary>
        /// 获取请假单据
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <param name="p_skcode"></param>
        /// <returns></returns>
        public List<EnQjInfoMobile> GetQjInfoMobile(string userID, string sdate, string edate, string skcode)
        {
            return BzQjInfoMobile.GetQjInfoMobile(userID, sdate, edate, skcode);

            
        }

        /// <summary>
        /// 获取门禁信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public List<EnMenjin> GetMenjinList(string userID, string date)
        {
            return BzMenjin.GetMenjinList(userID, date);
        }

        /// <summary>
        /// 获取指纹信息
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="p_date"></param>
        /// <returns></returns>
        public List<string> GetSksj(string userID, string date)
        {
            return BzSksj.GetSksj(userID, date);
        }

        /// <summary>
        /// 更新单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        [HttpGet]
        public int UpdateQjInfo(string dsdate, string dedate, string ltime, string lWorkTime, string sDepCode, string sInMemo, string sInPeoCode, string sKCode, string sPersoncode, string sStrName, string sTel)
        {
            EnQjInfoMobile enQjinfoMobile = new EnQjInfoMobile();
            enQjinfoMobile.dDate = DateTime.Now;
            enQjinfoMobile.dSDate = DateTime.Parse(dsdate);
            enQjinfoMobile.dEDate = DateTime.Parse(dedate);
            enQjinfoMobile.lTime = float.Parse(ltime);
            enQjinfoMobile.lWorkTime = float.Parse(lWorkTime);
            enQjinfoMobile.sDepCode = sDepCode;
            enQjinfoMobile.sInMemo = sInMemo;
            enQjinfoMobile.sInPeoCode = sInPeoCode;
            enQjinfoMobile.sKCode = sKCode;
            enQjinfoMobile.sPersoncode = sPersoncode;
            enQjinfoMobile.sStrName = sStrName;
            enQjinfoMobile.sTel = sTel;

            return BzQjInfoMobile.UpdateQjInfo(enQjinfoMobile);
 
        }

        /// <summary>
        /// 作废单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        [HttpGet]
        public int BlankOutQjInfo(string dsdate, string dedate, string ltime, string lWorkTime, string sDepCode, string sInMemo, string sInPeoCode, string sKCode, string sPersoncode, string sStrName, string sTel)
        {
            EnQjInfoMobile enQjinfoMobile = new EnQjInfoMobile();
            enQjinfoMobile.dDate = DateTime.Now;
            enQjinfoMobile.dSDate = DateTime.Parse(dsdate);
            enQjinfoMobile.dEDate = DateTime.Parse(dedate);
            enQjinfoMobile.lTime = float.Parse(ltime);
            enQjinfoMobile.lWorkTime = float.Parse(lWorkTime);
            enQjinfoMobile.sDepCode = sDepCode;
            enQjinfoMobile.sInMemo = sInMemo;
            enQjinfoMobile.sInPeoCode = sInPeoCode;
            enQjinfoMobile.sKCode = sKCode;
            enQjinfoMobile.sPersoncode = sPersoncode;
            enQjinfoMobile.sStrName = sStrName;
            enQjinfoMobile.sTel = sTel;

            return BzQjInfoMobile.BlankOutQjInfo(enQjinfoMobile);

        }

        /// <summary>
        /// 保存单据
        /// </summary>
        /// <param name="enQjinfoMobile"></param>
        /// <returns></returns>
        [HttpGet]
        public int AddQjInfo(string dsdate, string dedate, string ltime, string lWorkTime, string sDepCode, string sInMemo, string sInPeoCode, string sKCode, string sPersoncode, string sStrName, string sTel)
        {
            EnQjInfoMobile enQjinfoMobile = new EnQjInfoMobile();
            enQjinfoMobile.dDate = DateTime.Now;
            enQjinfoMobile.dSDate = DateTime.Parse(dsdate);
            enQjinfoMobile.dEDate = DateTime.Parse(dedate);
            enQjinfoMobile.lTime = float.Parse(ltime);
            enQjinfoMobile.lWorkTime = float.Parse(lWorkTime);
            enQjinfoMobile.sDepCode = sDepCode;
            enQjinfoMobile.sInMemo = sInMemo;
            enQjinfoMobile.sInPeoCode = sInPeoCode;
            enQjinfoMobile.sKCode = sKCode;
            enQjinfoMobile.sPersoncode = sPersoncode;
            enQjinfoMobile.sStrName = sStrName;
            enQjinfoMobile.sTel = sTel;


            return BzQjInfoMobile.AddQjInfo(enQjinfoMobile);

        }

        /// <summary>
        /// 是否超过填单期限
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="date"></param>
        /// <returns></returns>
        [HttpGet]
        public bool IsOverTime(string userID, string date)
        {
            return BzQjInfoMobile.IsOverTime(userID, date);
        }

        /// <summary>
        /// 获取员工手机号码
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public string GetUserMobile(string userID)
        {
            return BzQjInfoMobile.GetUserMobile(userID);

        }


        /// <summary>
        /// 获取员工某段时间的考勤班次，可调休时间和手机号码
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public EnComplexKQ GetTxTimeAndTelAndKqLbms(string userID, string sdate, string edate)
        {
            EnComplexKQ complexKQ = new EnComplexKQ();

            complexKQ.UserMobile = BzQjInfoMobile.GetUserMobile(userID);
            complexKQ.TxTime = BzQjInfoMobile.GetTxTime(userID);
            complexKQ.LbmsList = BzLbms.GetKqLbms(userID, sdate, edate);

            return complexKQ;
            

        }


    }
}
