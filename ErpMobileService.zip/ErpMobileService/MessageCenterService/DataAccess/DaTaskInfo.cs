﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MessageCenterServer.Entity;
using System.Data.SqlClient;
using System.Data;
using Nd.Erp.Mobile.Base;
using ND.Lib.Data.SqlHelper;

namespace MessageCenterServer.DataAccess
{
    public class DaTaskInfo
    {
        private static string _sqlCnnStr = BaseHelper.ErpDataBaseAccess;


        public NewRemindCountResult getNewRemindCount(string userID, DateTime? lastRemind)
        {
            var newRemindCountResult = new NewRemindCountResult() { Count = 0, MaxDate = DateTime.Now };
            if (lastRemind == null)
                return newRemindCountResult;

            String sql = @" SELECT  ISNULL(COUNT(autocode), 0) AS counts, ISNULL(MAX(dDate), '1900-1-1') AS maxDate
FROM    ( SELECT    AutoCode, dDate, sMnuCode, sIPersonCode, lstate
          FROM      dbo.X5_TaskInfo
          UNION ALL
          SELECT    lcode AS AutoCode, dEndDate AS dDate, '18192N' AS sMnuCode, sPersoncode AS sIPersonCode, 0 AS lstate
          FROM      X5_ToDoTaskInfo a JOIN  X5_WPeopleOrderView b ON a.lTaskCode = b.code
          WHERE     b.sInPersoncode = @sPersoncode AND sMark = '90' AND sOuPersonCode <> sInPersoncode AND dEndDate>@dDate ) AS result
WHERE   result.sMnuCode IN ( '18192N', '18192M' ) AND result.sIPersonCode = @sPersoncode AND result.dDate > @dDate AND lState = 0 ";
            SqlParameter[] arPara = new SqlParameter[2]{
             new SqlParameter("@dDate", lastRemind),
             new SqlParameter("@sPersoncode", userID)
            };
            DataTable dt = null;
            try
            {
                dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sql, arPara).Tables[0];
                if (dt != null && dt.Rows.Count > 0)
                {

                    newRemindCountResult.Count = Convert.ToInt32(dt.Rows[0]["counts"].ToString());
                    newRemindCountResult.MaxDate = Convert.ToDateTime(dt.Rows[0]["maxDate"].ToString());
                }
            }
            catch (Exception) { }
            return newRemindCountResult;
        }

        public List<EnTaskInfo> getTaskInfoList(string userID, bool isToDay)
        {
            List<EnTaskInfo> list = new List<EnTaskInfo>();
            String sqlStr = string.Format(@" 
                 SELECT *
     FROM   ( SELECT    AutoCode, bView, a.code, lState, lTaskCode, a.sFettle, sIDepCode, sIPersonCode, sLinkAdd, sMemo, sMnuCode, sODepCode, sOPersonCode,
                        sTitle, a.sXMFCode, lType, a.dDate, b.DDemDate, DReDate
              FROM      X5_WPeopleOrderView b
                        LEFT JOIN X5_TaskInfo a ON a.code = b.code AND a.lState = 0
              WHERE     a.sMnuCode IN ( '18192N', '18192M', '181927', '181928' ) AND a.sIPersonCode = '{0}'
              UNION ALL
              SELECT    AutoCode, 1 AS bView, b.code AS code, 1 AS lState, lTaskCode, sFettle, b.sInDepCode AS sIDepCode, b.sInPersoncode AS sIPersonCode,
                        NULL AS sLinkAdd, NULL AS sMemo, NULL AS sMnuCode, b.sOuDepCode AS sODepCode, b.sOuPersonCode AS sOPersonCode, sXmName, sXMFCode, lType,
                        b.dEndDate AS dDate, DDemDate, NULL AS DReDate
              FROM      X5_ToDoTaskInfo a
                        JOIN X5_WPeopleOrderView b ON a.lTaskCode = b.code
              WHERE     b.sInPersoncode = '{0}' AND sMark = '90' AND sOuPersonCode <> sInPersoncode ) AS d
     WHERE  1 = 1 
", userID);

            if (isToDay)
            {
                string startTime = DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + " 00:00:00";
                string endTime = DateTime.Now.Year + "-" + DateTime.Now.Month + "-" + DateTime.Now.Day + " 23:59:59";
                sqlStr += " and d.dDate between '" + startTime + "' and '" + endTime + "' ";
            }
            sqlStr += " order by d.dDate desc ";
            DataTable dt = null;
            try
            {
                dt = SqlHelper.ExecuteDataset(_sqlCnnStr, CommandType.Text, sqlStr, null).Tables[0];
                if (dt != null && dt.Rows.Count > 0)
                {
                    foreach (DataRow dr in dt.Rows)
                    {
                        EnTaskInfo task = new EnTaskInfo
                        {
                            AutoCode = dr["AutoCode"].ToString().Trim().Equals("") ? -1 : Convert.ToInt32(dr["AutoCode"].ToString().Trim()),
                            BView = dr["BView"].ToString().Trim().Equals("") ? -1 : Convert.ToInt32(dr["BView"].ToString().Trim()),
                            Code = dr["Code"].ToString().Trim().Equals("") ? -1 : Convert.ToInt32(dr["Code"].ToString().Trim()),
                            LState = dr["LState"].ToString().Trim().Equals("") ? -1 : Convert.ToInt32(dr["LState"].ToString().Trim()),
                            LTaskCode = dr["LTaskCode"].ToString().Trim().Equals("") ? -1 : Convert.ToInt32(dr["LTaskCode"].ToString().Trim()),
                            SFettle = dr["SFettle"].ToString().Trim(),
                            SIDepCode = dr["SIDepCode"].ToString().Trim(),
                            SIPersonCode = dr["SIPersonCode"].ToString().Trim(),
                            SLinkAdd = dr["SLinkAdd"].ToString().Trim(),
                            SMemo = dr["SMemo"].ToString().Trim(),
                            SMnuCode = dr["SMnuCode"].ToString().Trim(),
                            SODepCode = dr["SODepCode"].ToString().Trim(),
                            SOPersonCode = dr["SOPersonCode"].ToString().Trim(),
                            STitle = dr["STitle"].ToString().Trim(),
                            SXMFCode = dr["SXMFCode"].ToString().Trim(),
                            LType = dr["lType"].ToString().Trim()
                        };
                        if (!dr["DDate"].ToString().Trim().Equals(""))
                        {
                            task.DDate = Convert.ToDateTime(dr["DDate"].ToString().Trim());
                        }
                        if (!dr["DDemDate"].ToString().Trim().Equals(""))
                        {
                            task.DDemDate = Convert.ToDateTime(dr["DDemDate"].ToString().Trim());
                        }
                        if (!dr["DReDate"].ToString().Trim().Equals(""))
                        {
                            task.DReDate = Convert.ToDateTime(dr["DReDate"].ToString().Trim());
                        }

                        list.Add(task);
                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (dt != null)
                {
                    dt.Dispose();
                }
            }
            return list;
        }
    }
}
