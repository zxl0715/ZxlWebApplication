﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Http;
using MessageCenterServer.Entity;
using MessageCenterServer.Business;

namespace Nd.Erp.Mobile.Service.MessageCenter
{
    public class MessageCenterController :ApiController, IMessageCenterJson
    {
        public NewRemindCountResult getNewRemindCount(string userID, string lastRemind)
        {
         
            DateTime? finish = null;
            try
            {
                finish = DateTime.ParseExact(lastRemind.Trim(), "yyyy-MM-dd HH:mm:ss", System.Globalization.CultureInfo.CurrentCulture);
            }
            catch (Exception)
            { return new NewRemindCountResult(){ Count = 0,MaxDate = Convert.ToDateTime("1900-1-1")}; }
            return BzTaskInfo.getNewRemindCount(userID, finish);
        }

        /// <summary>
        /// 获得今天的任务列表
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<EnTaskInfo> getTodayTaskInfoList(string userID)
        {
            List<EnTaskInfo> list = new List<EnTaskInfo>();
            list = BzTaskInfo.getTodayTaskInfoList(userID);
            return list;
        }

        /// <summary>
        /// 获得所有的任务列表
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public List<EnTaskInfo> getAllTaskInfoList(string userID)
        {
            List<EnTaskInfo> list = new List<EnTaskInfo>();
            list = BzTaskInfo.getAllTaskInfoList(userID);
            return list;
        }
    }
}
