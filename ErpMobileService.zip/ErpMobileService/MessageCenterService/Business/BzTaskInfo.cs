﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using MessageCenterServer.DataAccess;
using MessageCenterServer.Entity;

namespace MessageCenterServer.Business
{
    public class BzTaskInfo
    {
        private static readonly DaTaskInfo dal = new DaTaskInfo();

        /// <summary>
        /// 获得新任务提醒数量
        /// </summary>
        /// <param name="userID"></param>
        /// <param name="lastRemind"></param>
        /// <returns></returns>
        public static NewRemindCountResult getNewRemindCount(string userID, DateTime? lastRemind)
        {
            return dal.getNewRemindCount(userID, lastRemind);
        }

        /// <summary>
        /// 获得今天的任务提醒列表
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static List<EnTaskInfo> getTodayTaskInfoList(string userID)
        {
            return dal.getTaskInfoList(userID, true);
        }

        /// <summary>
        /// 获得所有的任务提醒列表
        /// </summary>
        /// <param name="userID"></param>
        /// <returns></returns>
        public static List<EnTaskInfo> getAllTaskInfoList(string userID)
        {
            return dal.getTaskInfoList(userID, false);
        }
    }
}
