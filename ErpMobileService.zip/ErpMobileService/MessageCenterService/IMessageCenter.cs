﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.ServiceModel;
using System.ServiceModel.Web;
using MessageCenterServer.Entity;

namespace Nd.Erp.Mobile.Service.MessageCenter
{
    [ServiceContract]
    interface IMessageCenterJson
    {
        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getTodayTaskInfoList?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnTaskInfo> getTodayTaskInfoList(string userID);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getAllTaskInfoList?userID={userID}", BodyStyle = WebMessageBodyStyle.Bare)]
        List<EnTaskInfo> getAllTaskInfoList(string userID);

        [OperationContract]
        [WebInvoke(Method = "GET", RequestFormat = WebMessageFormat.Json, ResponseFormat = WebMessageFormat.Json, UriTemplate = "getNewRemindCount?userID={userID}&lastRemind={lastRemind}", BodyStyle = WebMessageBodyStyle.Bare)]
        NewRemindCountResult getNewRemindCount(string userID, string lastRemind);
    }
}
