﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MessageCenterServer.Entity
{
    [DataContract]
    public class NewRemindCountResult
    {
        [DataMember]
        public int Count { get; set; }

        [DataMember]
        public DateTime MaxDate { get; set; }
    }
}
