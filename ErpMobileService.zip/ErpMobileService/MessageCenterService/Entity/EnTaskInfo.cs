﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;

namespace MessageCenterServer.Entity
{
    [DataContract]
    public class EnTaskInfo
    {
        private int m_AutoCode;
        private string m_sMnuCode;
        private int m_code;
        private string m_sODepCode;
        private string m_sIDepCode;
        private string m_sOPersonCode;
        private string m_sIPersonCode;
        private string m_sTitle;
        private string m_sMemo;
        private string m_sLinkAdd;
        private DateTime? m_dDate;
        private int m_lState;
        private int m_bView;
        private string m_sFettle;
        private DateTime? m_dDemDate;
        private DateTime? m_dReDate;
        private string m_sXMFCode;
        private int m_lTaskCode;
        private string lType;

        [DataMember]
        public string LType
        {
            get { return lType; }
            set { lType = value; }
        }

        [DataMember]
        public int AutoCode
        {
            get { return m_AutoCode; }
            set { m_AutoCode = value; }
        }

        [DataMember]
        public string SMnuCode
        {
            get { return m_sMnuCode; }
            set { m_sMnuCode = value; }
        }

        [DataMember]
        public int Code
        {
            get { return m_code; }
            set { m_code = value; }
        }

        [DataMember]
        public string SODepCode
        {
            get { return m_sODepCode; }
            set { m_sODepCode = value; }
        }

        [DataMember]
        public string SIDepCode
        {
            get { return m_sIDepCode; }
            set { m_sIDepCode = value; }
        }

        [DataMember]
        public string SOPersonCode
        {
            get { return m_sOPersonCode; }
            set { m_sOPersonCode = value; }
        }

        [DataMember]
        public string SIPersonCode
        {
            get { return m_sIPersonCode; }
            set { m_sIPersonCode = value; }
        }

        [DataMember]
        public string STitle
        {
            get { return m_sTitle; }
            set { m_sTitle = value; }
        }

        [DataMember]
        public string SMemo
        {
            get { return m_sMemo; }
            set { m_sMemo = value; }
        }

        [DataMember]
        public string SLinkAdd
        {
            get { return m_sLinkAdd; }
            set { m_sLinkAdd = value; }
        }

        [DataMember]
        public DateTime? DDate
        {
            get { return m_dDate; }
            set { m_dDate = value; }
        }

        [DataMember]
        public int LState
        {
            get { return m_lState; }
            set { m_lState = value; }
        }

        [DataMember]
        public int BView
        {
            get { return m_bView; }
            set { m_bView = value; }
        }

        [DataMember]
        public string SFettle
        {
            get { return m_sFettle; }
            set { m_sFettle = value; }
        }

        [DataMember]
        public DateTime? DDemDate
        {
            get { return m_dDemDate; }
            set { m_dDemDate = value; }
        }

        [DataMember]
        public DateTime? DReDate
        {
            get { return m_dReDate; }
            set { m_dReDate = value; }
        }

        [DataMember]
        public string SXMFCode
        {
            get { return m_sXMFCode; }
            set { m_sXMFCode = value; }
        }

        [DataMember]
        public int LTaskCode
        {
            get { return m_lTaskCode; }
            set { m_lTaskCode = value; }
        }
    }
}
