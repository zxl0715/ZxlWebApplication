﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;
using System.IO;
using System.Net;
using System.Web;
using System.Diagnostics;

namespace WebMockUtility
{
    /// <summary>
    /// web访问类
    /// </summary>
    public class MyWebClient
    {
        public string Url;

        public bool AllowAutoRedirect = true;

        public CookieCollection cookie;

        public Encoding WebEncoding = Encoding.UTF8;

        public CookieContainer cookieContainer;

        public string ContentType = "application/x-www-form-urlencoded";

        public string Method = "POST";

        public string DownloadHtml(string URL, bool CreateCookie)
        {
            try
            {
                HttpWebRequest request = HttpWebRequest.Create(URL) as HttpWebRequest;
                if (cookie != null)
                {
                    request.CookieContainer = new CookieContainer();
                    request.CookieContainer.Add(cookie);
                }
            //    request.AllowAutoRedirect = false;
                //request.MaximumAutomaticRedirections = 3;
                request.Timeout = 20000;

                HttpWebResponse res = (HttpWebResponse)request.GetResponse();
                string r = "";

                System.IO.StreamReader S1 = new System.IO.StreamReader(res.GetResponseStream(), System.Text.Encoding.Default);
                try
                {
                    r = S1.ReadToEnd();
                    if (CreateCookie)
                        cookie = res.Cookies;
                }
                catch (Exception er)
                {
                    //Log l = new Log();
                    //l.writelog("下载Web错误", er.ToString());
                }
                finally
                {
                    res.Close();
                    S1.Close();
                }

                return r;
            }

            catch
            {

            }

            return string.Empty;
        }
        /// <summary>
        /// Post
        /// </summary>
        /// <param name="requestUrl"></param>
        /// <param name="data"></param>
        /// <returns></returns>
        public string Post(string requestUrl, string data, bool createCookie)
        {
            StreamReader reader = null;
            HttpWebResponse response = null;
            HttpWebRequest request = null;

            try
            {
                string StrUrl = requestUrl;
                request = HttpWebRequest.Create(StrUrl) as HttpWebRequest;
                request.Headers.Clear();
                request.AllowAutoRedirect = true;
                request.Timeout = 1000 * 60 * 20;
                string postdata = data;//data.GetData();
                request.Referer = requestUrl;
                // request.AllowAutoRedirect = true;
                request.UserAgent = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.2; SV1; Maxthon; .NET CLR 1.1.4322; .NET CLR 2.0.50727)";
                request.Timeout = 20000;

                if (cookie != null)
                {
                    cookieContainer = cookieContainer ?? new CookieContainer();
                    request.CookieContainer = cookieContainer;//new CookieContainer();
                    request.CookieContainer.Add(cookie);
                }

                Uri u = new Uri(StrUrl);

                if (postdata.Length > 0) //包含要提交的数据　就使用Post方式
                {
                    request.ContentType = ContentType;// "application/x-www-form-urlencoded"; //作为表单请求
                    request.Method = Method;//"POST";        //方式就是Post

                    //把提交的数据换成字节数组
                    Byte[] B = WebEncoding.GetBytes(postdata);
                    request.ContentLength = B.Length;

                    using (System.IO.Stream SW = request.GetRequestStream())
                    { //开始提交数据
                        SW.Write(B, 0, B.Length);
                    }

                }
                try
                {

                    response = request.GetResponse() as HttpWebResponse;
                }
                catch (WebException ex)
                {

                    string exMessage = ex.Message;

                    if (ex.Response != null)
                    {
                        using (var responseReader = new StreamReader(ex.Response.GetResponseStream()))
                        {
                            exMessage = responseReader.ReadToEnd();
                        }
                    }
                }



                if (createCookie)
                    cookie = response.Cookies;
                //  string domain =  GetTopLevelDomain();
                //domain=domain.Substring(domain.LastIndexOf('.', domain.LastIndexOf('.')) + 1);
                // AddCookieWithCookieHead(ref cookie, response.Headers["Set-Cookie"],request.RequestUri.Host);
                reader = new StreamReader(response.GetResponseStream(), WebEncoding);

                return reader.ReadToEnd();
            }
            catch (Exception ex) {
                Debug.WriteLine(ex.StackTrace);
                return null;
            }
            finally
            {
                if (response != null)
                    response.Close();
            }
        }

        private static string GetTopLevelDomain(string host) {
            string[] s = host.Split('.');
            if (s.Length < 2)
                return host;
            else
            {
                return s[s.Length - 2] + "." + s[s.Length - 1];
            }
        }

        #region 从包含多个 Cookie 的字符串读取到 CookieCollection 集合中
        private static void AddCookieWithCookieHead(ref CookieCollection cookieCol, string cookieHead, string defaultDomain)
        {
            if (cookieCol == null) cookieCol = new CookieCollection();
            if (cookieHead == null) return;
            string[] ary = cookieHead.Split(';');
            for (int i = 0; i < ary.Length; i++)
            {
                Cookie ck = GetCookieFromString(ary[i].Trim(), defaultDomain);
                if (ck != null)
                {
                    cookieCol.Add(ck);
                }
            }
        }

        #region 读取某一个 Cookie 字符串到 Cookie 变量中
        private static Cookie GetCookieFromString(string cookieString, string defaultDomain)
        {
            string[] ary = cookieString.Split(',');
            Hashtable hs = new Hashtable();
            for (int i = 0; i < ary.Length; i++)
            {
                string s = ary[i].Trim();
                int index = s.IndexOf("=");
                if (index > 0)
                {
                    hs.Add(s.Substring(0, index), s.Substring(index + 1));
                }
            }
            Cookie ck = new Cookie();
            foreach (object Key in hs.Keys)
            {
                if (Key.ToString() == "path") ck.Path = hs[Key].ToString();

                else if (Key.ToString() == "expires")
                {
                    //ck.Expires=DateTime.Parse(hs[Key].ToString();
                }
                else if (Key.ToString() == "domain") ck.Domain = hs[Key].ToString();
                else
                {
                    ck.Name = Key.ToString();
                    ck.Value = hs[Key].ToString();
                }
            }
            if (ck.Name == "") return null;
            if (ck.Domain == "") ck.Domain = defaultDomain;
            return ck;
        }
        #endregion
        #endregion
    }

    /// <summary>
    /// 请求数据
    /// </summary>
    public class RequestData
    {
        Hashtable hash = new Hashtable();

        public RequestData()
        {

        }

        //public string GetData()
        //{
        //    string r = "";

        //    foreach (string key in hash.Keys)
        //    {
        //        if (r.Length > 0) r += "&";
        //        r += key + "=" + HttpUtility.UrlEncode(hash[key].ToString());
        //    }

        //    return r;
        //}

        public RequestData Add(string key, string value)
        {
            hash[key] = value;
            return this;
        }


    }
}
