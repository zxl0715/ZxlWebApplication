﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using System.Collections.Generic;
using Nd.Erp.Mobile.Service.Common;
using System.Diagnostics;
using System.Linq;
using Nd.Erp.Mobile.Service.Common.Entity;
using Nd.Erp.Mobile.Service.Common.Extensions;
using WebMockUtility;
namespace SysComService.Tests
{
    
    
    /// <summary>
    ///This is a test class for SyncHelperTest and is intended
    ///to contain all SyncHelperTest Unit Tests
    ///</summary>
    [TestClass()]
    public class SyncHelperTest
    {


        private TestContext testContextInstance;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes


        private static EnMobileSyncServerSlave slave;
        // 
        //You can use the following additional attributes as you write your tests:
        //
        //Use ClassInitialize to run code before running the first test in the class
        [ClassInitialize()]
        public static void MyClassInitialize(TestContext testContext)
        {
            slave= new EnMobileSyncServerSlave()
            {
                lTableNameCode = 3,
                sTableCode = "4"
            };
        }
        //
        //Use ClassCleanup to run code after all tests in a class have run
        //[ClassCleanup()]
        //public static void MyClassCleanup()
        //{
        //}
        //
        //Use TestInitialize to run code before running each test
        //[TestInitialize()]
        public void MyTestInitialize()
        {
        }
        //
        //Use TestCleanup to run code after each test has run
        //[TestCleanup()]
        //public void MyTestCleanup()
        //{
        //}
        //
        #endregion




        /// <summary>
        ///A test for ToStringJoin
        ///</summary>
        [TestMethod()]
        public void ToStringJoinTest()
        {
            List<EnSyncTableDetail> enSyncTableDetailList = SyncHelper.SyncTableDetailDic[0]; // TODO: Initialize to an appropriate value
            string separator = ","; // TODO: Initialize to an appropriate value
            bool hasGenIdentityColumn = false; // TODO: Initialize to an appropriate value
            string expected = "AffairCode,Title,Address,Memo,ParentCode,UserID,AgentUserID,IsRepeat,IsUsingCheck,IsAvailability,AddTime,oldSchemeCode,XMCode,XMFCode,MeetingPurpose,IsUsingMeetingDecision"; // TODO: Initialize to an appropriate value
            string actual;
            actual = SyncHelper.ToStringJoin(enSyncTableDetailList,hasGenIdentityColumn);
            Assert.AreEqual(expected, actual);
        }

        [TestMethod()]
        [DeploymentItem("SysComService.dll")]
        public void ToStringJoinEntityValueTest()
        {
            //ToStringJoinEntityValueTestHelper<EnumSyncTableName.>();
        }

        /// <summary>
        ///A test for ToInsertSqliteSql
        ///</summary>
        [TestMethod()]
        public void ToInsertSqliteSqlTest1()
        {

            slave.ToInsertSqliteSql().ToList()
                .ForEach(s=> Trace.WriteLine(s));
        }

        /// <summary>
        ///A test for ToUpdateSqliteSql
        ///</summary>
        [TestMethod()]
        public void ToUpdateSqliteSqlTest()
        {
            Debug.WriteLine(slave.ToUpdateSqliteSql());
        }

        /// <summary>
        ///A test for ToDeleteSqliteSql
        ///</summary>
        [TestMethod()]
        public void ToDeleteSqliteSqlTest()
        {
            Debug.WriteLine(slave.ToDeleteSqliteSql());
        }

        [TestMethod()]
        public void ToSqliteSqlTest() {

            ToInsertSqliteSqlTest1();
            ToUpdateSqliteSqlTest();
            ToDeleteSqliteSqlTest();
        }

        [TestMethod()]
        public void PostMethodTest() {
            MyWebClient client = new MyWebClient() { ContentType = "application/json" };
            string data = "[{\"EnMobileSyncClientSlaveList\":[{\"AutoCode\":2,\"dAddTime\":1322473684000,\"lSyncMainCode\":1,\"lSyncState\":0,\"lTableNameCode\":1,\"lType\":1,\"sTableCode\":\"2\"}]}]";
            //data = "osType=1&sPersonCode=123";
            string html = client.Post("http://192.168.1.121:8732/ServiceHost/AsyncTask/json/PostSyncInfo", data, false);
            Debug.WriteLine(html);
        }
    }
}
