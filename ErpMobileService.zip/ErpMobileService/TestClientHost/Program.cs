﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Nd.Erp.Mobile.Service;

namespace TestClientHost
{
    class Program
    {
        static void Main(string[] args)
        {
            new Host().Start();
            Console.WriteLine("服务已启动...");
            Console.ReadLine();
        }
    }
}
